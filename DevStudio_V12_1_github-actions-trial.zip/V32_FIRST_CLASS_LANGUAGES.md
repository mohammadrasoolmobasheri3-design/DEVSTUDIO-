# V32 First-Class Languages

DEVSTUDIO ULTRA PRO MAX+ exposes these ten first-class offline language/framework profiles throughout the Studio:

1. Kotlin / Kotlin Script
2. Java
3. Python 3
4. C
5. C++
6. Dart
7. Flutter
8. JavaScript
9. HTML
10. CSS

Each profile has product-level editor, project, diagnostics, run and build integration points.

Important: product support and runtime readiness are separate. Java/Kotlin/Python/C/C++/Dart/Flutter require their real Android-compatible runtime/compiler payloads before execution can be marked ready. JavaScript/HTML/CSS use the Android WebView path.
