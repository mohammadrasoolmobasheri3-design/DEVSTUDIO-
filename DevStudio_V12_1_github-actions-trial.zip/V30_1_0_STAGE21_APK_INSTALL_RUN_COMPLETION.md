# DEVSTUDIO V30.1.0 — Stage 21

## APK / Install / Run Integration
- Added real APK metadata verification through PackageManager.
- Added installed-state and launchability inspection.
- Added Verify APK action to Build + Release.
- Added Run App action that launches the installed APK only when its package is detected and launchable.
- Existing Build -> Verify -> Archive -> Install flow preserved.
- No fake APK success, no fake signing, no arbitrary package execution.
- Existing toolchain preserved: Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29 / minSdk 23.
