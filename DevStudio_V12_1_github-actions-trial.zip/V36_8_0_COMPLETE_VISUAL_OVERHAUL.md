# DEVSTUDIO V36.8.0 — COMPLETE VISUAL OVERHAUL

One-pass visual pass based directly on V36.7.1.

- Premium mobile-first DEVSTUDIO entry/splash styling
- Glass/neon card system for Welcome and Home
- Stronger typography hierarchy and touch targets
- Graphics Studio chrome, tool buttons, canvas frame and offline status redesign
- Existing IDs, navigation, engines and offline behavior preserved
- No network capability added
