# DevStudio Stage 1 — Android Core

Visible project creation is Android App only. Home and Project Studio expose only the core Android workspace surface: Projects, Files, Code Editor, UI Builder, Assets, Preview/Run, Build entry, Problems/Output, Inspector and Project Settings.

Future services remain in source for later phases but are not exposed as active product choices in the Stage 1 UI. No fake build/toolchain behavior was added.
