# DEVSTUDIO V30.1.0 — UI Builder + Preview Completion

This update preserves the legacy toolchain and adds an additive design/preview sync layer.

## Added
- Live Design Preview activity using an offline WebView.
- Preview action from UI Builder.
- Generated HTML now carries `data-ds-id` and `data-ds-type` metadata.
- Import action reads the generated DEVSTUDIO HTML metadata back into the visual canvas.
- Position and size are restored from generated HTML styles.
- Existing `devstudio/ui_layout.dsl` remains the persistent design source.

## Flow
Design Canvas -> Generate HTML -> Live Preview
Generated HTML -> Import -> Design Canvas

No external network dependency is introduced.
