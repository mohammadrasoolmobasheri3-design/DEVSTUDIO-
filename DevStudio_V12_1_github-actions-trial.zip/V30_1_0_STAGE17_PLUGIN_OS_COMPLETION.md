# V30.1.0 Stage 17 — Plugin / Extension System

Completed on the existing Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29 foundation.

## Included
- Offline Plugin OS manager UI.
- Built-in plugin enable/disable registry.
- Local extension discovery and lifecycle states.
- Import of validated local `.zip` extension packages.
- Safe ZIP extraction with canonical-path traversal protection.
- SHA-256 package integrity marker.
- Per-extension permission grant/revoke UI.
- Declarative allow-listed extension actions.
- Extension dependency/state validation through the existing ExtensionPlatformEngine.
- Remove extension with path safety.
- Refresh / Disable All controls.
- No network marketplace and no arbitrary external DEX/JAR loading.

## Package contract
Each imported ZIP must contain `devstudio.extension` with fields such as:
`id=sample`
`name=Sample Extension`
`version=1.0`
`description=Local extension`
`entryPoint=declarative`
`permissions=PROJECT_READ`
`dependencies=`
`action=open_preview`

External code execution remains intentionally disabled; only declared allow-listed actions are queued by PluginPackageRuntime.
