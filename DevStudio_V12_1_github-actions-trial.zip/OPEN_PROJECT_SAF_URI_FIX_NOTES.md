# Open Project SAF Tree URI Fix

Applied to the existing project `com.example.ultrapromax`.

## Fixed
- `ACTION_OPEN_DOCUMENT_TREE` results are validated as real Tree URIs.
- Persistable read/write URI permission is retained using the existing Android SAF flow.
- Root Tree URIs now use `DocumentsContract.getTreeDocumentId(...)`.
- Child document URIs continue to use `DocumentsContract.getDocumentId(...)`.
- Root display-name lookup is performed through a document URI built from the Tree URI.
- The existing import-to-local-workspace and direct Project Studio flow is preserved.

## Root cause
The previous implementation passed the `content://.../tree/...` URI directly to
`DocumentsContract.getDocumentId(...)`. A Tree URI is not a Document URI, so Android
can reject it as an unsupported URI. The corrected implementation distinguishes the
root Tree URI from child Document URIs.

## Verification
The source was inspected from the supplied ZIP. A local Gradle compile could not be
completed in this environment because the Gradle 6.1.1 distribution was not cached
and network access to services.gradle.org was unavailable. The AndroidIDE project
structure and existing Gradle/Kotlin versions were left unchanged.
