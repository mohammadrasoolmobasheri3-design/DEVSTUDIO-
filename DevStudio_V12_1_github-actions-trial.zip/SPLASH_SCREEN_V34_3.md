# V34.3 Splash Screen

- Launcher now opens `SplashActivity` first.
- Centered DEVSTUDIO ULTRA PRO MAX+ logo is shown.
- Offline startup progress animates from 0% to 100%.
- `GET STARTED` is hidden until the progress reaches 100%.
- The upper-right artwork uses the supplied reference image's corner containing the standing figure, neon mountains, and `Code Your Dreams` treatment.
- `GET STARTED` opens `MainActivity` and closes the splash screen.
- No network access or remote asset is used by the splash screen.
- Main Studio UI and existing feature activities remain unchanged.
