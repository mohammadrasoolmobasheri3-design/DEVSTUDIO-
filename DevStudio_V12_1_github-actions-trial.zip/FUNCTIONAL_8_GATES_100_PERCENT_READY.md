# DEVSTUDIO V36.9 — Functional 8 Gates Hardening

This package hardens the eight critical gates without changing the baseline toolchain or visual layer.

## Baseline
- Gradle 6.1.1
- Android Gradle Plugin 3.5.3
- Kotlin 1.3.72
- compileSdk 29
- minSdk 23
- targetSdk 29
- versionCode 302
- versionName 30.1.0
- applicationId com.example.ultrapromax

## Gate rules
1. Android Toolchain: exact Platform 29 + Build Tools 29.0.3 + java/javac + adb/aapt/apksigner must execute locally.
2. Offline Dependency: Gradle `dependencies --offline` must actually resolve from local caches/files; fileTree presence alone is not PASS.
3. Real Offline Build: `assembleDebug --offline` must exit 0 and produce an APK.
4. APK Validation: APK structure is checked and, when apksigner is available, cryptographic signing verification is executed.
5. Install + Run: local ADB must report a real device and install/launch must succeed.
6. SQLite: real CREATE/INSERT/SELECT/UPDATE operations execute against a local SQLite database.
7. Offline Enforcement: loopback/file destinations are allowed; external destinations are blocked.
8. E2E Evidence: PASS is issued only when all seven preceding gates PASS in the same audit run; an evidence file is then written with SHA-256.

## Certification rule
A successful build of DEVSTUDIO itself does not prove these eight gates. The device must execute `FUNCTIONAL QA -> RUN 8-GATE FUNCTIONAL AUDIT` against a generated Android project. If a required local toolchain component or ADB device is missing, the report remains MISSING/CONDITIONAL and no certification is issued.

No network fallback, fake runtime, fake compiler, fake APK, or fake READY state is introduced.
