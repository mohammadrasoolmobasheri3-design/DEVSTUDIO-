DEVSTUDIO MONITOR UPDATE V8

RUN
- Opens independent RUN MONITOR.
- Scans the selected project before testing.
- Non-Android targets use the existing real UniversalRunEngine.
- HTML/preview targets open the existing real WebView preview.
- Android targets do NOT silently call BUILD; the monitor reports that Android interactive preview requires the real build/runtime path.

BUILD
- Opens BUILD MONITOR.
- Scans project structure, source/config files and common XML files first.
- Then invokes the existing real BuildEngine on a background thread.
- Only reports BUILD SUCCESS when the real build returns a successful APK.

PRLY
- Opens PRLY MONITOR.
- Scans the complete project first.
- Then invokes the existing real AppBuilderEngine ZIP export.
- Only reports PRLY SUCCESS when the output ZIP was actually created.

CONCURRENCY
- Monitor actions are guarded so repeated taps do not start multiple operations in the same monitor.
- Heavy scan/build/export work is kept off the UI thread.

NOTE
- This package was source-checked locally. Full Gradle compilation was not possible in the container because Gradle 6.1.1 was not installed and network access is unavailable. AndroidIDE remains the authoritative build test environment.
