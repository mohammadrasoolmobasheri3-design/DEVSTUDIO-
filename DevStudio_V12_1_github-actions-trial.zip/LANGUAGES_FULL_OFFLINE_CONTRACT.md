# DEVSTUDIO ULTRA PRO MAX+ — Full Offline Language Platform

This release treats the requested languages as first-class Studio targets:

- Kotlin / Kotlin Script
- Java
- Python 3
- C / C++
- Dart / Flutter
- JavaScript
- HTML / CSS

Every target has a stable profile, extension detection, runtime location, readiness gate, execution/build route, console/error route, and offline-only policy.

## Runtime truth

JavaScript and HTML/CSS use Android-provided execution facilities (WebView) where applicable.
Kotlin/Java/Python/C/C++/Dart/Flutter require real Android-compatible runtime/toolchain binaries. The project contains the complete integration contract and refuses to report a missing binary as READY.

No fake compiler, fake runtime, fake APK, network download, or fabricated success is used.

## Pack roots

`<app-private>/runtimes/<language>/`

Required real binaries/libraries are defined by `RuntimePackContractEngine` and `runtime-packs/contracts/README.md`.

A runtime pack is considered complete only when its required executable/shared-library checks pass and an execution/build smoke test succeeds.
