# Editor Completion Build Fix

Fixed the Kotlin 1.3.72 illegal-escape error in EditorEngine.kt.
The block-comment regular expression now uses valid escaped backslashes
for a normal Kotlin string literal.

Toolchain remains unchanged:
Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29 / minSdk 23.
