# V30.1.0 — Stage 12: Design ↔ Code ↔ Preview

Completed additive integration for the existing Studio UI Builder:
- Design Builder writes the generated HTML through a shared bridge.
- Generated HTML can be opened directly in Editor with the new Code action.
- Offline Preview receives the project directory and watches generated/index.html.
- Changes saved to generated/index.html are reloaded into the Preview automatically.
- Existing ui_layout.dsl remains the source of the visual builder state.
- Existing Import action keeps HTML → Design synchronization.
- No toolchain changes: Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29.
