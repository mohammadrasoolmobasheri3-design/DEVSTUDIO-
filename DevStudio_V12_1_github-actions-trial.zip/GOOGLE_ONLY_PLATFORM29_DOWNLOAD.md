# Google-only Android SDK Platform 29 download

DevStudio remains offline for normal IDE, Build, Run, Sign, Verify, Install and project operations.

The only added network path is the explicit button in **Build + Release**:

`Download Android SDK Platform 29 from Google`

It downloads only:

`https://dl.google.com/android/repository/platform-29_r05.zip`

The installer:
- accepts only HTTPS + `dl.google.com`;
- does not follow redirects;
- validates the expected size (78,293,913 bytes);
- validates the published SHA-1 `9d8a7e0ffa5168dbca6c60355b9129c6c7572aff`;
- safely extracts the ZIP (ZIP-slip protection);
- requires `platforms/android-29/android.jar`;
- installs under `files/internal-toolchain/android-sdk/platforms/android-29`;
- deletes the downloaded archive after successful installation.

Gradle Build itself continues to use `--offline` and never invokes this downloader automatically.
