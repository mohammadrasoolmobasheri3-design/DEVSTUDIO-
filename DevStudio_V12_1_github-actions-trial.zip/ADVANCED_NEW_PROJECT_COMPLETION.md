# V30.1.0 — Advanced New Project Completion

This update completes the next New Project stage without replacing the existing architecture.

## Added
- Advanced New Project screen
- Template selection using the existing ProjectTemplate catalog
- Project name + Package/App ID validation
- Offline generation console
- Optional README.md
- Optional .gitignore
- Optional .devstudio-project metadata
- Optional .devstudio workspace folders
- Existing ProjectStore registration
- Android package/path customization for generated Java projects
- Existing Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 toolchain preserved

## Main navigation
New Project and Start Coding now open Advanced New Project.

## Verification
XML parsing and source brace sanity checks passed in the build workspace.
The container could not run Gradle because Gradle 6.1.1 is not cached and services.gradle.org is unavailable in this environment. AndroidIDE remains the authoritative build test environment.
