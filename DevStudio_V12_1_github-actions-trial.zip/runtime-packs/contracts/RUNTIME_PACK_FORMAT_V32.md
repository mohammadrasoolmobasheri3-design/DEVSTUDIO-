# DEVSTUDIO V32 Runtime Pack Format

Runtime packs are **offline, real Android/ARM payloads**. The Studio never treats a pack as ready from source metadata alone.

Every pack must contain `runtime-pack.properties` with:

- `id=<language id>`
- `platform=android`
- `abi=arm64-v8a` (or `armeabi-v7a`)
- `offline=true`
- `required.files=<comma-separated required files>`

The installer rejects path traversal, wrong platform, unsupported ABI, missing files, and non-offline packs.

Required language payloads:

- Java: `bin/java`, `bin/javac`
- Kotlin: `bin/kotlinc` plus a compatible Java runtime
- Python: embedded `libpython*.so`, Python standard library, and bridge `.so`
- C: `bin/clang`
- C++: `bin/clang++`
- Dart: `bin/dart`
- Flutter: `bin/flutter` and its Flutter/Dart engine payload

JavaScript/HTML/CSS use the Android WebView and therefore do not require an external compiler pack.
