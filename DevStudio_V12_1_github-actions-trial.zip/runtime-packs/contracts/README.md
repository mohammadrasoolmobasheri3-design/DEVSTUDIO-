# Real Runtime Pack Contract

Place imported, legitimate offline runtime packs under the app's `files/runtimes/<profile>/` directory.

Required examples:
- java: `bin/java`, `bin/javac`
- kotlin: `bin/kotlinc`
- python: `lib/libdevstudio_python_bridge.so` plus the embedded Python library tree
- c: `bin/clang`
- cpp: `bin/clang++`
- dart: `bin/dart`
- flutter: `bin/flutter`

The Studio never marks a profile READY merely because a directory exists.
