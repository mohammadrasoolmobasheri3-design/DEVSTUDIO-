# DEVSTUDIO ULTRA PRO MAX+ — Full Language Runtime Contracts

A language is considered zero-to-hundred complete only after a real Android/ARM-compatible runtime/compiler is installed and passes the verifier.

## Built-in
- JavaScript: Android WebView JavaScript engine
- HTML: Android WebView
- CSS: Android WebView

## Required real runtime packs
- Kotlin: `kotlin/bin/kotlinc`, `kotlin/bin/kotlin` and a compatible Java runtime
- Java: `java/bin/javac`, `java/bin/java`
- Python 3: embedded CPython `lib/libpython*.so`, standard library tree, and `lib/libdevstudio_python_bridge.so`
- C: `c/bin/clang`
- C++: `cpp/bin/clang++`
- Dart: `dart/bin/dart`
- Flutter: `flutter/bin/flutter`

The Studio must never report a missing binary as ready and must never substitute a host Linux executable for an Android runtime.
