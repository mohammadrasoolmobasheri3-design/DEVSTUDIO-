# V32 Zero-to-Hundred Runtime Contract

V32 treats these as first-class offline languages:
Kotlin, Kotlin Script, Java, Python 3, C, C++, Dart, Flutter, JavaScript, HTML, CSS.

JavaScript/HTML/CSS are built into the Studio through Android WebView.

The remaining languages require REAL Android/ARM-compatible runtime/compiler payloads.
The application rejects missing, non-executable, or incompatible packs. Linux host
executables are not substituted and no fake compiler/runtime is accepted.

Required pack roots:
- kotlin/bin/kotlinc and kotlin/bin/kotlin
- java/bin/javac and java/bin/java
- python/python/lib/libpython*.so and python/lib/libdevstudio_python_bridge.so plus Python stdlib
- c/bin/clang
- cpp/bin/clang++
- dart/bin/dart
- flutter/bin/flutter

A pack is not considered complete merely because its directory exists.
