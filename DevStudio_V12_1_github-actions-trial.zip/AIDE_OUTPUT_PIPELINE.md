# DevStudio Android APK Output Pipeline

This version integrates an AIDE-compatible **real Android output flow** without copying
AIDE's proprietary APK assets.

Evidence used to model the integration:
- AIDE contains real Android build resources/tools including `aapt`, `aidl`, `android.jar.jet`
  and `framework.aidl`.
- AIDE code strings reference Maven dependency handling and its local `/.aide/maven`
  repository/cache.
- DevStudio therefore keeps Gradle as the project build orchestrator and makes the
  Android SDK tools + local Maven repository explicit inputs.

## Actual DevStudio flow

Project
-> local Gradle 6.1.1
-> AGP 3.5.3 / Kotlin 1.3.72
-> Java/Kotlin compilation
-> Android resource/AIDL processing
-> D8/DEX
-> APK packaging
-> `zipalign -c 4`
-> `apksigner verify --verbose`
-> real APK output

Build execution is forced to `--offline` and prefers the bundled Gradle 6.1.1
over `gradlew`, preventing an offline wrapper distribution download.

Expected internal toolchain:
`filesDir/internal-toolchain/`
- `jdk/bin/java`, `jdk/bin/javac`
- `gradle/bin/gradle` (6.1.1)
- `android-sdk/platforms/android-29/android.jar`
- `android-sdk/build-tools/34.0.4/{aapt2,aidl,d8,zipalign,apksigner}`
- `m2/` (or another real local Maven repository/cache)

The build remains truth-based: missing components stop the build; no APK is synthesized.
