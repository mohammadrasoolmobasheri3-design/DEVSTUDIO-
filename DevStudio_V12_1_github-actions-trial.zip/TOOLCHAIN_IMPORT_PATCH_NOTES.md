# Toolchain import patch

This patch adds an Android Storage Access Framework folder picker to Build & Release.

- Choose **IMPORT LOCAL TOOLCHAIN FOLDER** and select the folder that contains the toolchain's top-level folders (for example `jdk/`, `android-sdk/`, `gradle/`, and `m2/`).
- The selected folder is copied into the app-private `files/internal-toolchain/` directory.
- Common tool binaries are marked executable after copying.
- Build & Release status now displays the full local resolver result instead of reporting only whether Platform 29 was found.

The import operation copies files only; it does not download missing toolchain components or create a Maven repository. The imported folder must actually contain the needed JDK, SDK Platform 29, Build Tools, Gradle, and offline Maven artifacts. This source patch has not been compiled or device-tested in this environment; build it in AndroidIDE before installing.
