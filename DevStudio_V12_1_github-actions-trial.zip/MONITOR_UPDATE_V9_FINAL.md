# Monitor V9 Finalization

PRLY now performs full scan + code/config analysis + real Gradle APK build + PackageManager metadata inspection + strict APK structural/cryptographic validation before exposing INSTALL APK and RUN APP.

APK validation now resolves `apksigner` through the DevStudio local Android toolchain when a Context is available, so the internal offline signer is not incorrectly hidden by the host process PATH.

RUN remains independent from BUILD: Android RUN does not silently invoke BUILD. BUILD/PRLY are the real Android compilation path; RUN can launch a real installed APK only after a valid runnable artifact exists.
