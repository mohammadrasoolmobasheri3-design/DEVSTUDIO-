# Toolchain resolver update

This source update adds additional local SDK/JDK/Gradle candidate paths (including `/opt/android_sdk` and the AndroidIDE JDK/Gradle paths), selects the actual discovered Build Tools directory for PATH rather than hardcoding 34.0.4, and improves Build Tools discovery when 30.0.2 or 29.0.3 is installed.

Important: Android app sandboxing may prevent DEVSTUDIO from reading AndroidIDE-private `/opt` paths, and Android 11+ storage permissions may prevent direct access to Downloads. This patch does not grant those permissions or copy a toolchain into the app-private directory. It also does not manufacture the missing offline Maven repository. If those resources are inaccessible or absent, the app will still need an explicit import/copy workflow or the required toolchain placed in its private `files/internal-toolchain` directory.

Build/test status: source changes are provided; an APK build was not run for this updated archive.
