# DevStudio Internal Offline Toolchain

This release uses one fixed local build profile. It does not download build dependencies during a build.

Expected layout under `filesDir/internal-toolchain/`:

```text
internal-toolchain/
  jdk/
    bin/java
    bin/javac
  gradle/
    bin/gradle
  android-sdk/
    platforms/android-29/android.jar
    build-tools/<compatible-version>/
      aapt2
      d8
      zipalign
      apksigner
      aidl
    platform-tools/adb
  m2/                 # local Maven repository/cache used by the offline build
```

The resolver also accepts a user-supplied `DEVSTUDIO_TOOLCHAIN_ROOT` and
`Downloads/DevStudioToolchain` when the Android storage model permits access.

**Important:** this source release does not claim the binary toolchain is bundled.
The Build button reports `LOCAL TOOLCHAIN MISSING` until the real files exist.
No fake binaries, fake APKs, or fake success state are used.


The APK output stage additionally verifies the real artifact with zipalign and apksigner.
