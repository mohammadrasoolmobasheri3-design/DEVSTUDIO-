# PRLY Final Pipeline Contract

PRLY is the final local Android output workflow. It must not report success from a scan, ZIP export, placeholder APK, or metadata-only result.

## Required sequence
1. Full project scan: files, folders, readable source/config files, manifest, Gradle configuration.
2. Full readable code/config inspection: Kotlin/Java/XML/Gradle/KTS/properties/JSON/YAML/JS/TS/HTML/CSS/shell and related project configuration.
3. Static blocking checks: unreadable files, malformed XML, invalid text/binary content, obvious Kotlin/Java brace imbalance.
4. Real local toolchain preflight: Android SDK Platform 29, JDK, Gradle/wrapper availability, and required Android Build Tools.
5. Real Gradle `assembleDebug --offline` build. Compilation is the authoritative code/build check; PRLY must never replace it with a fake success state.
6. Real APK existence and size check.
7. Strict APK validation: APK/ZIP structure, AndroidManifest.xml, DEX, resources, safe paths, and `apksigner verify` when the real local signer is available.
8. Archive the verified APK under the project PRLY output directory.
9. Present INSTALL APK in the same PRLY monitor. Android's package installer performs the user-confirmed installation; silent installation is not claimed.
10. After installation, RUN APP launches the installed package only after PackageManager confirms that the expected package is installed and launchable.

## Truth rules
- No fake APKs.
- No fake compiler/runtime.
- No fake signing.
- No network fallback during offline build.
- No PRLY success before real build and strict APK validation pass.
- No RUN success before a real runnable artifact/runtime exists.
- Installation is only reported as opened/complete according to actual Android installer/package state.
