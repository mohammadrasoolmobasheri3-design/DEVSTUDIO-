# DevStudio GitHub Actions build trial

This workflow builds the DevStudio Android app's **debug APK** on a GitHub-hosted Ubuntu runner. It does not run the app's internal Build & Release engine and does not yet let DevStudio submit arbitrary projects for remote building.

## Run it

1. Create a private GitHub repository (recommended for source privacy).
2. Upload/commit the contents of this project directory to the repository root, including `.github/workflows/android-debug.yml`.
3. Open the repository's **Actions** tab and select **DevStudio Android Debug APK**.
4. Choose **Run workflow** (or push to `main` / `master`).
5. Open the completed run and download the `DevStudio-debug-apk` artifact.

The workflow installs Android SDK Platform 29 and Build Tools 29.0.3, then uses Java 8 for this project's legacy Android Gradle Plugin 3.5.3 / Gradle 6.1.1 build.

This is a first cloud-build test. A successful run proves the source can build on the runner; connecting DevStudio's in-app Build button to remote jobs and returning APKs requires a separate feature and secure GitHub authentication. Do not put access tokens in source code or workflow files.
