# Stage 26.1 — Full Testing / QA Access

Stage 26.1 keeps the Stage 26 QA engine and adds direct Project Studio access
to FullTestingQaActivity.

The existing toolchain and prior architecture are preserved.
