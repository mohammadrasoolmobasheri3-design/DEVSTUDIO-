DEVSTUDIO V12.1 DEEP AUDIT — 2026-09-17

Source audited:
DevStudio_V12_1_FUTURISTIC_UI_CRASH_FIXED.zip

Verified source-level findings and repairs in this package:
1. Google Platform 29 downloader:
   - Removed Tsinghua/Aliyun fallback URLs.
   - Only https://dl.google.com is accepted.
   - Redirects are rejected.
   - SHA-1 and exact archive size checks remain.
   - ZIP-slip path validation remains.
   - android.jar is required before installation is reported successful.
2. Build verification:
   - BuildPipelineCoordinator no longer treats "APK exists and is non-empty" as verification.
   - Successful builds are passed through ApkValidationEngine, including local apksigner verification.
3. Kotlin 1.3.72 compatibility:
   - BuildEngine no longer relies on maxByOrNull.
   - Empty APK candidate lists return null instead of throwing.
4. Deterministic dependency:
   - JUnit 4.+ was pinned to 4.13.2.
5. Network boundary:
   - Manifest cleartext traffic is disabled globally.
   - Local loopback cleartext remains controlled by network_security_config.xml.
   - The only hard-coded external downloader host is dl.google.com.

IMPORTANT — NOT CERTIFIED:
This ZIP has NOT been executed on the user's Android device in this audit.
The following remain environment-dependent and must be tested on-device:
- JDK compatible with AGP 3.5.3 / Gradle 6.1.1
- complete Android SDK Platform 29
- ARM64-compatible Build Tools (aapt2, d8, zipalign, apksigner)
- offline Gradle 6.1.1 distribution/cache
- offline Maven artifacts for AGP/Kotlin/AndroidX dependencies
- real assembleDebug/assembleRelease
- real apksigner verification
- real install and launch

Therefore this package does NOT claim BUILD SUCCESS, READY, COMPLETE, or CERTIFIED.
