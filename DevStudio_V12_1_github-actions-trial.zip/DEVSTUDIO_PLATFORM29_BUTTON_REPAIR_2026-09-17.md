DevStudio Platform 29 button repair

The Google Platform 29 download path was audited and the UI integration was repaired
where the downloader was disabled/private. The package remains Google-only:
https://dl.google.com/android/repository/platform-29_r05.zip

This package does NOT claim that an on-device download or build has succeeded.
After installation, the button must be tested on the Android device.
