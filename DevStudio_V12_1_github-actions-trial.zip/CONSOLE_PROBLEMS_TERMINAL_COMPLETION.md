# V30.1.0 Console / Problems / Terminal Completion

Added a shared persistent output/diagnostics store and a Studio Output screen
with Console, Problems and Terminal views.

This is additive and keeps the existing engines/toolchain intact.
Toolchain: Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29 / minSdk 23.

The Terminal view is intentionally a safe bridge/status surface; it does not
claim arbitrary shell execution inside the app.
