V30.0.1 FINAL COMPLETION PASS

The final release adds the missing product-vision integration layer: real-time preview, local plugin package installation, missions/streaks, glass/depth visuals, offline network policy, Web App -> Android build orchestration, APK signing bridge, and a final capability center.

DEVSTUDIO ULTRA PRO MAX+ V30 — FINAL RELEASE
============================================
V30 is the final major-release integration milestone. It adds final readiness auditing, centralized offline mode, a shared Studio visual system, an offline local plugin catalog, conservative self-healing coordination, and a real HTML/CSS/JS -> Android WebView project generator. The generator creates a compilable Android project; it does not falsely claim an APK exists when no build/signing toolchain is available.

The established V26.2-V29 infrastructure and the fixed toolchain remain preserved.

DEVSTUDIO ULTRA PRO MAX+ V29
=============================
V29 adds the Integration + Optimization + Quality Gate layer before V30.

DEVSTUDIO V28 - Advanced Studio Systems
----------------------------------------
V28 adds persistent Studio tabs/layout, task coordination and navigation history on top of V27.

# DEVSTUDIO ULTRA PRO MAX+ V27

V27 is the Studio Experience milestone: it unifies the existing development
infrastructure into a coherent mobile-first Project Studio with Command Center,
Explorer, Code/Design/Preview/Files navigation, Problems, Output and Terminal
quick access.

V27 builds on V26.2-V26.9 and preserves the established toolchain and runtime
architecture.

DEVSTUDIO ULTRA PRO MAX+ — V26.9
Plugin / Extension Platform Core

V26.9 adds the offline Extension Platform layer on top of the existing Plugin System. It provides local extension discovery, manifest validation, dependency checks, persisted enable/disable state and deny-by-default permission metadata. It intentionally does not execute arbitrary external JAR/DEX code.

V26.8 adds the Virtual File System + Package / Dependency Core on top of the existing V26.7 build/run infrastructure.

V26.7 adds Build / Run / Runtime Core on top of the existing V26.6 diagnostics and analysis infrastructure.

# DEVSTUDIO ULTRA PRO MAX+ — V26.6

## V26.6 — Diagnostics & Analysis Core
- Offline diagnostic model and analysis service
- Buffer, file and project analysis
- Syntax diagnostics bridge to the existing CodeCheckEngine
- Language/symbol diagnostics and duplicate-symbol foundation
- Project analysis summaries and indexed-symbol statistics
- Builds directly on V26.4 Language & Symbol Core and V26.5 Code Intelligence
- Existing Workspace, Session, Recovery and Runtime infrastructure is preserved

# DEVSTUDIO ULTRA PRO MAX+ — V26.5

## V26.5 — Code Intelligence Core
- Completion, definition, reference, hover and code-action foundations
- Builds directly on the V26.4 Language & Symbol Core
- Existing Workspace, Session, Recovery and Runtime infrastructure is preserved


V26.4 Language & Symbol Core:
- Central Language Registry and language metadata
- Dependency-free symbol model, extraction and project symbol index
- Kotlin, Java, Python, JavaScript, TypeScript, C, C++, PHP and Dart providers
- Extension detection for common language files
- Incremental file/project indexing API and symbol search
- Editor-buffer analysis API for unsaved code
- Language capability metadata without duplicating the existing Runtime system
- V26.2 Recovery and V26.3 Workspace/Session architecture preserved

# DEVSTUDIO ULTRA PRO MAX+ — v26.3

V26.3 Studio Core & Workspace Foundation:
- Workspace Core for mounting, inspection, safe boundaries and statistics
- Studio Session Core for offline session persistence
- Extended Beta Health checks
- Original architecture and fixed toolchain preserved

DEVSTUDIO ULTRA PRO MAX+ — v17

Visual UI Builder milestone:
- Real Android drag/drop palette
- Tap-to-add fallback
- Movable canvas components
- Component hierarchy
- Property inspector
- Duplicate/delete/clear
- Project-local UI layout persistence
- HTML generation
- Project Studio -> UI Builder integration

Toolchain remains Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29.

# DEVSTUDIO ULTRA PRO MAX+ (v5)

پایه‌ی این نسخه، پروژه‌ی خودتون (DEVSTUDIO) هست که با موفقیت به APK تبدیل شد.
روش این‌ها اضافه/تکمیل شد:

## اضافه‌شده‌ی این نسخه
- **رفع باگ File Explorer**: Drawer پروژه الان به فایل‌های واقعی وصله (قبلاً دو آیتم ثابت نشون می‌داد)
- **WebSocket واقعی** در Mini Server (`ws://127.0.0.1:PORT/ws`) — RFC 6455 handshake + text frame، broadcast به همه‌ی کلاینت‌ها
- **Plugin Manager UI واقعی** (`PluginsActivity`) — فعال/غیرفعال کردن پلاگین‌ها با Switch، ذخیره‌ی محلی
- **اعمال Theme Engine** روی صفحات ساده (AI Assistant، Plugins) — عمداً روی MainActivity/EditorActivity اعمال نشد چون طراحی چندلایه‌ی دستی دارن و اعمال خودکار خرابش می‌کرد
- **Glassmorphism drawable** (`glass_card.xml`) روی لیست پروژه‌های اخیر
- **Drag & Drop واقعی** (`UiBuilderActivity`) — با API رسمی اندروید (`View.startDrag` + `OnDragListener`)، نه تپ. از دکمه‌ی +UI → "Visual Builder" در دسترسه

## هنوز صادقانه ناقصه
- **AI واقعی (on-device model)** — همچنان rule-based
- **APK Builder داخل خودِ اپ** — کامپایل واقعی HTML→APK نیاز به toolchain کامل اندروید داره؛ فعلاً فقط export به zip. (خودِ AndroidIDE این کارو برای *کد اپ* انجام می‌ده، نه برای پروژه‌های وب کاربر)
- **Plugin Marketplace دانلودی** — پلاگین‌ها فقط bundled و داخل کدن، نه قابل دانلود (نیاز به اینترنت داره)

## نسخه‌ها (بدون تغییر، چون از قبل کش شده)
Gradle 6.1.1 + AGP 3.5.3 + Kotlin 1.3.72 + compileSdk 29 + minSdk 23


## Universal Run Engine
The editor Run button now dispatches by file type. HTML/HTM/CSS use the existing local WebView preview path; Android/Gradle projects use the real Gradle build path; scripting/compiled languages are executed only when their real runtime/compiler is present on the device. Missing runtimes are reported explicitly instead of being simulated. Supported routes include JavaScript, TypeScript, Python, Java, Kotlin/Kotlin Script, C/C++, Go, Rust, Swift, Dart, PHP, Ruby, Perl, Lua, Shell/Bash and SQLite SQL.

## Universal Run v4

The editor now has a central language runtime registry. Supported language profiles
are registered in `engine/run/LanguageRuntimeRegistry.kt`, and `UniversalRunEngine`
first checks app-private runtime packs under `filesDir/runtimes/<language>/bin/`, then
falls back to an executable available on the device PATH. This keeps the existing
architecture intact and makes runtime packs pluggable.

Important: Android cannot execute desktop x86/x64 compiler binaries copied from a PC.
A runtime pack must contain a compatible Android/ARM binary and its dependent files.
The app therefore reports a clear "runtime/compiler not available" result instead of
pretending that compilation happened.

## DEVSTUDIO v20 — Assets + Templates + Virtual FS

v20 extends Project Studio with a real project-scoped Virtual File System and a dedicated Asset Manager. The existing offline project storage and template scaffold remain intact.

### v20 additions
- Virtual File System screen with safe project-relative paths
- New file / folder, rename, duplicate, delete, inspect
- Project-relative path protection against traversal outside the project root
- File counts and size statistics
- Dedicated Asset Manager under each project
- Import assets from Android document picker into `<project>/assets`
- Create asset folders, rename/delete/inspect assets
- Automatic duplicate-safe imported asset names
- Project Studio shortcuts for Virtual FS and Templates
- Template browser/info inside Project Studio

### Compatibility
- Gradle 6.1.1
- Android Gradle Plugin 3.5.3
- Kotlin 1.3.72
- compileSdk 29

Build note: the container cannot download Gradle 6.1.1 because network access is unavailable. Final compilation should be performed in AndroidIDE.


## V21
V21 adds plugin permissions, a project-scoped PluginSandbox, hardened local Mini Server routing, and a Local Server console. Toolchain remains unchanged. See V21_NOTES.txt.

## V22 — Offline AI Assistant
V22 introduces a lightweight, fully offline AI Assistant foundation. It can inspect project structure, list/search project files, check the current file with the existing local diagnostics engine, and offer a safe Auto Fix action. The editor also has an AI overlay button; the overlay sits above the workspace rather than resizing the code editor, preserving the coding area. No cloud API, online AI service, external model download, or heavy new dependency is required.

## V23 - Universal Runtime (Offline)
- Universal Runtime Manager
- Local runtime profiles and readiness detection
- Import runtime packs from local ZIP files only
- Sandboxed extraction with traversal protection
- Offline execution dispatch for supported local runtimes
- Existing Android/Gradle, WebView and local-server infrastructure preserved


## V23.4 — Python 3 Embedded Runtime
Python is now routed through an Android embedded-runtime contract. A Python pack is considered READY only when libpython, the standard library, and the DEVSTUDIO JNI bridge are all present. No desktop python executable is assumed and no network download is performed.

## v23.5.1 — Java Runtime Pack Import
- Java Runtime import accepts a ZIP with `runtime.id=java` or a recognizable Java root containing `bin/javac` and `bin/java`.
- Nested pack roots such as `java/bin/...` or `jdk/bin/...` are detected automatically.
- Imported Java binaries are marked executable inside DEVSTUDIO's private runtime sandbox.
- No fake Java interpreter/compiler is included. A real Android-compatible Java runtime pack is still required for execution.


V23.7: centralized language runtime readiness/diagnostics and Kotlin runtime pack validation.

## V30.1.0 Stage 18 — Advanced Template Engine
The Studio now includes an offline template catalog with search, categories, favorites, safe preview, and direct handoff into Advanced New Project. Existing ProjectTemplate scaffolds and the legacy toolchain remain unchanged.

## V30.1.0 Final Hardened Completion Pass
The current hardened branch adds deterministic completion QA, strict offline networking boundaries, transactional recovery verification, shared design/motion tokens, bounded offline AI project generation, and a Completion Center that exercises these workflows locally. No APK/runtime success is fabricated; real builds still require the local Android toolchain/runtime packs.

## ENDGAME Stage 12
Stage 12 is the final feature gate. Certification is evidence-based and never fabricates real build/runtime results. Post-ENDGAME changes are limited to bug, security and compatibility fixes.

## V36.9 Functional 8-Gate Hardening
The critical functional gates now use real local probes: offline Gradle dependency resolution, offline build, APK validation/signature verification, ADB install/launch, SQLite CRUD, strict offline policy, and same-run E2E evidence. No gate is promoted to PASS by UI or contract presence.
