# DevStudio online build mode patch

This patch changes Gradle invocation from `--offline` to online dependency resolution. It keeps the JDK, Android SDK Platform 29, and compatible Build Tools as local prerequisites. Missing Maven artifacts and the Gradle wrapper distribution may be downloaded by Gradle when network access is available.

Repository order is official Google and Maven Central, followed by Aliyun mirrors. A blocked/unreachable host can still cause a build failure; Gradle will try repositories according to normal repository resolution behavior. Downloaded dependencies are cached in the Gradle user home configured by BuildEngine.

This patch does not install/download a JDK or Android SDK automatically. The app still needs a usable local Java runtime, SDK platform, and Build Tools. It has not been compiled or tested on-device; run `gradle --offline assembleDebug` from AndroidIDE to validate source compilation before installing.
