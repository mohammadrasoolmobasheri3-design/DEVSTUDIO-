# V30.1.0 Stage 19 — Security / Sandbox Completion

Added an offline Security / Sandbox Center without changing the legacy toolchain.

## Included
- SecurityPolicyEngine with lockdown state and policy fingerprint.
- Canonical-path sandbox validation.
- Local/loopback-only URL policy helper.
- Controlled execution allow-list (preview/diagnostics/build/format/symbols).
- Static project security audit with bounded file/size scanning.
- Detection/reporting for process/dynamic-loading patterns and external URLs.
- Plugin permission audit boundary.
- SecurityCenterActivity with Scan, Lockdown/Unlock and Policy controls.
- Project Studio SECURITY button now opens the Security / Sandbox Center.

## Safety boundary
No shell/process execution, arbitrary DEX/JAR loading, or external network execution was added.
This stage is a policy/audit layer, not a claim of OS-level sandboxing.

## Toolchain preserved
Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29 / minSdk 23.
