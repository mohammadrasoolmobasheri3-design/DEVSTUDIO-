# V30.1.0 — Stage 11: Editor ↔ Project Intelligence

Implemented additive integration between EditorActivity and CodeIntelligenceService.

- Project index is built when an Editor workspace opens.
- Current editor buffers are indexed, including unsaved changes.
- Project Completion uses indexed symbols and the current buffer.
- Go to Definition resolves indexed symbols and opens the target file/line.
- Find References scans the current project for symbol references.
- Project Intelligence is available from View menu.
- Navigation menu exposes Go to Definition and Find References.
- Code menu exposes Project Completion.
- Existing toolchain and architecture are preserved.

Toolchain: Gradle 6.1.1 / AGP 3.5.3 / Kotlin 1.3.72 / compileSdk 29.

The local environment cannot execute Gradle 6.1.1 because services.gradle.org is unreachable; AndroidIDE remains the authoritative build environment.
