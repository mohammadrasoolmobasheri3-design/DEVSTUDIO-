DEVSTUDIO Runtime Packs

Place a native runtime pack under the app-private filesDir/runtimes/<language>/bin/
when a compatible Android/ARM64 toolchain is available.

Profiles registered by UniversalRunEngine:
HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, Kotlin Script,
C, C++, Go, Rust, Swift, Dart, PHP, Ruby, Perl, Lua, Shell, Bash, SQLite SQL,
Android/Gradle.

The app never claims a runtime is installed unless the executable is actually
found either in this runtime directory or on the device PATH.

JAVA PACK (v23.5.1)
-------------------
Import a real Android-compatible Java runtime ZIP from Runtime Manager.
Accepted layouts include:
  runtime.id containing: java
  bin/javac + bin/java at the ZIP root
  java/bin/javac + java/bin/java
  jdk/bin/javac + jdk/bin/java

DEVSTUDIO does not emulate Java or report fake success.
