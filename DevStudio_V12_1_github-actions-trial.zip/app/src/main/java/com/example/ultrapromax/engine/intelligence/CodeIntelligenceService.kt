package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.LanguageService
import com.example.ultrapromax.engine.language.symbol.Symbol
import java.io.File

/** V26.5 facade: navigation, completion, hover, references and code-action foundations. */
class CodeIntelligenceService {
    val languageService = LanguageService()
    private val definitionResolver = DefinitionResolver(languageService.index)
    private val completionEngine = CompletionEngine(languageService.index)
    private val referenceEngine = ReferenceEngine()
    private val hoverEngine = HoverEngine(languageService.index)
    private val actionEngine = CodeActionEngine()

    fun complete(fileName: String, source: String, cursorOffset: Int, limit: Int = 40): List<CompletionItem> =
        completionEngine.complete(fileName, source, cursorOffset, limit)

    fun definition(name: String, filePath: String? = null): Symbol? =
        definitionResolver.resolve(name, filePath)

    fun references(projectRoot: File, symbol: Symbol): List<ReferenceEngine.Reference> =
        referenceEngine.find(projectRoot, symbol)

    fun hover(name: String): String? = hoverEngine.info(name)

    fun hover(symbol: Symbol): String = hoverEngine.info(symbol)

    fun codeActions(fileName: String, source: String, line: Int): List<CodeActionEngine.CodeAction> =
        actionEngine.actionsFor(fileName, source, line)

    fun indexFile(file: File): Boolean = languageService.indexFile(file)

    fun indexProject(root: File): Int = languageService.indexProject(root)
}
