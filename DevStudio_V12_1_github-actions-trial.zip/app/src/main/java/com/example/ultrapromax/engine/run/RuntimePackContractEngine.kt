package com.example.ultrapromax.engine.run

import java.io.File

/** Strict offline runtime contract. No runtime is considered complete without real executables/libraries. */
class RuntimePackContractEngine(private val root: File) {
    data class Check(val id: String, val ready: Boolean, val required: List<String>, val missing: List<String>)

    fun check(profile: LanguageRuntimeRegistry.Profile): Check {
        val dir = File(root, profile.id)
        val required = when (profile.id) {
            "java" -> listOf("bin/java", "bin/javac")
            "kotlin" -> listOf("bin/kotlinc")
            "python" -> listOf("lib/libdevstudio_python_bridge.so")
            "c" -> listOf("bin/clang")
            "cpp" -> listOf("bin/clang++")
            "dart" -> listOf("bin/dart")
            "flutter" -> listOf("bin/flutter")
            "javascript", "html", "css" -> emptyList()
            else -> emptyList()
        }
        val missing = required.filter { !File(dir, it).isFile }
        return Check(profile.id, missing.isEmpty() && required.isNotEmpty(), required, missing)
    }

    fun report(registry: LanguageRuntimeRegistry): String {
        return registry.all().joinToString("\n") { p ->
            val c = check(p)
            "${p.id}: ${if (c.ready) "READY" else "MISSING " + c.missing.joinToString(",") }"
        }
    }
}
