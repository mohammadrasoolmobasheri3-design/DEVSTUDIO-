package com.example.ultrapromax.nextupdate.ai.model

data class AiTask(
    val id: String,
    val instruction: String,
    val projectId: String? = null
)

enum class AiTaskState { PLANNED, WAITING_APPROVAL, RUNNING, SUCCEEDED, FAILED, CANCELLED }
