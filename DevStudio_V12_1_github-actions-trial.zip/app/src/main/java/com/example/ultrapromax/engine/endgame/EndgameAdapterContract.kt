package com.example.ultrapromax.engine.endgame

/**
 * Extension contract for local Server/Database packs.
 * Implementations must be deterministic and local; no network download is implied.
 */
data class EndgameAdapterContract(
    val id: String,
    val name: String,
    val kind: Kind,
    val executableCandidates: List<String>,
    val driverFiles: List<String>,
    val capabilities: Set<Capability>
) {
    enum class Kind { SERVER, DATABASE }
    enum class Capability { RUN, BUILD, QUERY, SCHEMA, MIGRATION, API, WEBSOCKET }
}
