package com.example.ultrapromax.engine.languageplatform

import android.content.Context
import com.example.ultrapromax.engine.run.FullLanguagePlatformEngine
import com.example.ultrapromax.engine.run.ZeroToHundredLanguageEngine
import java.io.File

/**
 * V32 single execution gateway for the ten first-class offline languages.
 * A non-built-in language can execute only when its real Android-compatible
 * runtime/compiler pack passes the existing contract gate.
 */
class LanguageExecutionPlatformV32(private val context: Context) {

    data class Result(
        val language: String,
        val ready: Boolean,
        val message: String,
        val runtimeRoot: File
    )

    private val root = File(context.filesDir, "runtimes")
    private val gate = ZeroToHundredLanguageEngine(context)
    private val platform = FullLanguagePlatformEngine(context)

    fun check(language: String): Result {
        val id = language.toLowerCase()
        val status = platform.statuses().firstOrNull { it.id == id }
        if (status == null) return Result(id, false, "unsupported-language", root)
        if (status.ready) return Result(id, true, "ready:${status.mode}", root)
        val gateStatus = gate.inspect().firstOrNull { it.id == id }
        val missing = gateStatus?.missing?.joinToString(", ") ?: status.detail
        return Result(id, false, "runtime-not-ready:$missing", root)
    }

    fun allReady(): Boolean = gate.allReady()

    fun summary(): String = gate.summary()
}
