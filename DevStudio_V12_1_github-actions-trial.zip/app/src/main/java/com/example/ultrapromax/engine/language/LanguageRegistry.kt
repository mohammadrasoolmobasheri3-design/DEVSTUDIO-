package com.example.ultrapromax.engine.language

import com.example.ultrapromax.engine.language.providers.CLanguageProvider
import com.example.ultrapromax.engine.language.providers.CppLanguageProvider
import com.example.ultrapromax.engine.language.providers.DartLanguageProvider
import com.example.ultrapromax.engine.language.providers.GenericLanguageProvider
import com.example.ultrapromax.engine.language.providers.JavaLanguageProvider
import com.example.ultrapromax.engine.language.providers.JavaScriptLanguageProvider
import com.example.ultrapromax.engine.language.providers.KotlinLanguageProvider
import com.example.ultrapromax.engine.language.providers.PHPLanguageProvider
import com.example.ultrapromax.engine.language.providers.PythonLanguageProvider
import com.example.ultrapromax.engine.language.providers.TypeScriptLanguageProvider

/** Central language registry. Runtime support remains in engine/run and is not replaced here. */
object LanguageRegistry {
    private val providers = LinkedHashMap<String, LanguageProvider>()
    private val extensionMap = HashMap<String, String>()

    init {
        register(KotlinLanguageProvider())
        extensionMap["kts"] = "kt"
        register(JavaLanguageProvider())
        register(PythonLanguageProvider())
        register(JavaScriptLanguageProvider())
        extensionMap["mjs"] = "js"
        register(TypeScriptLanguageProvider())
        extensionMap["tsx"] = "ts"
        register(CLanguageProvider())
        register(CppLanguageProvider())
        extensionMap["cc"] = "cpp"
        extensionMap["cxx"] = "cpp"
        register(PHPLanguageProvider())
        register(DartLanguageProvider())
        register(GenericLanguageProvider("html", "HTML", listOf("html", "htm"), "<!--", "-->"))
        register(GenericLanguageProvider("css", "CSS", listOf("css"), "/*", "*/"))
        register(GenericLanguageProvider("go", "Go", listOf("go"), "//", "/*"))
        register(GenericLanguageProvider("rust", "Rust", listOf("rs"), "//", "/*"))
        register(GenericLanguageProvider("swift", "Swift", listOf("swift"), "//", "/*"))
        register(GenericLanguageProvider("ruby", "Ruby", listOf("rb"), "#", null))
        register(GenericLanguageProvider("perl", "Perl", listOf("pl"), "#", null))
        register(GenericLanguageProvider("lua", "Lua", listOf("lua"), "--", "--[["))
        register(GenericLanguageProvider("shell", "Shell", listOf("sh", "bash"), "#", null))
        register(GenericLanguageProvider("sql", "SQL", listOf("sql"), "--", "/*"))
    }

    @Synchronized
    fun register(provider: LanguageProvider) {
        val definition = provider.definition()
        providers[definition.id] = provider
        for (extension in definition.extensions) {
            extensionMap[normalizeExtension(extension)] = definition.id
        }
    }

    fun get(id: String): LanguageProvider? = providers[id]

    fun all(): List<LanguageProvider> = ArrayList(providers.values)

    fun detect(fileName: String): LanguageProvider? {
        val lower = fileName.toLowerCase()
        val dot = lower.lastIndexOf('.')
        if (dot < 0 || dot == lower.length - 1) return null
        return extensionMap[lower.substring(dot + 1)]?.let { get(it) }
    }

    fun detectId(fileName: String): String = detect(fileName)?.definition()?.id ?: "text"

    private fun normalizeExtension(value: String): String = value.trim().trimStart('.').toLowerCase()
}
