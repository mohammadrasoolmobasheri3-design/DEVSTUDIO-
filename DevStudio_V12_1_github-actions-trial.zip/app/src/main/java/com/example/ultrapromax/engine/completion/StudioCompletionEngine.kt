package com.example.ultrapromax.engine.completion

import android.content.Context
import com.example.ultrapromax.engine.ai.OfflineAiAppBuilderEngine
import com.example.ultrapromax.engine.offline.OfflineInternetSimulationEngine
import com.example.ultrapromax.engine.offline.OfflineNetworkPolicy
import com.example.ultrapromax.engine.security.RecoveryTransactionEngine
import com.example.ultrapromax.engine.visual.StudioDesignSystemEngine
import com.example.ultrapromax.engine.visual.UiUxFactoryEngine
import com.example.ultrapromax.engine.webapp.WebAppProjectEngine
import com.example.ultrapromax.engine.plugin.LocalPluginCatalogEngine
import java.io.File

/** Final completion audit: executes deterministic local smoke workflows instead of only checking class names. */
class StudioCompletionEngine(private val context: Context) {
    data class Check(val id: String, val title: String, val status: String, val detail: String)
    data class Report(val checks: List<Check>, val timestamp: Long) {
        fun passed() = checks.count { it.status == "PASS" }
        fun warnings() = checks.count { it.status == "WARN" }
        fun failed() = checks.count { it.status == "FAIL" }
    }

    fun run(): Report {
        val out = ArrayList<Check>()
        version(out)
        design(out)
        simulation(out)
        offline(out)
        recovery(out)
        webBuilder(out)
        pluginCatalog(out)
        aiBuilder(out)
        return Report(out, System.currentTimeMillis())
    }

    private fun version(out: MutableList<Check>) {
        try {
            @Suppress("DEPRECATION")
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            val version = info.versionName ?: "unknown"
            out += Check("version", "Version contract", if (version == "30.1.0") "PASS" else "FAIL", "DEVSTUDIO $version")
        } catch (t: Throwable) {
            out += Check("version", "Version contract", "FAIL", t.message ?: "Unable to read package version")
        }
    }

    private fun design(out: MutableList<Check>) {
        try { val e = UiUxFactoryEngine(); val base = StudioDesignSystemEngine(); val ok = e.validate() && base.validate(); out += Check("design", "UI/UX Factory", if (ok) "PASS" else "FAIL", "${e.components().size} components • ${e.animations().size} motion presets • ${e.themes().size} themes • ${e.breakpoints().size} responsive profiles") }
        catch (t: Throwable) { out += Check("design", "Design system", "FAIL", t.message ?: "error") }
    }

    private fun simulation(out: MutableList<Check>) {
        val e = OfflineInternetSimulationEngine()
        val r = e.request("/api/health")
        out += Check("simulation", "Offline Internet Simulation", if (e.isOffline() && r.status == 200) "PASS" else "FAIL", "${e.routes().size} deterministic local API routes")
    }

    private fun offline(out: MutableList<Check>) {
        val policy = OfflineNetworkPolicy(context)
        val blocked = !policy.allow("https://example.com")
        val local = policy.allow("http://127.0.0.1:8080")
        out += Check("offline", "Strict offline boundary", if (blocked && local) "PASS" else "FAIL", "External URLs blocked; loopback remains available")
    }

    private fun recovery(out: MutableList<Check>) {
        val root = File(context.cacheDir, "completion-recovery")
        val source = File(root, "source.txt")
        val snapDir = File(context.cacheDir, "completion-recovery-snapshot")
        try {
            root.mkdirs(); source.parentFile?.mkdirs(); source.writeText("stable")
            val engine = RecoveryTransactionEngine(); val snap = engine.snapshot(root, snapDir)
            source.writeText("changed")
            val restored = engine.restore(snap)
            val ok = restored && source.readText() == "stable"
            root.deleteRecursively(); snapDir.deleteRecursively()
            out += Check("recovery", "Transactional recovery", if (ok) "PASS" else "FAIL", "Snapshot integrity + restore verified")
        } catch (t: Throwable) { root.deleteRecursively(); snapDir.deleteRecursively(); out += Check("recovery", "Transactional recovery", "FAIL", t.message ?: "error") }
    }

    private fun webBuilder(out: MutableList<Check>) {
        val root = File(context.cacheDir, "completion-web-root")
        val output = File(context.cacheDir, "completion-web-output")
        try {
            root.deleteRecursively(); output.deleteRecursively(); root.mkdirs(); File(root, "index.html").writeText("<html><body>DEVSTUDIO</body></html>")
            val r = WebAppProjectEngine().generateWebViewProject(root, output, "CompletionWebApp")
            val ok = r.filesCreated > 0 && File(r.projectDir, "app/src/main/assets/index.html").isFile
            root.deleteRecursively(); output.deleteRecursively()
            out += Check("web", "Web → Android project pipeline", if (ok) "PASS" else "FAIL", "Real offline WebView project generation verified; APK build uses local Android toolchain")
        } catch (t: Throwable) { root.deleteRecursively(); output.deleteRecursively(); out += Check("web", "Web → Android project pipeline", "FAIL", t.message ?: "error") }
    }

    private fun pluginCatalog(out: MutableList<Check>) {
        val root = File(context.cacheDir, "completion-plugins")
        try { root.mkdirs(); val entries = LocalPluginCatalogEngine().scan(root); root.deleteRecursively(); out += Check("plugins", "Offline plugin catalog", "PASS", "Local catalog ready • ${entries.size} packages discovered") }
        catch (t: Throwable) { root.deleteRecursively(); out += Check("plugins", "Offline plugin catalog", "FAIL", t.message ?: "error") }
    }

    private fun aiBuilder(out: MutableList<Check>) {
        try { val plan = OfflineAiAppBuilderEngine(context).plan("build an Android Kotlin app"); out += Check("ai-builder", "Offline AI app builder", if (plan.packageName.isNotBlank()) "PASS" else "FAIL", "Bounded planner → ${plan.template.displayName} → ${plan.packageName}") }
        catch (t: Throwable) { out += Check("ai-builder", "Offline AI app builder", "FAIL", t.message ?: "error") }
    }

}
