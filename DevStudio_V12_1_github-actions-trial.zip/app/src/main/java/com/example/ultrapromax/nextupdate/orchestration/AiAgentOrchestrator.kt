package com.example.ultrapromax.nextupdate.orchestration

import com.example.ultrapromax.nextupdate.ai.context.ContextProvider
import com.example.ultrapromax.nextupdate.ai.model.AiTask
import com.example.ultrapromax.nextupdate.ai.planner.AiPlanner
import com.example.ultrapromax.nextupdate.ai.tools.AiToolRegistry

data class AgentRunResult(
    val taskId: String,
    val summary: String,
    val requiresApproval: Boolean
)

class AiAgentOrchestrator(
    private val contextProvider: ContextProvider,
    private val planner: AiPlanner,
    private val tools: AiToolRegistry
) {
    fun prepare(task: AiTask): AgentRunResult {
        val context = task.projectId?.let { contextProvider.snapshot(it) }
        val plan = planner.createPlan(task, context)
        val needsApproval = plan.steps.any { it.destructive }
        return AgentRunResult(task.id, "Plan prepared with ${plan.steps.size} steps and ${tools.all().size} tools.", needsApproval)
    }
}
