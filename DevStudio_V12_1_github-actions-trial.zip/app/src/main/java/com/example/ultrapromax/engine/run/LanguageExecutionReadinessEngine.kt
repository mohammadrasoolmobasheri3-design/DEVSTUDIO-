package com.example.ultrapromax.engine.run

import android.content.Context
import java.io.File

/** Zero-to-hundred gate: READY means a real executable/runtime contract is present. */
class LanguageExecutionReadinessEngine(context: Context) {
    data class Gate(val id: String, val ready: Boolean, val reason: String)
    private val root = File(context.filesDir, "runtimes")
    private val registry = LanguageRuntimeRegistry(root)
    private val contracts = RuntimePackContractEngine(root)

    fun check(): List<Gate> = registry.all()
        .filter { it.id in setOf("kotlin", "kotlin-script", "java", "python", "c", "cpp", "dart", "flutter", "javascript", "html", "css") }
        .map { p ->
            if (p.id in setOf("javascript", "html", "css")) Gate(p.id, true, "ANDROID_WEBVIEW")
            else {
                val c = contracts.check(p)
                Gate(p.id, c.ready, if (c.ready) "REAL_ANDROID_RUNTIME" else "RUNTIME_PACK_REQUIRED")
            }
        }

    fun allReady(): Boolean = check().all { it.ready }
}
