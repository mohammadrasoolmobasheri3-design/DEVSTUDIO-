package com.example.ultrapromax.engine.quality

import java.io.File

/** V30.1.0 final hardening quality gate. Combines integration, compatibility and project checks. */
class StudioQualityGate {
    data class Result(
        val integrationHealthy: Boolean,
        val compatibilityHealthy: Boolean,
        val projectHealthy: Boolean,
        val message: String
    ) {
        fun passed(): Boolean = integrationHealthy && compatibilityHealthy && projectHealthy
    }

    fun evaluate(
        integration: IntegrationHealthEngine.Report,
        compatibility: List<CompatibilityEngine.Check>,
        projectRoot: File?
    ): Result {
        val compatibilityHealthy = compatibility.all { it.valid }
        val projectHealthy = projectRoot == null || (projectRoot.exists() && projectRoot.isDirectory)
        val message = if (integration.isHealthy() && compatibilityHealthy && projectHealthy) {
            "V30.1.0 QUALITY GATE: PASS"
        } else {
            "V30.1.0 QUALITY GATE: REVIEW REQUIRED"
        }
        return Result(integration.isHealthy(), compatibilityHealthy, projectHealthy, message)
    }
}
