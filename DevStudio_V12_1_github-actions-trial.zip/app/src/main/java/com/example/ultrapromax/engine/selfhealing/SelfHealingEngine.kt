package com.example.ultrapromax.engine.selfhealing

import com.example.ultrapromax.engine.security.RecoveryEngine
import com.example.ultrapromax.engine.security.RecoveryTransactionEngine
import java.io.File

/**
 * Safe self-healing coordinator. Repairs only known Studio metadata/state,
 * always snapshots first, verifies the snapshot and rolls back on failure.
 * User source files are never rewritten automatically.
 */
class SelfHealingEngine(private val recovery: RecoveryEngine) {
    data class Result(val repaired: Boolean, val action: String)
    data class RepairReport(val success: Boolean, val repairedFiles: Int, val rolledBack: Boolean, val detail: String)

    fun clearStaleCrashReport(): Result {
        return try {
            if (recovery.hasCrashReport()) {
                recovery.clearCrashReport()
                Result(true, "Cleared stale crash report")
            } else Result(false, "No stale crash report")
        } catch (e: Throwable) { Result(false, "Recovery cleanup failed: " + (e.message ?: "unknown")) }
    }

    fun isWorkspaceSafe(root: File?): Boolean {
        if (root == null) return false
        return try { root.canonicalFile.isDirectory && root.canonicalFile.canRead() } catch (_: Exception) { false }
    }

    fun repairWorkspace(root: File): RepairReport {
        if (!isWorkspaceSafe(root)) return RepairReport(false, 0, false, "Workspace is unavailable")
        val snapshotDir = File(root.parentFile ?: root, ".devstudio-selfheal-${System.nanoTime()}")
        val tx = RecoveryTransactionEngine()
        var repaired = 0
        try {
            val snap = tx.snapshot(root, snapshotDir)
            if (!tx.verify(snap).valid) return RepairReport(false, 0, false, "Snapshot verification failed")
            val stateDir = File(root, ".devstudio")
            if (!stateDir.exists()) { stateDir.mkdirs(); repaired++ }
            val state = File(stateDir, "workspace.state")
            if (!state.isFile) { state.writeText("activeTab=files\nbottomPanel=none\ndirty=false\n"); repaired++ }
            val tasks = File(stateDir, "tasks")
            if (!tasks.exists()) { tasks.mkdirs(); repaired++ }
            val backups = File(stateDir, "backups")
            if (!backups.exists()) { backups.mkdirs(); repaired++ }
            if (!tx.verify(snap).valid) {
                val restored = tx.restore(snap)
                return RepairReport(false, repaired, restored, "Post-repair verification failed; workspace restored")
            }
            return RepairReport(true, repaired, false, if (repaired == 0) "Workspace already healthy" else "Repaired Studio metadata safely")
        } catch (e: Throwable) {
            return RepairReport(false, repaired, false, e.message ?: "Self-healing failed")
        } finally { snapshotDir.deleteRecursively() }
    }
}
