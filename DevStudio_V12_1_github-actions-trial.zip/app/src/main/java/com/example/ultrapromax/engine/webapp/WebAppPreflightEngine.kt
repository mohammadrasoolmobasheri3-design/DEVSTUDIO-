package com.example.ultrapromax.engine.webapp

import java.io.File

/** Validates a web project before Android wrapper generation. */
class WebAppPreflightEngine {
    data class Report(val valid: Boolean, val files: Int, val warnings: List<String>, val errors: List<String>)
    fun inspect(root: File): Report {
        val errors = ArrayList<String>(); val warnings = ArrayList<String>()
        if (!root.isDirectory) errors += "Web project directory not found"
        val files = if (root.isDirectory) root.walkTopDown().count { it.isFile } else 0
        val index = File(root, "index.html")
        if (!index.isFile) errors += "index.html is required"
        if (files > 5000) warnings += "Large project: $files files"
        root.walkTopDown().filter { it.isFile }.forEach { f -> if (f.length() > 20L * 1024L * 1024L) warnings += "Large asset: ${f.name}" }
        return Report(errors.isEmpty(), files, warnings, errors)
    }
}
