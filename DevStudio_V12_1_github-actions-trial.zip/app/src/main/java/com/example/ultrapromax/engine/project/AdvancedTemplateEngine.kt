package com.example.ultrapromax.engine.project

import android.content.Context
import com.example.ultrapromax.engine.file.ProjectTemplate
import java.io.File
import java.util.Locale

/**
 * V30.1.0 Stage 18 — Advanced Template Engine.
 *
 * Keeps the original ProjectTemplate scaffolds intact and adds a safe catalog,
 * search/filter, metadata, preview and favorite state around them.
 * Everything is local/offline and compatible with the legacy toolchain.
 */
class AdvancedTemplateEngine(private val context: Context) {

    data class Definition(
        val template: ProjectTemplate,
        val category: String,
        val description: String,
        val tags: List<String>,
        val recommended: Boolean,
        val buildable: Boolean
    )

    data class Preview(
        val definition: Definition,
        val files: List<String>,
        val totalFiles: Int,
        val totalBytes: Long
    )

    private val prefs by lazy {
        context.getSharedPreferences("devstudio_templates", Context.MODE_PRIVATE)
    }

    private val catalog: List<Definition> = listOf(
        Definition(ProjectTemplate.Blank, "General", "Empty workspace for a custom project.", listOf("blank", "custom", "workspace"), false, false),
        Definition(ProjectTemplate.HtmlCssJs, "Web", "Offline HTML, CSS and JavaScript starter.", listOf("html", "css", "javascript", "web"), true, false),
        Definition(ProjectTemplate.Todo, "Web", "Interactive To-Do starter with local browser logic.", listOf("todo", "html", "css", "javascript"), true, false),
        Definition(ProjectTemplate.KotlinBasic, "Kotlin", "Small Kotlin console starter for code experiments.", listOf("kotlin", "console", "language"), false, false),
        Definition(ProjectTemplate.AndroidJava, "Android", "Legacy-compatible Android Java application scaffold.", listOf("android", "java", "gradle", "app"), true, true),
        Definition(ProjectTemplate.AndroidKotlin, "Android", "Buildable Android Kotlin application scaffold.", listOf("android", "kotlin", "gradle", "app"), true, true),
        Definition(ProjectTemplate.AndroidUi, "Android", "Android Java starter with a ready UI screen.", listOf("android", "java", "ui", "layout"), true, true),
        Definition(ProjectTemplate.WebViewApp, "Android", "Android WebView wrapper for local HTML/CSS/JS assets.", listOf("android", "webview", "html", "apk"), true, true)
    )

    fun all(): List<Definition> = catalog

    fun search(query: String, category: String? = null): List<Definition> {
        val q = query.trim().toLowerCase(Locale.US)
        return catalog.filter { item ->
            val categoryOk = category.isNullOrEmpty() || category == "All" || item.category == category
            val queryOk = q.isEmpty() || item.template.displayName.toLowerCase(Locale.US).contains(q) ||
                    item.template.id.toLowerCase(Locale.US).contains(q) ||
                    item.category.toLowerCase(Locale.US).contains(q) ||
                    item.tags.any { it.toLowerCase(Locale.US).contains(q) }
            categoryOk && queryOk
        }.sortedWith(compareByDescending<Definition> { isFavorite(it.template.id) }.thenByDescending { it.recommended }.thenBy { it.template.displayName })
    }

    fun categories(): List<String> = listOf("All") + catalog.map { it.category }.distinct()

    fun isFavorite(id: String): Boolean = prefs.getBoolean("favorite_$id", false)

    fun setFavorite(id: String, favorite: Boolean) {
        prefs.edit().putBoolean("favorite_$id", favorite).apply()
    }

    fun preview(definition: Definition): Preview {
        val safeName = "template_preview_${definition.template.id.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${System.currentTimeMillis()}"
        val root = File(context.cacheDir, safeName)
        if (root.exists()) root.deleteRecursively()
        root.mkdirs()
        return try {
            definition.template.scaffold(root)
            val files = root.walkTopDown().filter { it.isFile }.map { it.relativeTo(root).path }.sorted().toList()
            var bytes = 0L
            root.walkTopDown().filter { it.isFile }.forEach { bytes += it.length() }
            Preview(definition, files, files.size, bytes)
        } finally {
            root.deleteRecursively()
        }
    }

}
