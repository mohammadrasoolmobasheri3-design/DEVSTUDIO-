package com.example.ultrapromax.engine.language.parser

import com.example.ultrapromax.engine.language.symbol.Symbol

data class ParseResult(
    val symbols: List<Symbol>,
    val errors: List<String> = emptyList()
)
