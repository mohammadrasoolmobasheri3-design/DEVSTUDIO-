package com.example.ultrapromax.ui

import android.view.KeyEvent
import android.widget.EditText

object CodeEditorHelper {

    fun attach(editor: EditText) {

        editor.setOnKeyListener { _, keyCode, event ->

            if (event.action != KeyEvent.ACTION_DOWN) {
                return@setOnKeyListener false
            }

            when (keyCode) {

                KeyEvent.KEYCODE_TAB -> {

                    if (event.isShiftPressed) {
                        removeIndent(editor)
                    } else {
                        addIndent(editor)
                    }

                    true
                }

                KeyEvent.KEYCODE_ENTER -> {

                    autoIndent(editor)

                    true
                }

                else -> false
            }
        }

        attachBracketPairing(editor)
    }

    private fun addIndent(editor: EditText) {

        val start = editor.selectionStart
        val end = editor.selectionEnd

        if (start != end) {
            return
        }

        editor.text.insert(
            start,
            "    "
        )
    }

    private fun removeIndent(editor: EditText) {

        val start = editor.selectionStart

        if (start <= 0) {
            return
        }

        val lineStart =
            editor.text.toString()
                .lastIndexOf(
                    '\n',
                    start - 1
                )
                .let {
                    if (it == -1) 0 else it + 1
                }

        val beforeCursor =
            editor.text.substring(
                lineStart,
                start
            )

        if (beforeCursor.startsWith("    ")) {

            editor.text.delete(
                lineStart,
                lineStart + 4
            )

        } else if (beforeCursor.startsWith("\t")) {

            editor.text.delete(
                lineStart,
                lineStart + 1
            )
        }
    }

    private fun autoIndent(editor: EditText) {

        val cursor = editor.selectionStart

        if (cursor < 0) {
            return
        }

        val text = editor.text.toString()

        val previousLineStart =
            text.lastIndexOf(
                '\n',
                cursor - 1
            ).let {
                if (it == -1) 0 else it + 1
            }

        val previousLineEnd =
            text.indexOf(
                '\n',
                previousLineStart
            ).let {
                if (it == -1) cursor else it
            }

        val previousLine =
            text.substring(
                previousLineStart,
                previousLineEnd
            )

        val currentIndent =
            previousLine.takeWhile {
                it == ' ' || it == '\t'
            }

        var newIndent = currentIndent

        val trimmed =
            previousLine.trimEnd()

        if (
            trimmed.endsWith("{") ||
            trimmed.endsWith("(") ||
            trimmed.endsWith("[") ||
            trimmed.endsWith(":")
        ) {
            newIndent += "    "
        }

        editor.text.insert(
            cursor,
            "\n$newIndent"
        )
    }

    private fun attachBracketPairing(
        editor: EditText
    ) {

        editor.addTextChangedListener(
            object : android.text.TextWatcher {

                private var editing = false

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                }

                override fun afterTextChanged(
                    s: android.text.Editable?
                ) {

                    if (editing || s == null) {
                        return
                    }

                    if (s.length == 0) {
                        return
                    }

                    val cursor =
                        editor.selectionStart

                    if (cursor <= 0) {
                        return
                    }

                    val lastChar =
                        s[cursor - 1]

                    val closingChar =
                        when (lastChar) {

                            '(' -> ')'
                            '[' -> ']'
                            '{' -> '}'
                            '"' -> '"'
                            '\'' -> '\''

                            else -> null
                        }

                    if (closingChar == null) {
                        return
                    }

                    if (
                        cursor < s.length &&
                        s[cursor] == closingChar
                    ) {
                        return
                    }

                    editing = true

                    try {

                        s.insert(
                            cursor,
                            closingChar.toString()
                        )

                        editor.setSelection(
                            cursor
                        )

                    } finally {
                        editing = false
                    }
                }
            }
        )
    }
}