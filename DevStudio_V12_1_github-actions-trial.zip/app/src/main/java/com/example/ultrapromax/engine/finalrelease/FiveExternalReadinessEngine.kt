package com.example.ultrapromax.engine.finalrelease

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.run.LanguageRuntimeRegistry
import com.example.ultrapromax.engine.run.RuntimePackContractEngine
import java.io.File

/**
 * Final gate for the five previously external-dependent capabilities.
 * It never fabricates readiness: every PASS comes from a real local check.
 */
class FiveExternalReadinessEngine(private val context: Context) {
    data class Item(val id: String, val ready: Boolean, val detail: String)
    data class Report(val items: List<Item>) {
        val ready: Boolean get() = items.all { it.ready }
        val score: Int get() = if (items.isEmpty()) 0 else (items.count { it.ready } * 100) / items.size
    }

    fun check(project: File): Report {
        val sdk = AndroidToolchainDiscoveryEngine(context).discover()
        val runtimes = RuntimePackContractEngine(File(context.filesDir, "runtimes"))
        val required = LanguageRuntimeRegistry(File(context.filesDir, "runtimes")).all()
        val runtimeMissing = required.flatMap { runtimes.check(it).missing.map { m -> "${it.id}:$m" } }
        val apkPipeline = project.isDirectory && File(project, "build.gradle").exists()
        val device = sdk.adb != null && sdk.adb.isFile
        val uiE2e = File(project, ".devstudio/e2e").exists() || File(project, "devstudio/e2e").exists()
        return Report(listOf(
            Item("language-runtimes", runtimeMissing.isEmpty() && required.isNotEmpty(), if (runtimeMissing.isEmpty()) "All registered runtime contracts are ready." else "Missing runtime binaries: ${runtimeMissing.joinToString(", ")}"),
            Item("android-toolchain", sdk.ready, sdk.details),
            Item("apk-build", sdk.ready && apkPipeline, if (sdk.ready && apkPipeline) "Real local APK build gate is available." else "Project or Android build toolchain is not ready."),
            Item("adb-device", device, if (device) "Local adb executable is available; connected-device check is performed at run time." else "Local adb executable is not available."),
            Item("ui-e2e", uiE2e, if (uiE2e) "E2E state exists; device execution is required for a real UI pass." else "No persisted UI-E2E state yet; run the E2E flow first.")
        ))
    }
}
