package com.example.ultrapromax.nextupdate.agent

import com.example.ultrapromax.engine.ai.RuleBasedAiEngine
import com.example.ultrapromax.engine.editor.EditorEngine
import com.example.ultrapromax.nextupdate.security.AgentSecurityPolicy
import java.io.File

/**
 * V30.1.0 Stage 16: bounded offline AI Agent Loop.
 * Inspect -> diagnose -> propose -> approve -> apply -> verify.
 * No network and no unbounded autonomous execution.
 */
class AiAgentLoopEngine(private val projectRoot: File?) {

    data class Session(
        val file: File,
        val before: String,
        val after: String,
        val beforeIssues: Int,
        val afterIssues: Int,
        val language: String
    ) {
        val changed: Boolean get() = before != after
    }

    data class Result(
        val success: Boolean,
        val message: String,
        val session: Session? = null
    )

    private val security = AgentSecurityPolicy()
    private val ai = RuleBasedAiEngine()

    fun inspectAndPropose(file: File, text: String): Result {
        if (!insideProject(file)) return Result(false, "Agent Loop: فایل خارج از محدوده پروژه است.")
        if (!file.exists()) return Result(false, "Agent Loop: فایل پیدا نشد.")
        if (text.length > 1024 * 1024) return Result(false, "Agent Loop: فایل بزرگ‌تر از 1MB است.")

        val language = EditorEngine.languageForFileName(file.name)
        val beforeIssues = ai.lint(text, language).size
        val after = ai.autoFix(text, language)
        val afterIssues = ai.lint(after, language).size
        val session = Session(file, text, after, beforeIssues, afterIssues, language)

        if (!session.changed) return Result(true, "Agent Loop: اصلاح امنی برای این فایل پیدا نشد.", session)
        return Result(true, "Agent Loop آماده است: $beforeIssues مشکل → $afterIssues مشکل. تأیید کاربر لازم است.", session)
    }

    fun applyApproved(session: Session): Result {
        if (!security.allowsMutation(true)) return Result(false, "Agent Loop: سیاست امنیتی اجازه تغییر نمی‌دهد.")
        if (!insideProject(session.file)) return Result(false, "Agent Loop: مسیر فایل امن نیست.")

        return try {
            val current = session.file.readText()
            if (current != session.before) {
                return Result(false, "Agent Loop: فایل از زمان تحلیل تغییر کرده؛ برای جلوگیری از overwrite متوقف شد.", session)
            }
            session.file.writeText(session.after)
            val verify = ai.lint(session.file.readText(), session.language).size
            if (verify > session.beforeIssues) {
                session.file.writeText(session.before)
                Result(false, "Agent Loop: Verify ناموفق بود؛ تغییرات rollback شد.", session)
            } else {
                Result(true, "Agent Loop موفق: تغییرات اعمال و Verify شد. مشکلات: $verify", session)
            }
        } catch (e: Exception) {
            Result(false, "Agent Loop: خطا هنگام اعمال تغییرات: ${e.message ?: "unknown"}", session)
        }
    }

    private fun insideProject(file: File): Boolean {
        val root = projectRoot ?: return false
        return try {
            val r = root.canonicalFile
            val f = file.canonicalFile
            f.path == r.path || f.path.startsWith(r.path + File.separator)
        } catch (_: Exception) {
            false
        }
    }
}
