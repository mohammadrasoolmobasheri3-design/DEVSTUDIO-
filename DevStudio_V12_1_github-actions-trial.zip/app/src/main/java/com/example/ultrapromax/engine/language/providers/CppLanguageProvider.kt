package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class CppLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("cpp", "C++", listOf("cpp", "cc", "cxx"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("cpp").parse(source)
}
