package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.quality.FullSystemIntegrationEngine

/** V30.1.0 full-system integration center. */
class FullSystemIntegrationActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private var project: Project? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("project_id", -1L)
        project = if (id >= 0L) ProjectStore.getById(this, id) else ProjectStore.list(this).firstOrNull()
        buildUi()
        runChecks()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(14), dp(16), dp(16))
        root.setBackgroundColor(Color.rgb(6, 9, 16))

        val title = TextView(this)
        title.text = "FULL SYSTEM INTEGRATION"
        title.setTextColor(Color.WHITE)
        title.textSize = 21f
        title.gravity = Gravity.CENTER_VERTICAL

        val sub = TextView(this)
        sub.text = "V30.1.0 • offline integration verification"
        sub.setTextColor(Color.rgb(120, 210, 255))
        sub.textSize = 12f

        summary = TextView(this)
        summary.setTextColor(Color.rgb(90, 235, 170))
        summary.textSize = 13f
        summary.setPadding(0, dp(14), 0, dp(10))

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        val scroll = android.widget.ScrollView(this)
        scroll.addView(list)

        root.addView(title)
        root.addView(sub)
        root.addView(summary)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val back = TextView(this)
        back.text = "‹  BACK TO STUDIO"
        back.setTextColor(Color.WHITE)
        back.textSize = 13f
        back.gravity = Gravity.CENTER
        back.setPadding(0, dp(12), 0, dp(12))
        back.setOnClickListener { finish() }
        root.addView(back)

        setContentView(root)
    }

    private fun runChecks() {
        list.removeAllViews()
        val report = FullSystemIntegrationEngine(this).run(project)
        summary.text = "${report.passed()} / ${report.items.size} systems ready  •  ${report.fileCount} project files  •  ${report.durationMs} ms"

        report.items.forEach {
            val row = TextView(this)
            val mark = if (it.ready) "✓" else "!"
            row.text = "$mark  ${it.name}\n    ${it.detail}"
            row.setTextColor(if (it.ready) Color.rgb(110, 240, 175) else Color.rgb(255, 105, 105))
            row.textSize = 12f
            row.setPadding(dp(10), dp(9), dp(10), dp(9))
            list.addView(row)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
