package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.serverstudio.ServerStudioEngine
import java.io.File

/** ENDGAME Stage 6 — Server Studio. Local-loopback only; no external networking. */
class ServerStudioActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var engine: ServerStudioEngine
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var profile: Spinner
    private lateinit var port: EditText
    private lateinit var method: Spinner
    private lateinit var path: EditText
    private lateinit var routeBody: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_server_studio)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        engine = ServerStudioEngine(File(project.folderPath), File(filesDir, "runtimes"))
        status = findViewById(R.id.ssStatus); log = findViewById(R.id.ssLog)
        profile = findViewById(R.id.ssProfile); port = findViewById(R.id.ssPort)
        method = findViewById(R.id.ssMethod); path = findViewById(R.id.ssPath); routeBody = findViewById(R.id.ssBody)
        val names = engine.profiles().map { it.name }
        profile.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        method.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("GET", "POST", "PUT", "DELETE"))
        profile.setSelection(0)
        profile.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                engine.selectedProfileId = engine.profiles()[position].id; append(engine.readiness())
            }
        }
        findViewById<TextView>(R.id.ssBack).setOnClickListener { engine.stop(); finish() }
        findViewById<Button>(R.id.ssStart).setOnClickListener { start() }
        findViewById<Button>(R.id.ssStop).setOnClickListener { engine.stop(); render() }
        findViewById<Button>(R.id.ssRestart).setOnClickListener { engine.restart(); render() }
        findViewById<Button>(R.id.ssAddRoute).setOnClickListener { addRoute() }
        findViewById<Button>(R.id.ssTest).setOnClickListener { test() }
        findViewById<Button>(R.id.ssHealth).setOnClickListener { path.setText("/api/health"); test() }
        findViewById<Button>(R.id.ssClear).setOnClickListener { engine.clearLogs(); log.text = "" }
        append("SERVER STUDIO • 127.0.0.1 ONLY • OFFLINE")
        append(engine.readiness())
    }

    private fun start() {
        val p = port.text.toString().toIntOrNull() ?: 0
        engine.configure(File(project.folderPath), p)
        val ok = engine.start(); append(if (ok) "START OK: ${engine.baseUrl()}" else "START FAILED")
        render()
    }
    private fun addRoute() {
        val p = path.text.toString().ifBlank { "/api/demo" }
        val body = routeBody.text.toString().ifBlank { "{\"status\":\"ok\",\"offline\":true}" }
        engine.addRoute(method.selectedItem.toString(), p, body)
        append("ROUTE ADDED ${method.selectedItem} $p")
    }
    private fun test() {
        Thread {
            val r = engine.test(method.selectedItem.toString(), path.text.toString().ifBlank { "/api/health" })
            runOnUiThread { append("RESPONSE ${r.code} ${r.durationMs}ms\n${r.body.ifBlank { r.error ?: "" }}") }
        }.start()
    }
    private fun render() {
        status.text = if (engine.isRunning()) "● RUNNING  ${engine.baseUrl()}" else "● STOPPED"
        status.setTextColor(if (engine.isRunning()) Color.parseColor("#4CD964") else Color.parseColor("#9AA4C0"))
    }
    private fun append(s: String) { log.append("$s\n") }
    override fun onDestroy() { engine.stop(); super.onDestroy() }
    companion object { const val EXTRA_PROJECT_ID = "extra_server_studio_project_id" }
}
