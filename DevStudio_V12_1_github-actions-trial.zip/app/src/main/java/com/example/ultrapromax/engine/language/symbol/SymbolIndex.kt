package com.example.ultrapromax.engine.language.symbol

class SymbolIndex {
    private val byFile = LinkedHashMap<String, List<Symbol>>()

    @Synchronized
    fun replaceFile(filePath: String, symbols: List<Symbol>) {
        byFile[filePath] = symbols.map { it.copy(filePath = filePath) }
    }

    @Synchronized
    fun removeFile(filePath: String) { byFile.remove(filePath) }

    @Synchronized
    fun clear() { byFile.clear() }

    @Synchronized
    fun symbolsForFile(filePath: String): List<Symbol> = ArrayList(byFile[filePath] ?: emptyList())

    @Synchronized
    fun allSymbols(): List<Symbol> = byFile.values.flatten()

    @Synchronized
    fun files(): List<String> = ArrayList(byFile.keys)

    @Synchronized
    fun findByName(name: String): List<Symbol> = allSymbols().filter { it.name == name }

    @Synchronized
    fun search(query: String): List<Symbol> {
        val q = query.trim().toLowerCase()
        if (q.isEmpty()) return emptyList()
        return allSymbols().sortedWith(compareBy<Symbol> {
            when {
                it.name.toLowerCase() == q -> 0
                it.name.toLowerCase().startsWith(q) -> 1
                it.name.toLowerCase().contains(q) -> 2
                else -> 3
            }
        }.thenBy { it.name.toLowerCase() }).filter { it.name.toLowerCase().contains(q) }
    }

    @Synchronized
    fun fileCount(): Int = byFile.size

    @Synchronized
    fun symbolCount(): Int = byFile.values.sumBy { it.size }
}
