package com.example.ultrapromax.engine.diagnostics

data class StudioDiagnostic(
    val filePath: String,
    val line: Int,
    val column: Int = 1,
    val severity: String = "ERROR",
    val message: String
)
