package com.example.ultrapromax.engine.endgame

import android.content.Context
import java.io.File

/** Final ENDGAME gate. Reports evidence; never fabricates readiness. */
class EndgameCertificationEngine(private val context: Context) {
    enum class Status { PASS, CONDITIONAL, FAIL }
    data class Gate(val id: String, val title: String, val status: Status, val detail: String)
    data class Report(val gates: List<Gate>, val certified: Boolean, val summary: String)

    fun audit(): Report {
        val gates = ArrayList<Gate>()
        gates.add(gate("offline", "Offline Policy", offlineGate()))
        gates.add(gate("architecture", "12-Stage Architecture", architectureGate()))
        gates.add(gate("subsystems", "Core Subsystems", subsystemGate()))
        gates.add(gate("artifacts", "Certification Artifacts", artifactGate()))
        gates.add(gate("runtime", "External Runtime Readiness", runtimeGate()))
        gates.add(gate("build", "Real Build Evidence", buildGate()))
        gates.add(gate("e2e", "End-to-End Evidence", e2eGate()))
        gates.add(gate("recovery", "Recovery Evidence", recoveryGate()))
        gates.add(gate("security", "Security Evidence", securityGate()))
        gates.add(gate("final", "Final Certification", finalGate(gates)))

        val certified = gates.all { it.status == Status.PASS }
        val summary = if (certified) "ENDGAME CERTIFIED" else "NOT CERTIFIED — missing or conditional evidence remains"
        return Report(gates, certified, summary)
    }

    private fun gate(id: String, title: String, result: Pair<Status, String>): Gate = Gate(id, title, result.first, result.second)

    private fun offlineGate(): Pair<Status, String> {
        val manifest = File(context.applicationInfo.sourceDir)
        return if (manifest.exists()) Status.PASS to "Application package exists; certification remains local-only" else Status.FAIL to "Application package is unavailable"
    }

    private fun architectureGate(): Pair<Status, String> {
        return if (EndgameArchitectureEngine.stages.size == 12 && EndgameArchitectureEngine.stages.map { it.number }.toSet().size == 12)
            Status.PASS to "Exactly 12 ENDGAME stages are registered"
        else Status.FAIL to "ENDGAME stage contract is incomplete"
    }

    private fun subsystemGate(): Pair<Status, String> {
        val names = listOf(
            "com.example.ultrapromax.engine.appfactory.AppFactoryEngine",
            "com.example.ultrapromax.engine.serverstudio.ServerStudioEngine",
            "com.example.ultrapromax.engine.security.SecurityEngine",
            "com.example.ultrapromax.engine.security.RecoveryEngine",
            "com.example.ultrapromax.engine.plugin.PluginSystem",
            "com.example.ultrapromax.engine.ai.AiEngine"
        )
        val missing = names.filterNot { classExists(it) }
        return if (missing.isEmpty()) Status.PASS to "Core ENDGAME subsystem classes are present"
        else Status.FAIL to "Missing subsystem classes: ${missing.joinToString(", ")}" 
    }

    private fun artifactGate(): Pair<Status, String> {
        val root = File(context.filesDir, "endgame")
        if (!root.exists() && !root.mkdirs()) return Status.CONDITIONAL to "Certification directory could not be created"
        return Status.PASS to "Local certification workspace is available"
    }

    private fun runtimeGate(): Pair<Status, String> {
        val runtimes = File(context.filesDir, "runtimes")
        return if (runtimes.exists()) Status.PASS to "Runtime directory exists; individual packs remain truthfully reported by RuntimeManager"
        else Status.CONDITIONAL to "No private runtime-pack directory found; external toolchains must be validated on-device"
    }

    private fun buildGate(): Pair<Status, String> {
        val e = EndgameEvidenceStore(context).verify("build")
        return if (e != null && e.status == "PASS") Status.PASS to "Cryptographically verified real-build evidence"
        else Status.CONDITIONAL to "No valid hashed real-build evidence"
    }

    private fun e2eGate(): Pair<Status, String> {
        val e = EndgameEvidenceStore(context).verify("e2e")
        return if (e != null && e.status == "PASS") Status.PASS to "Cryptographically verified full E2E evidence"
        else Status.CONDITIONAL to "No valid hashed E2E evidence"
    }

    private fun recoveryGate(): Pair<Status, String> {
        val e = EndgameEvidenceStore(context).verify("recovery")
        return if (e != null && e.status == "PASS") Status.PASS to "Cryptographically verified recovery evidence"
        else Status.CONDITIONAL to "No valid hashed recovery evidence"
    }

    private fun securityGate(): Pair<Status, String> {
        val e = EndgameEvidenceStore(context).verify("security")
        return if (e != null && e.status == "PASS") Status.PASS to "Cryptographically verified security evidence"
        else Status.CONDITIONAL to "No valid hashed security evidence"
    }

    private fun finalGate(gates: List<Gate>): Pair<Status, String> {
        val blockers = gates.filter { it.id != "final" && it.status != Status.PASS }
        return if (blockers.isEmpty()) Status.PASS to "All ENDGAME gates passed"
        else Status.CONDITIONAL to "Certification blocked by: ${blockers.joinToString(", ") { it.title }}"
    }

    private fun classExists(name: String): Boolean = try {
        Class.forName(name)
        true
    } catch (_: Throwable) {
        false
    }
}
