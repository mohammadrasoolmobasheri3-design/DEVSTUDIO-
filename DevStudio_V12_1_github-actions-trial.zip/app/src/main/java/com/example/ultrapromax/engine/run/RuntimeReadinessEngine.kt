package com.example.ultrapromax.engine.run

import java.io.File

/** Read-only runtime readiness facade for Studio UI and tests. */
class RuntimeReadinessEngine(runtimeRoot: File) {
    private val registry = LanguageRuntimeRegistry(runtimeRoot)

    data class Summary(
        val total: Int,
        val ready: Int,
        val missing: Int,
        val builtIn: Int
    )

    fun all(): List<LanguageRuntimeRegistry.Readiness> = registry.all().map { registry.readiness(it) }

    fun summary(): Summary {
        val list = all()
        return Summary(
            list.size,
            list.count { it.ready },
            list.count { !it.ready && it.missing.isNotEmpty() },
            list.count { !it.ready && it.missing.isEmpty() }
        )
    }

    fun report(): String = registry.readinessReport()
}
