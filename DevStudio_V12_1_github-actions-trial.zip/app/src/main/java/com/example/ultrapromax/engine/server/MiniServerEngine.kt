package com.example.ultrapromax.engine.server

import com.example.ultrapromax.engine.websocket.WebSocketEngine
import com.example.ultrapromax.engine.security.SecurityEngine
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList

/**
 * MINI SERVER ENGINE ("Internet Simulation Engine")
 * A real local HTTP + WebSocket server bound only to 127.0.0.1 (loopback),
 * using plain java.net (no com.sun.net.httpserver — not guaranteed on
 * Android — and no third-party dependency).
 *
 * - Static files: serves the project folder.
 * - "Local Library": paths under /libs/ serve bundled local copies of common libraries.
 * - Virtual API: register JSON routes with addApiRoute("/api/...") { ... }.
 * - WebSocket: any request with "Upgrade: websocket" (e.g. path "/ws") is
 *   handed to WebSocketEngine; broadcast() sends to every connected client.
 *
 * Path-parameter API routes are supported. WebSocket routing remains a shared local channel.
 */
class MiniServerEngine(private val projectDir: File, private val assetsLibsDir: File?) {

    private var serverSocket: ServerSocket? = null
    private var serverThread: Thread? = null
    @Volatile private var running = false

    var port: Int = 0
        private set

    private val apiRoutes = mutableMapOf<String, () -> String>()
    private val apiPatternRoutes = mutableListOf<Pair<Regex, (Map<String, String>) -> String>>()
    private val webSocketClients = CopyOnWriteArrayList<Socket>()

    /** Optional hook: if set, every served .html file's text is passed through this first. */
    var htmlTransform: ((String) -> String)? = null

    fun addApiRoute(path: String, handler: () -> String) {
        apiRoutes[path] = handler
    }

    /**
     * Adds a local API route with {name} path parameters.
     * Example: /api/users/{id} matches /api/users/42.
     */
    fun addApiRoutePattern(pathPattern: String, handler: (Map<String, String>) -> String) {
        val names = Regex("\\{([A-Za-z_][A-Za-z0-9_]*)\\}").findAll(pathPattern).map { it.groupValues[1] }.toList()
        val token = Regex("\\{([A-Za-z_][A-Za-z0-9_]*)\\}")
        val regexText = buildString {
            var cursor = 0
            token.findAll(pathPattern).forEach { match ->
                append(Regex.escape(pathPattern.substring(cursor, match.range.first)))
                append("([^/]+)")
                cursor = match.range.last + 1
            }
            append(Regex.escape(pathPattern.substring(cursor)))
        }
        val regex = Regex("^$regexText$")
        apiPatternRoutes.add(regex to { values ->
            val map = LinkedHashMap<String, String>()
            names.forEachIndexed { index, name -> map[name] = values.entries.elementAtOrNull(index)?.value ?: "" }
            handler(map)
        })
    }

    init {
        addApiRoute("/api/ping") { "{\"status\":\"ok\",\"offline\":true}" }
    }

    fun start(): Int = startInternal(0)

    fun startOnPort(requestedPort: Int): Int = startInternal(requestedPort)

    private fun startInternal(requestedPort: Int): Int {
        stop()
        val socket = ServerSocket(requestedPort, 50, java.net.InetAddress.getByName("127.0.0.1"))
        serverSocket = socket
        port = socket.localPort
        running = true

        val thread = Thread {
            while (running) {
                try {
                    val client = socket.accept()
                    Thread { handleClient(client) }.apply { isDaemon = true }.start()
                } catch (e: Exception) {
                    if (running) { /* socket closed on stop(); ignore */ }
                }
            }
        }
        thread.isDaemon = true
        thread.start()
        serverThread = thread
        return port
    }

    fun stop() {
        running = false
        webSocketClients.forEach { runCatching { it.close() } }
        webSocketClients.clear()
        try { serverSocket?.close() } catch (e: Exception) { }
        serverSocket = null
        serverThread = null
    }

    fun isRunning(): Boolean = running

    fun baseUrl(): String = "http://127.0.0.1:$port/"
    fun webSocketUrl(): String = "ws://127.0.0.1:$port/ws"

    fun broadcast(message: String) {
        webSocketClients.forEach { client ->
            runCatching { WebSocketEngine.writeTextFrame(client.getOutputStream(), message) }
        }
    }

    private fun handleClient(client: Socket) {
        val reader = BufferedReader(InputStreamReader(client.getInputStream()))
        val requestLine = reader.readLine() ?: run { client.close(); return }
        val parts = requestLine.split(" ")
        if (parts.size < 2) { client.close(); return }
        val path = parts[1]

        val headers = mutableMapOf<String, String>()
        var line = reader.readLine()
        while (!line.isNullOrBlank()) {
            val idx = line.indexOf(":")
            if (idx > 0) headers[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
            line = reader.readLine()
        }

        if (WebSocketEngine.isUpgradeRequest(headers)) {
            val key = headers["Sec-WebSocket-Key"] ?: run { client.close(); return }
            WebSocketEngine.writeHandshakeResponse(client.getOutputStream(), key)
            webSocketClients.add(client)
            try {
                val input = client.getInputStream()
                webSocketLoop@ while (running) {
                    val frame = WebSocketEngine.readMessage(input) ?: break
                    when (frame.opcode) {
                        WebSocketEngine.OPCODE_TEXT -> broadcast(String(frame.payload, Charsets.UTF_8))
                        WebSocketEngine.OPCODE_PING -> WebSocketEngine.writePong(client.getOutputStream(), String(frame.payload, Charsets.UTF_8))
                        WebSocketEngine.OPCODE_CLOSE -> {
                            runCatching { WebSocketEngine.writeClose(client.getOutputStream()) }
                            break@webSocketLoop
                        }
                        WebSocketEngine.OPCODE_PONG -> { /* keep-alive acknowledgement */ }
                    }
                }
            } catch (e: Exception) {
            } finally {
                webSocketClients.remove(client)
                runCatching { client.close() }
            }
            return
        }

        client.use { socket ->
            val output = socket.getOutputStream()

            val apiHandler = apiRoutes[path]
            if (apiHandler != null) {
                val body = apiHandler().toByteArray()
                writeResponse(output, 200, "application/json; charset=utf-8", body)
                return
            }
            val patternRoute = apiPatternRoutes.firstOrNull { it.first.matches(path.substringBefore("?")) }
            if (patternRoute != null) {
                val values = patternRoute.first.find(path.substringBefore("?"))?.groupValues
                    ?.drop(1)?.mapIndexed { index, value -> index.toString() to value }?.toMap()
                    ?: emptyMap()
                val body = patternRoute.second(values).toByteArray()
                writeResponse(output, 200, "application/json; charset=utf-8", body)
                return
            }

            val requested = path.substringBefore("?").removePrefix("/").ifBlank { "index.html" }
            val root = if (requested.startsWith("libs/") && assetsLibsDir != null) assetsLibsDir else projectDir
            val relative = if (requested.startsWith("libs/")) requested.removePrefix("libs/") else requested
            val file = File(root, relative).canonicalFile
            val rootCanonical = root.canonicalFile

            if (!SecurityEngine.isInsideSandbox(rootCanonical, file)) {
                writeResponse(output, 403, "text/plain", "403 - sandbox path blocked".toByteArray())
                return
            }

            if (file.exists() && file.isFile) {
                val bytes = if (file.name.endsWith(".html") && htmlTransform != null) {
                    htmlTransform!!(String(file.readBytes(), Charsets.UTF_8)).toByteArray(Charsets.UTF_8)
                } else {
                    file.readBytes()
                }
                writeResponse(output, 200, contentTypeFor(file.name), bytes)
            } else {
                writeResponse(output, 404, "text/plain", "404 - $requested not found".toByteArray())
            }
        }
    }

    private fun writeResponse(output: java.io.OutputStream, code: Int, contentType: String, body: ByteArray) {
        val statusText = if (code == 200) "OK" else "Not Found"
        val header = "HTTP/1.0 $code $statusText\r\n" +
                "Content-Type: $contentType\r\n" +
                "Content-Length: ${body.size}\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray())
        output.write(body)
        output.flush()
    }

    private fun contentTypeFor(name: String): String = when {
        name.endsWith(".html") -> "text/html; charset=utf-8"
        name.endsWith(".css") -> "text/css"
        name.endsWith(".js") -> "application/javascript"
        name.endsWith(".png") -> "image/png"
        name.endsWith(".jpg") || name.endsWith(".jpeg") -> "image/jpeg"
        name.endsWith(".json") -> "application/json"
        else -> "application/octet-stream"
    }
}
