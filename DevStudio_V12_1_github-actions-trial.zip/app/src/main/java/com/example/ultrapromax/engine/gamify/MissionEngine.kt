package com.example.ultrapromax.engine.gamify

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MissionEngine(private val context: Context) {

    data class Mission(
        val id: String,
        val title: String,
        val goal: Int,
        val xp: Int
    )

    private val prefs = context.getSharedPreferences("mission_state", Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.US)

    fun missions(): List<Mission> {
        return listOf(
            Mission("open_studio", "Open Studio", 1, 5),
            Mission("create_project", "Create a project", 1, 20),
            Mission("edit_files", "Edit 3 files", 3, 25),
            Mission("build", "Run a build", 1, 30)
        )
    }

    fun progress(id: String): Int {
        resetIfNeeded()
        return prefs.getInt("p_$id", 0)
    }

    fun complete(id: String, amount: Int = 1): Boolean {
        resetIfNeeded()

        val mission = missions().firstOrNull { it.id == id } ?: return false
        val before = progress(id)
        val after = (before + amount).coerceAtMost(mission.goal)

        prefs.edit()
            .putInt("p_$id", after)
            .apply()

        if (before < mission.goal && after >= mission.goal &&
            !prefs.getBoolean("r_$id", false)
        ) {
            prefs.edit()
                .putBoolean("r_$id", true)
                .apply()
            return true
        }

        return false
    }

    fun streak(): Int {
        resetIfNeeded()
        return prefs.getInt("streak", 0)
    }

    private fun resetIfNeeded() {
        val today = dateFormat.format(Date())
        val storedDay = prefs.getString("day", null)

        if (storedDay != today) {
            val nextStreak = if (storedDay == null) {
                1
            } else {
                prefs.getInt("streak", 0) + 1
            }

            val editor = prefs.edit()
                .putString("day", today)
                .putInt("streak", nextStreak)

            missions().forEach { mission ->
                editor.remove("p_${mission.id}")
                editor.remove("r_${mission.id}")
            }

            editor.apply()
        }
    }
}
