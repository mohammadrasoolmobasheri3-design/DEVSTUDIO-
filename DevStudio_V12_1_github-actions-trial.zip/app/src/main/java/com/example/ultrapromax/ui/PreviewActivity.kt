package com.example.ultrapromax.ui

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.preview.PreviewEngine
import com.example.ultrapromax.engine.preview.RealTimePreviewController
import com.example.ultrapromax.engine.server.MiniServerEngine
import java.io.File

class PreviewActivity : AppCompatActivity() {

    private var server: MiniServerEngine? = null
    private var realtime: RealTimePreviewController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)

        val projectPath = intent.getStringExtra(EXTRA_PROJECT_DIR) ?: return
        val projectDir = File(projectPath)

        // libs/ folder bundled in assets (put jquery.min.js, bootstrap.min.css, etc. here
        // to give the "bundled local library" experience with zero internet connection)
        val libsDir = File(filesDir, "libs")

        val webView = findViewById<WebView>(R.id.webView)
        PreviewEngine.configure(webView)

        val srv = MiniServerEngine(projectDir, libsDir)

        val pluginManager = com.example.ultrapromax.engine.plugin.PluginManager(this)
        com.example.ultrapromax.engine.plugin.BuiltInPlugins.registerAll(pluginManager)
        if (pluginManager.isEnabledById("dark_reader")) {
            srv.htmlTransform = { html -> com.example.ultrapromax.engine.plugin.BuiltInPlugins.darkReader.injectDarkCss(html) }
        }

        srv.start()
        server = srv

        PreviewEngine.loadUrl(webView, srv.baseUrl())
        PreviewEngine.startAutoReload(webView, projectDir)
        realtime = RealTimePreviewController(webView, projectDir)
        realtime?.start()
    }

    override fun onDestroy() {
        PreviewEngine.stopAutoReload()
        realtime?.stop()
        server?.stop()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PROJECT_DIR = "extra_project_dir"
    }
}
