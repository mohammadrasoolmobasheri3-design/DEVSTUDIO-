package com.example.ultrapromax.engine.run

import android.content.Context
import java.io.File

/**
 * Single source of truth for the requested first-class offline languages.
 * Never claims a compiler/runtime is present unless its real pack contract passes.
 */
class FullLanguagePlatformEngine(private val context: Context) {
    data class Status(val id: String, val name: String, val ready: Boolean, val mode: String, val detail: String)

    private val root = File(context.filesDir, "runtimes")
    private val registry = LanguageRuntimeRegistry(root)
    private val contracts = RuntimePackContractEngine(root)

    fun statuses(): List<Status> = registry.all()
        .filter { it.id in setOf(
            "kotlin", "kotlin-script", "java", "python", "c", "cpp", "dart", "flutter",
            "javascript", "typescript", "html", "css", "csharp", "go", "rust", "php",
            "sql", "shell", "swift", "ruby"
        ) }
        .map { p ->
            when (p.id) {
                "html", "css" -> Status(p.id, p.displayName, true, "BUILT-IN", "Android WebView")
                "javascript" -> Status(p.id, p.displayName, true, "BUILT-IN", "Android WebView JavaScript")
                else -> {
                    val c = contracts.check(p)
                    Status(p.id, p.displayName, c.ready, if (c.ready) "REAL PACK" else "PACK REQUIRED",
                        if (c.ready) "real runtime contract satisfied" else c.missing.joinToString(", "))
                }
            }
        }

    fun report(): String = statuses().joinToString("\n") {
        "${it.name}: ${if (it.ready) "READY" else "NOT READY"} — ${it.mode} — ${it.detail}"
    }

    fun runtimeRoot(): File = root
}
