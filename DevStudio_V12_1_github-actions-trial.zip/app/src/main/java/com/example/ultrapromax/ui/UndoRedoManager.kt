package com.example.ultrapromax.ui

import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import java.util.Stack

class UndoRedoManager(
    private val editText: EditText
) {

    private val undoStack = Stack<String>()
    private val redoStack = Stack<String>()

    private var isApplying = false
    private var lastText = ""

    private val watcher = object : TextWatcher {

        override fun beforeTextChanged(
            s: CharSequence?,
            start: Int,
            count: Int,
            after: Int
        ) {
        }

        override fun onTextChanged(
            s: CharSequence?,
            start: Int,
            before: Int,
            count: Int
        ) {
        }

        override fun afterTextChanged(s: Editable?) {
            if (isApplying) return

            val current = s?.toString() ?: ""

            if (current != lastText) {
                undoStack.push(lastText)
                redoStack.clear()
                lastText = current
            }
        }
    }

    init {
        lastText = editText.text.toString()
        editText.addTextChangedListener(watcher)
    }

    fun undo() {
        if (undoStack.empty()) return

        isApplying = true

        try {
            val current = editText.text.toString()
            redoStack.push(current)

            val previous = undoStack.pop()
            editText.setText(previous)
            editText.setSelection(editText.text.length)

            lastText = previous
        } finally {
            isApplying = false
        }
    }

    fun redo() {
        if (redoStack.empty()) return

        isApplying = true

        try {
            val current = editText.text.toString()
            undoStack.push(current)

            val next = redoStack.pop()
            editText.setText(next)
            editText.setSelection(editText.text.length)

            lastText = next
        } finally {
            isApplying = false
        }
    }

    fun canUndo(): Boolean {
        return !undoStack.empty()
    }

    fun canRedo(): Boolean {
        return !redoStack.empty()
    }

    fun clearHistory() {
        undoStack.clear()
        redoStack.clear()
        lastText = editText.text.toString()
    }
}