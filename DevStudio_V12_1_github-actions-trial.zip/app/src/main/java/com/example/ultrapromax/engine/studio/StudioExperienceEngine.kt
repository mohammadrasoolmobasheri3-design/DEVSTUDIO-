package com.example.ultrapromax.engine.studio

import android.content.Context

data class StudioCommand(
    val id: String,
    val title: String,
    val category: String
)

data class StudioPanelState(
    val activeTab: String,
    val bottomPanel: String,
    val explorerVisible: Boolean
)

class StudioExperienceEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("devstudio_v27_experience", Context.MODE_PRIVATE)

    fun commands(): List<StudioCommand> {
        return listOf(
            StudioCommand("code", "Open Code Editor", "Workspace"),
            StudioCommand("files", "Project Explorer", "Workspace"),
            StudioCommand("design", "UI Builder", "Design"),
            StudioCommand("preview", "Preview / Run", "Run"),
            StudioCommand("build", "Build + Release", "Build"),
            StudioCommand("problems", "Problems & Diagnostics", "Analyze"),
            StudioCommand("output", "Run Output", "Run"),
            StudioCommand("terminal", "Local Terminal / Server", "Tools"),
            StudioCommand("assets", "Asset Manager", "Project"),
            StudioCommand("plugins", "Plugin Manager", "Platform"),
            StudioCommand("vfs", "Virtual File System", "Platform"),
            StudioCommand("runtime", "Runtime Manager", "Runtime"),
            StudioCommand("recovery", "Recovery / Self-Healing", "SYSTEM"),
            StudioCommand("settings", "Project Settings", "Project"),
            StudioCommand("beta", "Beta Test Center", "Quality"),
            StudioCommand("final_audit", "V30 Final Readiness", "Quality"),
            StudioCommand("webapp", "Web App → Android Project", "Build")
        )
    }

    fun savePanelState(projectId: Long, state: StudioPanelState) {
        prefs.edit()
            .putString(key(projectId, "tab"), state.activeTab)
            .putString(key(projectId, "bottom"), state.bottomPanel)
            .putBoolean(key(projectId, "explorer"), state.explorerVisible)
            .apply()
    }

    fun loadPanelState(projectId: Long): StudioPanelState {
        return StudioPanelState(
            prefs.getString(key(projectId, "tab"), "files") ?: "files",
            prefs.getString(key(projectId, "bottom"), "none") ?: "none",
            prefs.getBoolean(key(projectId, "explorer"), true)
        )
    }

    fun summary(projectName: String, fileCount: Int, dirty: Boolean): String {
        return projectName + " • " + fileCount + " files" +
                if (dirty) " • Unsaved changes" else " • All changes saved"
    }

    private fun key(projectId: Long, name: String): String {
        return projectId.toString() + "_" + name
    }
}
