package com.example.ultrapromax.engine.offline

/** Deterministic local internet simulation. No DNS, sockets or external network are used. */
class OfflineInternetSimulationEngine {
    data class Response(val status: Int, val contentType: String, val body: String)
    private data class Route(val method: String, val path: String, val response: Response)
    private val routes = ArrayList<Route>()

    init {
        register("GET", "/api/health", Response(200, "application/json", "{\"ok\":true,\"offline\":true}"))
        register("GET", "/api/config", Response(200, "application/json", "{\"mode\":\"offline\",\"network\":\"simulated\"}"))
        register("GET", "/api/version", Response(200, "application/json", "{\"studio\":\"30.1.0\"}"))
        register("GET", "/api/time", Response(200, "application/json", "{\"source\":\"deterministic-local\",\"epoch\":0}"))
    }

    fun register(path: String, response: Response) = register("GET", path, response)

    fun register(method: String, path: String, response: Response) {
        val m = method.trim().toUpperCase()
        if (path.startsWith("/") && m.isNotEmpty()) {
            routes.removeAll { it.method == m && it.path == path }
            routes.add(Route(m, path, response))
        }
    }

    fun request(path: String): Response = request("GET", path)

    fun request(method: String, path: String): Response {
        val m = method.trim().toUpperCase()
        return routes.firstOrNull { it.method == m && it.path == path }?.response
            ?: Response(404, "application/json", "{\"error\":\"route_not_found\",\"offline\":true}")
    }

    fun routes(): List<String> = routes.map { "${it.method} ${it.path}" }
    fun isOffline(): Boolean = true
    fun externalNetworkUsed(): Boolean = false
}
