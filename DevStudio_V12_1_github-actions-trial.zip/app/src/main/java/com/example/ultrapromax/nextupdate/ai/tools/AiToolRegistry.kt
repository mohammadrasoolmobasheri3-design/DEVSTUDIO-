package com.example.ultrapromax.nextupdate.ai.tools

class AiToolRegistry {
    private val tools = LinkedHashMap<String, AiTool>()

    fun register(tool: AiTool) { tools[tool.id] = tool }
    fun get(id: String): AiTool? = tools[id]
    fun all(): List<AiTool> = tools.values.toList()
}
