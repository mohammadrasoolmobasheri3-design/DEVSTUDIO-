package com.example.ultrapromax.nextupdate.ai.context

interface ContextProvider {
    fun snapshot(projectId: String): ProjectContext?
}
