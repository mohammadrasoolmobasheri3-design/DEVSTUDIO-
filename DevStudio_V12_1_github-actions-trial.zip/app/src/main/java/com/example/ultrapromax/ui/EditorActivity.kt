package com.example.ultrapromax.ui

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ScrollView
import android.text.InputType
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.ai.RuleBasedAiEngine
import com.example.ultrapromax.engine.ai.OfflineAiAgentEngine
import com.example.ultrapromax.engine.backup.BackupEngine
import com.example.ultrapromax.engine.builder.ApkInstaller
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.editor.EditorEngine
import com.example.ultrapromax.engine.editor.UnlimitedWorkspaceEngine
import com.example.ultrapromax.engine.editor.UniversalEditorEngine
import com.example.ultrapromax.engine.file.FileEngine
import com.example.ultrapromax.engine.gamify.GamificationEngine
import com.example.ultrapromax.engine.intelligence.CodeIntelligenceService
import com.example.ultrapromax.engine.intelligence.ProjectIntelligenceEngine
import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.run.UniversalRunEngine
import com.example.ultrapromax.engine.security.RecoveryEngine
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class EditorActivity : AppCompatActivity() {

    private lateinit var fileEngine: FileEngine
    private lateinit var gamify: GamificationEngine
    private lateinit var backupEngine: BackupEngine
    private lateinit var pluginManager: com.example.ultrapromax.engine.plugin.PluginManager
    private val buildEngine = BuildEngine()
    private val intelligenceService = CodeIntelligenceService()
    private val intelligenceEngine = ProjectIntelligenceEngine()
    private var intelligenceSnapshot: ProjectIntelligenceEngine.Snapshot? = null
    private val universalRunEngine by lazy {
        UniversalRunEngine(File(filesDir, "runtimes"))
    }

    private val aiEngine = RuleBasedAiEngine()
    private lateinit var recoveryEngine: RecoveryEngine

    private var project: Project? = null
    private var currentFile: File? = null
    private var isDirty = false
    private var wordWrapEnabled = false
    private lateinit var unlimitedWorkspace: UnlimitedWorkspaceEngine

    private val openFiles = mutableListOf<File>()
    private val prlyRunning = AtomicBoolean(false)

    private lateinit var tabStrip: LinearLayout
    private lateinit var codeEditor: EditText
    private lateinit var currentFileName: TextView
    private lateinit var lineNumbers: LineNumberView
    private lateinit var undoRedoManager: UndoRedoManager
    private lateinit var autocompleteManager: AutocompleteManager

    private lateinit var studioDrawer: LinearLayout
    private lateinit var statusPosition: TextView
    private lateinit var statusLanguage: TextView
    private lateinit var fileStatus: TextView


    /* ===================================================== */
    /* STUDIO WORKSPACE TOOLS                               */
    /* ===================================================== */

    private fun setupAutosave() {
        codeEditor.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                autosaveRunnable?.let { autosaveHandler.removeCallbacks(it) }
                val target = currentFile
                val currentProject = project
                if (target != null && currentProject != null && isDirty) {
                    val targetFile = target
                    val projectId = currentProject.id
                    val snapshot = s?.toString() ?: ""
                    autosaveRunnable = Runnable {
                        recoveryEngine.saveDraft(projectId, targetFile, snapshot)
                    }
                    autosaveHandler.postDelayed(autosaveRunnable!!, 1200L)
                }
            }
        })
    }

    private fun selectAllLines() {
        codeEditor.setSelection(0, codeEditor.text.length)
        Toast.makeText(this, "All lines selected", Toast.LENGTH_SHORT).show()
    }

    private fun showProjectSearchDialog(selectFile: Boolean = false) {
        val root = project?.folderPath?.let { File(it) } ?: return
        val input = EditText(this)
        input.hint = "Search project..."
        input.setSingleLine(true)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpToPx(16), 0, dpToPx(16), 0)
        box.addView(input)
        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(results)
        box.addView(scroll, LinearLayout.LayoutParams(-1, dpToPx(240)))
        val dialog = AlertDialog.Builder(this).setTitle(if (selectFile) "Go to File" else "Search in Project").setView(box).setNegativeButton("Close", null).create()
        fun refresh() {
            results.removeAllViews()
            val q = input.text.toString().trim().toLowerCase()
            root.walkTopDown().filter { it.isFile && !it.path.contains("/.gradle/") && !it.path.contains("/build/") }.forEach { f ->
                val content = try { f.readText() } catch (_: Exception) { "" }
                val match = if (q.isEmpty()) true else f.name.toLowerCase().contains(q) || content.toLowerCase().contains(q)
                if (match) {
                    val row = TextView(this).apply {
                        text = if (selectFile || q.isEmpty()) f.relativeTo(root).path else "${f.relativeTo(root).path}  •  ${content.split("\n").count { it.toLowerCase().contains(q) }} match"
                        setTextColor(Color.parseColor("#D6DEEB")); textSize = 12f; gravity = Gravity.CENTER_VERTICAL
                        setPadding(dpToPx(10), 0, dpToPx(10), 0)
                        layoutParams = LinearLayout.LayoutParams(-1, dpToPx(38))
                        setOnClickListener { dialog.dismiss(); openFile(f, false); refreshFileList(root) }
                    }
                    results.addView(row)
                }
            }
            if (results.childCount == 0) results.addView(TextView(this).apply { text="No results"; setTextColor(Color.GRAY); setPadding(10,10,10,10) })
        }
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { refresh() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        dialog.setOnShowListener { refresh() }
        dialog.show()
    }

    private fun showSymbolsDialog() {
        val text = codeEditor.text.toString()
        val language = currentFile?.let { EditorEngine.languageForFileName(it.name) } ?: "text"
        val patterns = when (language) {
            "kt", "kotlin", "java" -> arrayOf("\\b(?:class|interface|object|fun|void|[A-Za-z_][A-Za-z0-9_]*\\s+)([A-Za-z_][A-Za-z0-9_]*)\\s*(?:\\(|\\{)")
            "py", "python" -> arrayOf("\\b(?:def|class)\\s+([A-Za-z_][A-Za-z0-9_]*)")
            "js", "javascript", "ts", "typescript" -> arrayOf("\\b(?:function|class|const|let|var)\\s+([A-Za-z_$][A-Za-z0-9_$]*)")
            else -> arrayOf("\\b(?:class|function|fun|def)\\s+([A-Za-z_][A-Za-z0-9_]*)")
        }
        val symbols = mutableListOf<Pair<String, Int>>()
        patterns.forEach { p -> Regex(p).findAll(text).forEach { m ->
            val name = if (m.groupValues.size > 1) m.groupValues[1] else m.value.trim()
            symbols.add(Pair(name, text.substring(0, m.range.first).count { it == '\n' } + 1))
        } }
        val labels = if (symbols.isEmpty()) arrayOf("No symbols found") else symbols.map { "${it.first}   • line ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Symbols").setItems(labels) { _, which ->
            if (symbols.isNotEmpty()) {
                val line = symbols[which].second
                gotoLine(line)
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun gotoLine(line: Int) {
        val lines = codeEditor.text.toString().split("\n")
        var pos = 0
        var i = 0
        while (i < line - 1 && i < lines.size) { pos += lines[i].length + 1; i++ }
        codeEditor.requestFocus(); codeEditor.setSelection(pos.coerceAtMost(codeEditor.text.length))
    }

    private fun showInspectorDialog() {
        val f = currentFile
        val p = project
        val msg = if (f == null) "No file selected\n\nProject: ${p?.name ?: "-"}" else {
            val size = try { f.length() } catch (_: Exception) { 0L }
            "File\n${f.name}\n\nPath\n${f.absolutePath}\n\nSize\n$size bytes\n\nLanguage\n${EditorEngine.languageForFileName(f.name)}\n\nStatus\n${fileStatus.text}"
        }
        AlertDialog.Builder(this).setTitle("Inspector").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun showAssetManagerDialog() {
        val root = project?.folderPath?.let { File(it) } ?: return
        val assets = root.walkTopDown().filter { it.isFile && (it.extension.toLowerCase() in listOf("png","jpg","jpeg","webp","gif","svg","mp3","wav","ogg","json","ttf","otf")) }.toList()
        val msg = if (assets.isEmpty()) "No assets found.\n\nSupported: images, audio, fonts and JSON." else assets.joinToString("\n") { "• ${it.relativeTo(root).path} (${it.length()} B)" }
        AlertDialog.Builder(this).setTitle("Asset Manager").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun showProjectSettingsDialog() {
        val p = project
        val root = p?.folderPath?.let { File(it) }
        val msg = "Project: ${p?.name ?: "-"}\n\nFolder: ${root?.absolutePath ?: "-"}\n\nFiles: ${root?.walkTopDown()?.count { it.isFile } ?: 0}\n\nRun: Universal Runner\nBuild: Debug Builder\nOutput: PRLY package"
        AlertDialog.Builder(this).setTitle("Project Settings").setMessage(msg).setPositiveButton("OK", null).show()
    }

    /* ===================================================== */
    /* CODE CHECK                                            */
    /* ===================================================== */

    private lateinit var btnCodeCheck: TextView
    private lateinit var codeCheckResult: TextView
    private lateinit var btnProblems: TextView

    private var lastProblems =
        mutableListOf<CodeProblem>()

    /* ===================================================== */
    /* LIVE DIAGNOSTICS                                      */
    /* ===================================================== */

    private val diagnosticsHandler =
        Handler(Looper.getMainLooper())

    private var diagnosticsRunnable: Runnable? = null

    private var suppressLiveCheck = false

    private val LIVE_CHECK_DELAY = 350L

    private val autosaveHandler = Handler(Looper.getMainLooper())
    private var autosaveRunnable: Runnable? = null

    /* ===================================================== */
    /* LIFECYCLE                                             */
    /* ===================================================== */

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_editor
        )

        fileEngine =
            FileEngine(this)

        gamify =
            GamificationEngine(this)

        backupEngine =
            BackupEngine(this)

        unlimitedWorkspace = UnlimitedWorkspaceEngine(this)

        recoveryEngine = RecoveryEngine(this)

        pluginManager =
            com.example.ultrapromax.engine.plugin.PluginManager(this)
        com.example.ultrapromax.engine.plugin.BuiltInPlugins.registerAll(pluginManager)

        tabStrip =
            findViewById(R.id.tabStrip)

        codeEditor =
            findViewById(R.id.codeEditor)

        currentFileName =
            findViewById(R.id.currentFileName)

        currentFileName.contentDescription = unlimitedWorkspace.label()
        findViewById<TextView>(R.id.powerModeBadge).contentDescription = unlimitedWorkspace.label()

        lineNumbers =
            findViewById(R.id.lineNumbers)

        studioDrawer =
            findViewById(R.id.studioDrawer)

        statusPosition =
            findViewById(R.id.statusPosition)

        statusLanguage =
            findViewById(R.id.statusLanguage)

        fileStatus =
            findViewById(R.id.fileStatus)

        btnCodeCheck =
            findViewById(R.id.btnCodeCheck)

        codeCheckResult =
            findViewById(R.id.codeCheckResult)

        btnProblems =
            findViewById(R.id.btnProblems)

        lineNumbers.bindTo(
            codeEditor
        )

        undoRedoManager =
            UndoRedoManager(
                codeEditor
            )

        /*
         * Stage 4
         * Auto indent + brackets + Tab
         */
        CodeEditorHelper.attach(
            codeEditor
        )

        /*
         * Stage 5 / 5.2
         * Smart autocomplete + local symbols
         */
        autocompleteManager =
            AutocompleteManager(
                codeEditor
            )

        setupStudioNavigation()
        setupEditorTools()
        setupEditorStatus()
        setupCodeCheck()
        setupLiveDiagnostics()
        setupAutosave()

        val projectId =
            intent.getLongExtra(
                EXTRA_PROJECT_ID,
                -1L
            )

        if (projectId == -1L) {

            Toast.makeText(
                this,
                "Project not found",
                Toast.LENGTH_SHORT
            ).show()

            finish()
            return
        }

        val loadedProject =
            ProjectStore.getById(
                this,
                projectId
            )

        if (loadedProject == null) {

            Toast.makeText(
                this,
                "Project not found",
                Toast.LENGTH_SHORT
            ).show()

            finish()
            return
        }

        project =
            loadedProject

        val projectDir =
            File(
                loadedProject.folderPath
            )

        refreshProjectIntelligence(projectDir)

        val healedCount = backupEngine.autoHealIfCorrupted(projectDir, loadedProject.name)
        if (healedCount > 0) {
            Toast.makeText(
                this,
                "Self-Healing: restored $healedCount corrupted file(s) from backup",
                Toast.LENGTH_LONG
            ).show()
        }

        refreshFileList(
            projectDir
        )

        // Project Studio can open a specific nested file.  Older code ignored
        // EXTRA_FILE_PATH and always reopened the first root-level file, which
        // made every selected file appear as the same document (often
        // .gitattributes). Prefer the requested file when it belongs to this
        // project; only fall back to a sensible project file when no path was
        // supplied.
        val requestedPath = intent.getStringExtra(EXTRA_FILE_PATH)
        val requestedFile = requestedPath?.let { path ->
            try {
                val candidate = File(path).canonicalFile
                val root = projectDir.canonicalFile
                val rootPath = root.path + File.separator
                if (candidate.isFile && candidate.path.startsWith(rootPath)) candidate else null
            } catch (_: Exception) {
                null
            }
        }

        val firstFile = requestedFile ?: preferredInitialFile(projectDir)

        if (firstFile != null) {

            openFile(
                firstFile
            )

        } else {

            currentFileName.text =
                "No files"

            codeEditor.setText("")

            fileStatus.text =
                "NO FILE"

            statusLanguage.text =
                "TEXT"

            codeCheckResult.text =
                "Ready"

            btnProblems.text =
                "Problems 0"

            updateCursorStatus()
        }
    }

    private fun preferredInitialFile(root: File): File? {
        val preferredNames = listOf(
            "settings.gradle.kts",
            "settings.gradle",
            "build.gradle.kts",
            "build.gradle",
            "AndroidManifest.xml"
        )
        for (name in preferredNames) {
            val candidate = File(root, name)
            if (candidate.isFile) return candidate
        }
        return fileEngine
            .listChildren(root)
            .firstOrNull { it.isFile && !it.name.startsWith(".") }
            ?: fileEngine.listChildren(root).firstOrNull { it.isFile }
    }

    private fun refreshProjectIntelligence(root: File) {
        if (!root.isDirectory) return
        Thread {
            try {
                val snapshot = intelligenceEngine.inspect(root)
                intelligenceSnapshot = snapshot
                val names = snapshot.symbols.map { it.name }
                runOnUiThread {
                    if (::autocompleteManager.isInitialized) {
                        autocompleteManager.setProjectSuggestions(names)
                    }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private fun currentWord(): String {
        val text = codeEditor.text.toString()
        var end = codeEditor.selectionStart.coerceIn(0, text.length)
        while (end > 0 && (text[end - 1].isLetterOrDigit() || text[end - 1] == '_' || text[end - 1] == '$')) end--
        var start = codeEditor.selectionStart.coerceIn(0, text.length)
        while (start < text.length && (text[start].isLetterOrDigit() || text[start] == '_' || text[start] == '$')) start++
        return text.substring(end, start).trim()
    }

    private fun showDefinition() {
        val word = currentWord()
        if (word.isEmpty()) { Toast.makeText(this, "Place cursor on a symbol", Toast.LENGTH_SHORT).show(); return }
        val symbol = intelligenceService.definition(word, currentFile?.absolutePath)
        if (symbol == null) { Toast.makeText(this, "Definition not found: $word", Toast.LENGTH_SHORT).show(); return }
        val target = File(symbol.filePath ?: "")
        if (target.isFile && target.absolutePath != currentFile?.absolutePath) openFile(target, true)
        gotoLine(symbol.line)
        Toast.makeText(this, "Definition: ${symbol.name} • line ${symbol.line}", Toast.LENGTH_SHORT).show()
    }

    private fun showReferences() {
        val word = currentWord()
        if (word.isEmpty()) { Toast.makeText(this, "Place cursor on a symbol", Toast.LENGTH_SHORT).show(); return }
        val symbol = intelligenceService.definition(word, currentFile?.absolutePath)
        val root = project?.folderPath?.let { File(it) }
        if (symbol == null || root == null) { Toast.makeText(this, "Symbol not found: $word", Toast.LENGTH_SHORT).show(); return }
        val refs = intelligenceService.references(root, symbol)
        val labels = refs.map { "${it.file.relativeTo(root).path} • line ${it.line}" }.toTypedArray()
        if (labels.isEmpty()) { Toast.makeText(this, "No references found", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("References • $word").setItems(labels) { _, which ->
            val ref = refs[which]
            openFile(ref.file, true)
            gotoLine(ref.line)
        }.setNegativeButton("Close", null).show()
    }

    private fun showIntelligenceStatus() {
        val s = intelligenceSnapshot
        if (s == null) { Toast.makeText(this, "Project intelligence is still indexing...", Toast.LENGTH_SHORT).show(); return }
        val languages = s.languages.joinToString("\n") { "${it.label}: ${it.files} files / ${it.lines} lines" }
        val modules = s.modules.joinToString("\n") { "${it.name}: ${it.kind}" }
        AlertDialog.Builder(this)
            .setTitle("Project Intelligence")
            .setMessage("Files: ${s.files}\nFolders: ${s.folders}\nLines: ${s.lines}\nSymbols: ${s.symbols.size}\n\nLanguages\n$languages\n\nModules\n${modules.ifEmpty { "None detected" }}")
            .setPositiveButton("Refresh") { _, _ -> project?.folderPath?.let { refreshProjectIntelligence(File(it)) } }
            .setNegativeButton("Close", null).show()
    }

    /* ===================================================== */
    /* STUDIO NAVIGATION                                     */
    /* ===================================================== */

    private fun setupStudioNavigation() {

        findViewById<TextView>(
            R.id.btnStudioMenu
        ).setOnClickListener {

            studioDrawer.visibility =
                View.VISIBLE
        }

        findViewById<TextView>(
            R.id.btnCloseDrawer
        ).setOnClickListener {

            studioDrawer.visibility =
                View.GONE
        }

        findViewById<TextView>(
            R.id.btnRun
        ).setOnClickListener {
            runProject()
        }

        findViewById<TextView>(
            R.id.btnBuild
        ).setOnClickListener {
            buildProject(false)
        }

        findViewById<TextView>(
            R.id.btnPrly
        ).setOnClickListener {
            exportPrlyPackage()
        }

        findViewById<TextView>(
            R.id.btnMore
        ).setOnClickListener {

            showMoreMenu()
        }

        setupTopMenuBar()

        findViewById<TextView>(
            R.id.drawerRun
        ).setOnClickListener {
            studioDrawer.visibility = View.GONE
            runProject()
        }

        findViewById<TextView>(
            R.id.drawerBuild
        ).setOnClickListener {
            studioDrawer.visibility = View.GONE
            buildProject(false)
        }
    }

    /* ===================================================== */
    /* REAL TOP MENU BAR                                     */
    /* ===================================================== */

    private fun copySelection() {
        val start = codeEditor.selectionStart.coerceAtLeast(0)
        val end = codeEditor.selectionEnd.coerceAtLeast(0)
        val from = minOf(start, end)
        val to = maxOf(start, end)
        if (from == to) {
            Toast.makeText(this, "Select text first", Toast.LENGTH_SHORT).show()
            return
        }
        val text = codeEditor.text.subSequence(from, to).toString()
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("DEVSTUDIO", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun cutSelection() {
        val start = codeEditor.selectionStart.coerceAtLeast(0)
        val end = codeEditor.selectionEnd.coerceAtLeast(0)
        val from = minOf(start, end)
        val to = maxOf(start, end)
        if (from == to) {
            Toast.makeText(this, "Select text first", Toast.LENGTH_SHORT).show()
            return
        }
        val text = codeEditor.text.subSequence(from, to).toString()
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("DEVSTUDIO", text))
        codeEditor.text.delete(from, to)
        codeEditor.setSelection(from)
        Toast.makeText(this, "Cut", Toast.LENGTH_SHORT).show()
    }

    private fun pasteClipboard() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        if (!clipboard.hasPrimaryClip()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val clip = clipboard.primaryClip
        val item = if (clip != null && clip.itemCount > 0) clip.getItemAt(0) else null
        val text = item?.coerceToText(this)?.toString() ?: ""
        if (text.isEmpty()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val start = codeEditor.selectionStart.coerceAtLeast(0)
        val end = codeEditor.selectionEnd.coerceAtLeast(0)
        val from = minOf(start, end)
        val to = maxOf(start, end)
        codeEditor.text.replace(from, to, text)
        codeEditor.setSelection(from + text.length)
        Toast.makeText(this, "Pasted", Toast.LENGTH_SHORT).show()
    }

    private fun setupTopMenuBar() {
        findViewById<TextView>(R.id.menuFile).setOnClickListener { showStudioMenu(it, "File", arrayOf(
            "New File", "Open Project Files", "Save", "Save As", "Backup", "Close File"
        )) { which ->
            when (which) {
                0 -> addFile()
                1 -> { studioDrawer.visibility = View.VISIBLE }
                2 -> saveCurrentFile()
                3 -> saveAsCurrentFile()
                4 -> showBackupDialog()
                5 -> currentFile?.let { closeTab(it) }
            }
        } }

        findViewById<TextView>(R.id.menuEdit).setOnClickListener { showStudioMenu(it, "Edit", arrayOf(
            "Undo", "Redo", "Cut", "Copy", "Paste", "Select All", "Select Line", "Duplicate Line", "Delete Line", "Find / Replace", "Select All Lines", "Auto Fix"
        )) { which ->
            when (which) {
                0 -> undoRedoManager.undo()
                1 -> undoRedoManager.redo()
                2 -> cutSelection()
                3 -> copySelection()
                4 -> pasteClipboard()
                5 -> codeEditor.selectAll()
                6 -> selectCurrentLine()
                7 -> duplicateCurrentLine()
                8 -> deleteCurrentLine()
                9 -> SearchReplaceManager(this, codeEditor).show()
                10 -> selectAllLines()
                11 -> runAutoFix()
            }
            markDirty()
            updateCursorStatus()
        } }

        findViewById<TextView>(R.id.menuView).setOnClickListener { showStudioMenu(it, "View", arrayOf(
            "Preview", "Problems", "Output", "Terminal", "Project Files", "UI Builder", "Inspector", "Project Search", "Symbols", "Toggle Word Wrap", "Editor Font Size"
        )) { which ->
            when (which) {
                0 -> openPreview()
                1 -> showProblems()
                2 -> showOutputPanel()
                3 -> showTerminalPanel()
                4 -> studioDrawer.visibility = View.VISIBLE
                5 -> showUiBuilderDialog()
                6 -> showInspectorDialog()
                7 -> showProjectSearchDialog()
                8 -> showSymbolsDialog()
                9 -> toggleWordWrap()
                10 -> showFontSizeDialog()
            }
        } }

        findViewById<TextView>(R.id.menuNavigate).setOnClickListener { showStudioMenu(it, "Navigate", arrayOf(
            "Project Files", "Go to File", "Go to Line", "Go to Symbol", "Go to Definition", "Find References", "Project Intelligence", "First Line", "Last Line", "Current File"
        )) { which ->
            when (which) {
                0 -> studioDrawer.visibility = View.VISIBLE
                1 -> showProjectSearchDialog(true)
                2 -> showGoToLineDialog()
                3 -> showSymbolsDialog()
                4 -> showDefinition()
                5 -> showReferences()
                6 -> showIntelligenceStatus()
                7 -> { codeEditor.setSelection(0); codeEditor.requestFocus() }
                8 -> { codeEditor.setSelection(codeEditor.text.length); codeEditor.requestFocus() }
                9 -> Toast.makeText(this, currentFile?.name ?: "No file", Toast.LENGTH_SHORT).show()
            }
        } }

        findViewById<TextView>(R.id.menuCode).setOnClickListener { showStudioMenu(it, "Code", arrayOf(
            "Check Code", "Auto Fix", "AI Assistant", "Format Document", "Select Word", "Find Matching Bracket", "Find / Replace", "Toggle Comment", "Indent", "Outdent", "Go to Symbol", "Go to Definition", "Find References", "Duplicate Line", "Delete Line"
        )) { which ->
            when (which) {
                0 -> runCodeCheck(true)
                1 -> runAutoFix()
                2 -> showOfflineAiPanel()
                3 -> {
                    val language = currentFile?.let { EditorEngine.languageForFileName(it.name) } ?: "text"
                    val formatted = UniversalEditorEngine.format(codeEditor.text.toString(), language)
                    codeEditor.setText(formatted)
                    codeEditor.setSelection(formatted.length.coerceAtMost(codeEditor.text.length))
                    markDirty()
                    Toast.makeText(this, "Document formatted", Toast.LENGTH_SHORT).show()
                }
                4 -> UniversalEditorEngine.selectCurrentWord(codeEditor)
                5 -> {
                    val match = UniversalEditorEngine.matchingBracketPosition(codeEditor.text.toString(), codeEditor.selectionStart)
                    if (match == null) Toast.makeText(this, "Matching bracket not found", Toast.LENGTH_SHORT).show()
                    else { codeEditor.setSelection(match); Toast.makeText(this, "Matching bracket", Toast.LENGTH_SHORT).show() }
                }
                6 -> SearchReplaceManager(this, codeEditor).show()
                7 -> toggleComment()
                8 -> indentSelection()
                9 -> outdentSelection()
                10 -> showSymbolsDialog()
                11 -> showDefinition()
                12 -> showReferences()
                13 -> duplicateCurrentLine()
                14 -> deleteCurrentLine()
            }
        } }

        findViewById<TextView>(R.id.menuBuild).setOnClickListener { showStudioMenu(it, "Build", arrayOf(
            "Build Debug APK", "Check Code", "Create PRLY Package"
        )) { which ->
            when (which) {
                0 -> buildProject(false)
                1 -> runCodeCheck(true)
                2 -> exportPrlyPackage()
            }
        } }

        findViewById<TextView>(R.id.menuRun).setOnClickListener { showStudioMenu(it, "Run", arrayOf(
            "▶ Run Project", "Preview", "Check Code"
        )) { which ->
            when (which) {
                0 -> runProject()
                1 -> openPreview()
                2 -> runCodeCheck(true)
            }
        } }

        findViewById<TextView>(R.id.menuTools).setOnClickListener { showStudioMenu(it, "Tools", arrayOf(
            "UI Builder", "Backup", "Terminal", "Output", "Problems", "Asset Manager", "Project Settings", "Inspector"
        )) { which ->
            when (which) {
                0 -> showUiBuilderDialog()
                1 -> showBackupDialog()
                2 -> showTerminalPanel()
                3 -> showOutputPanel()
                4 -> showProblems()
                5 -> showAssetManagerDialog()
                6 -> showProjectSettingsDialog()
                7 -> showInspectorDialog()
            }
        } }

        findViewById<TextView>(R.id.menuHelp).setOnClickListener { showStudioMenu(it, "Help", arrayOf(
            "About DEVSTUDIO", "Runtime Status", "Editor Status"
        )) { which ->
            when (which) {
                0 -> showAboutDialog()
                1 -> Toast.makeText(this, "Runtime registry: ready", Toast.LENGTH_SHORT).show()
                2 -> Toast.makeText(this, "${fileStatus.text} • ${statusLanguage.text}", Toast.LENGTH_SHORT).show()
            }
        } }
    }

    private fun showAboutDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("DEVSTUDIO ULTRA PRO MAX+")
            .setMessage("Offline-first mobile IDE\n\nBuild • Run • PRLY\nReal project inspection and local toolchain integration.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showStudioMenu(anchor: View, title: String, items: Array<String>, action: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.setColor(Color.parseColor("#151C28"))
        bg.setStroke(dpToPx(1), Color.parseColor("#354056"))
        bg.cornerRadius = dpToPx(12).toFloat()
        box.background = bg

        val heading = TextView(this)
        heading.text = title.toUpperCase()
        heading.setTextColor(Color.parseColor("#B47CFF"))
        heading.textSize = 11f
        heading.setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
        box.addView(heading)

        items.forEachIndexed { index, label ->
            val row = TextView(this)
            row.text = label
            row.setTextColor(Color.parseColor("#D6DEEB"))
            row.textSize = 14f
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dpToPx(14), 0, dpToPx(14), 0)
            row.layoutParams = LinearLayout.LayoutParams(-1, dpToPx(44))
            row.setOnClickListener { action(index) }
            box.addView(row)
        }

        val popup = PopupWindow(box, dpToPx(250), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(bg)
        popup.isOutsideTouchable = true
        popup.elevation = dpToPx(10).toFloat()
        items.forEachIndexed { index, _ ->
            val row = box.getChildAt(index + 1)
            row.setOnClickListener {
                popup.dismiss()
                action(index)
            }
        }
        popup.showAsDropDown(anchor, -dpToPx(20), dpToPx(4))
    }

    private fun exportPrlyPackage() {
        val p = project ?: return
        saveCurrentFile()
        val i = Intent(this, MonitorActivity::class.java)
        i.putExtra(MonitorActivity.EXTRA_PROJECT_ID, p.id)
        i.putExtra(MonitorActivity.EXTRA_MODE, MonitorActivity.MODE_PRLY)
        startActivity(i)
    }

    /* ===================================================== */
    /* V22 OFFLINE AI PANEL                                  */
    /* ===================================================== */

    private var aiPopup: PopupWindow? = null

    private fun showOfflineAiPanel() {
        aiPopup?.dismiss()
        val root = project?.folderPath?.let { File(it) }
        val agent = OfflineAiAgentEngine(root)
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(10))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.setColor(Color.parseColor("#111824"))
        bg.setStroke(dpToPx(1), Color.parseColor("#35456A"))
        bg.cornerRadius = dpToPx(16).toFloat()
        panel.background = bg

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "✦  Offline AI Assistant"
        title.setTextColor(Color.parseColor("#E7E9FF"))
        title.textSize = 15f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, dpToPx(42), 1f))
        val close = TextView(this)
        close.text = "×"
        close.textSize = 25f
        close.gravity = Gravity.CENTER
        close.setTextColor(Color.parseColor("#AEB8C8"))
        header.addView(close, LinearLayout.LayoutParams(dpToPx(42), dpToPx(42)))
        panel.addView(header)

        val status = TextView(this)
        status.text = "OFFLINE • Project context enabled"
        status.setTextColor(Color.parseColor("#55D6A5"))
        status.textSize = 10f
        status.setPadding(dpToPx(8), 0, dpToPx(8), dpToPx(6))
        panel.addView(status)

        val scroll = ScrollView(this)
        val chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        scroll.addView(chat)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun addChat(text: String, user: Boolean) {
            val bubble = TextView(this)
            bubble.text = text
            bubble.setTextColor(if (user) Color.WHITE else Color.parseColor("#D6DEEB"))
            bubble.textSize = 13f
            bubble.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            bubble.setBackgroundColor(if (user) Color.parseColor("#3A2A78") else Color.parseColor("#192232"))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dpToPx(4), 0, dpToPx(4))
            chat.addView(bubble, lp)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }

        addChat("سلام! من AI آفلاین سبک v22 هستم. درباره کد یا همین پروژه سؤال بپرس.", false)

        lateinit var ask: Runnable

        // Declare the chat input before preset button listeners capture it.
        val input = EditText(this)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val presets = arrayOf("تحلیل پروژه", "بررسی کد", "فایل‌ها")
        presets.forEach { label ->
            val b = TextView(this)
            b.text = label
            b.gravity = Gravity.CENTER
            b.setTextColor(Color.parseColor("#D6DEEB"))
            b.textSize = 10f
            b.setPadding(dpToPx(5), 0, dpToPx(5), 0)
            b.setBackgroundColor(Color.parseColor("#202A3A"))
            b.setOnClickListener {
                input.setText(label)
                ask.run()
            }
            actions.addView(b, LinearLayout.LayoutParams(0, dpToPx(36), 1f))
        }
        panel.addView(actions)

        val inputRow = LinearLayout(this)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.gravity = Gravity.CENTER_VERTICAL
        input.hint = "سؤال خود را بنویسید..."
        input.setTextColor(Color.parseColor("#E7E9FF"))
        input.setHintTextColor(Color.parseColor("#68758A"))
        input.setSingleLine(true)
        input.setBackgroundColor(Color.parseColor("#0B1018"))
        input.setPadding(dpToPx(10), 0, dpToPx(10), 0)
        inputRow.addView(input, LinearLayout.LayoutParams(0, dpToPx(48), 1f))
        val send = TextView(this)
        send.text = "➤"
        send.gravity = Gravity.CENTER
        send.textSize = 20f
        send.setTextColor(Color.WHITE)
        send.setBackgroundColor(Color.parseColor("#6A4DFF"))
        inputRow.addView(send, LinearLayout.LayoutParams(dpToPx(52), dpToPx(48)))
        panel.addView(inputRow)

        ask = Runnable {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@Runnable
            addChat(q, true)
            val f = currentFile
            val text = try { codeEditor.text.toString() } catch (_: Exception) { "" }
            val result = agent.ask(q, f, text)
            addChat(result.text, false)
            if (result.action == OfflineAiAgentEngine.Action.FIX_CURRENT_FILE) {
                val fix = TextView(this)
                fix.text = "اجرای Auto Fix"
                fix.gravity = Gravity.CENTER
                fix.setTextColor(Color.WHITE)
                fix.setBackgroundColor(Color.parseColor("#4B35A6"))
                fix.setPadding(0, dpToPx(8), 0, dpToPx(8))
                fix.setOnClickListener {
                    val target = currentFile ?: return@setOnClickListener
                    val language = EditorEngine.languageForFileName(target.name)
                    val fixed = RuleBasedAiEngine().autoFix(codeEditor.text.toString(), language)
                    codeEditor.setText(fixed)
                    markDirty()
                    addChat("✓ Auto Fix روی ${target.name} اعمال شد. فایل هنوز ذخیره نشده است.", false)
                    fix.visibility = View.GONE
                }
                chat.addView(fix, LinearLayout.LayoutParams(-1, dpToPx(42)))
            }
            input.setText("")
        }
        send.setOnClickListener { ask.run() }
        input.setOnEditorActionListener { _, _, _ -> ask.run(); true }
        close.setOnClickListener { aiPopup?.dismiss() }

        aiPopup = PopupWindow(panel, popupWidth(), -1, true)
        aiPopup?.setBackgroundDrawable(bg)
        aiPopup?.isOutsideTouchable = true
        aiPopup?.elevation = dpToPx(10).toFloat()
        aiPopup?.showAtLocation(codeEditor, Gravity.RIGHT or Gravity.TOP, dpToPx(6), dpToPx(74))
    }

    private fun popupWidth(): Int {
        val width = resources.displayMetrics.widthPixels
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        return if (landscape) (width * 0.38f).toInt().coerceAtLeast(dpToPx(300)) else (width * 0.92f).toInt()
    }

    /* ===================================================== */
    /* EDITOR TOOLS                                          */
    /* ===================================================== */

    private fun setupEditorTools() {

        findViewById<TextView>(
            R.id.btnUndo
        ).setOnClickListener {

            undoRedoManager.undo()

            updateCursorStatus()

            scheduleLiveCheck()
        }

        findViewById<TextView>(
            R.id.btnRedo
        ).setOnClickListener {

            undoRedoManager.redo()

            updateCursorStatus()

            scheduleLiveCheck()
        }

        findViewById<TextView>(
            R.id.btnAddFile
        ).setOnClickListener {

            studioDrawer.visibility =
                View.GONE

            addFile()
        }

        findViewById<TextView>(
            R.id.btnSave
        ).setOnClickListener {

            saveCurrentFile()

            fileStatus.text =
                "SAVED"

            Toast.makeText(
                this,
                "Saved",
                Toast.LENGTH_SHORT
            ).show()
        }

        findViewById<TextView>(
            R.id.btnAi
        ).setOnClickListener {
            showOfflineAiPanel()
        }

        findViewById<TextView>(
            R.id.btnPreview
        ).setOnClickListener {

            openPreview()
        }

        findViewById<TextView>(
            R.id.btnSearch
        ).setOnClickListener {

            SearchReplaceManager(
                this,
                codeEditor
            ).show()
        }

        findViewById<TextView>(
            R.id.btnAutoFix
        ).setOnClickListener {

            runAutoFix()
        }

        findViewById<TextView>(
            R.id.btnBackup
        ).setOnClickListener {

            showBackupDialog()
        }

        findViewById<TextView>(
            R.id.btnUiBuilder
        ).setOnClickListener {

            showUiBuilderDialog()
        }

        btnProblems.setOnClickListener {

            showProblems()
        }

        findViewById<TextView>(
            R.id.btnOutput
        ).setOnClickListener {

            showOutputPanel()
        }

        findViewById<TextView>(
            R.id.btnTerminal
        ).setOnClickListener {

            showTerminalPanel()
        }
    }


    /* ===================================================== */
    /* CODE CHECK                                            */
    /* ===================================================== */

    private fun setupCodeCheck() {

        btnCodeCheck.setOnClickListener {

            cancelLiveCheck()

            runCodeCheck(
                true
            )
        }
    }

    /* ===================================================== */
    /* LIVE DIAGNOSTICS                                      */
    /* ===================================================== */

    private fun setupLiveDiagnostics() {

        codeEditor.addTextChangedListener(
            object : android.text.TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {

                    if (!suppressLiveCheck && currentFile != null) {
                        markDirty()
                    }
                    updateCursorStatus()

                    if (!suppressLiveCheck) {
                        scheduleLiveCheck()
                    }
                }

                override fun afterTextChanged(
                    s: android.text.Editable?
                ) {
                }
            }
        )
    }

    private fun scheduleLiveCheck() {

        cancelLiveCheck()

        if (suppressLiveCheck) {
            return
        }

        diagnosticsRunnable =
            Runnable {

                runCodeCheck(
                    false
                )
            }

        diagnosticsHandler.postDelayed(
            diagnosticsRunnable!!,
            LIVE_CHECK_DELAY
        )
    }

    private fun cancelLiveCheck() {

        diagnosticsRunnable?.let {

            diagnosticsHandler.removeCallbacks(
                it
            )
        }

        diagnosticsRunnable =
            null
    }

    private fun runCodeCheck(
        showChecking: Boolean
    ) {

        val source =
            codeEditor.text.toString()

        if (
            source.trim().isEmpty()
        ) {

            lastProblems.clear()

            codeCheckResult.text =
                "Ready"

            codeCheckResult.setTextColor(
                Color.parseColor(
                    "#8FA1B8"
                )
            )

            btnProblems.text =
                "Problems 0"

            fileStatus.text =
                "READY"

            return
        }

        if (showChecking) {

            codeCheckResult.text =
                "Checking..."

            codeCheckResult.setTextColor(
                Color.parseColor(
                    "#B47CFF"
                )
            )
        }

        val file =
            currentFile

        val language =
            if (file != null) {

                EditorEngine
                    .languageForFileName(
                        file.name
                    )

            } else {

                "text"
            }

        lastProblems =
            CodeCheckEngine
                .check(
                    source,
                    language
                )
                .toMutableList()

        updateDiagnosticsUI()
    }

    private fun updateDiagnosticsUI() {

        if (
            lastProblems.isEmpty()
        ) {

            codeCheckResult.text =
                "✓ No problems"

            codeCheckResult.setTextColor(
                Color.parseColor(
                    "#9BE7B0"
                )
            )

            btnProblems.text =
                "Problems 0"

            fileStatus.text =
                "VALID"

        } else {

            val count =
                lastProblems.size

            codeCheckResult.text =
                "❌ $count problem(s)"

            codeCheckResult.setTextColor(
                Color.parseColor(
                    "#FF7B7B"
                )
            )

            btnProblems.text =
                "Problems $count"

            fileStatus.text =
                "ERRORS"
        }
    }

    private fun showProblems() {
        if (lastProblems.isEmpty()) {
            codeCheckResult.text = "✓ No problems"
            codeCheckResult.setTextColor(Color.parseColor("#9BE7B0"))
            Toast.makeText(this, "No problems found", Toast.LENGTH_SHORT).show()
            return
        }

        val labels = lastProblems.map {
            "Line ${it.line}  •  ${it.message}"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Problems (${lastProblems.size})")
            .setItems(labels) { _, which ->
                gotoLine(lastProblems[which].line)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /* ===================================================== */
    /* STATUS                                                */
    /* ===================================================== */

    private fun setupEditorStatus() {

        codeEditor
            .setOnSelectionChangedListenerCompat {

                updateCursorStatus()
            }
    }

    private fun updateCursorStatus() {

        val cursor =
            codeEditor.selectionStart

        if (cursor < 0) {
            return
        }

        val text =
            codeEditor.text.toString()

        val safeCursor =
            if (
                cursor > text.length
            ) {
                text.length
            } else {
                cursor
            }

        val before =
            text.substring(
                0,
                safeCursor
            )

        val line =
            before.count {
                it == '\n'
            } + 1

        val lastNewLine =
            before.lastIndexOf(
                '\n'
            )

        val column =
            if (
                lastNewLine == -1
            ) {

                safeCursor + 1

            } else {

                safeCursor -
                    lastNewLine
            }

        statusPosition.text =
            "Ln $line, Col $column"
    }

    /* ===================================================== */
    /* FILE LIST                                             */
    /* ===================================================== */

    private fun refreshFileList(
        dir: File
    ) {
        val container =
            findViewById<LinearLayout>(R.id.fileList)

        container.removeAllViews()

        val header = TextView(this).apply {
            text = "  📁 ${dir.name}"
            setTextColor(Color.parseColor("#C8D1E0"))
            textSize = 12f
            setPadding(0, 0, 0, 0)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(36)
            )
            layoutParams = params
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        container.addView(header)

        val files = fileEngine.listChildren(dir).filter { it.isFile }
        if (files.isEmpty()) {
            val empty = TextView(this).apply {
                text = "  (no files yet)"
                setTextColor(Color.parseColor("#667085"))
                textSize = 12f
                setPadding(dpToPx(20), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(34)
                )
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            container.addView(empty)
            return
        }

        files.forEach { file ->
            val row = TextView(this).apply {
                text = "  ${file.name}"
                setTextColor(
                    if (file == currentFile) Color.parseColor("#B47CFF") else Color.parseColor("#AEB8C8")
                )
                textSize = 12f
                setPadding(dpToPx(20), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(34)
                )
                gravity = android.view.Gravity.CENTER_VERTICAL
                setOnClickListener {
                    studioDrawer.visibility = View.GONE
                    openFile(file, false)
                    refreshFileList(dir)
                }
                setOnLongClickListener {
                    showFileActions(file, dir)
                    true
                }
            }
            container.addView(row)
        }
    }


    private fun showFileActions(file: File, root: File) {
        val items = arrayOf("Open", "Rename", "Duplicate", "Delete", "Inspect")
        AlertDialog.Builder(this).setTitle(file.name).setItems(items) { _, which ->
            when (which) {
                0 -> openFile(file, false)
                1 -> {
                    val input = EditText(this); input.setSingleLine(true); input.setText(file.name); input.selectAll()
                    AlertDialog.Builder(this).setTitle("Rename").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Rename") { _, _ ->
                        val n = input.text.toString().trim()
                        if (n.isNotEmpty() && n != file.name && !n.contains("/") && !n.contains("\\")) {
                            val renamed = fileEngine.rename(file, n)
                            if (currentFile == file) currentFile = renamed
                            openFiles.remove(file); if (!openFiles.contains(renamed)) openFiles.add(renamed)
                            refreshFileList(root); refreshTabs(); openFile(renamed, false)
                        }
                    }.show()
                }
                2 -> {
                    val copy = File(root, file.nameWithoutExtension + "_copy" + if (file.extension.isEmpty()) "" else ".${file.extension}")
                    if (!copy.exists()) copy.writeText(try { file.readText() } catch (_: Exception) { "" })
                    refreshFileList(root)
                }
                3 -> {
                    AlertDialog.Builder(this).setTitle("Delete file?").setMessage(file.name).setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                        if (currentFile == file) { openFiles.remove(file); currentFile = null; codeEditor.setText(""); currentFileName.text = "No files" }
                        fileEngine.delete(file); refreshFileList(root); refreshTabs()
                    }.show()
                }
                4 -> showInspectorForFile(file)
            }
        }.show()
    }

    private fun showInspectorForFile(file: File) {
        AlertDialog.Builder(this).setTitle("Inspector").setMessage("${file.name}\n\n${file.absolutePath}\n\n${file.length()} bytes").setPositiveButton("OK", null).show()
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    /* ===================================================== */
    /* TABS                                                  */
    /* ===================================================== */

    private fun refreshTabs() {

        tabStrip.removeAllViews()

        for (
            file in openFiles
        ) {

            val row =
                LinearLayout(this).apply {

                    orientation =
                        LinearLayout.HORIZONTAL

                    gravity =
                        android.view.Gravity
                            .CENTER_VERTICAL

                    setPadding(
                        14,
                        0,
                        8,
                        0
                    )

                    setBackgroundColor(
                        if (
                            file ==
                            currentFile
                        ) {

                            Color.parseColor(
                                "#242044"
                            )

                        } else {

                            Color.parseColor(
                                "#101321"
                            )
                        }
                    )
                }

            val label =
                TextView(this).apply {

                    text =
                        if (file == currentFile && isDirty) "* ${file.name}" else file.name

                    setTextColor(
                        if (
                            file ==
                            currentFile
                        ) {

                            Color.WHITE

                        } else {

                            Color.parseColor(
                                "#9691AD"
                            )
                        }
                    )

                    textSize =
                        12f

                    setPadding(
                        4,
                        0,
                        10,
                        0
                    )

                    setOnClickListener {

                        openFile(
                            file,
                            false
                        )
                    }
                }

            val close =
                TextView(this).apply {

                    text =
                        "×"

                    setTextColor(
                        Color.parseColor(
                            "#AAA5BD"
                        )
                    )

                    textSize =
                        18f

                    setPadding(
                        5,
                        0,
                        5,
                        0
                    )

                    setOnClickListener {

                        closeTab(
                            file
                        )
                    }
                }

            row.addView(
                label
            )

            row.addView(
                close
            )

            tabStrip.addView(
                row
            )
        }
    }

    /* ===================================================== */
    /* ADD FILE                                              */
    /* ===================================================== */

    private fun addFile() {
        val input = EditText(this)
        input.hint = "example.py / index.html / Main.kt"
        input.setSingleLine(true)
        input.setPadding(dpToPx(16), 0, dpToPx(16), 0)

        AlertDialog.Builder(this)
            .setTitle("New File")
            .setMessage("Choose a file name and extension")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val currentProject = project ?: return@setPositiveButton
                var name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "File name is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (name.contains("/") || name.contains("\\")) {
                    Toast.makeText(this, "Invalid file name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (!name.contains(".")) name += ".txt"
                val dir = File(currentProject.folderPath)
                val file = fileEngine.createFile(dir, name, "")
                refreshFileList(dir)
                gamify.onFileCreated().forEach { achievement ->
                    Toast.makeText(this, "Achievement unlocked: ${achievement.title} (+${achievement.xpReward} XP)", Toast.LENGTH_LONG).show()
                }
                openFile(file)
            }
            .show()
    }

    private fun saveAsCurrentFile() {
        val file = currentFile ?: run {
            Toast.makeText(this, "No file is open", Toast.LENGTH_SHORT).show()
            return
        }
        val input = EditText(this)
        input.setSingleLine(true)
        input.setText(file.name)
        input.selectAll()
        AlertDialog.Builder(this)
            .setTitle("Save As")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                var name = input.text.toString().trim()
                if (name.isEmpty() || name.contains("/") || name.contains("\\")) {
                    Toast.makeText(this, "Invalid file name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val dir = file.parentFile ?: return@setPositiveButton
                val target = File(dir, name)
                if (target != file && target.exists()) {
                    Toast.makeText(this, "File already exists", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                fileEngine.writeText(target, codeEditor.text.toString())
                if (target != file) {
                    openFiles.remove(file)
                    openFiles.add(target)
                    currentFile = target
                }
                isDirty = false
                currentFileName.text = target.name
                refreshFileList(dir)
                refreshTabs()
                Toast.makeText(this, "Saved as ${target.name}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    /* ===================================================== */
    /* OPEN FILE                                             */
    /* ===================================================== */

    private fun openFile(
        file: File,
        addTab: Boolean
    ) {

        if (
            currentFile != null &&
            currentFile != file
        ) {
            saveCurrentFile()
        }

        if (
            !openFiles.contains(file)
        ) {
            openFiles.add(file)
        }

        currentFile =
            file
        isDirty = false

        currentFileName.text =
            file.name

        suppressLiveCheck =
            true

        codeEditor.setText(
            fileEngine.readText(file)
        )

        codeEditor.setSelection(
            codeEditor.text.length
        )

        suppressLiveCheck =
            false

        undoRedoManager.clearHistory()

        val recoveryProject = project
        if (recoveryProject != null && recoveryEngine.hasDraft(recoveryProject.id, file)) {
            AlertDialog.Builder(this)
                .setTitle("Recover unsaved changes?")
                .setMessage("A newer local draft was found for ${file.name}. Restore it?")
                .setNegativeButton("Discard") { _, _ -> recoveryEngine.clearDraft(recoveryProject.id, file) }
                .setPositiveButton("Restore") { _, _ ->
                    val draft = recoveryEngine.readDraft(recoveryProject.id, file)
                    if (draft != null) {
                        suppressLiveCheck = true
                        codeEditor.setText(draft)
                        codeEditor.setSelection(codeEditor.text.length)
                        suppressLiveCheck = false
                        isDirty = true
                        fileStatus.text = "RECOVERED"
                        scheduleLiveCheck()
                    }
                }
                .show()
        }

        val language =
            EditorEngine
                .languageForFileName(
                    file.name
                )

        autocompleteManager
            .setLanguage(
                language
            )

        EditorEngine.attachHighlighting(
            codeEditor,
            language
        )

        statusLanguage.text =
            language.toUpperCase()

        fileStatus.text =
            "READY"

        cancelLiveCheck()

        lastProblems.clear()

        btnProblems.text =
            "Problems 0"

        codeCheckResult.text =
            "Checking..."

        codeCheckResult.setTextColor(
            Color.parseColor(
                "#B47CFF"
            )
        )

        refreshTabs()

        updateCursorStatus()

        scheduleLiveCheck()
    }

    private fun openFile(
        file: File
    ) {

        openFile(
            file,
            true
        )
    }

    /* ===================================================== */
    /* CLOSE TAB                                             */
    /* ===================================================== */

    private fun closeTab(
        file: File
    ) {
        if (file == currentFile && isDirty) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved Changes")
                .setMessage("Save changes to ${file.name} before closing?")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Discard") { _, _ -> closeTabNow(file) }
                .setPositiveButton("Save") { _, _ ->
                    saveCurrentFile()
                    closeTabNow(file)
                }
                .show()
            return
        }
        closeTabNow(file)
    }

    private fun closeTabNow(
        file: File
    ) {

        openFiles.remove(
            file
        )

        if (
            currentFile == file
        ) {

            val nextFile =
                openFiles.lastOrNull()

            if (nextFile != null) {

                openFile(
                    nextFile,
                    false
                )

            } else {

                currentFile =
                    null
                isDirty = false

                currentFileName.text =
                    "No file"

                suppressLiveCheck =
                    true

                codeEditor.setText("")

                suppressLiveCheck =
                    false

                fileStatus.text =
                    "NO FILE"

                statusLanguage.text =
                    "TEXT"

                lastProblems.clear()

                btnProblems.text =
                    "Problems 0"

                codeCheckResult.text =
                    "Ready"

                refreshTabs()

                updateCursorStatus()
            }

        } else {

            refreshTabs()
        }
    }

    private fun markDirty() {
        if (currentFile != null) {
            isDirty = true
            fileStatus.text = "MODIFIED"
            refreshTabs()
        }
    }

    private fun selectionBounds(): Pair<Int, Int> {
        val start = codeEditor.selectionStart.coerceAtLeast(0)
        val end = codeEditor.selectionEnd.coerceAtLeast(0)
        return Pair(minOf(start, end), maxOf(start, end))
    }

    private fun selectCurrentLine() {
        val text = codeEditor.text.toString()
        if (text.isEmpty()) return
        val cursor = codeEditor.selectionStart.coerceIn(0, text.length)
        val start = text.lastIndexOf('\n', (cursor - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endIndex = text.indexOf('\n', cursor)
        val end = if (endIndex < 0) text.length else endIndex
        codeEditor.setSelection(start, end)
        codeEditor.requestFocus()
    }

    private fun duplicateCurrentLine() {
        val text = codeEditor.text.toString()
        if (text.isEmpty()) return
        val cursor = codeEditor.selectionStart.coerceIn(0, text.length)
        val start = text.lastIndexOf('\n', (cursor - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endIndex = text.indexOf('\n', cursor)
        val end = if (endIndex < 0) text.length else endIndex
        val line = text.substring(start, end)
        val insertAt = if (end < text.length) end + 1 else end
        val insertion = line + if (end < text.length) "\n" else "\n"
        suppressLiveCheck = true
        codeEditor.text.insert(insertAt, insertion)
        codeEditor.setSelection(insertAt + insertion.length)
        suppressLiveCheck = false
        markDirty()
        scheduleLiveCheck()
    }

    private fun deleteCurrentLine() {
        val text = codeEditor.text.toString()
        if (text.isEmpty()) return
        val cursor = codeEditor.selectionStart.coerceIn(0, text.length)
        val start = text.lastIndexOf('\n', (cursor - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endIndex = text.indexOf('\n', cursor)
        val end = if (endIndex < 0) text.length else endIndex + 1
        suppressLiveCheck = true
        codeEditor.text.delete(start, end)
        codeEditor.setSelection(start.coerceAtMost(codeEditor.text.length))
        suppressLiveCheck = false
        markDirty()
        scheduleLiveCheck()
    }

    private fun indentSelection() {
        val (from, to) = selectionBounds()
        val text = codeEditor.text.toString()
        val lineStart = text.lastIndexOf('\n', (from - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endLine = text.indexOf('\n', to)
        val lineEnd = if (endLine < 0) text.length else endLine
        val block = text.substring(lineStart, lineEnd)
        val updated = block.split("\n").joinToString("\n") { "    " + it }
        suppressLiveCheck = true
        codeEditor.text.replace(lineStart, lineEnd, updated)
        codeEditor.setSelection((to + (updated.length - block.length)).coerceAtMost(codeEditor.text.length))
        suppressLiveCheck = false
        markDirty()
        scheduleLiveCheck()
    }

    private fun outdentSelection() {
        val (from, to) = selectionBounds()
        val text = codeEditor.text.toString()
        val lineStart = text.lastIndexOf('\n', (from - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endLine = text.indexOf('\n', to)
        val lineEnd = if (endLine < 0) text.length else endLine
        val block = text.substring(lineStart, lineEnd)
        val updated = block.split("\n").joinToString("\n") { line ->
            when {
                line.startsWith("    ") -> line.substring(4)
                line.startsWith("\t") -> line.substring(1)
                line.startsWith(" ") -> line.substring(1)
                else -> line
            }
        }
        suppressLiveCheck = true
        codeEditor.text.replace(lineStart, lineEnd, updated)
        codeEditor.setSelection((to - (block.length - updated.length)).coerceAtLeast(lineStart).coerceAtMost(codeEditor.text.length))
        suppressLiveCheck = false
        markDirty()
        scheduleLiveCheck()
    }

    private fun toggleComment() {
        val text = codeEditor.text.toString()
        val (from, to) = selectionBounds()
        val lineStart = text.lastIndexOf('\n', (from - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val endLine = text.indexOf('\n', to)
        val lineEnd = if (endLine < 0) text.length else endLine
        val block = text.substring(lineStart, lineEnd)
        val fileName = currentFile?.name?.toLowerCase() ?: ""
        val prefix = if (fileName.endsWith(".py") || fileName.endsWith(".sh") || fileName.endsWith(".rb") || fileName.endsWith(".pl") || fileName.endsWith(".lua")) "#" else "//"
        val lines = block.split("\n")
        val allCommented = lines.filter { it.trim().isNotEmpty() }.all { it.trimStart().startsWith(prefix) }
        val updated = lines.joinToString("\n") { line ->
            if (line.trim().isEmpty()) line
            else if (allCommented) {
                val leading = line.takeWhile { it == ' ' || it == '\t' }
                val body = line.substring(leading.length)
                if (body.startsWith(prefix + " ")) leading + body.substring(prefix.length + 1) else leading + body.substring(prefix.length)
            } else {
                val leading = line.takeWhile { it == ' ' || it == '\t' }
                leading + prefix + " " + line.substring(leading.length)
            }
        }
        suppressLiveCheck = true
        codeEditor.text.replace(lineStart, lineEnd, updated)
        codeEditor.setSelection((lineStart + updated.length).coerceAtMost(codeEditor.text.length))
        suppressLiveCheck = false
        markDirty()
        scheduleLiveCheck()
    }

    private fun showGoToLineDialog() {
        val input = EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        input.setSingleLine(true)
        input.hint = "Line number"
        AlertDialog.Builder(this)
            .setTitle("Go to Line")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Go") { _, _ ->
                val target = input.text.toString().toIntOrNull() ?: 1
                val text = codeEditor.text.toString()
                var pos = 0
                var line = 1
                while (line < target && pos < text.length) {
                    val next = text.indexOf('\n', pos)
                    if (next < 0) break
                    pos = next + 1
                    line++
                }
                codeEditor.setSelection(pos.coerceAtMost(text.length))
                codeEditor.requestFocus()
                updateCursorStatus()
            }
            .show()
    }

    private fun toggleWordWrap() {
        wordWrapEnabled = !wordWrapEnabled
        codeEditor.setHorizontallyScrolling(!wordWrapEnabled)
        codeEditor.setHorizontalScrollBarEnabled(!wordWrapEnabled)
        Toast.makeText(this, if (wordWrapEnabled) "Word wrap ON" else "Word wrap OFF", Toast.LENGTH_SHORT).show()
    }

    private fun showFontSizeDialog() {
        val sizes = arrayOf("10sp", "12sp", "14sp", "16sp", "18sp", "20sp")
        val current = codeEditor.textSize / resources.displayMetrics.scaledDensity
        var selected = sizes.indices.minBy { kotlin.math.abs(sizes[it].removeSuffix("sp").toFloat() - current) } ?: 0
        AlertDialog.Builder(this)
            .setTitle("Editor Font Size")
            .setSingleChoiceItems(sizes, selected) { dialog, which ->
                selected = which
                codeEditor.textSize = sizes[which].removeSuffix("sp").toFloat()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /* ===================================================== */
    /* SAVE                                                  */
    /* ===================================================== */

    override fun onPause() {
        super.onPause()
        // Persist the current editor buffer when the activity leaves the foreground.
        if (currentFile != null && isDirty) {
            saveCurrentFile()
        }
    }

    private fun saveCurrentFile() {

        val file =
            currentFile ?: return

        var content = codeEditor.text.toString()
        val language = EditorEngine.languageForFileName(file.name)

        if (pluginManager.isEnabledById("auto_formatter")) {
            content = com.example.ultrapromax.engine.plugin.BuiltInPlugins.autoFormatter.format(content, language)
        }

        fileEngine.writeText(
            file,
            content
        )
        isDirty = false
        project?.let { p -> recoveryEngine.clearDraft(p.id, file) }
        refreshTabs()

        if (pluginManager.isEnabledById("git_backup") &&
            com.example.ultrapromax.engine.plugin.BuiltInPlugins.gitBackup.shouldSnapshotNow()
        ) {
            project?.let { p -> backupEngine.backup(File(p.folderPath), p.name) }
        }

        fileStatus.text =
            "SAVED"
    }

    /* ===================================================== */
    /* BUILD / RUN                                           */
    /* ===================================================== */

    private fun runProject() {
        saveCurrentFile()
        val p = project ?: return
        val i = Intent(this, MonitorActivity::class.java)
        i.putExtra(MonitorActivity.EXTRA_PROJECT_ID, p.id)
        i.putExtra(MonitorActivity.EXTRA_MODE, MonitorActivity.MODE_RUN)
        currentFile?.let { i.putExtra(MonitorActivity.EXTRA_TARGET, it.absolutePath) }
        startActivity(i)
    }

    private fun showRunResult(success: Boolean, language: String, output: String) {
        showFullOutputDialog(
            if (success) "Run • $language" else "Run failed • $language",
            output.ifBlank { if (success) "Program finished successfully." else "No output.\n\nCheck Output/Terminal for details." }
        )
    }

    private fun showFullOutputDialog(title: String, output: String) {
        val text = TextView(this).apply {
            setTextColor(Color.BLACK)
            textSize = 12f
            setText(output)
            setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12))
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(text, ViewGroup.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun buildProject(installAfterBuild: Boolean) {
        saveCurrentFile()
        val p = project ?: return
        val i = Intent(this, MonitorActivity::class.java)
        i.putExtra(MonitorActivity.EXTRA_PROJECT_ID, p.id)
        i.putExtra(MonitorActivity.EXTRA_MODE, MonitorActivity.MODE_BUILD)
        i.putExtra("monitor_install_after_build", installAfterBuild)
        startActivity(i)
    }

    private fun showBuildResult(success: Boolean, output: String) {
        showFullOutputDialog(
            if (success) "Build successful" else "Build failed",
            output.ifBlank { "No build output was returned.\n\nCheck Output/Terminal." }
        )
    }

    /* ===================================================== */
    /* PREVIEW                                               */
    /* ===================================================== */

    private fun openPreview() {

        saveCurrentFile()

        val currentProject =
            project ?: return

        val dir =
            File(
                currentProject.folderPath
            )

        val intent =
            Intent(
                this,
                PreviewActivity::class.java
            )

        intent.putExtra(
            PreviewActivity.EXTRA_PROJECT_DIR,
            dir.absolutePath
        )

        startActivity(
            intent
        )
    }

    /* ===================================================== */
    /* AUTO FIX                                              */
    /* ===================================================== */

    private fun runAutoFix() {

        val file =
            currentFile ?: return

        val language =
            EditorEngine
                .languageForFileName(
                    file.name
                )

        val fixed =
            aiEngine.autoFix(
                codeEditor.text.toString(),
                language
            )

        suppressLiveCheck =
            true

        codeEditor.setText(
            fixed
        )

        codeEditor.setSelection(
            codeEditor.text.length
        )

        suppressLiveCheck =
            false

        lastProblems.clear()

        btnProblems.text =
            "Problems 0"

        codeCheckResult.text =
            "Checking..."

        codeCheckResult.setTextColor(
            Color.parseColor(
                "#B47CFF"
            )
        )

        Toast.makeText(
            this,
            "Auto Fix applied",
            Toast.LENGTH_SHORT
        ).show()

        scheduleLiveCheck()
    }

    /* ===================================================== */
    /* BACKUP                                                */
    /* ===================================================== */

    private fun showBackupDialog() {

        val currentProject =
            project ?: return

        val dir =
            File(
                currentProject.folderPath
            )

        val options =
            arrayOf(
                "Create backup now",
                "Restore from backup",
                "Export minified (.zip)"
            )

        AlertDialog.Builder(this)
            .setTitle(
                "Backup"
            )
            .setItems(
                options
            ) { _, which ->

                if (which == 0) {

                    saveCurrentFile()

                    backupEngine.backup(
                        dir,
                        currentProject.name
                    )

                    gamify
                        .onBuildExported()
                        .forEach { achievement ->

                            Toast.makeText(
                                this,
                                "Achievement unlocked: " +
                                    "${achievement.title} " +
                                    "(+${achievement.xpReward} XP)",
                                Toast.LENGTH_LONG
                            ).show()
                        }

                    Toast.makeText(
                        this,
                        "Backup created",
                        Toast.LENGTH_SHORT
                    ).show()

                } else if (which == 2) {

                    if (!pluginManager.isEnabledById("minifier")) {
                        Toast.makeText(
                            this,
                            "Enable the Minifier plugin first (Plugins screen)",
                            Toast.LENGTH_LONG
                        ).show()
                        return@setItems
                    }

                    saveCurrentFile()
                    val zip = backupEngine.exportMinified(dir, currentProject.name)
                    Toast.makeText(
                        this,
                        "Minified export created: ${zip.name}",
                        Toast.LENGTH_LONG
                    ).show()

                } else {

                    val backups =
                        backupEngine.listBackups(
                            currentProject.name
                        )

                    if (
                        backups.isEmpty()
                    ) {

                        Toast.makeText(
                            this,
                            "No backups yet",
                            Toast.LENGTH_SHORT
                        ).show()

                        return@setItems
                    }

                    val names =
                        backups
                            .map {
                                it.name
                            }
                            .toTypedArray()

                    AlertDialog.Builder(
                        this
                    )
                        .setTitle(
                            "Choose a backup to restore"
                        )
                        .setItems(
                            names
                        ) { _, index ->

                            backupEngine.restore(
                                backups[index],
                                dir
                            )

                            Toast.makeText(
                                this,
                                "Restored",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        .show()
                }
            }
            .show()
    }

    /* ===================================================== */
    /* UI BUILDER                                            */
    /* ===================================================== */

    /*
     * Built directly into EditorActivity.
     *
     * No UiBuilderEngine.kt is required.
     *
     * This version works with the existing
     * Android/Kotlin 1.3.72 toolchain.
     */
    private fun showUiBuilderDialog() {

        val file =
            currentFile

        if (
            file == null ||
            !file.name.endsWith(
                ".html",
                ignoreCase = true
            )
        ) {

            Toast.makeText(
                this,
                "Open an .html file first",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val items =
            arrayOf(
                "🖐 Visual Builder (drag & drop)",
                "HTML Page",
                "Heading",
                "Paragraph",
                "Button",
                "Text Input",
                "Image",
                "Link",
                "Card",
                "Container",
                "List",
                "Form",
                "CSS Style"
            )

        AlertDialog.Builder(this)
            .setTitle(
                "UI Builder"
            )
            .setItems(
                items
            ) { _, which ->

                if (which == 0) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(
                        Intent(this, UiBuilderActivity::class.java),
                        UiBuilderActivity.REQUEST_CODE
                    )
                    return@setItems
                }

                val component =
                    createHtmlComponent(
                        which - 1
                    )

                insertUiComponent(
                    component
                )
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == UiBuilderActivity.REQUEST_CODE && resultCode == RESULT_OK) {
            val html = data?.getStringExtra(UiBuilderActivity.EXTRA_GENERATED_HTML)
            if (!html.isNullOrBlank()) {
                insertUiComponent(html)
            }
        }
    }

    private fun createHtmlComponent(
        type: Int
    ): String {

        return when (type) {

            0 ->
                """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEVSTUDIO</title>
</head>
<body>

</body>
</html>
                """.trimIndent()

            1 ->
                """
<h1>Heading</h1>
                """.trimIndent()

            2 ->
                """
<p>Write your text here...</p>
                """.trimIndent()

            3 ->
                """
<button type="button">Button</button>
                """.trimIndent()

            4 ->
                """
<input type="text" placeholder="Enter text">
                """.trimIndent()

            5 ->
                """
<img src="image.png" alt="Image">
                """.trimIndent()

            6 ->
                """
<a href="#">Link</a>
                """.trimIndent()

            7 ->
                """
<div class="card">
    <h2>Card Title</h2>
    <p>Card content...</p>
</div>
                """.trimIndent()

            8 ->
                """
<div class="container">

</div>
                """.trimIndent()

            9 ->
                """
<ul>
    <li>Item 1</li>
    <li>Item 2</li>
    <li>Item 3</li>
</ul>
                """.trimIndent()

            10 ->
                """
<form>
    <input type="text" placeholder="Name">
    <button type="submit">Submit</button>
</form>
                """.trimIndent()

            11 ->
                """
<style>
    body {
        font-family: sans-serif;
        margin: 20px;
    }

    .card {
        padding: 16px;
        border-radius: 10px;
        border: 1px solid #444444;
    }
</style>
                """.trimIndent()

            else ->
                ""
        }
    }

    private fun insertUiComponent(
        component: String
    ) {

        if (
            component.trim().isEmpty()
        ) {
            return
        }

        val oldText =
            codeEditor.text.toString()

        val cursor =
            codeEditor.selectionStart

        val safeCursor =
            if (
                cursor < 0 ||
                cursor > oldText.length
            ) {
                oldText.length
            } else {
                cursor
            }

        val before =
            oldText.substring(
                0,
                safeCursor
            )

        val after =
            oldText.substring(
                safeCursor
            )

        val updated =
            before +
                "\n" +
                component +
                "\n" +
                after

        suppressLiveCheck =
            true

        codeEditor.setText(
            updated
        )

        val newCursor =
            before.length +
                component.length +
                2

        val finalCursor =
            if (
                newCursor > codeEditor.text.length
            ) {
                codeEditor.text.length
            } else {
                newCursor
            }

        codeEditor.setSelection(
            finalCursor
        )

        suppressLiveCheck =
            false

        scheduleLiveCheck()

        Toast.makeText(
            this,
            "Component inserted",
            Toast.LENGTH_SHORT
        ).show()
    }

    /* ===================================================== */
    /* OUTPUT                                                */
    /* ===================================================== */

    private fun showOutputPanel() {

        val message =
            if (lastProblems.isEmpty()) {
                "Build Output\n\nNo current errors."
            } else {
                val builder =
                    StringBuilder()

                builder.append(
                    "Build Output\n\n"
                )

                for (
                    problem in lastProblems
                ) {

                    builder.append(
                        "Line "
                    )

                    builder.append(
                        problem.line
                    )

                    builder.append(
                        ": "
                    )

                    builder.append(
                        problem.message
                    )

                    builder.append(
                        "\n"
                    )
                }

                builder.toString()
            }

        AlertDialog.Builder(this)
            .setTitle(
                "Output"
            )
            .setMessage(
                message
            )
            .setPositiveButton(
                "Close",
                null
            )
            .show()
    }

    /* ===================================================== */
    /* TERMINAL                                              */
    /* ===================================================== */

    private fun showTerminalPanel() {

        val terminalText =
            """
DEVSTUDIO TERMINAL

> project: ${project?.name ?: "none"}

> current file:
${currentFile?.name ?: "none"}

> status:
${fileStatus.text}

> language:
${statusLanguage.text}

Terminal engine is ready.
            """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle(
                "Terminal"
            )
            .setMessage(
                terminalText
            )
            .setPositiveButton(
                "Close",
                null
            )
            .show()
    }

    /* ===================================================== */
    /* MORE MENU                                             */
    /* ===================================================== */

    private fun showMoreMenu() {

        val items =
            arrayOf(
                "Save",
                "Preview",
                "Search",
                "Auto Fix",
                "Backup",
                "UI Builder",
                "Check Code"
            )

        AlertDialog.Builder(this)
            .setTitle(
                "DEVSTUDIO"
            )
            .setItems(
                items
            ) { _, which ->

                when (which) {

                    0 ->
                        saveCurrentFile()

                    1 ->
                        openPreview()

                    2 ->
                        SearchReplaceManager(
                            this,
                            codeEditor
                        ).show()

                    3 ->
                        runAutoFix()

                    4 ->
                        showBackupDialog()

                    5 ->
                        showUiBuilderDialog()

                    6 ->
                        runCodeCheck(
                            true
                        )
                }
            }
            .show()
    }

    /* ===================================================== */
    /* DESTROY                                               */
    /* ===================================================== */

    override fun onDestroy() {

        autosaveRunnable?.let { autosaveHandler.removeCallbacks(it) }
        if (isDirty) {
            val target = currentFile
            val currentProject = project
            if (target != null && currentProject != null) {
                recoveryEngine.saveDraft(currentProject.id, target, codeEditor.text.toString())
            }
        }

        cancelLiveCheck()

        diagnosticsHandler.removeCallbacksAndMessages(
            null
        )

        super.onDestroy()
    }

    /* ===================================================== */
    /* BACK BUTTON                                           */
    /* ===================================================== */

    override fun onBackPressed() {

        if (
            studioDrawer.visibility ==
            View.VISIBLE
        ) {

            studioDrawer.visibility =
                View.GONE

            return
        }

        saveCurrentFile()

        super.onBackPressed()
    }

    companion object {

        const val EXTRA_FILE_PATH = "extra_file_path"
        const val EXTRA_PROJECT_ID =
            "extra_project_id"
    }
}


/* ========================================================= */
/* CURSOR COMPATIBILITY                                      */
/* ========================================================= */

private fun EditText.setOnSelectionChangedListenerCompat(
    listener: () -> Unit
) {

    addTextChangedListener(
        object : android.text.TextWatcher {

            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {

                listener()
            }

            override fun afterTextChanged(
                s: android.text.Editable?
            ) {

                listener()
            }
        }
    )
}