package com.example.ultrapromax.engine.language.symbol

data class SymbolScope(
    val name: String?,
    val startLine: Int,
    val endLine: Int,
    val parent: String? = null
) {
    fun contains(line: Int): Boolean = line >= startLine && line <= endLine
}
