package com.example.ultrapromax.nextupdate.testing

data class VerificationCheck(val id: String, val passed: Boolean, val message: String)

data class VerificationReport(val checks: List<VerificationCheck>) {
    val passed: Boolean get() = checks.all { it.passed }
}

class VerificationEngine {
    fun report(checks: List<VerificationCheck>): VerificationReport = VerificationReport(checks)
}
