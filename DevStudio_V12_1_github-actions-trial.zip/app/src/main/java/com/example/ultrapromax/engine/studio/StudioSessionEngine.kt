package com.example.ultrapromax.engine.studio

import android.content.Context
import java.io.File

/** V26.3 lightweight Studio session persistence. */
class StudioSessionEngine(private val context: Context) {

    data class Session(
        val projectId: Long,
        val openFiles: List<String>,
        val activeFile: String?,
        val savedAt: Long
    )

    private val sessionFile: File
        get() = File(context.filesDir, "studio_session.state")

    fun save(session: Session): Boolean {
        return try {
            val safeFiles = session.openFiles
                .filter { it.isNotBlank() }
                .joinToString(";") { it.replace(";", "_").replace("\n", "_") }
            val active = (session.activeFile ?: "")
                .replace(";", "_")
                .replace("\n", "_")
            val text = "${session.projectId}\n$safeFiles\n$active\n${session.savedAt}\n"
            atomicWrite(sessionFile, text)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun load(): Session? {
        if (!sessionFile.isFile) return null
        return try {
            val lines = sessionFile.readLines()
            if (lines.size < 4) return null
            val projectId = lines[0].toLongOrNull() ?: return null
            val files = if (lines[1].isBlank()) emptyList() else lines[1].split(";")
            val active = lines[2].ifBlank { null }
            val savedAt = lines[3].toLongOrNull() ?: 0L
            Session(projectId, files, active, savedAt)
        } catch (_: Exception) {
            null
        }
    }

    fun clear(): Boolean = try {
        !sessionFile.exists() || sessionFile.delete()
    } catch (_: Exception) {
        false
    }

    fun hasSession(): Boolean = sessionFile.isFile && sessionFile.length() > 0L

    private fun atomicWrite(target: File, text: String) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp")
        temp.writeText(text)
        if (target.exists() && !target.delete()) {
            temp.delete()
            return
        }
        if (!temp.renameTo(target)) {
            target.writeText(text)
            temp.delete()
        }
    }
}
