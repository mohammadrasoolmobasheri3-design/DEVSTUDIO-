package com.example.ultrapromax.engine.dependency

import com.example.ultrapromax.engine.vfs.VirtualFileSystem
import java.io.File

/** V26.8 package/dependency facade. Local-only: it never pretends a remote artifact was downloaded. */
class PackageDependencyEngine(private val vfs: VirtualFileSystem) {
    data class ProjectDependencyReport(val sourceFiles: List<String>, val report: DependencyReport, val lockProblems: List<String>)

    fun scanGradleFiles(): List<File> {
        val result = ArrayList<File>()
        collect(vfs.root(), result)
        return result.filter { it.name == "build.gradle" || it.name == "build.gradle.kts" }
    }

    fun inspectProject(): ProjectDependencyReport {
        val records = ArrayList<DependencyRecord>()
        val sources = ArrayList<String>()
        for (file in scanGradleFiles()) {
            sources.add(vfs.relative(file))
            records.addAll(DependencyParser.parseFile(file.readText(), vfs.relative(file)))
        }
        val report = DependencyValidator.validate(records)
        val lock = DependencyLock(File(vfs.root(), ".devstudio/dependencies.lock"))
        val coordinates = report.dependencies.filter { it.status == DependencyStatus.VALID || it.status == DependencyStatus.DECLARED }.map { it.coordinate }
        return ProjectDependencyReport(sources, report, lock.check(coordinates))
    }

    fun writeLock(): Boolean {
        val coordinates = inspectProject().report.dependencies.filter { it.status == DependencyStatus.VALID || it.status == DependencyStatus.DECLARED }.map { it.coordinate }
        return DependencyLock(File(vfs.root(), ".devstudio/dependencies.lock")).write(coordinates)
    }

    fun resolveLocalArtifact(group: String, artifact: String, version: String): File? {
        val coordinate = DependencyCoordinate(group, artifact, version)
        val roots = listOf(
            File(System.getProperty("user.home", ""), ".gradle/caches/modules-2/files-2.1"),
            File(vfs.root(), ".gradle/caches/modules-2/files-2.1")
        )
        for (root in roots) {
            val versionRoot = File(File(File(root, coordinate.group), coordinate.artifact), coordinate.version)
            val found = versionRoot.walkTopDown().firstOrNull { it.isFile && (it.name == "$artifact.jar" || it.name == "$artifact.aar") }
            if (found != null) return found
        }
        return null
    }

    private fun collect(dir: File, output: MutableList<File>) {
        val children = dir.listFiles() ?: return
        for (child in children) if (child.isDirectory) collect(child, output) else output.add(child)
    }
}
