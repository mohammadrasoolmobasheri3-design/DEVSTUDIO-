package com.example.ultrapromax.engine.plugincompiler

import android.content.Context
import dalvik.system.DexClassLoader
import java.io.File

/**
 * OFFLINE PLUGIN COMPILER
 * Compiles a plain Java source file the user writes INSIDE the app into a
 * loadable plugin — zero downloads, zero internet. Pipeline:
 *   1. javac:  MyPlugin.java  ->  MyPlugin.class      (JVM bytecode)
 *   2. d8/dx:  MyPlugin.class ->  classes.dex          (Android bytecode)
 *   3. DexClassLoader loads the class and we call it via reflection.
 *
 * PLUGIN CONTRACT (kept deliberately simple so javac needs no special
 * -classpath): the class must have a public no-arg constructor and a
 * public method `String process(String input)`.
 *
 * Example plugin source a user can type directly in-app:
 *   public class MyPlugin {
 *       public String process(String input) {
 *           return input.toUpperCase();
 *       }
 *   }
 *
 * Current limitation: single-file reflection plugins only; no arbitrary plugin dependencies are fetched.
 * Java interface (needs a precompiled .class bundled as an asset to put on
 * javac's -classpath — skipped here in favor of the simpler reflection
 * contract above, which needs no extra classpath at all).
 */
class PluginCompilerEngine(private val context: Context) {

    data class CompileResult(
        val success: Boolean,
        val log: String,
        val dexJarPath: String? = null,
        val className: String? = null
    )

    data class RunResult(val success: Boolean, val output: String)

    private val pluginsDir: File
        get() = File(context.filesDir, "compiled_plugins").apply { mkdirs() }

    fun compile(className: String, javaSource: String): CompileResult {
        if (!className.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) {
            return CompileResult(false, "Invalid Java class name.")
        }
        if (javaSource.length > 512 * 1024) {
            return CompileResult(false, "Plugin source exceeds the 512 KB local safety limit.")
        }
        if (!ToolLocator.hasCompilerToolchain()) {
            return CompileResult(
                false,
                "Compiler toolchain not found on this device.\n\n" +
                    ToolLocator.describeAvailability() +
                    "\n\nAndroidIDE normally ships javac + d8 for building your own app; " +
                    "if they're missing here, they may be sandboxed to AndroidIDE's own process only."
            )
        }

        val workDir = File(context.cacheDir, "plugin_build_${System.currentTimeMillis()}").apply { mkdirs() }
        val log = StringBuilder()

        try {
            val sourceFile = File(workDir, "$className.java")
            sourceFile.writeText(javaSource)

            // Step 1: javac
            val javac = ToolLocator.find("javac")!!
            val javacResult = runProcess(listOf(javac, "-d", workDir.absolutePath, sourceFile.absolutePath), workDir)
            log.append("javac exit=${javacResult.first}\n${javacResult.second}\n")
            if (javacResult.first != 0) {
                return CompileResult(false, log.toString())
            }

            val classFile = File(workDir, "$className.class")
            if (!classFile.exists()) {
                log.append("ERROR: $className.class was not produced\n")
                return CompileResult(false, log.toString())
            }

            // Step 2: dex conversion (prefer d8, fall back to dx)
            val d8 = ToolLocator.find("d8")
            val dx = ToolLocator.find("dx")
            val dexResult = if (d8 != null) {
                runProcess(listOf(d8, "--output", workDir.absolutePath, classFile.absolutePath), workDir)
            } else {
                runProcess(listOf(dx!!, "--dex", "--output=${File(workDir, "classes.dex").absolutePath}", classFile.absolutePath), workDir)
            }
            log.append("dex exit=${dexResult.first}\n${dexResult.second}\n")
            if (dexResult.first != 0) {
                return CompileResult(false, log.toString())
            }

            val dexFile = File(workDir, "classes.dex")
            if (!dexFile.exists()) {
                log.append("ERROR: classes.dex was not produced\n")
                return CompileResult(false, log.toString())
            }

            // Step 3: package classes.dex into a jar (DexClassLoader expects a jar/zip container)
            val outputJar = File(pluginsDir, "$className.jar")
            java.util.zip.ZipOutputStream(outputJar.outputStream()).use { zos ->
                zos.putNextEntry(java.util.zip.ZipEntry("classes.dex"))
                dexFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }

            log.append("SUCCESS: ${outputJar.name}\n")
            return CompileResult(true, log.toString(), outputJar.absolutePath, className)
        } finally {
            workDir.deleteRecursively()
        }
    }

    fun run(dexJarPath: String, className: String, input: String): RunResult {
        val jar = File(dexJarPath).canonicalFile
        val root = pluginsDir.canonicalFile
        if (!jar.isFile || !jar.absolutePath.startsWith(root.absolutePath + File.separator)) {
            return RunResult(false, "Plugin execution blocked: artifact is outside the compiled plugin sandbox.")
        }
        if (jar.length() > 5L * 1024L * 1024L) {
            return RunResult(false, "Plugin execution blocked: artifact exceeds the 5 MB safety limit.")
        }
        return try {
            val optimizedDir = File(context.cacheDir, "plugin_dex_opt").apply { mkdirs() }
            val loader = DexClassLoader(dexJarPath, optimizedDir.absolutePath, null, context.classLoader)
            val clazz = loader.loadClass(className)
            val instance = clazz.getDeclaredConstructor().newInstance()
            val method = clazz.getMethod("process", String::class.java)
            val result = method.invoke(instance, input) as? String ?: "(plugin returned no string)"
            RunResult(true, result)
        } catch (e: Exception) {
            RunResult(false, "Error running plugin: ${e.message}")
        }
    }

    fun listCompiledPlugins(): List<File> =
        pluginsDir.listFiles()?.filter { it.extension == "jar" } ?: emptyList()

    fun deletePlugin(jarFile: File): Boolean = jarFile.delete()

    private fun runProcess(command: List<String>, workDir: File): Pair<Int, String> {
        return try {
            val process = ProcessBuilder(command)
                .directory(workDir)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            exitCode to output
        } catch (e: Exception) {
            -1 to "Process failed to start: ${e.message}"
        }
    }
}
