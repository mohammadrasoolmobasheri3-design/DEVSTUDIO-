package com.example.ultrapromax.engine.buildrun

import com.example.ultrapromax.engine.diagnostics.StudioDiagnostic
import java.io.File

/** Converts common Gradle/Kotlin compiler lines into clickable Studio diagnostics. */
object BuildDiagnosticsParser {
    fun parse(output: String, projectDir: File): List<StudioDiagnostic> {
        val result = ArrayList<StudioDiagnostic>()
        val patterns = listOf(
            Regex("^e: (.+):(\\d+):(\\d+): (.+)$"),
            Regex("^(.+):(\\d+):(\\d+): (.+)$"),
            Regex("^(.+):(\\d+): (.+)$")
        )
        output.split("\n").forEach { raw ->
            val line = raw.trim()
            var matched: StudioDiagnostic? = null
            for (pattern in patterns) {
                val m = pattern.find(line) ?: continue
                val path = m.groupValues[1]
                val lineNo = m.groupValues[2].toIntOrNull() ?: 1
                val column = if (m.groupValues.size > 4) m.groupValues[3].toIntOrNull() ?: 1 else 1
                val message = if (m.groupValues.size > 4) m.groupValues[4] else m.groupValues[3]
                val severity = if (line.contains("warning", true)) "WARNING" else "ERROR"
                val file = resolvePath(path, projectDir)
                matched = StudioDiagnostic(file.absolutePath, lineNo, column, severity, message)
                break
            }
            if (matched != null) result.add(matched)
        }
        return result.distinctBy { it.filePath + ":" + it.line + ":" + it.column + ":" + it.message }
    }

    private fun resolvePath(path: String, projectDir: File): File {
        val clean = path.removePrefix("file://")
        val direct = File(clean)
        if (direct.isAbsolute) return direct
        return File(projectDir, clean)
    }
}
