package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.project.AdvancedTemplateEngine

/** Stage 18 template gallery: browse, search, preview and launch a template. */
class TemplateGalleryActivity : AppCompatActivity() {
    private lateinit var engine: AdvancedTemplateEngine
    private lateinit var searchInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_template_gallery)
        engine = AdvancedTemplateEngine(this)
        searchInput = findViewById(R.id.templateSearch)
        categorySpinner = findViewById(R.id.templateCategory)
        list = findViewById(R.id.templateList)

        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, engine.categories())
        findViewById<Button>(R.id.btnTemplateBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnTemplateSearch).setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val category = categorySpinner.selectedItem?.toString() ?: "All"
        val results = engine.search(searchInput.text.toString(), category)
        if (results.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No templates found."
                setTextColor(Color.parseColor("#9AA4C0"))
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
            return
        }
        results.forEach { addTemplateCard(it) }
    }

    private fun addTemplateCard(definition: AdvancedTemplateEngine.Definition) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundResource(R.drawable.glass_card)
        }
        val title = TextView(this).apply {
            text = (if (engine.isFavorite(definition.template.id)) "★  " else "☆  ") + definition.template.displayName
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val info = TextView(this).apply {
            text = "${definition.category}  •  ${if (definition.buildable) "Android Build" else "Studio Template"}\n${definition.description}\nTags: ${definition.tags.joinToString(", ")}"
            setTextColor(Color.parseColor("#B8C2D8"))
            textSize = 12f
            setPadding(0, dp(7), 0, dp(9))
        }
        val actions = LinearLayout(this).apply { gravity = Gravity.END }
        val preview = Button(this).apply {
            text = "PREVIEW"
            setOnClickListener { showPreview(definition) }
        }
        val favorite = Button(this).apply {
            text = if (engine.isFavorite(definition.template.id)) "UNFAVORITE" else "FAVORITE"
            setOnClickListener {
                engine.setFavorite(definition.template.id, !engine.isFavorite(definition.template.id))
                refresh()
            }
        }
        val use = Button(this).apply {
            text = "USE TEMPLATE"
            setOnClickListener { useTemplate(definition) }
        }
        actions.addView(preview)
        actions.addView(favorite)
        actions.addView(use)
        card.addView(title)
        card.addView(info)
        card.addView(actions)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(10))
        list.addView(card, lp)
    }

    private fun showPreview(definition: AdvancedTemplateEngine.Definition) {
        val preview = engine.preview(definition)
        val files = if (preview.files.isEmpty()) "(empty scaffold)" else preview.files.joinToString("\n") { "• $it" }
        android.app.AlertDialog.Builder(this)
            .setTitle("${definition.template.displayName}  •  Preview")
            .setMessage("${definition.description}\n\nFiles: ${preview.totalFiles}\nSize: ${preview.totalBytes} bytes\n\n$files")
            .setPositiveButton("USE TEMPLATE") { _, _ -> useTemplate(definition) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun useTemplate(definition: AdvancedTemplateEngine.Definition) {
        startActivity(Intent(this, AdvancedNewProjectActivity::class.java).apply {
            putExtra(AdvancedNewProjectActivity.EXTRA_TEMPLATE_ID, definition.template.id)
        })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
