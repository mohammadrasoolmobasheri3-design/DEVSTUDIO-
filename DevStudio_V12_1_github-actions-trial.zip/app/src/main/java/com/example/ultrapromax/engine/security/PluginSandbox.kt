package com.example.ultrapromax.engine.security

import com.example.ultrapromax.engine.plugin.Plugin
import com.example.ultrapromax.engine.plugin.PluginPermission
import java.io.File

/**
 * DEVSTUDIO v21 plugin sandbox. Built-in plugins are still in-process, but
 * every sensitive project operation can be gated by an explicit permission.
 * No shell/process execution or network-to-internet capability is exposed.
 */
class PluginSandbox(private val projectRoot: File, private val plugin: Plugin) {

    fun can(permission: PluginPermission): Boolean = plugin.permissions.contains(permission)

    fun require(permission: PluginPermission) {
        if (!can(permission)) throw SecurityException("Plugin ${plugin.id} lacks $permission permission")
    }

    fun resolve(relativePath: String, write: Boolean = false): File {
        require(if (write) PluginPermission.PROJECT_WRITE else PluginPermission.PROJECT_READ)
        val root = projectRoot.canonicalFile
        val target = File(root, relativePath).canonicalFile
        if (!SecurityEngine.isInsideSandbox(root, target)) {
            throw SecurityException("Sandbox path escape blocked")
        }
        return target
    }

    fun readText(relativePath: String): String = resolve(relativePath).readText()

    fun writeText(relativePath: String, content: String) {
        val target = resolve(relativePath, true)
        target.parentFile?.mkdirs()
        target.writeText(content)
    }

    fun projectInfo(): String {
        require(PluginPermission.PROJECT_READ)
        val files = projectRoot.walkTopDown().count { it.isFile }
        return "files=$files; root=${projectRoot.canonicalPath}"
    }
}
