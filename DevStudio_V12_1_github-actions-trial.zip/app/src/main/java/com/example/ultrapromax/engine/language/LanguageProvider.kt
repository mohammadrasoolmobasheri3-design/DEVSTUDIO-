package com.example.ultrapromax.engine.language

import com.example.ultrapromax.engine.language.parser.ParseResult

interface LanguageProvider {
    fun definition(): LanguageDefinition
    fun parse(source: String): ParseResult
}
