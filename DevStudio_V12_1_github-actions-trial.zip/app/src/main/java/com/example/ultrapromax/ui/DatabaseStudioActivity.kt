package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.databasestudio.DatabaseStudioEngine
import java.io.File

/** ENDGAME Stage 7 — Database Studio. Real local SQLite; external databases are shown missing until a real adapter exists. */
class DatabaseStudioActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var engine: DatabaseStudioEngine
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var profile: Spinner
    private lateinit var sql: EditText
    private lateinit var migrationName: EditText
    private lateinit var migrationSql: EditText
    private lateinit var table: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_database_studio)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        engine = DatabaseStudioEngine(File(project.folderPath), File(filesDir, "runtimes"))
        status = findViewById(R.id.dsStatus); output = findViewById(R.id.dsOutput); profile = findViewById(R.id.dsProfile)
        sql = findViewById(R.id.dsSql); migrationName = findViewById(R.id.dsMigrationName); migrationSql = findViewById(R.id.dsMigrationSql); table = findViewById(R.id.dsTable)
        val ps = engine.profiles(); profile.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ps.map { it.name })
        profile.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { engine.select(ps[position].id); render() }
        }
        findViewById<TextView>(R.id.dsBack).setOnClickListener { engine.close(); finish() }
        findViewById<Button>(R.id.dsOpen).setOnClickListener { append(if (engine.open()) "DATABASE OPENED: ${engine.databaseFile().absolutePath}" else "OPEN BLOCKED: ${engine.readiness()}"); render() }
        findViewById<Button>(R.id.dsClose).setOnClickListener { engine.close(); append("DATABASE CLOSED"); render() }
        findViewById<Button>(R.id.dsRun).setOnClickListener { appendResult(engine.execute(sql.text.toString())) }
        findViewById<Button>(R.id.dsTables).setOnClickListener { append("TABLES:\n" + engine.tables().joinToString("\n").ifBlank { "(none)" }) }
        findViewById<Button>(R.id.dsSchema).setOnClickListener { appendResult(engine.schema(table.text.toString())) }
        findViewById<Button>(R.id.dsMigration).setOnClickListener { appendResult(engine.applyMigration(migrationName.text.toString(), migrationSql.text.toString())) }
        findViewById<Button>(R.id.dsMigrations).setOnClickListener { appendResult(engine.migrations()) }
        findViewById<Button>(R.id.dsExport).setOnClickListener { append("SCHEMA:\n" + engine.exportSchema()) }
        append("DATABASE STUDIO • OFFLINE / LOCAL ONLY"); render()
    }
    private fun appendResult(r: DatabaseStudioEngine.QueryResult) { if (r.error != null) append("ERROR: ${r.error}") else { val header = r.columns.joinToString(" | "); val body = r.rows.joinToString("\n") { it.joinToString(" | ") }; append("OK affected=${r.affected}\n" + if (header.isNotBlank()) header + "\n" + body else "(statement executed)") } }
    private fun append(s: String) { output.append("$s\n\n") }
    private fun render() { status.text = if (engine.isOpen()) "● OPEN  SQLite • ${engine.databaseFile().name}" else "● CLOSED  •  ${engine.readiness()}"; status.setTextColor(if (engine.isOpen()) Color.parseColor("#4CD964") else Color.parseColor("#9AA4C0")) }
    override fun onDestroy() { engine.close(); super.onDestroy() }
    companion object { const val EXTRA_PROJECT_ID = "extra_database_studio_project_id" }
}
