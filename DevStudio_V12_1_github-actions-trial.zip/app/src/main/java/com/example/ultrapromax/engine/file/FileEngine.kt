package com.example.ultrapromax.engine.file

import android.content.Context
import java.io.File

/**
 * FILE ENGINE
 *
 * Real virtual file system inside the application sandbox.
 *
 * Compatible with Kotlin 1.3.72.
 */
class FileEngine(private val context: Context) {

    private val rootDir: File by lazy {
        File(context.filesDir, "projects").apply {
            mkdirs()
        }
    }

    fun projectRoot(folderName: String): File =
        File(rootDir, folderName).apply {
            mkdirs()
        }

    fun createProject(
        folderName: String,
        template: ProjectTemplate
    ): File {
        val dir = projectRoot(folderName)
        template.scaffold(dir)
        if (template.isAndroidGradleProject) {
            installGradleWrapper(dir)
        }
        return dir
    }

    /**
     * Copies the app's own proven-working Gradle wrapper (bundled as assets,
     * since it's the exact wrapper this app itself builds with) into a
     * newly generated Android project, so BuildEngine can actually run
     * ./gradlew on it without any extra download.
     */
    private fun installGradleWrapper(projectDir: File) {
        val assetNames = listOf(
            "gradlew" to projectDir,
            "gradlew.bat" to projectDir
        )
        assetNames.forEach { (name, targetDir) ->
            context.assets.open("project_wrapper/$name").use { input ->
                File(targetDir, name).outputStream().use { output -> input.copyTo(output) }
            }
        }
        File(projectDir, "gradlew").setExecutable(true)

        val wrapperDir = File(projectDir, "gradle/wrapper").apply { mkdirs() }
        listOf("gradle-wrapper.jar", "gradle-wrapper.properties").forEach { name ->
            context.assets.open("project_wrapper/$name").use { input ->
                File(wrapperDir, name).outputStream().use { output -> input.copyTo(output) }
            }
        }
    }

    fun listChildren(dir: File): List<File> =
        dir.listFiles()
            ?.sortedWith(
                compareBy(
                    { !it.isDirectory },
                    { it.name }
                )
            )
            ?: emptyList()

    fun createFile(
        parent: File,
        name: String,
        content: String = ""
    ): File {
        val file = File(parent, name)
        file.writeText(content)
        return file
    }

    fun createFolder(
        parent: File,
        name: String
    ): File {
        val folder = File(parent, name)
        folder.mkdirs()
        return folder
    }

    fun readText(file: File): String =
        file.readText()

    fun writeText(
        file: File,
        content: String
    ) {
        file.writeText(content)
    }

    fun rename(
        file: File,
        newName: String
    ): File {
        val target = File(file.parentFile, newName)
        file.renameTo(target)
        return target
    }

    fun delete(file: File): Boolean =
        if (file.isDirectory) {
            file.deleteRecursively()
        } else {
            file.delete()
        }

    fun sizeOf(file: File): Long {

        if (!file.isDirectory) {
            return file.length()
        }

        var total = 0L

        file.walkTopDown()
            .filter { it.isFile }
            .forEach {
                total += it.length()
            }

        return total
    }
}

/**
 * Starter project templates.
 */
sealed class ProjectTemplate(
    val id: String,
    val displayName: String,
    val isAndroidGradleProject: Boolean = false
) {

    abstract fun scaffold(dir: File)

    object Blank : ProjectTemplate(
        "blank",
        "Blank"
    ) {
        override fun scaffold(dir: File) {
            // Empty project.
        }
    }

    object HtmlCssJs : ProjectTemplate(
        "html-css-js",
        "HTML / CSS / JS"
    ) {

        override fun scaffold(dir: File) {

            File(dir, "index.html").writeText(
                """
                <!DOCTYPE html>
                <html lang="fa">
                <head>
                  <meta charset="UTF-8">
                  <title>New Project</title>
                  <link rel="stylesheet" href="style.css">
                </head>
                <body>
                  <h1>Hello, Ultra Pro Max+</h1>
                  <script src="script.js"></script>
                </body>
                </html>
                """.trimIndent()
            )

            File(dir, "style.css").writeText(
                "body { font-family: sans-serif; }\n"
            )

            File(dir, "script.js").writeText(
                "console.log('App initialized successfully');\n"
            )
        }
    }

    object Todo : ProjectTemplate(
        "todo-app",
        "To-Do App (HTML/CSS/JS)"
    ) {

        override fun scaffold(dir: File) {

            File(dir, "index.html").writeText(
                """
                <!DOCTYPE html>
                <html lang="fa">
                <head>
                  <meta charset="UTF-8">
                  <title>To-Do</title>
                  <link rel="stylesheet" href="style.css">
                </head>
                <body>
                  <h1>My To-Do List</h1>
                  <input id="newTask" placeholder="New task...">
                  <button onclick="addTask()">Add</button>
                  <ul id="taskList"></ul>
                  <script src="script.js"></script>
                </body>
                </html>
                """.trimIndent()
            )

            File(dir, "style.css").writeText(
                "body { font-family: sans-serif; padding: 16px; }\n" +
                        "li { padding: 8px 0; }\n"
            )

            File(dir, "script.js").writeText(
                """
                function addTask() {
                  const input = document.getElementById('newTask');
                  if (!input.value.trim()) return;
                  const li = document.createElement('li');
                  li.textContent = input.value;
                  document.getElementById('taskList').appendChild(li);
                  input.value = '';
                }
                """.trimIndent()
            )
        }
    }

    object KotlinBasic : ProjectTemplate(
        "kotlin-basic",
        "Kotlin Console Basic"
    ) {

        override fun scaffold(dir: File) {

            File(dir, "Main.kt").writeText(
                """
                fun main() {
                    println("Hello from Ultra Pro Max+")
                }
                """.trimIndent()
            )
        }
    }


    object AndroidJava : ProjectTemplate(
        "android-java",
        "Android Java",
        isAndroidGradleProject = true
    ) {
        override fun scaffold(dir: File) {
            File(dir, "settings.gradle").writeText("rootProject.name = \"NewProject\"\ninclude ':app'\n")
            File(dir, "build.gradle").writeText(
                """buildscript {
    repositories { google(); jcenter() }
    dependencies { classpath 'com.android.tools.build:gradle:3.5.3' }
}

allprojects { repositories { google(); jcenter() } }
""".trimIndent()
            )
            val app = File(dir, "app").apply { mkdirs() }
            File(app, "build.gradle").writeText(
                """apply plugin: 'com.android.application'

android {
    compileSdkVersion 29
    defaultConfig {
        applicationId 'com.example.newproject'
        minSdkVersion 23
        targetSdkVersion 29
        versionCode 1
        versionName '1.0'
    }
}
""".trimIndent()
            )
            val java = File(app, "src/main/java/com/example/newproject").apply { mkdirs() }
            File(java, "MainActivity.java").writeText(
                """package com.example.newproject;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
""".trimIndent()
            )
            val res = File(app, "src/main/res/layout").apply { mkdirs() }
            File(res, "activity_main.xml").writeText(
                """<?xml version=\"1.0\" encoding=\"utf-8\"?>
<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"
    android:layout_width=\"match_parent\"
    android:layout_height=\"match_parent\"
    android:gravity=\"center\"
    android:orientation=\"vertical\">
    <TextView
        android:layout_width=\"wrap_content\"
        android:layout_height=\"wrap_content\"
        android:text=\"Hello from DEVSTUDIO\"
        android:textSize=\"22sp\" />
</LinearLayout>
""".trimIndent()
            )
            File(app, "src/main/AndroidManifest.xml").parentFile.mkdirs()
            File(app, "src/main/AndroidManifest.xml").writeText(
                """<?xml version=\"1.0\" encoding=\"utf-8\"?>
<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">
    <application android:theme=\"@android:style/Theme.Material.Light.NoActionBar\" android:label=\"New Project\">
        <activity android:name=\".MainActivity\" android:exported=\"true\">
            <intent-filter>
                <action android:name=\"android.intent.action.MAIN\" />
                <category android:name=\"android.intent.category.LAUNCHER\" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""".trimIndent()
            )
        }
    }

    object AndroidUi : ProjectTemplate(
        "android-ui",
        "Android UI Starter",
        isAndroidGradleProject = true
    ) {
        override fun scaffold(dir: File) {
            AndroidJava.scaffold(dir)
            val layout = File(dir, "app/src/main/res/layout/activity_main.xml")
            layout.parentFile?.mkdirs()
            layout.writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="24dp">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="DEVSTUDIO UI Starter"
        android:textSize="24sp" />
    <Button
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:text="Start Building" />
</LinearLayout>
""".trimIndent()
            )
        }
    }

    object WebViewApp : ProjectTemplate(
        "webview-app",
        "WebView App",
        isAndroidGradleProject = true
    ) {
        override fun scaffold(dir: File) {
            AndroidJava.scaffold(dir)

            // IMPORTANT: write the web files ONCE, directly into
            // app/src/main/assets — this is the ONLY copy, so whatever the
            // user edits in the File Explorer is exactly what the WebView
            // loads. (A previous version also called HtmlCssJs.scaffold(dir)
            // which wrote a second, unused copy to the project root — those
            // edits never showed up in the built app. Fixed here.)
            val assets = File(dir, "app/src/main/assets").apply { mkdirs() }
            File(assets, "index.html").writeText(
                """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DEVSTUDIO WebView</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello from DEVSTUDIO</h1>
  <p>Edit index.html, style.css and script.js — this WebView loads them directly.</p>
  <script src="script.js"></script>
</body>
</html>
"""
            )
            File(assets, "style.css").writeText("body { font-family: sans-serif; padding: 24px; }\n")
            File(assets, "script.js").writeText("console.log('WebView App ready');\n")

            val java = File(dir, "app/src/main/java/com/example/newproject/MainActivity.java")
            java.writeText(
                """package com.example.newproject;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
}
""".trimIndent()
            )
            val manifest = File(dir, "app/src/main/AndroidManifest.xml")
            manifest.writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="New Project">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
            )
        }
    }

    object AndroidKotlin : ProjectTemplate(
        "android-kotlin",
        "Android Kotlin App",
        isAndroidGradleProject = true
    ) {
        override fun scaffold(dir: File) {
            File(dir, "settings.gradle").writeText("rootProject.name = \"NewProject\"\ninclude ':app'\n")
            File(dir, "build.gradle").writeText(
                """buildscript {
    ext.kotlin_version = "1.3.72"
    repositories { google(); jcenter() }
    dependencies {
        classpath 'com.android.tools.build:gradle:3.5.3'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:${'$'}kotlin_version"
    }
}

allprojects { repositories { google(); jcenter() } }
"""
            )
            val app = File(dir, "app").apply { mkdirs() }
            File(app, "build.gradle").writeText(
                """apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'

android {
    compileSdkVersion 29
    defaultConfig {
        applicationId 'com.example.newproject'
        minSdkVersion 23
        targetSdkVersion 29
        versionCode 1
        versionName '1.0'
    }
}

dependencies {
    implementation "org.jetbrains.kotlin:kotlin-stdlib:1.3.72"
}
"""
            )
            val kotlin = File(app, "src/main/java/com/example/newproject").apply { mkdirs() }
            File(kotlin, "MainActivity.kt").writeText(
                """package com.example.newproject

import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
"""
            )
            val res = File(app, "src/main/res/layout").apply { mkdirs() }
            File(res, "activity_main.xml").writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Hello from DEVSTUDIO (Kotlin)"
        android:textSize="20sp" />
</LinearLayout>
"""
            )
            File(app, "src/main/AndroidManifest.xml").parentFile.mkdirs()
            File(app, "src/main/AndroidManifest.xml").writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="New Project">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
            )
        }
    }

    companion object {

        fun all(): List<ProjectTemplate> =
            listOf(
                Blank,
                HtmlCssJs,
                Todo,
                KotlinBasic,
                AndroidJava,
                AndroidKotlin,
                AndroidUi,
                WebViewApp
            )
    }
}