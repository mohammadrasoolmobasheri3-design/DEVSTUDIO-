package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.preview.PreviewEngine
import com.example.ultrapromax.engine.run.UniversalRunEngine
import com.example.ultrapromax.engine.server.MiniServerEngine
import java.io.File

/**
 * DEVSTUDIO v18 - Preview + Run Studio.
 * One workspace for preview, run configuration, console and problems.
 * Compatible with Kotlin 1.3.72 / old Android toolchain.
 */
class RunStudioActivity : AppCompatActivity() {

    private lateinit var project: Project
    private lateinit var webView: WebView
    private lateinit var console: TextView
    private lateinit var problems: TextView
    private lateinit var status: TextView
    private lateinit var targetText: TextView
    private lateinit var consolePanel: View
    private lateinit var problemsPanel: View

    private var server: MiniServerEngine? = null
    private var selectedTarget: File? = null
    private var running = false
    private val handler = Handler(Looper.getMainLooper())
    private var reloadRunnable: Runnable? = null
    private var lastModified = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_run_studio)

        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run {
            finish()
            return
        }

        webView = findViewById(R.id.runWebView)
        console = findViewById(R.id.runConsole)
        problems = findViewById(R.id.runProblems)
        status = findViewById(R.id.runStatus)
        targetText = findViewById(R.id.runTarget)
        consolePanel = findViewById(R.id.consolePanel)
        problemsPanel = findViewById(R.id.problemsPanel)

        findViewById<TextView>(R.id.runBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.runTargetButton).setOnClickListener { chooseTarget() }
        findViewById<Button>(R.id.runButton).setOnClickListener { runStudio() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopStudio() }
        findViewById<Button>(R.id.restartButton).setOnClickListener { restartStudio() }
        findViewById<Button>(R.id.runtimeButton).setOnClickListener {
            startActivity(Intent(this, RuntimeManagerActivity::class.java))
        }
        findViewById<Button>(R.id.openDesignButton).setOnClickListener { openDesign() }
        findViewById<Button>(R.id.openCodeButton).setOnClickListener { openCode() }
        findViewById<Button>(R.id.consoleTab).setOnClickListener { showConsole() }
        findViewById<Button>(R.id.problemsTab).setOnClickListener { showProblems() }

        configureWebView()
        selectDefaultTarget()
        appendConsole("DEVSTUDIO v23 • Universal Run Studio ready")
        appendConsole("Project: ${project.name} • ${project.template}")
    }

    private fun configureWebView() {
        PreviewEngine.configure(webView)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = message.messageLevel().name
                appendConsole(
                    "[$level] ${message.message()}  " +
                        "(${message.sourceId()}:${message.lineNumber()})"
                )

                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    appendProblem(message.message())
                }

                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView?, url: String?) {
                status.text = "● PREVIEW RUNNING"
                status.setTextColor(Color.parseColor("#4CD964"))
                appendConsole("Loaded: ${url ?: "preview"}")
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                appendProblem(
                    "Web error $errorCode: ${description ?: "unknown error"}"
                )
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request == null || request.isForMainFrame) {
                    appendProblem(
                        "Web error: ${error?.description ?: "unknown error"}"
                    )
                }
            }
        }
    }

    private fun selectDefaultTarget() {
        val root = File(project.folderPath)
        val generated = File(root, "devstudio/generated/index.html")
        val index = File(root, "index.html")

        selectedTarget = when {
            generated.exists() -> generated
            index.exists() -> index
            else -> findRunnableFile(root)
        }

        updateTargetLabel()
    }

    private fun chooseTarget() {
        val root = File(project.folderPath)

        val candidates = root.walkTopDown()
            .filter { it.isFile }
            .filter {
                !it.absolutePath.contains("/.gradle/") &&
                    !it.absolutePath.contains("/build/")
            }
            .filter { isSupportedTarget(it) }
            .toList()

        if (candidates.isEmpty()) {
            Toast.makeText(
                this,
                "No runnable target found in this project.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val labels = candidates
            .map { it.relativeTo(root).path }
            .toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Run Target")
            .setItems(labels) { _, which ->
                selectedTarget = candidates[which]
                updateTargetLabel()
                appendConsole("Target selected: ${labels[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runStudio() {
        if (running) {
            appendConsole("Run is already active.")
            return
        }

        val root = File(project.folderPath)

        if (!root.exists()) {
            appendProblem("Project folder is missing.")
            return
        }

        val target = selectedTarget ?: findRunnableFile(root)

        if (target == null) {
            appendProblem(
                "No runnable target found. Use Run Target to select a file."
            )
            showProblems()
            return
        }

        selectedTarget = target
        updateTargetLabel()
        clearProblems()
        appendConsole("▶ Starting ${target.relativeTo(root).path}")
        setRunningUi(true)

        val source = runCatching {
            target.readText()
        }.getOrElse {
            setRunningUi(false)
            appendProblem("Unable to read target: ${it.message}")
            return
        }

        val runtime = UniversalRunEngine(File(filesDir, "runtimes"))
        val language = runtime.detectLanguage(target, source, root)

        appendConsole("Detected language: $language")

        if (language == "html" || language == "css") {
            val previewRoot =
                if (
                    target.name.equals("index.html", true) &&
                    target.parentFile?.name == "generated"
                ) {
                    target.parentFile ?: root
                } else {
                    root
                }

            startWebPreview(previewRoot, root, target, source)
            return
        }

        if (language == "android") {
            appendConsole(
                "Android/Gradle target detected. Starting debug build…"
            )

            Thread {
                /*
                 * IMPORTANT:
                 * Pass the real Activity Context into BuildEngine.
                 *
                 * Previously this was:
                 *     BuildEngine().buildDebug(root)
                 *
                 * That created BuildEngine with context == null,
                 * preventing LocalToolchainResolver from resolving
                 * filesDir/internal-toolchain and filesDir/toolchain.
                 */
                val result = BuildEngine(this@RunStudioActivity)
                    .buildDebug(root)

                runOnUiThread {
                    setRunningUi(false)
                    appendConsole(result.output)

                    if (result.success) {
                        status.text = "● BUILD SUCCESS"
                        status.setTextColor(Color.parseColor("#4CD964"))

                        Toast.makeText(
                            this,
                            "Debug APK built successfully.",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        status.text = "● BUILD FAILED"
                        status.setTextColor(Color.parseColor("#FF5B6E"))

                        appendProblem(
                            "Android build failed. See Console for Gradle output."
                        )
                        showProblems()
                    }
                }
            }.start()

            return
        }

        Thread {
            val result = runtime.run(
                target,
                source,
                root,
                cacheDir
            )

            runOnUiThread {
                setRunningUi(false)

                appendConsole(
                    result.output.ifBlank {
                        "Program finished with no output."
                    }
                )

                if (result.success) {
                    status.text = "● RUN SUCCESS"
                    status.setTextColor(Color.parseColor("#4CD964"))
                } else {
                    status.text = "● RUN FAILED"
                    status.setTextColor(Color.parseColor("#FF5B6E"))

                    appendProblem(
                        result.output.ifBlank {
                            "Runtime failed."
                        }
                    )
                    showProblems()
                }

                if (result.previewDir != null) {
                    startWebPreview(
                        result.previewDir,
                        root,
                        File(result.previewDir, "index.html"),
                        source
                    )
                }
            }
        }.start()
    }

    private fun startWebPreview(
        projectDir: File,
        watchDir: File,
        target: File,
        source: String
    ) {
        stopServerOnly()

        val libsDir = File(filesDir, "libs")
        val srv = MiniServerEngine(projectDir, libsDir)

        val pluginManager =
            com.example.ultrapromax.engine.plugin.PluginManager(this)

        com.example.ultrapromax.engine.plugin.BuiltInPlugins
            .registerAll(pluginManager)

        if (pluginManager.isEnabledById("dark_reader")) {
            srv.htmlTransform = { html ->
                com.example.ultrapromax.engine.plugin.BuiltInPlugins
                    .darkReader
                    .injectDarkCss(html)
            }
        }

        srv.start()
        server = srv
        running = true

        val url = if (target.name.endsWith(".css", true)) {
            srv.baseUrl()
        } else {
            srv.baseUrl()
        }

        PreviewEngine.loadUrl(webView, url)

        webView.visibility = View.VISIBLE

        startLiveReload(watchDir)

        appendConsole("Local server started: ${srv.baseUrl()}")
        appendConsole("Live Reload: ON")

        status.text = "● PREVIEW RUNNING"
        status.setTextColor(Color.parseColor("#4CD964"))
    }

    private fun startLiveReload(dir: File) {
        stopLiveReload()

        lastModified = newestModifiedTime(dir)

        val r = object : Runnable {
            override fun run() {
                if (!running) return

                val current = newestModifiedTime(dir)

                if (current != lastModified) {
                    lastModified = current
                    PreviewEngine.reload(webView)
                    appendConsole("↻ Live Reload — project changed")
                }

                handler.postDelayed(this, 900L)
            }
        }

        reloadRunnable = r
        handler.postDelayed(r, 900L)
    }

    private fun restartStudio() {
        appendConsole("↻ Restart requested")
        stopStudio()
        handler.postDelayed({ runStudio() }, 180L)
    }

    private fun stopStudio() {
        stopLiveReload()
        stopServerOnly()

        running = false
        webView.stopLoading()
        webView.visibility = View.VISIBLE

        status.text = "● STOPPED"
        status.setTextColor(Color.parseColor("#9AA4C0"))

        appendConsole("■ Studio stopped")
    }

    private fun stopServerOnly() {
        server?.stop()
        server = null
    }

    private fun stopLiveReload() {
        reloadRunnable?.let {
            handler.removeCallbacks(it)
        }
        reloadRunnable = null
    }

    private fun openDesign() {
        startActivity(
            Intent(this, UiBuilderActivity::class.java)
                .putExtra(
                    UiBuilderActivity.EXTRA_PROJECT_ID,
                    project.id
                )
        )
    }

    private fun openCode() {
        val intent = Intent(
            this,
            EditorActivity::class.java
        ).putExtra(
            EditorActivity.EXTRA_PROJECT_ID,
            project.id
        )

        selectedTarget?.let {
            intent.putExtra(
                EditorActivity.EXTRA_FILE_PATH,
                it.absolutePath
            )
        }

        startActivity(intent)
    }

    private fun showConsole() {
        consolePanel.visibility = View.VISIBLE
        problemsPanel.visibility = View.GONE
    }

    private fun showProblems() {
        consolePanel.visibility = View.GONE
        problemsPanel.visibility = View.VISIBLE
    }

    private fun setRunningUi(active: Boolean) {
        running = active

        findViewById<Button>(R.id.runButton).isEnabled = !active
        findViewById<Button>(R.id.stopButton).isEnabled = active
        findViewById<Button>(R.id.restartButton).isEnabled = active

        if (active) {
            status.text = "● STARTING…"
            status.setTextColor(Color.parseColor("#F0C75E"))
        }
    }

    private fun updateTargetLabel() {
        val target = selectedTarget

        targetText.text =
            if (target == null) {
                "Target: —"
            } else {
                "Target: ${
                    target.relativeTo(
                        File(project.folderPath)
                    ).path
                }"
            }
    }

    private fun findRunnableFile(root: File): File? =
        root.walkTopDown()
            .filter {
                it.isFile && isSupportedTarget(it)
            }
            .filter {
                !it.absolutePath.contains("/.gradle/") &&
                    !it.absolutePath.contains("/build/")
            }
            .firstOrNull()

    private fun isSupportedTarget(file: File): Boolean =
        when (file.extension.toLowerCase()) {
            "html",
            "htm",
            "css",
            "js",
            "mjs",
            "ts",
            "tsx",
            "py",
            "java",
            "kt",
            "kts",
            "c",
            "cc",
            "cpp",
            "cxx",
            "cs",
            "go",
            "rs",
            "swift",
            "dart",
            "php",
            "rb",
            "pl",
            "lua",
            "sh",
            "bash",
            "sql" -> true

            else -> false
        }

    private fun newestModifiedTime(dir: File): Long {
        var newest = 0L

        runCatching {
            dir.walkTopDown()
                .filter { it.isFile }
                .forEach {
                    if (it.lastModified() > newest) {
                        newest = it.lastModified()
                    }
                }
        }

        return newest
    }

    private fun appendConsole(text: String) {
        runOnUiThread {
            if (text.isBlank()) return@runOnUiThread

            console.append("\n$text")

            val parent = console.parent

            if (parent is ScrollView) {
                parent.post {
                    parent.fullScroll(View.FOCUS_DOWN)
                }
            }
        }
    }

    private fun appendProblem(text: String) {
        runOnUiThread {
            if (text.isBlank()) return@runOnUiThread

            if (
                problems.text.isNullOrBlank() ||
                problems.text.toString() == "No problems detected."
            ) {
                problems.text = ""
            }

            problems.append("\n• $text")
        }
    }

    private fun clearProblems() {
        problems.text = "No problems detected."
    }

    override fun onDestroy() {
        stopLiveReload()
        stopServerOnly()
        running = false
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PROJECT_ID = "extra_run_studio_project_id"
    }
}