package com.example.ultrapromax.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.run.LanguageRuntimeRegistry
import com.example.ultrapromax.engine.run.RuntimePackManager
import com.example.ultrapromax.engine.run.PythonEmbeddedRuntime
import java.io.File

/** DEVSTUDIO v23 — Offline Universal Runtime Manager. */
class RuntimeManagerActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var registry: LanguageRuntimeRegistry
    private lateinit var manager: RuntimePackManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_runtime_manager)
        list = findViewById(R.id.runtimeList)
        status = findViewById(R.id.runtimeStatus)
        val root = File(filesDir, "runtimes")
        root.mkdirs()
        registry = LanguageRuntimeRegistry(root)
        manager = RuntimePackManager(root)

        findViewById<TextView>(R.id.runtimeBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.importRuntime).setOnClickListener { choosePack() }
        findViewById<Button>(R.id.refreshRuntime).setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val installed = manager.listInstalled(registry)
        val ready = installed.count { it.ready }
        status.text = "OFFLINE • $ready runtime pack(s) ready • ${installed.size} profiles"
        status.setTextColor(Color.parseColor("#4CD964"))
        installed.forEach { info ->
            val p = registry.find(info.id) ?: return@forEach
            val row = TextView(this)
            row.setPadding(16, 14, 16, 14)
            row.textSize = 13f
            row.setTextColor(Color.WHITE)
            val readiness = registry.readiness(p)
            var state = when {
                p.id == "html" || p.id == "css" -> "BUILT-IN • WebView"
                readiness.ready -> "READY • ${info.files} files"
                else -> "NOT READY • ${readiness.missing.joinToString(", ")}"
            }
            if (p.id == "python") {
                val check = PythonEmbeddedRuntime(registry.runtimeDir(p)).check()
                state = if (check.ready) "READY • embedded Python 3" else "NOT READY • ${check.message}"
            }
            row.text = "${p.displayName}\n${p.id}  •  $state\nExtensions: ${p.extensions.joinToString(", ").ifBlank { "project target" }}"
            row.setBackgroundResource(R.drawable.glass_card)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 0, 0, 8)
            list.addView(row, lp)
        }
    }

    private fun choosePack() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/zip"
        startActivityForResult(intent, REQUEST_PACK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PACK || resultCode != RESULT_OK || data?.data == null) return
        try {
            val temp = File(cacheDir, "runtime-pack-${System.currentTimeMillis()}.zip")
            contentResolver.openInputStream(data.data!!).use { input ->
                if (input == null) throw IllegalStateException("Unable to open selected file")
                temp.outputStream().use { output -> input.copyTo(output) }
            }
            val message = manager.installZip(temp, registry)
            temp.delete()
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    companion object { private const val REQUEST_PACK = 2301 }
}
