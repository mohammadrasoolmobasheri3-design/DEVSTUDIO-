package com.example.ultrapromax.nextupdate.ai.context

data class ProjectContext(
    val projectId: String,
    val projectName: String,
    val rootPath: String,
    val files: List<String> = emptyList(),
    val openFiles: List<String> = emptyList(),
    val diagnostics: List<String> = emptyList()
)
