package com.example.ultrapromax.engine.endgame

/** Canonical project contract connecting UI/Web, Server/API and Database layers. */
data class FullStackProjectContract(
    val projectId: Long,
    val frontend: Frontend,
    val server: String,
    val database: String,
    val offlineOnly: Boolean = true
) {
    enum class Frontend { ANDROID, FLUTTER, WEB, NATIVE, CLI }
}
