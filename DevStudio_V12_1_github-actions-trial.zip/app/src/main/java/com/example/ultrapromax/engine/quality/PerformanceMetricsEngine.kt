package com.example.ultrapromax.engine.quality

/** Lightweight offline performance measurement helpers for Studio subsystems. */
class PerformanceMetricsEngine {
    data class Metric(val name: String, val durationMs: Long, val success: Boolean)

    fun <T> measure(name: String, action: () -> T): Pair<T?, Metric> {
        val start = System.nanoTime()
        return try {
            val result = action()
            val elapsed = (System.nanoTime() - start) / 1000000L
            Pair(result, Metric(name, elapsed, true))
        } catch (_: Throwable) {
            val elapsed = (System.nanoTime() - start) / 1000000L
            Pair(null, Metric(name, elapsed, false))
        }
    }

    fun summary(metrics: List<Metric>): String {
        if (metrics.isEmpty()) return "No metrics"
        val total = metrics.fold(0L) { sum, item -> sum + item.durationMs }
        val failed = metrics.count { !it.success }
        return "Metrics: ${metrics.size} | Total: ${total}ms | Failed: $failed"
    }
}
