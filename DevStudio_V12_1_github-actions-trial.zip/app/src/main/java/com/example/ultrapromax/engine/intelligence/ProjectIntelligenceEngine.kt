package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.LanguageService
import com.example.ultrapromax.engine.language.symbol.Symbol
import java.io.File
import java.util.Locale

/** Offline project intelligence snapshot. It inspects structure, languages and symbols without executing project code. */
class ProjectIntelligenceEngine {
    data class LanguageStat(val extension: String, val label: String, val files: Int, val lines: Int)
    data class ModuleStat(val name: String, val path: String, val kind: String, val ready: Boolean)
    data class Snapshot(
        val root: String,
        val files: Int,
        val folders: Int,
        val lines: Int,
        val languages: List<LanguageStat>,
        val modules: List<ModuleStat>,
        val symbols: List<Symbol>,
        val entryPoints: List<String>,
        val warnings: List<String>
    )

    private val languageService = LanguageService()
    private val ignored = setOf(".git", ".gradle", "build", "node_modules", ".idea")

    fun inspect(root: File): Snapshot {
        if (!root.isDirectory) return Snapshot(root.absolutePath, 0, 0, 0, emptyList(), emptyList(), emptyList(), emptyList(), listOf("Project folder is missing."))
        val filesByExt = LinkedHashMap<String, MutableList<File>>()
        var folders = 0
        var lines = 0
        root.walkTopDown().onEnter { it.name !in ignored }.forEach { file ->
            if (file == root) return@forEach
            if (file.isDirectory) { folders++; return@forEach }
            val ext = file.extension.toLowerCase(Locale.US)
            if (ext.isEmpty()) return@forEach
            filesByExt.getOrPut(ext) { ArrayList() }.add(file)
            if (isText(ext)) {
                try { lines += safeLines(file) } catch (_: Exception) { }
            }
        }
        val symbols = ArrayList<Symbol>()
        filesByExt.values.flatten().forEach { file ->
            try {
                val provider = languageService.languageFor(file.name)
                if (provider != null && file.length() <= 2L * 1024L * 1024L) symbols.addAll(languageService.analyzeBuffer(file.name, file.readText()).map { it.copy(filePath = file.absolutePath) })
            } catch (_: Exception) { }
        }
        val languages = filesByExt.entries.map { (ext, files) ->
            LanguageStat(ext, label(ext), files.size, files.sumBy { safeLines(it) })
        }.sortedWith(compareByDescending<LanguageStat> { it.files }.thenBy { it.extension })
        val modules = discoverModules(root)
        val entries = discoverEntries(root)
        val warnings = ArrayList<String>()
        if (!File(root, "settings.gradle").exists() && !File(root, "settings.gradle.kts").exists()) warnings.add("No Gradle settings file detected.")
        if (modules.isEmpty()) warnings.add("No Android/Gradle module was detected.")
        if (symbols.isEmpty()) warnings.add("No symbols were indexed from supported source files.")
        return Snapshot(root.absolutePath, filesByExt.values.sumBy { it.size }, folders, lines, languages, modules, symbols, entries, warnings)
    }

    fun search(snapshot: Snapshot, query: String, limit: Int = 40): List<Symbol> {
        val q = query.trim().toLowerCase(Locale.US)
        if (q.isEmpty()) return snapshot.symbols.take(limit)
        return snapshot.symbols.filter { it.name.toLowerCase(Locale.US).contains(q) }.take(limit)
    }

    private fun discoverModules(root: File): List<ModuleStat> {
        val result = ArrayList<ModuleStat>()
        if (File(root, "app/build.gradle").exists() || File(root, "app/build.gradle.kts").exists()) result.add(ModuleStat("app", "app", "Android module", true))
        root.listFiles()?.filter { it.isDirectory && !ignored.contains(it.name) }?.forEach { dir ->
            if (dir.name == "app") return@forEach
            if (File(dir, "build.gradle").exists() || File(dir, "build.gradle.kts").exists()) result.add(ModuleStat(dir.name, dir.name, "Gradle module", true))
        }
        return result
    }

    private fun discoverEntries(root: File): List<String> {
        val result = ArrayList<String>()
        if (File(root, "app/src/main/AndroidManifest.xml").exists()) result.add("AndroidManifest.xml")
        root.walkTopDown().onEnter { it.name !in ignored }.forEach { file ->
            if (!file.isFile) return@forEach
            if (file.name == "MainActivity.kt" || file.name == "MainActivity.java" || file.name == "index.html") result.add(relative(root, file))
        }
        return result.distinct().take(20)
    }

    private fun isText(ext: String): Boolean = ext in setOf("kt", "java", "xml", "json", "gradle", "kts", "js", "ts", "py", "c", "cpp", "h", "hpp", "dart", "php", "html", "css", "md", "txt")
    private fun safeLines(file: File): Int = try { if (file.length() > 2L * 1024L * 1024L) 0 else file.useLines { seq -> seq.count() } } catch (_: Exception) { 0 }
    private fun relative(root: File, file: File): String = try { file.relativeTo(root).path } catch (_: Exception) { file.name }
    private fun label(ext: String): String = when (ext) {
        "kt" -> "Kotlin"; "java" -> "Java"; "xml" -> "XML"; "py" -> "Python"; "js" -> "JavaScript"; "ts" -> "TypeScript"; "cpp", "hpp" -> "C++"; "c", "h" -> "C"; "dart" -> "Dart"; "php" -> "PHP"; "html" -> "HTML"; "css" -> "CSS"; "gradle", "kts" -> "Gradle"; "json" -> "JSON"; "md" -> "Markdown"; else -> ext.toUpperCase(Locale.US)
    }
}
