package com.example.ultrapromax.engine.language

data class LanguageCapabilities(
    val canHighlight: Boolean,
    val canExtractSymbols: Boolean,
    val canIndex: Boolean,
    val canRun: Boolean
)

object LanguageCapabilitiesRegistry {
    fun forLanguage(id: String): LanguageCapabilities {
        val known = LanguageRegistry.get(id) != null
        return LanguageCapabilities(known, known, known, runtimeAvailable(id))
    }

    private fun runtimeAvailable(id: String): Boolean {
        // Runtime availability is deliberately not guessed here. engine/run remains the source of truth.
        return when (id) {
            "html", "css" -> true
            else -> false
        }
    }
}
