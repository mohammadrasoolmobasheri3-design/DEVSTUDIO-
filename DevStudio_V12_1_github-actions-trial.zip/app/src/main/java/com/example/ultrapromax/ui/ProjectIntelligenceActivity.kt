package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.intelligence.ProjectIntelligenceEngine
import com.example.ultrapromax.engine.language.symbol.Symbol
import java.io.File

/** Defensive Project Intelligence screen. Never lets an inspection exception crash the Studio. */
class ProjectIntelligenceActivity : AppCompatActivity() {
    private lateinit var engine: ProjectIntelligenceEngine
    private lateinit var project: Project
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private var snapshot: ProjectIntelligenceEngine.Snapshot? = null
    private var inspecting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_project_intelligence)
            engine = ProjectIntelligenceEngine()
            val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
            val loaded = ProjectStore.getById(this, id)
            if (loaded == null) {
                Toast.makeText(this, "Project could not be loaded.", Toast.LENGTH_LONG).show()
                finish()
                return
            }
            project = loaded
            content = findViewById(R.id.intelligenceContent)
            search = findViewById(R.id.symbolSearch)
            findViewById<Button>(R.id.btnRefreshIntelligence).setOnClickListener { inspect() }
            findViewById<Button>(R.id.btnCloseIntelligence).setOnClickListener { finish() }
            search.setOnEditorActionListener { _, _, _ -> renderSymbols(); true }
            inspect()
        } catch (t: Throwable) {
            Toast.makeText(this, "Project Intelligence failed to open.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun inspect() {
        if (inspecting || isFinishing) return
        inspecting = true
        try {
            val root = File(project.folderPath)
            if (!root.exists() || !root.isDirectory) {
                snapshot = ProjectIntelligenceEngine.Snapshot(
                    root.absolutePath, 0, 0, 0,
                    emptyList(), emptyList(), emptyList(), emptyList(),
                    listOf("Project folder is missing: ${root.absolutePath}")
                )
                render()
                inspecting = false
                return
            }
            // Inspect off the UI thread; large projects must not freeze or crash the Activity.
            Thread {
                val result = try {
                    engine.inspect(root)
                } catch (t: Throwable) {
                    ProjectIntelligenceEngine.Snapshot(
                        root.absolutePath, 0, 0, 0,
                        emptyList(), emptyList(), emptyList(), emptyList(),
                        listOf("Inspection error: ${t.javaClass.simpleName}")
                    )
                }
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        snapshot = result
                        render()
                    }
                    inspecting = false
                }
            }.start()
        } catch (t: Throwable) {
            inspecting = false
            showError(t)
        }
    }

    private fun render() {
        try {
            val s = snapshot ?: return
            content.removeAllViews()
            addTitle("PROJECT INTELLIGENCE")
            addText("${project.name}  •  ${project.template}", Color.LTGRAY)
            addCard("STRUCTURE", "${s.files} files  •  ${s.folders} folders  •  ${s.lines} lines")
            addCard("MODULES", if (s.modules.isEmpty()) "None detected" else s.modules.joinToString("\n") { "✓ ${it.name} — ${it.kind}" })
            addCard("LANGUAGES", if (s.languages.isEmpty()) "No supported source files" else s.languages.take(12).joinToString("\n") { "${it.label}: ${it.files} files • ${it.lines} lines" })
            addCard("ENTRY POINTS", if (s.entryPoints.isEmpty()) "No obvious entry points" else s.entryPoints.joinToString("\n"))
            addTitle("SYMBOL INDEX")
            // Move the existing search view safely instead of creating duplicate parents.
            content.addView(search)
            renderSymbols()
            if (s.warnings.isNotEmpty()) addCard("INTELLIGENCE NOTES", s.warnings.joinToString("\n") { "• $it" })
        } catch (t: Throwable) {
            showError(t)
        }
    }

    private fun renderSymbols() {
        try {
            val s = snapshot ?: return
            val old = content.findViewWithTag<View>("symbolList")
            if (old != null) content.removeView(old)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                tag = "symbolList"
            }
            val q = search.text.toString()
            val symbols: List<Symbol> = try { engine.search(s, q, 50) } catch (_: Throwable) { emptyList<Symbol>() }
            if (symbols.isEmpty()) {
                box.addView(textView("No matching symbols."))
            } else {
                symbols.forEach { symbol ->
                    val path = try {
                        File(symbol.filePath).relativeTo(File(project.folderPath)).path
                    } catch (_: Exception) { symbol.filePath }
                    box.addView(textView("${symbol.name}  •  ${symbol.kind}\n$path:${symbol.line}"))
                }
            }
            content.addView(box)
        } catch (t: Throwable) {
            showError(t)
        }
    }

    private fun showError(t: Throwable) {
        if (isFinishing) return
        try {
            Toast.makeText(this, "Intelligence error: ${t.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        } catch (_: Throwable) { }
    }

    private fun addTitle(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(Color.CYAN)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(6))
        })
    }

    private fun addText(text: String, color: Int) { content.addView(textView(text, color)) }
    private fun addCard(title: String, body: String) { content.addView(textView("$title\n$body", Color.WHITE, true)) }

    private fun textView(text: String, color: Int = Color.LTGRAY, card: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = if (card) 12f else 11f
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (card) setBackgroundResource(R.drawable.glass_card)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(7))
        layoutParams = lp
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object { const val EXTRA_PROJECT_ID = "extra_project_id" }
}
