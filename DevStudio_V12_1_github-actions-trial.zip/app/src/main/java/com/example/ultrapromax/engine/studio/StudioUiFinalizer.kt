package com.example.ultrapromax.engine.studio

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.Window

/**
 * V30.1.0 Stage 24 — final Studio UI/UX pass.
 * Keeps the existing architecture and toolchain; only normalizes the shell chrome.
 */
object StudioUiFinalizer {
    fun apply(activity: Activity) {
        val window: Window = activity.window
        window.statusBarColor = Color.rgb(5, 2, 15)
        window.navigationBarColor = Color.rgb(5, 2, 15)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = 0
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility and
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.navigationBarDividerColor = Color.rgb(30, 24, 55)
        }
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
}
