package com.example.ultrapromax.engine.ai

import com.example.ultrapromax.nextupdate.ai.context.ContextProvider
import com.example.ultrapromax.nextupdate.ai.context.ProjectContext
import com.example.ultrapromax.nextupdate.ai.model.AiTask
import com.example.ultrapromax.nextupdate.ai.patch.FilePatch
import com.example.ultrapromax.nextupdate.ai.patch.PatchApproval
import com.example.ultrapromax.nextupdate.ai.patch.PatchSet
import com.example.ultrapromax.nextupdate.ai.patch.ApprovalState
import com.example.ultrapromax.nextupdate.ai.planner.AiPlanner
import com.example.ultrapromax.nextupdate.ai.tools.AiTool
import com.example.ultrapromax.nextupdate.ai.tools.AiToolRegistry
import com.example.ultrapromax.nextupdate.orchestration.AiAgentOrchestrator
import com.example.ultrapromax.nextupdate.security.AgentSecurityPolicy
import java.io.File
import java.util.UUID

/**
 * V30.1.0 Stage 15: project-aware offline AI orchestration facade.
 * It intentionally remains rule-based; no network or hidden model is used.
 */
class AiStudioAssistantEngine(private val projectRoot: File?) {
    data class PlanPreview(val text: String, val requiresApproval: Boolean)

    private val tools = AiToolRegistry()
    private val planner = AiPlanner()
    private val security = AgentSecurityPolicy()
    private val approvals = HashMap<String, PatchApproval>()

    init {
        tools.register(object : AiTool {
            override val id: String = "project-context"
            override val requiresApproval: Boolean = false
            override fun execute(input: String): com.example.ultrapromax.nextupdate.ai.tools.ToolResult {
                val c = buildContext()
                return com.example.ultrapromax.nextupdate.ai.tools.ToolResult(true, "${c.projectName}: ${c.files.size} files, ${c.diagnostics.size} diagnostics")
            }
        })
        tools.register(object : AiTool {
            override val id: String = "safe-lint"
            override val requiresApproval: Boolean = false
            override fun execute(input: String): com.example.ultrapromax.nextupdate.ai.tools.ToolResult =
                com.example.ultrapromax.nextupdate.ai.tools.ToolResult(true, "Runs the local rule-based linter.")
        })
    }

    fun preparePlan(instruction: String): PlanPreview {
        val task = AiTask(UUID.randomUUID().toString(), instruction, projectRoot?.absolutePath)
        val orchestrator = AiAgentOrchestrator(
            object : ContextProvider {
                override fun snapshot(projectId: String): ProjectContext? = buildContext()
            },
            planner,
            tools
        )
        val result = orchestrator.prepare(task)
        val mode = if (result.requiresApproval) "تغییر فایل نیاز به تأیید دارد." else "بدون تغییر مخرب."
        return PlanPreview("AI Plan\n\n${result.summary}\n\n$mode\n\nحالت اجرا: کاملاً آفلاین", result.requiresApproval)
    }

    fun createSafePatch(file: File, before: String): PatchSet? {
        if (projectRoot == null || !isInsideProject(file)) return null
        val language = EditorLanguageBridge.language(file.name)
        val after = RuleBasedAiEngine().autoFix(before, language)
        if (after == before) return null
        val id = UUID.randomUUID().toString()
        approvals[id] = PatchApproval(id)
        return PatchSet(id, listOf(FilePatch(file.absolutePath, before, after)))
    }

    fun approve(patch: PatchSet): Boolean {
        if (!security.allowsMutation(true)) return false
        val approval = approvals[patch.id] ?: return false
        approval.state = ApprovalState.APPROVED
        return true
    }

    fun applyApproved(patch: PatchSet): Boolean {
        val approval = approvals[patch.id] ?: return false
        if (approval.state != ApprovalState.APPROVED) return false
        return try {
            patch.patches.forEach { p ->
                val target = File(p.path)
                if (!isInsideProject(target)) return false
                target.parentFile?.mkdirs()
                target.writeText(p.after)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun buildContext(): ProjectContext {
        val root = projectRoot
        if (root == null || !root.exists()) return ProjectContext("none", "No Project", "", emptyList())
        val files = try {
            root.walkTopDown()
                .filter { it.isFile && !it.path.contains("${File.separator}.gradle${File.separator}") && !it.path.contains("${File.separator}build${File.separator}") }
                .map { it.relativeTo(root).path }
                .take(300)
                .toList()
        } catch (_: Exception) { emptyList<String>() }
        return ProjectContext(root.absolutePath, root.name, root.absolutePath, files, emptyList(), emptyList())
    }

    private fun isInsideProject(file: File): Boolean {
        val root = projectRoot ?: return false
        return try {
            val r = root.canonicalFile
            val f = file.canonicalFile
            f.path == r.path || f.path.startsWith(r.path + File.separator)
        } catch (_: Exception) { false }
    }

    private object EditorLanguageBridge {
        fun language(name: String): String = when (name.toLowerCase()) {
            in listOf("kt", "kts") -> "kt"
            "java" -> "java"
            "js" -> "js"
            "css" -> "css"
            "html", "htm" -> "html"
            else -> "text"
        }
    }
}
