package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class TypeScriptLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("ts", "TypeScript", listOf("ts", "tsx"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("ts").parse(source)
}
