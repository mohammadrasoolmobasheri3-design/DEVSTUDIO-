package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.symbol.Symbol
import java.io.File
import java.util.regex.Pattern

/** Lightweight reference finder. It deliberately avoids claiming semantic compiler-level references. */
class ReferenceEngine {
    data class Reference(val file: File, val line: Int, val column: Int, val text: String)

    fun find(root: File, symbol: Symbol): List<Reference> {
        if (!root.isDirectory || symbol.name.isEmpty()) return emptyList()
        val result = ArrayList<Reference>()
        val pattern = Pattern.compile("\\b" + Pattern.quote(symbol.name) + "\\b")
        root.walkTopDown().forEach { file ->
            if (!file.isFile || file.length() > 5L * 1024L * 1024L) return@forEach
            try {
                val text = file.readText()
                val matcher = pattern.matcher(text)
                while (matcher.find()) {
                    val line = lineOf(text, matcher.start())
                    val column = columnOf(text, matcher.start())
                    result.add(Reference(file, line, column, lineText(text, line)))
                }
            } catch (_: Exception) { }
        }
        return result
    }

    private fun lineOf(text: String, offset: Int): Int {
        var line = 1
        var i = 0
        while (i < offset && i < text.length) {
            if (text[i] == '\n') line++
            i++
        }
        return line
    }

    private fun columnOf(text: String, offset: Int): Int {
        var column = 1
        var i = offset - 1
        while (i >= 0 && text[i] != '\n') { column++; i-- }
        return column
    }

    private fun lineText(text: String, line: Int): String {
        var current = 1
        var start = 0
        var i = 0
        while (i < text.length) {
            if (current == line) {
                val end = text.indexOf('\n', i).let { if (it < 0) text.length else it }
                return text.substring(i, end).trim()
            }
            if (text[i] == '\n') current++
            i++
        }
        return ""
    }
}
