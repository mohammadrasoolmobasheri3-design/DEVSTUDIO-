package com.example.ultrapromax.engine.analysis

import com.example.ultrapromax.engine.language.LanguageService
import java.io.File

/** Stable facade for V26.6+ diagnostics consumers. */
class AnalysisService {
    private val languageService = LanguageService()
    private val diagnosticEngine = DiagnosticEngine(languageService)

    fun analyzeBuffer(fileName: String, source: String): List<Diagnostic> =
        diagnosticEngine.analyzeBuffer(fileName, source)

    fun analyzeFile(file: File): List<Diagnostic> = diagnosticEngine.analyzeFile(file)

    fun analyzeProject(root: File): List<Diagnostic> = diagnosticEngine.analyzeProject(root)

    fun analyzeProjectWithSummary(root: File): ProjectAnalyzer.Report = ProjectAnalyzer(root).run()
}
