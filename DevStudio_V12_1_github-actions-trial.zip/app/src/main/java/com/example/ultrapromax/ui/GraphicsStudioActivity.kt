package com.example.ultrapromax.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.graphicsstudio.GraphicsStudioEngine
import java.io.File
import kotlin.math.abs
import kotlin.math.max

class GraphicsStudioActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var engine: GraphicsStudioEngine
    private lateinit var drawing: GraphicsCanvasView
    private lateinit var status: TextView
    private val svgCommands = ArrayList<String>()
    private val undoBitmaps = ArrayList<Bitmap>()
    private val redoBitmaps = ArrayList<Bitmap>()
    private var currentColor = Color.WHITE
    private var strokeWidth = 8f
    private var tool = Tool.PEN
    private var fillShapes = false
    private var importedBitmap: Bitmap? = null
    private var importedUri: Uri? = null

    enum class Tool { PEN, ERASER, LINE, RECT, CIRCLE, TEXT }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graphics_studio)
        val id = intent.getLongExtra("project_id", -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        engine = GraphicsStudioEngine(File(project.folderPath))
        status = findViewById(R.id.graphicsStatus)
        drawing = findViewById(R.id.graphicsCanvas)
        drawing.configure()
        drawing.tool = tool.name
        drawing.strokeColor = currentColor
        drawing.strokeWidth = strokeWidth
        drawing.fillShapes = fillShapes
        drawing.onShapeCommitted = { command -> svgCommands.add(command) }
        drawing.onEditStarted = { snapshot() }

        findViewById<TextView>(R.id.graphicsBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.graphicsUndo).setOnClickListener { undo() }
        findViewById<Button>(R.id.graphicsRedo).setOnClickListener { redo() }
        findViewById<Button>(R.id.graphicsClear).setOnClickListener { clearCanvas() }
        findViewById<Button>(R.id.graphicsImport).setOnClickListener { importImage() }
        findViewById<Button>(R.id.graphicsSave).setOnClickListener { savePng() }
        findViewById<Button>(R.id.graphicsSvg).setOnClickListener { saveSvg() }
        findViewById<Button>(R.id.graphicsText).setOnClickListener { chooseText() }
        findViewById<Button>(R.id.graphicsPen).setOnClickListener { setTool(Tool.PEN) }
        findViewById<Button>(R.id.graphicsErase).setOnClickListener { setTool(Tool.ERASER) }
        findViewById<Button>(R.id.graphicsLine).setOnClickListener { setTool(Tool.LINE) }
        findViewById<Button>(R.id.graphicsRect).setOnClickListener { setTool(Tool.RECT) }
        findViewById<Button>(R.id.graphicsCircle).setOnClickListener { setTool(Tool.CIRCLE) }
        findViewById<Button>(R.id.graphicsFill).setOnClickListener { fillShapes = !fillShapes; drawing.fillShapes = fillShapes; updateStatus("Fill: ${if (fillShapes) "ON" else "OFF"}") }
        findViewById<Button>(R.id.graphicsColor).setOnClickListener { chooseColor() }
        findViewById<SeekBar>(R.id.graphicsSize).apply {
            progress = 8
            max = 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { strokeWidth = max(1, progress).toFloat(); drawing.strokeWidth = strokeWidth; updateStatus("Brush ${strokeWidth.toInt()} px") }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        updateStatus("Graphics Studio • offline • ${project.name}")
    }

    private fun setTool(next: Tool) { tool = next; drawing.tool = next.name; updateStatus("Tool: ${next.name}") }
    private fun updateStatus(text: String) { status.text = text }

    private fun snapshot() {
        if (drawing.width <= 0 || drawing.height <= 0) return
        undoBitmaps.add(drawing.exportBitmap())
        if (undoBitmaps.size > 30) undoBitmaps.removeAt(0)
        redoBitmaps.clear()
    }

    private fun undo() {
        if (undoBitmaps.isEmpty()) return
        redoBitmaps.add(drawing.exportBitmap())
        drawing.setBitmap(undoBitmaps.removeAt(undoBitmaps.lastIndex))
        updateStatus("Undo")
    }

    private fun redo() {
        if (redoBitmaps.isEmpty()) return
        undoBitmaps.add(drawing.exportBitmap())
        drawing.setBitmap(redoBitmaps.removeAt(redoBitmaps.lastIndex))
        updateStatus("Redo")
    }

    private fun clearCanvas() {
        snapshot(); drawing.clear(); svgCommands.clear(); importedBitmap = null; importedUri = null; updateStatus("Canvas cleared")
    }

    private fun chooseColor() {
        val colors = arrayOf(Color.WHITE, Color.BLACK, Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.rgb(255, 128, 0))
        val labels = arrayOf("White", "Black", "Red", "Yellow", "Green", "Cyan", "Blue", "Magenta", "Orange")
        AlertDialog.Builder(this).setTitle("Brush Color").setItems(labels) { _, which -> currentColor = colors[which]; drawing.strokeColor = currentColor; updateStatus("Color: ${labels[which]}") }.show()
    }

    private fun chooseText() {
        val input = EditText(this)
        input.hint = "Text to draw"
        AlertDialog.Builder(this).setTitle("Add Text").setView(input).setPositiveButton("ADD") { _, _ ->
            val text = input.text.toString()
            if (text.isNotEmpty()) { snapshot(); drawing.addText(text, currentColor, strokeWidth * 4f); svgCommands.add("<text x=\"40\" y=\"80\" fill=\"${engine.colorHex(currentColor)}\" font-size=\"${strokeWidth * 4f}\">${escapeXml(text)}</text>"); updateStatus("Text added") }
        }.setNegativeButton("CANCEL", null).show()
    }

    private fun escapeXml(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun importImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(intent, 90)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 90 || resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        try {
            snapshot()
            val bm = MediaStore.Images.Media.getBitmap(contentResolver, uri)
            importedBitmap = bm
            importedUri = uri
            drawing.addImage(bm)
            updateStatus("Image imported locally")
        } catch (e: Exception) { Toast.makeText(this, "Image import failed", Toast.LENGTH_SHORT).show() }
    }

    private fun savePng() {
        val file = engine.savePng(drawing.exportBitmap(), project.name + "_graphics")
        updateStatus("PNG saved: ${file.name}")
        Toast.makeText(this, "Saved ${file.name}", Toast.LENGTH_SHORT).show()
    }

    private fun saveSvg() {
        val file = engine.saveSvg(drawing.width, drawing.height, Color.rgb(18, 20, 28), svgCommands, project.name + "_graphics")
        updateStatus("SVG saved: ${file.name}")
        Toast.makeText(this, "Saved ${file.name}", Toast.LENGTH_SHORT).show()
    }

}
