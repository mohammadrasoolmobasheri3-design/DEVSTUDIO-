package com.example.ultrapromax.engine.preview
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.io.File
class RealTimePreviewController(private val webView:WebView,private val projectDir:File){
 private val handler=Handler(Looper.getMainLooper()); private var pending:Runnable?=null; private var last=0L
 fun start(intervalMs:Long=350L){stop();val task=object:Runnable{override fun run(){val now=newest(projectDir);if(last!=0L&&now!=last)webView.reload();last=now;handler.postDelayed(this,intervalMs)}};pending=task;handler.post(task)}
 fun stop(){pending?.let{handler.removeCallbacks(it)};pending=null}
 private fun newest(root:File):Long{var v=0L;if(!root.isDirectory)return v;root.walkTopDown().filter{it.isFile}.forEach{if(it.lastModified()>v)v=it.lastModified()};return v}
}
