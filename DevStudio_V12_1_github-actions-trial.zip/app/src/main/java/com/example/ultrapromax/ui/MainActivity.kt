package com.example.ultrapromax.ui

import android.content.Intent
import androidx.appcompat.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.workspace.WorkspaceSession
import com.example.ultrapromax.engine.file.FileEngine
import com.example.ultrapromax.engine.file.ProjectTemplate
import com.example.ultrapromax.engine.gamify.GamificationEngine
import com.example.ultrapromax.engine.studio.StudioUiFinalizer
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object { private const val REQUEST_OPEN_PROJECT = 2401 }
    private lateinit var fileEngine: FileEngine
    private lateinit var gamify: GamificationEngine
    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = Color.parseColor("#02051A")
        window.navigationBarColor = Color.parseColor("#02051A")
        window.decorView.systemUiVisibility = 0

        try { fileEngine = FileEngine(this) } catch (_: Throwable) { }
        try { gamify = GamificationEngine(this) } catch (_: Throwable) { }
        listContainer = findViewById(R.id.recentProjectsList)

        findViewById<Button>(R.id.btnNewProject).setOnClickListener { openAdvancedNewProject() }
        findViewById<Button>(R.id.btnOpenProject).setOnClickListener { openSystemProjectPicker() }
        findViewById<Button>(R.id.btnUiBuilder).setOnClickListener { openCurrentUiBuilder() }
        findViewById<Button>(R.id.btnFileExplorer).setOnClickListener { openCurrentFileManager() }
        findViewById<Button>(R.id.btnProjectStudio).setOnClickListener { openCurrentProjectStudio() }
        findViewById<View>(R.id.navHome).setOnClickListener { findViewById<android.widget.ScrollView>(R.id.homeScroll).smoothScrollTo(0, 0) }
        findViewById<View>(R.id.btnNotifications).setOnClickListener { showSystemStatus() }
        findViewById<TextView>(R.id.navProjects).setOnClickListener { openCurrentProjectStudio() }
        findViewById<TextView>(R.id.navCreate).setOnClickListener { openAdvancedNewProject() }
        findViewById<TextView>(R.id.navMore).setOnClickListener { openDrawer() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { openDrawer() }
        findViewById<View>(R.id.btnCloseDrawer).setOnClickListener { closeDrawer() }
        findViewById<View>(R.id.drawerShade).setOnClickListener { closeDrawer() }

        wireDrawerItem(R.id.menuHome) { closeDrawer() }
        wireDrawerItem(R.id.menuProjects) { closeDrawer(); openCurrentProjectStudio() }
        wireDrawerItem(R.id.menuEditor) { closeDrawer(); openCurrentEditor() }
        wireDrawerItem(R.id.menuUiBuilder) { closeDrawer(); openCurrentUiBuilder() }
        wireDrawerItem(R.id.menuAssets) { closeDrawer(); openCurrentAssets() }
        wireDrawerItem(R.id.menuConsole) { closeDrawer(); openCurrentDiagnostics() }
        wireDrawerItem(R.id.menuBuild) { closeDrawer(); openCurrentBuildRelease() }
        wireDrawerItem(R.id.menuSettings) { closeDrawer(); showSettingsInfo() }
        wireDrawerItem(R.id.menuAbout) { closeDrawer(); showAboutDialog() }

        val statusText = findViewById<TextView>(R.id.topStatus)
        try {
            statusText.text = getString(R.string.offline_mode)
            gamify.level
        } catch (_: Throwable) { }
    }

    private fun wireDrawerItem(id: Int, action: () -> Unit) {
        findViewById<TextView>(id).setOnClickListener { action() }
    }

    private fun openDrawer() {
        val drawer = findViewById<View>(R.id.navigationDrawer)
        val shade = findViewById<View>(R.id.drawerShade)
        shade.visibility = View.VISIBLE
        drawer.animate().translationX(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        val drawer = findViewById<View>(R.id.navigationDrawer)
        val shade = findViewById<View>(R.id.drawerShade)
        drawer.animate().translationX(-dp(320).toFloat()).setDuration(200).withEndAction {
            shade.visibility = View.GONE
        }.start()
    }

    override fun onBackPressed() {
        val drawer = findViewById<View>(R.id.navigationDrawer)
        if (drawer.translationX > -dp(300)) {
            closeDrawer()
        } else {
            super.onBackPressed()
        }
    }

    private fun showSystemStatus() {
        val project = currentProject()
        val name = project?.name ?: "No project selected"
        AlertDialog.Builder(this)
            .setTitle("System Status")
            .setMessage("Mode: Offline-first\nProject: $name\nProject Engine: Ready\nEditor Engine: Ready\nUI Engine: Ready\nBuild Engine: depends on installed toolchain")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSettingsInfo() {
        AlertDialog.Builder(this)
            .setTitle("DevStudio Settings")
            .setMessage("Use the Studio modules to configure editor, build, runtime, security and project options.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("DEVSTUDIO ULTRA PRO MAX+")
            .setMessage("Offline-first development studio\nVersion 30.1.0\n\nBuild your dreams.")
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshProjectList()
        try {
            findViewById<TextView>(R.id.topStatus).text = getString(R.string.offline_mode) + "  |  Lv.${gamify.level}  (${gamify.xp} XP) →"
        } catch (_: Throwable) { }
    }

    private fun refreshProjectList() {
        listContainer.removeAllViews()
        val projects = ProjectStore.list(this)
        if (projects.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "No projects yet — create your first workspace."
                setTextColor(Color.parseColor("#8FA0D0"))
                textSize = 11f
                setPadding(dp(10), dp(16), dp(10), dp(16))
            })
            return
        }
        projects.take(8).forEach { project ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(8), dp(9))
                setBackgroundResource(R.drawable.ultra_outline)
                isClickable = true
                isFocusable = true
                setOnClickListener { openProject(project) }
            }
            val icon = TextView(this).apply {
                text = "▣"
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#52E8FF"))
                textSize = 18f
                setBackgroundResource(R.drawable.mobile_chip)
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(6), 0)
            }
            info.addView(TextView(this).apply {
                text = project.name
                setTextColor(Color.WHITE)
                textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            info.addView(TextView(this).apply {
                text = "${project.template}  •  Workspace"
                setTextColor(Color.parseColor("#8FA0D0"))
                textSize = 9f
                setPadding(0, dp(2), 0, 0)
            })
            row.addView(info, LinearLayout.LayoutParams(0, dp(56), 1f))
            val open = Button(this).apply {
                text = "OPEN"
                setAllCaps(false)
                setTextColor(Color.WHITE)
                textSize = 9f
                background = getDrawable(R.drawable.ultra_glow_blue)
                backgroundTintList = null
                setOnClickListener { openProject(project) }
            }
            row.addView(open, LinearLayout.LayoutParams(dp(62), dp(42)))
            val delete = TextView(this).apply {
                text = "×"
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#FF7A9B"))
                textSize = 22f
                setPadding(dp(7), 0, dp(3), 0)
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Delete project?")
                        .setMessage("${project.name}\n\nThis removes the DevStudio registration and its project folder.")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("DELETE") { _, _ ->
                            try {
                                ProjectStore.delete(this@MainActivity, project.id)
                                File(project.folderPath).deleteRecursively()
                                refreshProjectList()
                                Toast.makeText(this@MainActivity, "Project deleted: ${project.name}", Toast.LENGTH_SHORT).show()
                            } catch (e: Throwable) {
                                Toast.makeText(this@MainActivity, "Delete failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                            }
                        }.show()
                }
            }
            row.addView(delete, LinearLayout.LayoutParams(dp(34), dp(48)))
            val lp = LinearLayout.LayoutParams(-1, dp(72))
            lp.setMargins(0, 0, 0, dp(7))
            listContainer.addView(row, lp)
        }
    }

    private data class ProjectTypeOption(
        val title: String,
        val subtitle: String,
        val backgroundRes: Int,
        val template: ProjectTemplate?
    )

    private fun openCurrentFileManager() {
        val project = currentProject()
        if (project == null) {
            Toast.makeText(this, "Create or open an Android project first.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, InternalFileManagerActivity::class.java).apply {
            putExtra(InternalFileManagerActivity.EXTRA_PROJECT_ID, project.id)
        })
    }

    private fun openAdvancedNewProject() {
        startActivity(Intent(this, AdvancedNewProjectActivity::class.java))
    }

    private fun showNewProjectDialog() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(12))
            setBackgroundResource(R.drawable.neon_panel)
        }

        val title = TextView(this).apply {
            text = "✦  CREATE NEW PROJECT"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        panel.addView(title, LinearLayout.LayoutParams(-1, dp(42)))

        val subtitle = TextView(this).apply {
            text = "Choose what you want to build"
            setTextColor(Color.parseColor("#FF8FE8FF"))
            textSize = 11f
            gravity = Gravity.CENTER
        }
        panel.addView(subtitle, LinearLayout.LayoutParams(-1, dp(28)))

        val search = createProjectInput("Search project type...", "")
        panel.addView(search, LinearLayout.LayoutParams(-1, dp(46)).apply {
            setMargins(0, dp(4), 0, dp(5))
        })

        val typesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        panel.addView(typesContainer, LinearLayout.LayoutParams(-1, 0, 1f))

        val options = listOf(
            ProjectTypeOption("▣  NATIVE KOTLIN PROJECT", "Android • Kotlin", R.drawable.home_button_cyan, ProjectTemplate.AndroidKotlin),
            ProjectTypeOption("☕  ANDROID JAVA PROJECT", "Android • Java", R.drawable.home_button_violet, ProjectTemplate.AndroidJava),
            ProjectTypeOption("◈  ANDROID UI PROJECT", "Android • Kotlin + XML UI", R.drawable.home_button_pink, ProjectTemplate.AndroidUi)
        )

        fun renderOptions(query: String) {
            typesContainer.removeAllViews()
            val q = query.trim().toLowerCase(Locale.US)
            options.filter {
                q.isEmpty() || it.title.toLowerCase(Locale.US).contains(q) || it.subtitle.toLowerCase(Locale.US).contains(q)
            }.forEach { option ->
                addProjectTypeButton(typesContainer, option.title, option.subtitle, option.backgroundRes) {
                    dialog.dismiss()
                    if (option.template == null) {
                        showTemplatePicker()
                    } else {
                        showProjectDetails(option.template)
                    }
                }
            }
            if (typesContainer.childCount == 0) {
                typesContainer.addView(TextView(this).apply {
                    text = "No project type found"
                    setTextColor(Color.parseColor("#FF8FA0C8"))
                    gravity = Gravity.CENTER
                    setPadding(0, dp(18), 0, dp(18))
                })
            }
        }

        renderOptions("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderOptions(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        val cancel = TextView(this).apply {
            text = "CANCEL"
            setTextColor(Color.parseColor("#FFB8C6E8"))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { dialog.dismiss() }
        }
        panel.addView(cancel, LinearLayout.LayoutParams(-1, dp(42)))

        dialog = AlertDialog.Builder(this)
            .setView(panel)
            .create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), dp(620))
    }

    private lateinit var dialog: AlertDialog

    private fun addProjectTypeButton(
        parent: LinearLayout,
        titleText: String,
        subtitleText: String,
        backgroundRes: Int,
        action: () -> Unit
    ) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(7), dp(16), dp(7))
            setBackgroundResource(backgroundRes)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }

        val title = TextView(this).apply {
            text = titleText
            setTextColor(Color.WHITE)
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = subtitleText
            setTextColor(Color.parseColor("#FFD6E2FF"))
            textSize = 9f
            gravity = Gravity.CENTER_VERTICAL
        }
        box.addView(title, LinearLayout.LayoutParams(-1, dp(24)))
        box.addView(subtitle, LinearLayout.LayoutParams(-1, dp(20)))

        val lp = LinearLayout.LayoutParams(-1, dp(66))
        lp.setMargins(0, dp(7), 0, 0)
        parent.addView(box, lp)
    }

    private fun showProjectNameDialog(template: ProjectTemplate?) {
        if (template == null) {
            showTemplatePicker()
            return
        }
        showProjectDetails(template)
    }

    private fun showTemplatePicker() {
        val templates = ProjectTemplate.all()
        val labels = templates.map {
            when (it) {
                ProjectTemplate.KotlinBasic -> "▣  Kotlin Basic"
                ProjectTemplate.HtmlCssJs -> "◇  Web App (HTML/CSS/JS)"
                ProjectTemplate.Todo -> "◆  To-Do Web App"
                ProjectTemplate.Blank -> "□  Empty Project"
                else -> it.displayName
            }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Choose Project Template")
            .setItems(labels) { _, which -> showProjectDetails(templates[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showProjectDetails(template: ProjectTemplate) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(4))
        }

        val nameInput = createProjectInput("Project name", "MyProject")
        val packageInput = createProjectInput("Package / App ID", defaultPackageFor(template))

        panel.addView(label("PROJECT NAME"))
        panel.addView(nameInput, LinearLayout.LayoutParams(-1, dp(48)))
        panel.addView(label("PACKAGE / APP ID"))
        panel.addView(packageInput, LinearLayout.LayoutParams(-1, dp(48)))

        if (template == ProjectTemplate.HtmlCssJs || template == ProjectTemplate.Todo) {
            panel.addView(label("WEB TEMPLATE"))
            panel.addView(TextView(this).apply {
                text = template.displayName
                setTextColor(Color.parseColor("#FF8FE8FF"))
                textSize = 12f
                setPadding(dp(4), 0, 0, dp(10))
            })
        } else if (template == ProjectTemplate.KotlinBasic) {
            panel.addView(label("LANGUAGE"))
            panel.addView(TextView(this).apply {
                text = "Kotlin"
                setTextColor(Color.parseColor("#FFD6E2FF"))
                textSize = 12f
                setPadding(dp(4), 0, 0, dp(10))
            })
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("${template.displayName} • Project Details")
            .setView(panel)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE PROJECT", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameInput.text.toString().trim()
                val packageName = packageInput.text.toString().trim()

                val nameError = validateProjectName(name)
                if (nameError != null) {
                    nameInput.error = nameError
                    return@setOnClickListener
                }

                val packageError = validatePackageName(packageName, template)
                if (packageError != null) {
                    packageInput.error = packageError
                    return@setOnClickListener
                }

                if (ProjectStore.list(this).any { it.name.equals(name, ignoreCase = true) }) {
                    nameInput.error = "A project with this name already exists"
                    return@setOnClickListener
                }

                dialog.dismiss()
                createProject(name, template, packageName)
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), -2)
    }

    private fun createProjectInput(hint: String, value: String): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#FF8FA0C8"))
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundResource(R.drawable.studio_input)
        }
    }

    private fun label(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#FF8FE8FF"))
            textSize = 9f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(4), dp(8), 0, dp(4))
        }
    }

    private fun defaultPackageFor(template: ProjectTemplate): String {
        return when (template) {
            ProjectTemplate.KotlinBasic -> "com.example.myproject"
            ProjectTemplate.AndroidJava, ProjectTemplate.AndroidUi, ProjectTemplate.WebViewApp, ProjectTemplate.AndroidKotlin -> "com.example.newproject"
            ProjectTemplate.HtmlCssJs -> "my-web-app"
            ProjectTemplate.Todo -> "my-todo-app"
            ProjectTemplate.Blank -> "my-project"
        }
    }

    private fun validateProjectName(name: String): String? {
        if (name.isEmpty()) return "Project name is required"
        if (name.length > 60) return "Project name is too long"
        if (!name.matches(Regex("[A-Za-z0-9][A-Za-z0-9 _-]*"))) {
            return "Use letters, numbers, spaces, _ or -"
        }
        return null
    }

    private fun validatePackageName(value: String, template: ProjectTemplate): String? {
        if (value.isEmpty()) return "This field is required"
        if (template == ProjectTemplate.HtmlCssJs || template == ProjectTemplate.Todo || template == ProjectTemplate.Blank) {
            if (!value.matches(Regex("[A-Za-z0-9][A-Za-z0-9_-]*"))) return "Use letters, numbers, _ or -"
        } else if (!value.matches(Regex("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+"))) {
            return "Example: com.example.myproject"
        }
        return null
    }

    private fun showTemplatesDialog() {
        val templates = ProjectTemplate.all()
        AlertDialog.Builder(this).setTitle(R.string.templates).setItems(templates.map { it.displayName }.toTypedArray()) { _, which ->
            val t = templates[which]; createProject(t.displayName, t)
        }.show()
    }

    private fun openSystemProjectPicker() {
        // OPEN PROJECT is a folder workflow, not a ZIP/file workflow.
        // The selected folder is imported into DevStudio's local workspace and
        // then opened directly in Project Studio.
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra("android.content.extra.SHOW_ADVANCED", true)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            startActivityForResult(intent, REQUEST_OPEN_PROJECT)
        } catch (_: Exception) {
            Toast.makeText(this, "No folder picker is available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Using the legacy result API keeps compatibility with the project's AndroidX versions.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_OPEN_PROJECT || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        if (!DocumentsContract.isTreeUri(treeUri)) {
            Toast.makeText(this, "Selected location is not a folder.", Toast.LENGTH_LONG).show()
            return
        }

        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Some providers do not offer persistable permissions; the current
            // operation can still continue with the granted URI.
        }

        importProjectFolder(treeUri)
    }

    private fun importProjectFolder(treeUri: Uri) {
        Toast.makeText(this, "Opening project folder…", Toast.LENGTH_SHORT).show()

        Thread {
            try {
                val rootName = queryDocumentName(treeUri)?.takeIf { it.isNotBlank() } ?: "ImportedProject"
                val safeFolderName = "${System.currentTimeMillis()}_${sanitizeFolderName(rootName)}"
                val target = fileEngine.projectRoot(safeFolderName)
                if (target.exists()) target.deleteRecursively()
                target.mkdirs()

                copyTreeDocument(treeUri, treeUri, target)
                val projectName = readImportedProjectName(target, rootName)
                val template = detectImportedTemplate(target)

                val existing = ProjectStore.getByFolder(this, target.absolutePath)
                val project = existing ?: ProjectStore.insert(this, projectName, target.absolutePath, template.id)

                runOnUiThread {
                    Toast.makeText(this, "Project opened in Project Studio", Toast.LENGTH_SHORT).show()
                    refreshProjectList()
                    openProject(project)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Could not open project folder: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun queryDocumentName(treeUri: Uri): String? {
        // A TREE URI is not itself a document URI. Query the root document
        // represented by the tree URI instead of passing the tree URI to
        // DocumentsContract.getDocumentId(), which throws on
        // content://.../tree/... URIs on Android's external storage provider.
        val rootDocumentUri = try {
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        } catch (_: Exception) {
            treeUri
        }

        val projection = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        contentResolver.query(rootDocumentUri, projection, null, null, null)?.use { cursor ->
            val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            if (nameCol >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameCol)
            }
        }
        return null
    }

    private fun copyTreeDocument(treeUri: Uri, documentUri: Uri, targetDir: File) {
        // The root passed from ACTION_OPEN_DOCUMENT_TREE is a TREE URI, while
        // child document URIs built below are DOCUMENT URIs. They require
        // different DocumentsContract accessors.
        val documentId = if (documentUri == treeUri) {
            DocumentsContract.getTreeDocumentId(treeUri)
        } else {
            DocumentsContract.getDocumentId(documentUri)
        }
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, documentId
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getString(idCol)
                val name = cursor.getString(nameCol) ?: "item"
                val mime = cursor.getString(mimeCol) ?: ""
                if (name == ".gradle" || name == "build") continue

                val safeName = sanitizeFileName(name)
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                val out = File(targetDir, safeName)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    out.mkdirs()
                    copyTreeDocument(treeUri, childUri, out)
                } else {
                    out.parentFile?.mkdirs()
                    contentResolver.openInputStream(childUri)?.use { input ->
                        out.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Cannot read $name")
                }
            }
        }
    }

    private fun readImportedProjectName(dir: File, fallback: String): String {
        val marker = File(dir, ".devstudio-project")
        if (marker.isFile) {
            marker.readLines().firstOrNull { it.startsWith("name=") }?.substringAfter("=")?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return fallback.removeSuffix(".zip").removeSuffix(".ZIP")
    }

    private fun detectImportedTemplate(dir: File): ProjectTemplate {
        if (File(dir, "settings.gradle").exists() || File(dir, "settings.gradle.kts").exists() || File(dir, "gradlew").exists()) {
            return ProjectTemplate.AndroidKotlin
        }
        if (File(dir, "index.html").exists()) return ProjectTemplate.HtmlCssJs
        return ProjectTemplate.Blank
    }

    private fun sanitizeFolderName(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "ImportedProject" }

    private fun sanitizeFileName(value: String): String =
        value.replace("/", "_").replace("\\", "_").ifBlank { "item" }

    private fun createProject(name: String, template: ProjectTemplate, packageName: String = "") {
        val folderName = "${System.currentTimeMillis()}_${name.replace(" ", "_")}"
        val dir = fileEngine.createProject(folderName, template)
        customizeGeneratedProject(dir, template, packageName, name)
        File(dir, ".devstudio-project").writeText(
            "name=$name\ntemplate=${template.id}\npackage=$packageName\nversion=1\n"
        )
        val project = ProjectStore.insert(this, name, dir.absolutePath, template.id)
        gamify.onProjectCreated().forEach { achievement -> Toast.makeText(this, "Achievement unlocked: ${achievement.title} (+${achievement.xpReward} XP)", Toast.LENGTH_LONG).show() }
        refreshProjectList(); openProject(project)
    }

    private fun customizeGeneratedProject(dir: File, template: ProjectTemplate, packageName: String, projectName: String) {
        if (template != ProjectTemplate.AndroidJava && template != ProjectTemplate.AndroidUi &&
            template != ProjectTemplate.WebViewApp && template != ProjectTemplate.AndroidKotlin) return
        val safePackage = packageName.trim()
        if (safePackage.isEmpty()) return

        val oldPackage = "com.example.newproject"
        dir.walkTopDown()
            .filter { it.isFile && (it.extension == "java" || it.extension == "kt" || it.extension == "gradle" || it.extension == "xml") }
            .forEach { file ->
                try {
                    val text = file.readText()
                    file.writeText(
                        text.replace(oldPackage, safePackage)
                            .replace("rootProject.name = \"NewProject\"", "rootProject.name = \"" + projectName.replace("\"", "") + "\"")
                            .replace("android:label=\"New Project\"", "android:label=\"" + projectName.replace("\"", "") + "\"")
                    )
                } catch (_: Exception) {
                    // Keep the generated file if a single replacement fails.
                }
            }
    }

    private fun openProject(project: Project) {
        try {
            if (project.id < 0L) {
                Toast.makeText(this, "Invalid project ID.", Toast.LENGTH_LONG).show()
                return
            }
            val stored = ProjectStore.getById(this, project.id)
            if (stored == null) {
                Toast.makeText(this, "Project is not registered in DevStudio.", Toast.LENGTH_LONG).show()
                return
            }
            WorkspaceSession.open(this, stored, "files")
            val intent = Intent(this, ProjectStudioActivity::class.java).apply {
                putExtra(ProjectStudioActivity.EXTRA_PROJECT_ID, stored.id)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(intent)
        } catch (e: Throwable) {
            Toast.makeText(this, "Could not open project: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showProjectActions(project: Project) {
        AlertDialog.Builder(this).setTitle(project.name).setItems(arrayOf("Open Project Studio", "Open Code Editor", "File Manager", "Rename", "Delete", "Properties")) { _, which ->
            when (which) {
                0 -> openProject(project)
                1 -> startActivity(Intent(this, EditorActivity::class.java).putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id))
                2 -> startActivity(Intent(this, InternalFileManagerActivity::class.java).putExtra(InternalFileManagerActivity.EXTRA_PROJECT_ID, project.id))
                3 -> renameProject(project)
                4 -> { ProjectStore.delete(this, project.id); File(project.folderPath).deleteRecursively(); refreshProjectList() }
                5 -> AlertDialog.Builder(this).setTitle("Project Properties").setMessage("${project.name}\n${project.template}\n${project.folderPath}").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun renameProject(project: Project) {
        val input = EditText(this).apply { setText(project.name) }
        AlertDialog.Builder(this).setTitle("Rename Project").setView(input).setPositiveButton("Save") { _, _ ->
            val name = input.text.toString().trim(); if (name.isNotEmpty()) {
                val all = ProjectStore.list(this).map { if (it.id == project.id) it.copy(name = name) else it }
                File(filesDir, "projects.index").writeText(all.joinToString("\n") { "${it.id}|${it.name}|${it.folderPath}|${it.createdAt}|${it.template}" } + "\n")
                refreshProjectList()
            }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun currentProject(): com.example.ultrapromax.data.Project? {
        val id = WorkspaceSession.lastProjectId(this)
        if (id >= 0L) ProjectStore.getById(this, id)?.let { return it }
        return ProjectStore.list(this).firstOrNull()
    }

    private fun openCurrentProjectStudio() {
        val p = currentProject()
        if (p == null) {
            Toast.makeText(this, "No project is available. Open or create a project first.", Toast.LENGTH_LONG).show()
            return
        }
        WorkspaceSession.open(this, p, "files")
        startActivity(Intent(this, ProjectStudioActivity::class.java).apply {
            putExtra(ProjectStudioActivity.EXTRA_PROJECT_ID, p.id)
        })
    }

    private fun openCurrentEditor() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        WorkspaceSession.open(this, p, "code")
        startActivity(Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_PROJECT_ID, p.id)
        })
    }

    private fun openCurrentUiBuilder() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        WorkspaceSession.open(this, p, "design")
        startActivity(Intent(this, UiBuilderActivity::class.java).apply {
            putExtra(UiBuilderActivity.EXTRA_PROJECT_ID, p.id)
        })
    }

    private fun openCurrentAssets() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, AssetManagerActivity::class.java).apply {
            putExtra(AssetManagerActivity.EXTRA_PROJECT_ID, p.id)
        })
    }

    private fun openCurrentDiagnostics() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, DiagnosticsActivity::class.java).apply {
            putExtra("project_id", p.id)
        })
    }

    private fun openCurrentRunStudio() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, RunStudioActivity::class.java).apply {
            putExtra(RunStudioActivity.EXTRA_PROJECT_ID, p.id)
        })
    }

    private fun openCurrentBuildRelease() {
        val p = currentProject() ?: run {
            Toast.makeText(this, "No project is available.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, BuildReleaseActivity::class.java).apply {
            putExtra(BuildReleaseActivity.EXTRA_PROJECT_ID, p.id)
        })
    }


}
