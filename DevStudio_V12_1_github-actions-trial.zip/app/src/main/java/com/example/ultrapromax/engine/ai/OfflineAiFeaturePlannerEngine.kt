package com.example.ultrapromax.engine.ai

/** Deterministic offline feature planner used before generation. */
class OfflineAiFeaturePlannerEngine {
    data class Feature(val id: String, val description: String, val files: List<String>)
    fun plan(prompt: String): List<Feature> {
        val p = prompt.toLowerCase()
        val out = ArrayList<Feature>()
        fun add(id: String, d: String, vararg files: String) { out.add(Feature(id, d, files.toList())) }
        if (p.contains("login") || p.contains("auth")) add("auth", "Local authentication flow", "AuthManager.kt", "LoginActivity.kt")
        if (p.contains("database") || p.contains("sqlite") || p.contains("دیتابیس")) add("database", "Local SQLite data layer", "Database.kt")
        if (p.contains("api") || p.contains("server")) add("local_api", "Offline loopback API integration", "LocalApi.kt")
        if (p.contains("list") || p.contains("todo") || p.contains("لیست")) add("list", "List based UI", "ListScreen.kt")
        if (p.contains("theme") || p.contains("dark") || p.contains("تم")) add("theme", "Theme and design tokens", "Theme.kt")
        if (p.contains("animation") || p.contains("انیمیشن")) add("motion", "Local motion presets", "Motion.kt")
        if (out.isEmpty()) add("starter", "Verified starter application", "MainActivity.kt")
        return out
    }
}
