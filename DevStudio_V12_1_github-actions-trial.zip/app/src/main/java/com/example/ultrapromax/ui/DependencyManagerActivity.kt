package com.example.ultrapromax.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.dependency.DependencyStatus
import com.example.ultrapromax.engine.dependency.LocalPackageManager
import com.example.ultrapromax.engine.dependency.PackageDependencyEngine
import com.example.ultrapromax.engine.vfs.VirtualFileSystem
import java.io.File

class DependencyManagerActivity : AppCompatActivity() {
    companion object { const val EXTRA_PROJECT_ID = "extra_project_id"; private const val PICK_ARTIFACT = 7101 }
    private lateinit var project: Project
    private lateinit var engine: PackageDependencyEngine
    private lateinit var local: LocalPackageManager
    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        project = ProjectStore.getById(this, intent.getLongExtra(EXTRA_PROJECT_ID, -1L)) ?: run { finish(); return }
        val root = File(project.folderPath)
        engine = PackageDependencyEngine(VirtualFileSystem(root))
        local = LocalPackageManager(root)
        setContentView(buildUi())
        refresh()
    }

    private fun buildUi(): View {
        val bg = Color.rgb(7, 9, 16)
        val panel = Color.rgb(17, 21, 33)
        val primary = Color.WHITE
        val secondary = Color.rgb(154, 164, 192)
        val accent = Color.rgb(100, 210, 255)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(panel) }
        val back = TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(primary); gravity = Gravity.CENTER; setOnClickListener { finish() } }
        header.addView(back, LinearLayout.LayoutParams(dp(44), dp(54)))
        header.addView(TextView(this).apply { text = "DEPENDENCY / PACKAGE MANAGER\n${project.name}"; textSize = 16f; setTextColor(primary); setTypeface(null, 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(4)) }
        actions.addView(button("SCAN", accent) { refresh() }, weightParams())
        actions.addView(button("LOCK", accent) { writeLock() }, weightParams())
        actions.addView(button("ADD JAR/AAR", primary) { pickArtifact() }, weightParams(1.25f))
        root.addView(actions)

        status = TextView(this).apply { setTextColor(secondary); textSize = 12f; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(panel) }
        root.addView(status)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(18)) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun refresh() {
        list.removeAllViews()
        val report = engine.inspectProject()
        val valid = report.report.dependencies.count { it.status == DependencyStatus.VALID }
        val problems = report.report.dependencies.count { it.status == DependencyStatus.CONFLICT || it.status == DependencyStatus.DUPLICATE || it.status == DependencyStatus.INVALID || it.status == DependencyStatus.MISSING_VERSION }
        status.text = "Gradle files: ${report.sourceFiles.size}   •   Dependencies: ${report.report.dependencies.size}   •   Valid: $valid   •   Problems: $problems\nLocal artifacts: ${local.list().size}   •   Lock: ${if (report.lockProblems.isEmpty()) "OK" else "MISMATCH"}"
        if (report.report.dependencies.isEmpty()) addMessage("No standard Gradle dependency declarations were found.")
        report.report.dependencies.forEach { record ->
            val color = when (record.status) { DependencyStatus.VALID -> Color.rgb(130, 230, 160); DependencyStatus.DUPLICATE -> Color.rgb(255, 210, 100); DependencyStatus.CONFLICT, DependencyStatus.INVALID, DependencyStatus.MISSING_VERSION -> Color.rgb(255, 110, 110); else -> Color.WHITE }
            addCard("${record.coordinate.notation()}\n${record.coordinate.scope}  •  ${record.status}\n${record.detail}", color)
        }
        if (report.lockProblems.isNotEmpty()) report.lockProblems.forEach { addCard("LOCK: $it", Color.rgb(255, 180, 90)) }
        addMessage("LOCAL LIBS")
        local.list().forEach { artifact -> addArtifactCard(artifact.file.name, artifact.type.toUpperCase() + "  •  " + artifact.size + " bytes") }
    }

    private fun writeLock() {
        if (engine.writeLock()) { Toast.makeText(this, "Dependency lock saved locally.", Toast.LENGTH_SHORT).show(); refresh() }
        else Toast.makeText(this, "Could not write dependency lock.", Toast.LENGTH_SHORT).show()
    }

    private fun pickArtifact() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, PICK_ARTIFACT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_ARTIFACT || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val name = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "local-artifact.jar" } ?: "local-artifact.jar"
                val temp = File(cacheDir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                temp.outputStream().use { output -> input.copyTo(output) }
                val installed = local.install(temp)
                temp.delete()
                Toast.makeText(this, if (installed != null) "Installed in project libs/" else "Only .jar and .aar are supported.", Toast.LENGTH_SHORT).show()
                refresh()
            }
        } catch (e: Exception) { Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun addArtifactCard(title: String, detail: String) { addCard("$title\n$detail", Color.rgb(170, 190, 220)) }
    private fun addMessage(text: String) { list.addView(TextView(this).apply { this.text = text; setTextColor(Color.rgb(154,164,192)); textSize = 12f; setPadding(dp(4), dp(10), dp(4), dp(6)) }) }
    private fun addCard(text: String, color: Int) { val row = TextView(this).apply { this.text = text; setTextColor(color); textSize = 12f; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundResource(R.drawable.glass_card) }; val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(6)); list.addView(row, lp) }
    private fun button(text: String, color: Int, click: () -> Unit) = Button(this).apply { this.text = text; setTextColor(color); textSize = 9f; setOnClickListener { click() }; background = getDrawable(R.drawable.studio_action_button); minHeight = 0; minWidth = 0; setPadding(0,0,0,0) }
    private fun weightParams(weight: Float = 1f) = LinearLayout.LayoutParams(0, dp(42), weight).apply { setMargins(dp(3), 0, dp(3), 0) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
