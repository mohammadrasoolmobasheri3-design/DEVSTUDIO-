package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.file.FileEngine
import com.example.ultrapromax.engine.studio.StudioIntegrationEngine
import com.example.ultrapromax.engine.studio.StudioExperienceEngine
import com.example.ultrapromax.engine.studio.StudioUiFinalizer
import com.example.ultrapromax.engine.workspace.WorkspaceSession
import com.example.ultrapromax.engine.workspace.ProjectOsEngine
import com.example.ultrapromax.engine.studio.StudioPanelState
import java.io.File
import java.text.DecimalFormat

class ProjectStudioActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var fileTree: LinearLayout
    private lateinit var fileEngine: FileEngine
    private lateinit var studioIntegration: StudioIntegrationEngine
    private lateinit var studioExperience: StudioExperienceEngine
    private lateinit var projectOs: ProjectOsEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_studio)
        try { StudioUiFinalizer.apply(this) } catch (e: Throwable) {
            Toast.makeText(this, "Studio UI initialization warning: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
        try {
            fileEngine = FileEngine(this)
            studioIntegration = StudioIntegrationEngine(this)
            studioExperience = StudioExperienceEngine(this)
            projectOs = ProjectOsEngine(this)
        } catch (e: Throwable) {
            Toast.makeText(this, "Project Studio initialization failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
            finish(); return
        }

        var id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        if (id < 0L) {
            id = WorkspaceSession.lastProjectId(this)
        }

        val loadedProject = if (id >= 0L) ProjectStore.getById(this, id) else null
        if (loadedProject == null) {
            Toast.makeText(this, "No valid project was supplied to Project Studio.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        project = loadedProject
        WorkspaceSession.open(this, project, "files")
        try { projectOs.open(project) } catch (e: Throwable) {
            Toast.makeText(this, "Project OS warning: ${e.message ?: "unknown error"}", Toast.LENGTH_SHORT).show()
        }
        try { studioExperience.loadPanelState(project.id) } catch (_: Throwable) { }
        findViewById<TextView>(R.id.studioTitle).text = project.name
        findViewById<TextView>(R.id.studioSubtitle).text = "Project Studio • ${project.template}"
        findViewById<TextView>(R.id.projectMeta).text = "${project.name}\n${project.template}\n${project.folderPath}"
        fileTree = findViewById(R.id.fileTree)
        try { updateStudioIntegration() } catch (e: Throwable) {
            findViewById<TextView>(R.id.studioIntegrationStatus).text = "Integration inspection unavailable: ${e.message ?: "unknown error"}"
        }
        try { updateProjectOsStatus() } catch (e: Throwable) {
            findViewById<TextView>(R.id.workspaceStatus).text = "Project OS inspection unavailable: ${e.message ?: "unknown error"}"
        }

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnRunStudio).setOnClickListener { openRunStudio() }
        findViewById<Button>(R.id.btnBuildRelease).setOnClickListener { openBuildRelease() }
        findViewById<Button>(R.id.tabCode).setOnClickListener { WorkspaceSession.update(this, project, "code"); openEditor() }
        findViewById<Button>(R.id.tabFiles).setOnClickListener { WorkspaceSession.update(this, project, "files"); refreshTree() }
        findViewById<Button>(R.id.tabDesign).setOnClickListener { WorkspaceSession.update(this, project, "design"); openUiBuilder() }
        findViewById<Button>(R.id.tabPreview).setOnClickListener { WorkspaceSession.update(this, project, "preview"); openRunStudio() }
        findViewById<Button>(R.id.btnUiBuilder).setOnClickListener { openUiBuilder() }
        findViewById<Button>(R.id.btnInspector).setOnClickListener { showInspector() }
        findViewById<Button>(R.id.btnAssets).setOnClickListener { openAssets() }
        findViewById<Button>(R.id.btnFileManager).setOnClickListener { openFileManager() }
        findViewById<Button>(R.id.btnProjectSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnNewFile).setOnClickListener { showCreateDialog() }
        findViewById<Button>(R.id.btnProblems).setOnClickListener { openDiagnostics() }
        findViewById<Button>(R.id.btnOutput).setOnClickListener { openRunStudio() }
        findViewById<Button>(R.id.btnBottomProblems).setOnClickListener { openDiagnostics() }
        findViewById<Button>(R.id.btnBottomOutput).setOnClickListener { openRunStudio() }
        try { refreshTree() } catch (e: Throwable) {
            Toast.makeText(this, "File tree warning: ${e.message ?: "unknown error"}", Toast.LENGTH_SHORT).show()
        }
        try { restoreWorkspace() } catch (e: Throwable) {
            Toast.makeText(this, "Workspace restore warning: ${e.message ?: "unknown error"}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restoreWorkspace() {
        val tab = WorkspaceSession.lastTab(this)
        val lastFile = WorkspaceSession.resolveLastFile(this, project)
        if (lastFile != null) {
            findViewById<TextView>(R.id.studioIntegrationStatus).append("\nLast file: ${lastFile.relativeTo(File(project.folderPath)).path}")
        }
        when (tab) {
            "code" -> openEditor()
            "design" -> openUiBuilder()
            "preview" -> openRunStudio()
        }
    }

    private fun updateStudioIntegration() {
        val snapshot = studioIntegration.inspect(project)
        findViewById<TextView>(R.id.studioIntegrationStatus).text = studioIntegration.summary(snapshot)
    }

    private fun updateProjectOsStatus() {
        val state = projectOs.inspect(project)
        findViewById<TextView>(R.id.workspaceStatus).text = projectOs.stateSummary(state)
    }

    override fun onPause() {
        super.onPause()
        if (::studioExperience.isInitialized && ::project.isInitialized) {
            val activeTab = WorkspaceSession.lastTab(this)
            val activeFile = WorkspaceSession.resolveLastFile(this, project)
            val state = StudioPanelState(
                activeTab = activeTab,
                bottomPanel = "none",
                explorerVisible = true
            )
            studioExperience.savePanelState(project.id, state)
            WorkspaceSession.update(this, project, activeTab, activeFile)
        }
    }

    private fun refreshTree() {
        fileTree.removeAllViews()
        val root = File(project.folderPath)
        if (!root.exists()) {
            addMessage("Project folder is missing.")
            return
        }
        addTree(root, 0, true)
    }

    private fun addTree(file: File, depth: Int, root: Boolean) {
        val children = if (file.isDirectory) fileEngine.listChildren(file) else emptyList()
        if (!root) {
            if (file.isDirectory) {
                val group = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                }
                val row = TextView(this).apply {
                    text = "›  📁  ${file.name}"
                    setTextColor(Color.WHITE)
                    textSize = 13f
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10 + depth * 12), dp(8), dp(8), dp(8))
                    setBackgroundResource(R.drawable.studio_file_row)
                }
                val childContainer = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                }
                row.setOnClickListener {
                    val open = childContainer.visibility != View.VISIBLE
                    childContainer.visibility = if (open) View.VISIBLE else View.GONE
                    row.text = if (open) "⌄  📁  ${file.name}" else "›  📁  ${file.name}"
                }
                row.setOnLongClickListener { showFileActions(file); true }
                group.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply {
                    setMargins(0, 0, 0, dp(4))
                })
                group.addView(childContainer)
                fileTree.addView(group, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                children.forEach { child -> addTreeInto(child, depth + 1, childContainer) }
            } else {
                val row = TextView(this).apply {
                    text = "  📄  ${file.name}"
                    setTextColor(Color.parseColor("#D6DBE8"))
                    textSize = 12.5f
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10 + depth * 12), dp(8), dp(8), dp(8))
                    setSingleLine(true)
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    setBackgroundResource(R.drawable.studio_file_row)
                    setOnClickListener { openFile(file) }
                    setOnLongClickListener { showFileActions(file); true }
                }
                fileTree.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply {
                    setMargins(0, 0, 0, dp(4))
                })
            }
        } else {
            children.forEach { child -> addTree(child, 0, false) }
        }
    }

    private fun addTreeInto(file: File, depth: Int, container: LinearLayout) {
        val children = if (file.isDirectory) fileEngine.listChildren(file) else emptyList()
        if (file.isDirectory) {
            val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val row = TextView(this).apply {
                text = "›  📁  ${file.name}"
                setTextColor(Color.WHITE)
                textSize = 12.5f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8 + depth * 10), dp(7), dp(6), dp(7))
                setBackgroundResource(R.drawable.studio_file_row)
            }
            val childContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
            }
            row.setOnClickListener {
                val open = childContainer.visibility != View.VISIBLE
                childContainer.visibility = if (open) View.VISIBLE else View.GONE
                row.text = if (open) "⌄  📁  ${file.name}" else "›  📁  ${file.name}"
            }
            row.setOnLongClickListener { showFileActions(file); true }
            group.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { setMargins(0, 0, 0, dp(3)) })
            group.addView(childContainer)
            container.addView(group)
            children.forEach { child -> addTreeInto(child, depth + 1, childContainer) }
        } else {
            val row = TextView(this).apply {
                text = "  📄  ${file.name}"
                setTextColor(Color.parseColor("#C7CEE2"))
                textSize = 12f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8 + depth * 10), dp(7), dp(6), dp(7))
                setSingleLine(true)
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                setBackgroundResource(R.drawable.studio_file_row)
                setOnClickListener { openFile(file) }
                setOnLongClickListener { showFileActions(file); true }
            }
            container.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)).apply { setMargins(0, 0, 0, dp(3)) })
        }
    }

    private fun addMessage(text: String) {
        fileTree.addView(TextView(this).apply { this.text = text; setTextColor(Color.parseColor("#9AA4C0")); setPadding(dp(8), dp(12), dp(8), dp(12)) })
    }

    private fun openFile(file: File) {
        WorkspaceSession.update(this, project, "code", file)
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id)
        i.putExtra(EditorActivity.EXTRA_FILE_PATH, file.absolutePath)
        startActivity(i)
    }

    private fun openEditor() {
        WorkspaceSession.update(this, project, "code", WorkspaceSession.resolveLastFile(this, project))
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }
    private fun openRecoveryCenter() {
        val i = Intent(this, RecoveryCenterActivity::class.java)
        i.putExtra(RecoveryCenterActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }

    private fun openDiagnostics() { startActivity(Intent(this, DiagnosticsActivity::class.java)) }

    private fun openRunStudio() {
        WorkspaceSession.update(this, project, "preview", WorkspaceSession.resolveLastFile(this, project))
        val i = Intent(this, RunStudioActivity::class.java)
        i.putExtra(RunStudioActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }

    private fun openBuildRelease() {
        val i = Intent(this, BuildReleaseActivity::class.java)
        i.putExtra(BuildReleaseActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }

    private fun openPreviewOrEditor() {
        val root = File(project.folderPath)
        val index = File(root, "index.html")
        if (index.exists()) {
            val i = Intent(this, PreviewActivity::class.java)
            i.putExtra(PreviewActivity.EXTRA_PROJECT_DIR, root.absolutePath)
            startActivity(i)
        } else openEditor()
    }

    private fun openUiBuilder() {
        WorkspaceSession.update(this, project, "design", WorkspaceSession.resolveLastFile(this, project))
        val i = Intent(this, UiBuilderActivity::class.java)
        i.putExtra(UiBuilderActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }

    private fun showInspector() {
        val root = File(project.folderPath)
        val count = root.walkTopDown().count { it.isFile }
        val size = root.walkTopDown().filter { it.isFile }.sumBy { it.length().toInt() }.toLong()
        AlertDialog.Builder(this).setTitle("Project Inspector")
            .setMessage("Name: ${project.name}\nTemplate: ${project.template}\nFiles: $count\nSize: ${formatBytes(size)}\nPath: ${project.folderPath}")
            .setPositiveButton("OK", null).show()
    }

    private fun openAssets() {
        startActivity(Intent(this, AssetManagerActivity::class.java).putExtra(AssetManagerActivity.EXTRA_PROJECT_ID, project.id))
    }

    private fun openFileManager() {
        WorkspaceSession.update(this, project, "files", null)
        val i = Intent(this, InternalFileManagerActivity::class.java)
        i.putExtra(InternalFileManagerActivity.EXTRA_PROJECT_ID, project.id)
        startActivity(i)
    }

    private fun openPlugins() { startActivity(Intent(this, PluginsActivity::class.java)) }

    private fun showSettings() {
        val input = EditText(this).apply { setText(project.name); hint = "Project name" }
        AlertDialog.Builder(this).setTitle("Project Settings").setView(input)
            .setMessage("Template: ${project.template}\nProject ID: ${project.id}")
            .setPositiveButton("Save") { _, _ ->
                Toast.makeText(this, "Project settings saved locally. Name changes are available in project actions.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showCreateDialog() {
        val items = arrayOf("New File", "New Folder")
        AlertDialog.Builder(this).setTitle("Create in Project").setItems(items) { _, which ->
            showNameDialog(which == 1)
        }.show()
    }

    private fun showNameDialog(folder: Boolean) {
        val input = EditText(this).apply { hint = if (folder) "Folder name" else "File name" }
        AlertDialog.Builder(this).setTitle(if (folder) "New Folder" else "New File").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty() || name.contains("/") || name.contains("\\")) return@setPositiveButton
                val target = File(project.folderPath, name)
                if (target.exists()) Toast.makeText(this, "Already exists.", Toast.LENGTH_SHORT).show()
                else { if (folder) target.mkdirs() else target.writeText(""); refreshTree() }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFileActions(file: File) {
        val items = arrayOf("Open", "Rename", "Duplicate", "Delete", "Inspect")
        AlertDialog.Builder(this).setTitle(file.name).setItems(items) { _, which ->
            when (which) {
                0 -> if (file.isFile) openFile(file)
                1 -> renameFile(file)
                2 -> duplicateFile(file)
                3 -> { fileEngine.delete(file); refreshTree() }
                4 -> AlertDialog.Builder(this).setTitle("File Inspector").setMessage("Path: ${file.absolutePath}\nType: ${if (file.isDirectory) "Folder" else "File"}\nSize: ${formatBytes(fileEngine.sizeOf(file))}").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun renameFile(file: File) {
        val input = EditText(this).apply { setText(file.name) }
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setPositiveButton("Save") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty() && !name.contains("/") && !name.contains("\\")) { fileEngine.rename(file, name); refreshTree() }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun duplicateFile(file: File) {
        val target = File(file.parentFile, file.nameWithoutExtension + "_copy" + if (file.extension.isEmpty()) "" else ".${file.extension}")
        if (file.isDirectory) file.copyRecursively(target, overwrite = false) else file.copyTo(target, overwrite = false)
        refreshTree()
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${DecimalFormat("0.0").format(bytes / 1024.0)} KB"
        else -> "${DecimalFormat("0.0").format(bytes / (1024.0 * 1024.0))} MB"
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object { const val EXTRA_PROJECT_ID = "extra_project_studio_id" }

}
