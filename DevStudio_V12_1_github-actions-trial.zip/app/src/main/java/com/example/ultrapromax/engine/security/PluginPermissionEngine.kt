package com.example.ultrapromax.engine.security

import android.content.Context
import com.example.ultrapromax.engine.plugin.PluginPermission

/** Persistent least-privilege permission grants for declarative plugins. */
class PluginPermissionEngine(context: Context) {
    private val prefs = context.getSharedPreferences("plugin_permissions", Context.MODE_PRIVATE)
    fun grants(pluginId: String): Set<PluginPermission> = PluginPermission.values().filter { prefs.getBoolean("$pluginId:${it.name}", false) }.toSet()
    fun grant(pluginId: String, permission: PluginPermission) { prefs.edit().putBoolean("$pluginId:${permission.name}", true).apply() }
    fun revoke(pluginId: String, permission: PluginPermission) { prefs.edit().putBoolean("$pluginId:${permission.name}", false).apply() }
    fun revokeAll(pluginId: String) { prefs.edit().apply { PluginPermission.values().forEach { remove("$pluginId:${it.name}") } }.apply() }
    fun allowed(pluginId: String, permission: PluginPermission): Boolean = grants(pluginId).contains(permission)
}
