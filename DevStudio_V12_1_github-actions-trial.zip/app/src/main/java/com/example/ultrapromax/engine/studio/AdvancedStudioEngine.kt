package com.example.ultrapromax.engine.studio

import android.content.Context
import java.io.File

/** V28 advanced Studio coordination layer. Offline and deterministic. */
class AdvancedStudioEngine(private val context: Context) {

    enum class Surface { CODE, DESIGN, PREVIEW, FILES, PROBLEMS, OUTPUT, TERMINAL }

    data class Tab(
        val id: String,
        val title: String,
        val filePath: String,
        val pinned: Boolean = false,
        val dirty: Boolean = false
    )

    data class Layout(
        val primarySurface: Surface,
        val explorerVisible: Boolean,
        val bottomPanelVisible: Boolean,
        val bottomPanel: Surface,
        val commandBarVisible: Boolean
    )

    data class ProjectSnapshot(
        val root: String,
        val files: Int,
        val directories: Int,
        val totalBytes: Long,
        val openTabs: Int,
        val dirtyTabs: Int
    )

    private val prefs = context.getSharedPreferences("devstudio_v28_advanced", Context.MODE_PRIVATE)

    fun addOrUpdateTab(projectId: Long, tab: Tab) {
        val tabs = loadTabs(projectId).filter { it.id != tab.id }.toMutableList()
        tabs.add(tab)
        saveTabs(projectId, tabs)
    }

    fun removeTab(projectId: Long, tabId: String) {
        saveTabs(projectId, loadTabs(projectId).filter { it.id != tabId })
    }

    fun loadTabs(projectId: Long): List<Tab> {
        val raw = prefs.getString("tabs_$projectId", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        val result = ArrayList<Tab>()
        raw.split('\n').forEach { line ->
            val p = line.split('|')
            if (p.size >= 5) {
                result.add(
                    Tab(
                        id = p[0],
                        title = p[1],
                        filePath = p[2],
                        pinned = p[3] == "1",
                        dirty = p[4] == "1"
                    )
                )
            }
        }
        return result
    }

    fun saveLayout(projectId: Long, layout: Layout) {
        prefs.edit()
            .putString("layout_${projectId}_primary", layout.primarySurface.name)
            .putBoolean("layout_${projectId}_explorer", layout.explorerVisible)
            .putBoolean("layout_${projectId}_bottomVisible", layout.bottomPanelVisible)
            .putString("layout_${projectId}_bottom", layout.bottomPanel.name)
            .putBoolean("layout_${projectId}_command", layout.commandBarVisible)
            .apply()
    }

    fun loadLayout(projectId: Long): Layout {
        return Layout(
            primarySurface = enumOrDefault(
                prefs.getString("layout_${projectId}_primary", null),
                Surface.CODE
            ),
            explorerVisible = prefs.getBoolean("layout_${projectId}_explorer", true),
            bottomPanelVisible = prefs.getBoolean("layout_${projectId}_bottomVisible", false),
            bottomPanel = enumOrDefault(
                prefs.getString("layout_${projectId}_bottom", null),
                Surface.OUTPUT
            ),
            commandBarVisible = prefs.getBoolean("layout_${projectId}_command", true)
        )
    }

    fun inspectProject(root: File?, openTabs: List<Tab> = emptyList()): ProjectSnapshot {
        if (root == null || !root.isDirectory) {
            return ProjectSnapshot("", 0, 0, 0L, openTabs.size, openTabs.count { it.dirty })
        }
        var files = 0
        var directories = 0
        var bytes = 0L
        root.walkTopDown().forEach { item ->
            if (item.isFile) {
                files++
                bytes += item.length()
            } else if (item.isDirectory && item != root) {
                directories++
            }
        }
        return ProjectSnapshot(root.absolutePath, files, directories, bytes, openTabs.size, openTabs.count { it.dirty })
    }

    fun snapshotText(snapshot: ProjectSnapshot): String {
        return "Files: ${snapshot.files} | Directories: ${snapshot.directories} | " +
                "Size: ${formatBytes(snapshot.totalBytes)} | Open tabs: ${snapshot.openTabs} | " +
                "Unsaved: ${snapshot.dirtyTabs}"
    }

    private fun saveTabs(projectId: Long, tabs: List<Tab>) {
        val safe = tabs.map {
            listOf(
                it.id.replace("|", "_"),
                it.title.replace("|", "_"),
                it.filePath.replace("|", "_"),
                if (it.pinned) "1" else "0",
                if (it.dirty) "1" else "0"
            ).joinToString("|")
        }.joinToString("\n")
        prefs.edit().putString("tabs_$projectId", safe).apply()
    }

    private fun <T : Enum<T>> enumOrDefault(value: String?, defaultValue: T): T {
        if (value == null) return defaultValue
        return try {
            java.lang.Enum.valueOf(defaultValue.declaringClass, value)
        } catch (_: IllegalArgumentException) {
            defaultValue
        }
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
            else -> "${bytes / (1024L * 1024L)} MB"
        }
    }
}
