package com.example.ultrapromax.engine.plugin

import android.content.Context
import java.io.File
import java.util.Locale

/**
 * V26.9 Extension Platform.
 *
 * This layer manages local extension descriptors and their lifecycle metadata.
 * It deliberately does not load arbitrary external DEX/JAR code. External code
 * execution needs a stronger sandbox/class-loader design and is left for a
 * future release. Built-in Plugin implementations remain fully compatible with
 * PluginSystem.
 */
enum class ExtensionState {
    DISCOVERED, ENABLED, DISABLED, INVALID, BLOCKED
}

data class ExtensionDescriptor(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val entryPoint: String,
    val permissions: Set<PluginPermission>,
    val dependencies: List<String>,
    val sourceFile: File?
)

data class ExtensionRecord(
    val descriptor: ExtensionDescriptor,
    var state: ExtensionState,
    var error: String = ""
)

class ExtensionManifestParser {

    fun parse(file: File): ExtensionDescriptor? {
        if (!file.exists() || !file.isFile) return null

        val values = LinkedHashMap<String, String>()
        file.readLines().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach
            val index = line.indexOf('=')
            if (index <= 0) return@forEach
            val key = line.substring(0, index).trim()
            val value = line.substring(index + 1).trim()
            values[key] = value
        }

        val id = values["id"] ?: return null
        val name = values["name"] ?: id
        val version = values["version"] ?: "1.0"
        val description = values["description"] ?: ""
        val entryPoint = values["entryPoint"] ?: ""

        val permissions = parsePermissions(values["permissions"] ?: "")
        val dependencies = (values["dependencies"] ?: "")
            .split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        return ExtensionDescriptor(
            id = id,
            name = name,
            version = version,
            description = description,
            entryPoint = entryPoint,
            permissions = permissions,
            dependencies = dependencies,
            sourceFile = file
        )
    }

    private fun parsePermissions(value: String): Set<PluginPermission> {
        val result = LinkedHashSet<PluginPermission>()
        value.split(',').forEach { raw ->
            val normalized = raw.trim().toUpperCase(Locale.US)
            try {
                if (normalized.isNotEmpty()) {
                    result.add(PluginPermission.valueOf(normalized))
                }
            } catch (_: IllegalArgumentException) {
                // Unknown permissions are ignored rather than granted.
            }
        }
        return result
    }
}

/**
 * Local extension registry. It is intentionally deterministic and offline.
 */
class ExtensionPlatformEngine(private val context: Context) {

    private val records = LinkedHashMap<String, ExtensionRecord>()
    private val prefs = context.getSharedPreferences(
        "extension_platform_state",
        Context.MODE_PRIVATE
    )

    fun discover(root: File): List<ExtensionRecord> {
        records.clear()
        if (!root.exists() || !root.isDirectory) return emptyList()

        val parser = ExtensionManifestParser()
        val manifests = root.walkTopDown()
            .filter { it.isFile && it.name == "devstudio.extension" }
            .toList()

        for (manifest in manifests) {
            val descriptor = parser.parse(manifest)
            if (descriptor == null) {
                val fallback = ExtensionDescriptor(
                    id = manifest.parentFile?.name ?: manifest.name,
                    name = manifest.parentFile?.name ?: manifest.name,
                    version = "unknown",
                    description = "",
                    entryPoint = "",
                    permissions = emptySet(),
                    dependencies = emptyList(),
                    sourceFile = manifest
                )
                records[fallback.id] = ExtensionRecord(
                    fallback,
                    ExtensionState.INVALID,
                    "Invalid extension manifest"
                )
                continue
            }

            val enabled = prefs.getBoolean(descriptor.id, false)
            val state = if (enabled) ExtensionState.ENABLED else ExtensionState.DISCOVERED
            records[descriptor.id] = ExtensionRecord(descriptor, state)
        }

        resolveDependencyStates()
        return records.values.toList()
    }

    fun all(): List<ExtensionRecord> = records.values.toList()

    fun find(id: String): ExtensionRecord? = records[id]

    fun setEnabled(id: String, enabled: Boolean): Boolean {
        val record = records[id] ?: return false

        if (enabled && record.state == ExtensionState.INVALID) {
            return false
        }

        if (enabled && !dependenciesReady(record)) {
            record.state = ExtensionState.BLOCKED
            record.error = "Required extension dependency is missing or disabled"
            return false
        }

        record.state = if (enabled) ExtensionState.ENABLED else ExtensionState.DISABLED
        record.error = ""
        prefs.edit().putBoolean(id, enabled).apply()
        return true
    }

    fun disableAll(): Int {
        var count = 0
        for (record in records.values) {
            if (record.state == ExtensionState.ENABLED) {
                record.state = ExtensionState.DISABLED
                prefs.edit().putBoolean(record.descriptor.id, false).apply()
                count++
            }
        }
        return count
    }

    fun enabledCount(): Int {
        return records.values.count { it.state == ExtensionState.ENABLED }
    }

    fun validate(record: ExtensionRecord): List<String> {
        val errors = ArrayList<String>()
        val d = record.descriptor

        if (d.id.trim().isEmpty()) errors.add("Missing id")
        if (d.name.trim().isEmpty()) errors.add("Missing name")
        if (d.version.trim().isEmpty()) errors.add("Missing version")
        if (d.entryPoint.trim().isEmpty()) {
            errors.add("Missing entryPoint")
        }

        for (dependency in d.dependencies) {
            if (!records.containsKey(dependency)) {
                errors.add("Missing dependency: $dependency")
            }
        }
        return errors
    }

    fun statusSummary(): String {
        val total = records.size
        val enabled = enabledCount()
        val invalid = records.values.count { it.state == ExtensionState.INVALID }
        val blocked = records.values.count { it.state == ExtensionState.BLOCKED }
        return "Extensions: $total | Enabled: $enabled | Invalid: $invalid | Blocked: $blocked"
    }

    private fun dependenciesReady(record: ExtensionRecord): Boolean {
        return record.descriptor.dependencies.all { dependencyId ->
            val dependency = records[dependencyId]
            dependency != null && dependency.state == ExtensionState.ENABLED
        }
    }

    private fun resolveDependencyStates() {
        for (record in records.values) {
            if (validate(record).isNotEmpty()) {
                if (record.state != ExtensionState.ENABLED) {
                    record.state = ExtensionState.INVALID
                }
                record.error = validate(record).joinToString("; ")
            }
        }
    }
}
