package com.example.ultrapromax.engine.dependency

import java.io.File

/** Manages real project-local JAR/AAR artifacts. No network or fake package install is used. */
class LocalPackageManager(private val projectRoot: File) {
    private val libsDir: File = File(projectRoot, "libs")

    data class LocalArtifact(val file: File, val type: String, val size: Long)

    fun list(): List<LocalArtifact> {
        val files = libsDir.listFiles() ?: return emptyList()
        return files.filter { it.isFile && (it.extension.toLowerCase() == "jar" || it.extension.toLowerCase() == "aar") }
            .sortedBy { it.name.toLowerCase() }
            .map { LocalArtifact(it, it.extension.toLowerCase(), it.length()) }
    }

    fun install(source: File): LocalArtifact? {
        if (!source.exists() || !source.isFile) return null
        val ext = source.extension.toLowerCase()
        if (ext != "jar" && ext != "aar") return null
        libsDir.mkdirs()
        val target = File(libsDir, source.name)
        return try {
            source.copyTo(target, overwrite = true)
            LocalArtifact(target, ext, target.length())
        } catch (_: Exception) { null }
    }

    fun remove(fileName: String): Boolean {
        if (fileName.isBlank() || fileName.contains("/") || fileName.contains("\\") || fileName == "." || fileName == "..") return false
        val target = File(libsDir, fileName).canonicalFile
        val base = libsDir.canonicalFile
        if (!target.path.startsWith(base.path + File.separator)) return false
        return target.isFile && target.delete()
    }
}
