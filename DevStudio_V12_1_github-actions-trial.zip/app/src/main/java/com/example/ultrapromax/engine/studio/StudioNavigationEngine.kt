package com.example.ultrapromax.engine.studio

/** V28 navigation model shared by Studio surfaces. */
class StudioNavigationEngine {
    data class Destination(
        val id: String,
        val title: String,
        val surface: AdvancedStudioEngine.Surface
    )

    private val history = ArrayList<Destination>()
    private var cursor = -1

    fun navigate(destination: Destination) {
        while (history.size > cursor + 1) history.removeAt(history.lastIndex)
        history.add(destination)
        cursor = history.lastIndex
    }

    fun current(): Destination? = if (cursor in history.indices) history[cursor] else null

    fun canBack(): Boolean = cursor > 0
    fun canForward(): Boolean = cursor >= 0 && cursor < history.lastIndex

    fun back(): Destination? {
        if (!canBack()) return current()
        cursor--
        return current()
    }

    fun forward(): Destination? {
        if (!canForward()) return current()
        cursor++
        return current()
    }

    fun clear() {
        history.clear()
        cursor = -1
    }
}
