package com.example.ultrapromax.engine.security

import android.content.Context
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.engine.workspace.WorkspaceEngine
import java.io.File

/** V26 offline beta health and integration test engine. */
class BetaTestEngine(private val context: Context) {
    data class TestResult(val name: String, val state: String, val detail: String)
    data class Report(val results: List<TestResult>, val files: Int, val bytes: Long) {
        fun passed(): Int = results.count { it.state == "PASS" }
        fun warnings(): Int = results.count { it.state == "WARN" }
        fun failed(): Int = results.count { it.state == "FAIL" }
    }

    fun run(project: Project?): Report {
        val results = ArrayList<TestResult>()
        val root = project?.let { File(it.folderPath) }
        val exists = root != null && root.isDirectory
        val files = if (exists) root!!.walkTopDown().count { it.isFile } else 0
        val bytes = if (exists) root!!.walkTopDown().filter { it.isFile }.fold(0L) { total, f -> total + f.length() } else 0L

        results.add(check("Project workspace", exists, if (exists) "Workspace is mounted" else "Project folder is missing"))
        results.add(checkClass("Project Studio", "com.example.ultrapromax.ui.ProjectStudioActivity"))
        results.add(checkClass("Code Editor", "com.example.ultrapromax.ui.EditorActivity"))
        results.add(checkClass("UI Builder", "com.example.ultrapromax.ui.UiBuilderActivity"))
        results.add(checkClass("Preview / Run Studio", "com.example.ultrapromax.ui.RunStudioActivity"))
        results.add(checkClass("Build / Release", "com.example.ultrapromax.ui.BuildReleaseActivity"))
        results.add(checkClass("Assets / Virtual FS", "com.example.ultrapromax.ui.AssetManagerActivity"))
        results.add(checkClass("Offline AI", "com.example.ultrapromax.ui.AiAssistantActivity"))
        results.add(checkClass("Plugins / Sandbox", "com.example.ultrapromax.ui.PluginsActivity"))
        results.add(checkClass("Security / Diagnostics", "com.example.ultrapromax.ui.DiagnosticsActivity"))
        results.add(checkClass("Universal Runtime", "com.example.ultrapromax.engine.run.UniversalRunEngine"))
        results.add(checkClass("Backup / Recovery", "com.example.ultrapromax.engine.backup.BackupEngine"))
        results.add(check("Studio integration engine", classExists("com.example.ultrapromax.engine.studio.StudioIntegrationEngine"), "Integration layer available"))
        results.add(check("Beta test engine", true, "Offline test engine active"))
        results.add(checkClass("Workspace Core", "com.example.ultrapromax.engine.workspace.WorkspaceEngine"))
        results.add(checkClass("Studio Session Core", "com.example.ultrapromax.engine.studio.StudioSessionEngine"))
        results.add(checkClass("Language Registry", "com.example.ultrapromax.engine.language.LanguageRegistry"))
        results.add(checkClass("Symbol Index", "com.example.ultrapromax.engine.language.symbol.SymbolIndex"))
        results.add(checkClass("Symbol Indexer", "com.example.ultrapromax.engine.language.symbol.SymbolIndexer"))
        results.add(checkClass("Language Service", "com.example.ultrapromax.engine.language.LanguageService"))
        results.add(checkClass("Code Intelligence", "com.example.ultrapromax.engine.intelligence.CodeIntelligenceService"))
        results.add(checkClass("Completion Engine", "com.example.ultrapromax.engine.intelligence.CompletionEngine"))
        results.add(checkClass("Definition Resolver", "com.example.ultrapromax.engine.intelligence.DefinitionResolver"))
        results.add(checkClass("Reference Engine", "com.example.ultrapromax.engine.intelligence.ReferenceEngine"))
        results.add(checkClass("Hover Engine", "com.example.ultrapromax.engine.intelligence.HoverEngine"))
        results.add(checkClass("Diagnostic Model", "com.example.ultrapromax.engine.analysis.Diagnostic"))
        results.add(checkClass("Diagnostic Engine", "com.example.ultrapromax.engine.analysis.DiagnosticEngine"))
        results.add(checkClass("Project Analyzer", "com.example.ultrapromax.engine.analysis.ProjectAnalyzer"))
        results.add(checkClass("Analysis Service", "com.example.ultrapromax.engine.analysis.AnalysisService"))
        results.add(checkClass("Build Pipeline Core", "com.example.ultrapromax.engine.buildrun.BuildPipelineEngine"))
        results.add(checkClass("Run Session Core", "com.example.ultrapromax.engine.buildrun.RunSessionEngine"))
        results.add(checkClass("Extension Platform", "com.example.ultrapromax.engine.plugin.ExtensionPlatformEngine"))
        results.add(checkClass("Extension Manifest Parser", "com.example.ultrapromax.engine.plugin.ExtensionManifestParser"))
        results.add(checkClass("Extension Plugin System", "com.example.ultrapromax.engine.plugin.PluginManager"))
        results.add(checkClass("Integration Health", "com.example.ultrapromax.engine.quality.IntegrationHealthEngine"))
        results.add(checkClass("Performance Metrics", "com.example.ultrapromax.engine.quality.PerformanceMetricsEngine"))
        results.add(checkClass("Compatibility Contract", "com.example.ultrapromax.engine.quality.CompatibilityEngine"))
        results.add(checkClass("Studio Quality Gate", "com.example.ultrapromax.engine.quality.StudioQualityGate"))

        val qualityCheck = qualityCoreCheck(root)
        results.add(TestResult("V30.1.0 integration / quality smoke test", qualityCheck.first, qualityCheck.second))
        results.add(checkClass("Runtime Readiness Core", "com.example.ultrapromax.engine.run.RuntimeReadinessEngine"))
        results.add(checkClass("Package Dependency Core", "com.example.ultrapromax.engine.dependency.PackageDependencyEngine"))
        results.add(checkClass("Dependency Parser", "com.example.ultrapromax.engine.dependency.DependencyParser"))
        results.add(checkClass("Dependency Lock", "com.example.ultrapromax.engine.dependency.DependencyLock"))
        results.add(checkClass("Local Package Manager", "com.example.ultrapromax.engine.dependency.LocalPackageManager"))
        val dependencyCheck = dependencyCoreCheck()
        results.add(TestResult("VFS / Package / Dependency smoke test", dependencyCheck.first, dependencyCheck.second))

        val finalCheck = finalCoreCheck()
        results.add(TestResult("V30 final systems smoke test", finalCheck.first, finalCheck.second))

        val buildRunCheck = buildRunCoreCheck()
        results.add(TestResult("Build / Run / Runtime smoke test", buildRunCheck.first, buildRunCheck.second))
        val analysisCheck = analysisCoreCheck()
        results.add(TestResult("Diagnostics / Analysis smoke test", analysisCheck.first, analysisCheck.second))

        val languageCheck = languageCoreCheck()
        results.add(TestResult("Language / Symbol smoke test", languageCheck.first, languageCheck.second))

        if (project != null) {
            val workspace = WorkspaceEngine(context).inspect(project)
            results.add(check(
                "Workspace write access",
                workspace.exists && workspace.writable,
                if (workspace.exists && workspace.writable) "Workspace is writable" else "Workspace is unavailable or read-only"
            ))
        }

        if (exists && files == 0) {
            results.add(TestResult("Project content", "WARN", "Workspace exists but contains no files"))
        } else if (exists) {
            results.add(TestResult("Project content", "PASS", "$files files / ${formatBytes(bytes)}"))
        } else {
            results.add(TestResult("Project content", "WARN", "Skipped because workspace is unavailable"))
        }
        return Report(results, files, bytes)
    }

    private fun languageCoreCheck(): Pair<String, String> {
        return try {
            val service = com.example.ultrapromax.engine.language.LanguageService()
            val source = "class Demo {\n    fun run() {}\n    val value = 1\n}"
            val symbols = service.analyzeBuffer("Demo.kt", source)
            val hasClass = symbols.any { it.name == "Demo" }
            val hasFunction = symbols.any { it.name == "run" }
            val intelligence = com.example.ultrapromax.engine.intelligence.CodeIntelligenceService()
            val completions = intelligence.complete("Demo.kt", source, source.length, 10)
            val definitionReady = intelligence.definition("Demo") != null || completions.any { it.label == "Demo" }
            if (hasClass && hasFunction && definitionReady) {
                Pair("PASS", "Language core and V26.5 code intelligence are operational")
            } else {
                Pair("WARN", "Language core loaded but smoke symbols were incomplete")
            }
        } catch (e: Throwable) {
            Pair("FAIL", "Language core error: " + (e.message ?: "unknown"))
        }
    }

    private fun finalCoreCheck(): Pair<String, String> {
        return try {
            val offline = com.example.ultrapromax.engine.offline.OfflineModeEngine(context)
            val visual = com.example.ultrapromax.engine.visual.StudioVisualEngine().profile()
            val final = com.example.ultrapromax.engine.finalrelease.FinalReleaseEngine().audit()
            val web = com.example.ultrapromax.engine.webapp.WebAppProjectEngine()
            val catalog = com.example.ultrapromax.engine.plugin.LocalPluginCatalogEngine()
            val offlineOk = offline.isOffline()
            val visualOk = visual.surface == com.example.ultrapromax.engine.visual.StudioVisualEngine.Surface.GLASS
            val classesOk = final.failed() == 0
            val buildersOk = web != null && catalog != null
            if (offlineOk && visualOk && classesOk && buildersOk) {
                Pair("PASS", "V30 final systems are available in offline mode")
            } else {
                Pair("WARN", "V30 final systems loaded with a review required")
            }
        } catch (e: Throwable) {
            Pair("FAIL", "V30 final systems error: " + (e.message ?: "unknown"))
        }
    }

    private fun analysisCoreCheck(): Pair<String, String> {
        return try {
            val service = com.example.ultrapromax.engine.analysis.AnalysisService()
            val source = "class Demo {\n    fun run( {\n    val value = 1\n}"
            val diagnostics = service.analyzeBuffer("Demo.kt", source)
            val hasSyntax = diagnostics.any { it.code == "SYNTAX" }
            val clean = service.analyzeBuffer("Clean.kt", "class Clean {\n    fun run() {}\n}")
            if (hasSyntax && clean.none { it.severity == com.example.ultrapromax.engine.analysis.DiagnosticSeverity.ERROR }) {
                Pair("PASS", "Diagnostics and project analysis foundation are operational")
            } else {
                Pair("WARN", "Analysis core loaded but smoke diagnostics were incomplete")
            }
        } catch (e: Throwable) {
            Pair("FAIL", "Analysis core error: " + (e.message ?: "unknown"))
        }
    }

    private fun dependencyCoreCheck(): Pair<String, String> {
        return try {
            val root = File(context.cacheDir, "v268-dependency-smoke")
            root.mkdirs()
            val build = File(root, "build.gradle")
            build.writeText("dependencies {\n    implementation 'com.example:demo:1.0'\n    api \"org.sample:core:2.0\"\n}")
            val vfs = com.example.ultrapromax.engine.vfs.VirtualFileSystem(root)
            val engine = com.example.ultrapromax.engine.dependency.PackageDependencyEngine(vfs)
            val report = engine.inspectProject()
            val parsed = report.report.dependencies.size == 2
            val lockOk = engine.writeLock()
            val lockProblems = com.example.ultrapromax.engine.dependency.DependencyLock(File(root, ".devstudio/dependencies.lock")).check(
                report.report.dependencies.map { it.coordinate }
            )
            if (parsed && lockOk && lockProblems.isEmpty()) {
                Pair("PASS", "Virtual FS package scanning, dependency validation and lock core are operational")
            } else {
                Pair("WARN", "Package/dependency core loaded but smoke state was incomplete")
            }
        } catch (e: Throwable) {
            Pair("FAIL", "Package/dependency core error: " + (e.message ?: "unknown"))
        }
    }

    private fun buildRunCoreCheck(): Pair<String, String> {
        return try {
            val temp = File(context.cacheDir, "v267-smoke")
            temp.mkdirs()
            val readiness = com.example.ultrapromax.engine.run.RuntimeReadinessEngine(File(temp, "runtimes")).summary()
            val sessions = com.example.ultrapromax.engine.buildrun.RunSessionEngine(temp)
            val ok = sessions.record(com.example.ultrapromax.engine.buildrun.RunSessionEngine.Session(
                "smoke", temp.absolutePath, "Demo.kt", "kotlin", "TEST",
                System.currentTimeMillis(), System.currentTimeMillis(), true, "ok"
            ))
            sessions.clear()
            if (ok && readiness.total > 0) Pair("PASS", "Build/run pipeline, session history and runtime readiness are operational")
            else Pair("WARN", "Build/run core loaded but smoke state was incomplete")
        } catch (e: Throwable) {
            Pair("FAIL", "Build/run core error: " + (e.message ?: "unknown"))
        }
    }


    private fun qualityCoreCheck(projectRoot: File?): Pair<String, String> {
        return try {
            val integration = com.example.ultrapromax.engine.quality.IntegrationHealthEngine(context).run(projectRoot)
            val compatibilityEngine = com.example.ultrapromax.engine.quality.CompatibilityEngine()
            val compatibility = compatibilityEngine.validate(compatibilityEngine.expected())
            val gate = com.example.ultrapromax.engine.quality.StudioQualityGate().evaluate(
                integration, compatibility, projectRoot
            )
            if (gate.passed()) {
                Pair("PASS", "V30.1.0 integration checks and quality gate are operational")
            } else {
                Pair("WARN", gate.message)
            }
        } catch (e: Throwable) {
            Pair("FAIL", "V30.1.0 quality core error: " + (e.message ?: "unknown"))
        }
    }

    private fun check(name: String, ok: Boolean, detail: String): TestResult =
        TestResult(name, if (ok) "PASS" else "FAIL", detail)

    private fun checkClass(name: String, className: String): TestResult =
        check(name, classExists(className), if (classExists(className)) "Connected" else "Missing implementation")

    private fun classExists(name: String): Boolean = try {
        Class.forName(name)
        true
    } catch (_: Throwable) {
        false
    }

    fun summary(report: Report): String =
        "BETA HEALTH  •  ${report.passed()} PASS  •  ${report.warnings()} WARN  •  ${report.failed()} FAIL"

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> "${bytes / (1024L * 1024L)} MB"
    }
}
