package com.example.ultrapromax.engine.studio

import java.util.UUID

/** V28 task coordination and history. It does not fake execution of tools. */
class StudioTaskEngine {
    enum class State { QUEUED, RUNNING, SUCCESS, FAILED, CANCELLED }
    enum class Kind { BUILD, RUN, ANALYSIS, INDEX, SEARCH, FILE_OPERATION, CUSTOM }

    data class Task(
        val id: String,
        val kind: Kind,
        val title: String,
        val createdAt: Long,
        var startedAt: Long = 0L,
        var finishedAt: Long = 0L,
        var state: State = State.QUEUED,
        var output: String = ""
    )

    private val tasks = LinkedHashMap<String, Task>()

    fun create(kind: Kind, title: String): Task {
        val task = Task(UUID.randomUUID().toString(), kind, title, System.currentTimeMillis())
        tasks[task.id] = task
        return task
    }

    fun start(id: String): Boolean {
        val task = tasks[id] ?: return false
        if (task.state != State.QUEUED) return false
        task.state = State.RUNNING
        task.startedAt = System.currentTimeMillis()
        return true
    }

    fun finish(id: String, success: Boolean, output: String): Boolean {
        val task = tasks[id] ?: return false
        if (task.state != State.RUNNING) return false
        task.state = if (success) State.SUCCESS else State.FAILED
        task.finishedAt = System.currentTimeMillis()
        task.output = output
        return true
    }

    fun cancel(id: String): Boolean {
        val task = tasks[id] ?: return false
        if (task.state != State.QUEUED && task.state != State.RUNNING) return false
        task.state = State.CANCELLED
        task.finishedAt = System.currentTimeMillis()
        return true
    }

    fun all(): List<Task> = tasks.values.toList()

    fun active(): List<Task> = tasks.values.filter {
        it.state == State.QUEUED || it.state == State.RUNNING
    }

    fun clearFinished(): Int {
        val ids = tasks.values.filter {
            it.state == State.SUCCESS || it.state == State.FAILED || it.state == State.CANCELLED
        }.map { it.id }
        ids.forEach { tasks.remove(it) }
        return ids.size
    }
}
