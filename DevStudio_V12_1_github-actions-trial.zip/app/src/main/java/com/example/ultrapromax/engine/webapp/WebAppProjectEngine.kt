package com.example.ultrapromax.engine.webapp

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * V30 Web App -> Android wrapper project generator.
 *
 * It creates a real Android WebView project from local HTML/CSS/JS assets.
 * It does not pretend that an APK was built: the generated project must be
 * compiled by an available Android toolchain (for example AndroidIDE).
 */
class WebAppProjectEngine {
    data class Result(val projectDir: File, val filesCreated: Int)

    fun generateWebViewProject(webRoot: File, outputDir: File, appName: String = "WebApp", toolchainRoot: File? = null): Result {
        require(webRoot.isDirectory) { "Web root does not exist" }
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            throw IllegalStateException("Could not create output directory")
        }

        val safeName = sanitizeName(appName)
        val packageName = "com.example.devstudio.web." + safeName.toLowerCase().replace(Regex("[^a-z0-9_]"), "_").trim('_').ifEmpty { "app" }.take(30)
        val appDir = File(outputDir, safeName)
        if (!appDir.exists() && !appDir.mkdirs()) {
            throw IllegalStateException("Could not create generated project")
        }

        write(File(appDir, "settings.gradle"), "rootProject.name = '$safeName'\ninclude ':app'\n")
        write(File(appDir, "build.gradle"),
            "buildscript {\n" +
            "    ext.kotlin_version = '1.3.72'\n" +
            "    repositories { google(); jcenter() }\n" +
            "    dependencies { classpath 'com.android.tools.build:gradle:3.5.3' }\n" +
            "}\n\nallprojects { repositories { google(); jcenter() } }\n")

        val wrapperSource = toolchainRoot
        if (wrapperSource != null) {
            val gradlew = File(wrapperSource, "gradlew")
            val gradlewBat = File(wrapperSource, "gradlew.bat")
            if (gradlew.isFile) { gradlew.copyTo(File(appDir, "gradlew"), true) }
            if (gradlewBat.isFile) { gradlewBat.copyTo(File(appDir, "gradlew.bat"), true) }
            val wrapperDir = File(wrapperSource, "gradle/wrapper")
            if (wrapperDir.isDirectory) {
                wrapperDir.copyRecursively(File(appDir, "gradle/wrapper"), true)
            }
        }

        val app = File(appDir, "app")
        val src = File(app, "src/main")
        val javaPath = packageName.replace('.', File.separatorChar)
        File(src, "java/$javaPath").mkdirs()
        File(src, "assets").mkdirs()
        File(src, "res/values").mkdirs()

        write(File(app, "build.gradle"),
            "apply plugin: 'com.android.application'\n\n" +
            "android {\n" +
            "    compileSdkVersion 29\n" +
            "    defaultConfig { applicationId '" + packageName + "'; minSdkVersion 23; targetSdkVersion 29; versionCode 1; versionName '1.0' }\n" +
            "}\n")

        write(File(src, "AndroidManifest.xml"),
            "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">\n" +
            "    <application android:theme=\"@style/AppTheme\" android:label=\"" + xmlEscape(appName) + "\">\n" +
            "        <activity android:name=\".MainActivity\" android:screenOrientation=\"portrait\" android:exported=\"true\">\n" +
            "            <intent-filter>\n" +
            "                <action android:name=\"android.intent.action.MAIN\"/>\n" +
            "                <category android:name=\"android.intent.category.LAUNCHER\"/>\n" +
            "            </intent-filter>\n" +
            "        </activity>\n" +
            "    </application>\n" +
            "</manifest>\n")

        write(File(src, "res/values/styles.xml"),
            "<resources><style name=\"AppTheme\" parent=\"android:style/Theme.Material.NoActionBar\"><item name=\"android:fontFamily\">sans</item></style></resources>\n")

        write(File(src, "java/$javaPath/MainActivity.java"),
            "package " + packageName + ";\n\n" +
            "import android.app.Activity;\nimport android.os.Bundle;\nimport android.webkit.WebSettings;\nimport android.webkit.WebView;\n\n" +
            "public class MainActivity extends Activity {\n" +
            "  @Override public void onCreate(Bundle state) { super.onCreate(state); WebView w = new WebView(this); WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setWebViewClient(new android.webkit.WebViewClient()); w.loadUrl(\"file:///android_asset/index.html\"); setContentView(w); }\n" +
            "}\n")

        var count = 6
        val assetRoot = File(src, "assets")
        webRoot.walkTopDown().filter { it.isFile }.forEach { file ->
            val target = File(assetRoot, file.relativeTo(webRoot).path)
            target.parentFile?.mkdirs()
            file.copyTo(target, true)
            count++
        }

        val index = File(assetRoot, "index.html")
        if (!index.exists()) {
            write(index, "<!doctype html><html><body><h1>DEVSTUDIO Web App</h1></body></html>")
            count++
        }

        write(File(appDir, ".devstudio-webapp"), "name=$appName\npackage=$packageName\noffline=true\nsource=local\n")
        count++
        return Result(appDir, count)
    }

    fun exportZip(projectDir: File, output: File): File {
        ZipOutputStream(FileOutputStream(output)).use { zip ->
            projectDir.walkTopDown().filter { it.isFile }.forEach { file ->
                zip.putNextEntry(ZipEntry(file.relativeTo(projectDir).path.replace(File.separatorChar, '/')))
                zip.write(file.readBytes())
                zip.closeEntry()
            }
        }
        return output
    }

    private fun write(file: File, text: String) {
        file.parentFile?.mkdirs()
        file.writeText(text)
    }

    private fun sanitizeName(value: String): String {
        val cleaned = value.replace(Regex("[^A-Za-z0-9_\\-]"), "_")
        return if (cleaned.isEmpty()) "WebApp" else cleaned
    }

    private fun xmlEscape(value: String): String {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    }
}
