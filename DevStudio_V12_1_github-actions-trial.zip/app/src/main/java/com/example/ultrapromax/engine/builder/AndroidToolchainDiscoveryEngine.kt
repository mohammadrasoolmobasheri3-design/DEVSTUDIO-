package com.example.ultrapromax.engine.builder

import android.content.Context
import android.os.Environment
import java.io.File

/**
 * Truth-based local Android toolchain discovery.
 * No network fallback is allowed.
 *
 * The baseline build uses SDK Platform 29. Build Tools may be the fixed
 * local ARM64 version installed in the internal toolchain.
 */
class AndroidToolchainDiscoveryEngine(private val context: Context) {
    data class Result(
        val sdk: File?,
        val adb: File?,
        val apksigner: File?,
        val aapt: File?,
        val platform: File?,
        val buildTools: File?,
        val java: File?,
        val javac: File?,
        val gradleWrapper: File?,
        val ready: Boolean,
        val details: String
    )

    fun discover(): Result {
        val roots = linkedSetOf<File>()
        roots += File(context.filesDir, "internal-toolchain")
        roots += File(context.filesDir, "toolchain")
        System.getenv("DEVSTUDIO_TOOLCHAIN_ROOT")?.takeIf { it.isNotBlank() }?.let { roots += File(it) }

        val env = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
        if (!env.isNullOrEmpty()) roots += File(env)

        val sdkCandidates = ArrayList<File>()
        roots.forEach {
            sdkCandidates += File(it, "android-sdk")
            sdkCandidates += File(it, "sdk")
            sdkCandidates += it
        }
        sdkCandidates += File(System.getProperty("user.home") ?: ".", "Android/Sdk")
        // Common Linux/proot package-manager install locations. Worth checking
        // because this device's AndroidIDE environment already exposes tools
        // like aapt2 at /usr/bin/aapt2 (a real, globally-readable path), so an
        // apt-style Android SDK package could plausibly live at these paths too.
        sdkCandidates += File("/usr/lib/android-sdk")
        sdkCandidates += File("/usr/share/android-sdk")
        sdkCandidates += File("/opt/android-sdk")
        sdkCandidates += File("/opt/android_sdk")
        sdkCandidates += File("/usr/local/android-sdk")

        val sdk = sdkCandidates.firstOrNull { File(it, "platforms/android-29/android.jar").isFile }

        val buildTools = sdk?.let { findBuildTools(it) }
            ?: File("/usr/bin").takeIf { firstFile(it, "aapt2", "aapt") != null }
        val signer = buildTools?.let { firstFile(it, "apksigner", "apksigner.bat") }
        val aapt = buildTools?.let { firstFile(it, "aapt2", "aapt2.exe", "aapt", "aapt.exe") }
        val adb = sdk?.let { firstFile(it, "platform-tools/adb", "platform-tools/adb.exe") }
        val platform = sdk?.let { File(it, "platforms/android-29") }
        val java = findJava()
        val javac = java?.let { File(it.parentFile, "javac") }

        val wrapper = File(context.filesDir, "generated_projects/gradle-wrapper/gradlew")

        val missing = ArrayList<String>()
        if (sdk == null) missing.add("Android SDK Platform 29")
        if (buildTools == null) missing.add("Android Build Tools")
        if (signer == null) missing.add("apksigner")
        if (aapt == null) missing.add("aapt/aapt2")
        if (java == null) missing.add("JDK java")
        if (javac == null) missing.add("JDK javac")

        val ready = missing.isEmpty()
        val detail = if (ready) {
            "READY: local SDK Platform 29 + ${buildTools?.name} + JDK found. No network fallback."
        } else {
            "MISSING: ${missing.joinToString(", ")}. Expected real files under ${File(context.filesDir, "internal-toolchain").absolutePath} or an existing local SDK/JDK. No network fallback."
        }

        return Result(sdk, adb, signer, aapt, platform, buildTools, java, javac, wrapper, ready, detail)
    }

    private fun findBuildTools(sdk: File): File? {
        val dir = File(sdk, "build-tools")
        if (!dir.isDirectory) return null
        // Prefer the fixed ARM64 toolchain version, then any locally installed version.
        val preferred = listOf("30.0.2", "29.0.3", "34.0.4", "35.0.0").map { File(dir, it) }
            .firstOrNull { it.isDirectory && firstFile(it, "aapt2", "aapt") != null && firstFile(it, "apksigner") != null }
        if (preferred != null) return preferred
        return dir.listFiles()
            ?.filter { it.isDirectory && firstFile(it, "aapt2", "aapt", "apksigner") != null }
            ?.maxBy { it.name }
    }

    private fun findJava(): File? {
        val candidates = ArrayList<File>()
        System.getenv("DEVSTUDIO_TOOLCHAIN_ROOT")?.takeIf { it.isNotBlank() }?.let {
            candidates += File(it, "jdk/bin/java")
        }
        candidates += File(context.filesDir, "internal-toolchain/jdk/bin/java")
        candidates += File(context.filesDir, "toolchain/jdk/bin/java")
        try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            candidates += File(downloads, "DevStudioToolchain/jdk/bin/java")
            candidates += File(downloads, "DevStudioToolchain/jdk17/bin/java")
        } catch (_: Throwable) {}
        System.getenv("DEVSTUDIO_JAVA_HOME")?.takeIf { it.isNotBlank() }?.let { candidates += File(it, "bin/java") }
        System.getenv("JAVA_HOME")?.takeIf { it.isNotBlank() }?.let { candidates += File(it, "bin/java") }
        candidates += File("/usr/bin/java")
        candidates += File("/opt/java/jdk1.8.0_212/bin/java")
        findOnPath("java")?.let { candidates += it }
        return candidates.firstOrNull { it.isFile }
    }

    private fun firstFile(root: File, vararg paths: String): File? =
        paths.asSequence().map { File(root, it) }.firstOrNull { it.isFile }

    private fun findOnPath(name: String): File? {
        val path = System.getenv("PATH") ?: return null
        return path.split(File.pathSeparator).asSequence()
            .map { File(it, name) }
            .firstOrNull { it.isFile }
    }
}
