package com.example.ultrapromax.engine.endgame

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Final 13-domain Studio contract.
 *
 * A domain is COMPLETE only when its implementation surface exists.
 * External/runtime dependent domains are CONDITIONAL until the local device
 * provides the required toolchain and real evidence. No marker file can certify them.
 */
class Studio13DomainCompletionEngine(private val context: Context) {
    enum class Status { COMPLETE, CONDITIONAL, BLOCKED }
    data class Domain(val id: Int, val title: String, val status: Status, val detail: String)
    data class Report(val domains: List<Domain>, val generatedAt: Long) {
        fun complete() = domains.all { it.status == Status.COMPLETE }
        fun summary(): String = "${domains.count { it.status == Status.COMPLETE }}/${domains.size} COMPLETE • ${domains.count { it.status == Status.CONDITIONAL }} CONDITIONAL • ${domains.count { it.status == Status.BLOCKED }} BLOCKED"
    }

    fun audit(): Report {
        val root = File(context.filesDir, "projects")
        val domains = ArrayList<Domain>()
        val sourceRoot = locateSourceRoot()
        domains += domain(1, "Language Platform", hasAny(sourceRoot, "engine/language/LanguageRegistry.kt", "engine/language/LanguageService.kt", "engine/languagecatalog/FirstClassLanguageCatalog.kt"), "Language registry, providers and execution platform")
        domains += domain(2, "Universal Editor", hasAny(sourceRoot, "engine/editor/UniversalEditorEngine.kt", "engine/editor/EditorEngine.kt", "engine/editor/UnlimitedWorkspaceEngine.kt"), "Universal editing services and unlimited workspace contract")
        domains += domain(3, "Project OS", hasAny(sourceRoot, "engine/file/FileEngine.kt", "data/ProjectStore.kt", "engine/workspace/ProjectOsEngine.kt"), "Virtual files, project registry and workspace")
        domains += domain(4, "UI/UX Factory", hasAny(sourceRoot, "engine/visual/UiUxFactoryEngine.kt", "engine/uibuilder/UiBuilderEngine.kt", "engine/preview/PreviewEngine.kt"), "UI factory, visual builder and preview")
        domains += domain(5, "App Factory", hasAny(sourceRoot, "engine/appfactory/AppFactoryProductionEngine.kt", "engine/builder/BuildEngine.kt", "engine/builder/ApkValidationEngine.kt"), "Real Android project generation, build and artifact validation")
        domains += runtimeDomain(6, "Server Studio", hasAny(sourceRoot, "engine/serverstudio/ServerStudioEngine.kt", "engine/endgame/UniversalServerRegistry.kt"), "Server APIs are local; real runtime readiness depends on installed local tools")
        domains += domain(7, "Database Studio", hasAny(sourceRoot, "engine/databasestudio/DatabaseStudioEngine.kt", "engine/endgame/UniversalDatabaseRegistry.kt"), "SQLite/database studio and adapter registry")
        domains += domain(8, "Debug & Testing", hasAny(sourceRoot, "engine/security/DiagnosticEngine.kt", "engine/analysis/DiagnosticEngine.kt", "engine/FullQaEngine.kt", "engine/quality/StudioE2EEngine.kt", "engine/buildrun/BuildDiagnosticsParser.kt"), "Diagnostics, QA, build diagnostics and E2E surfaces")
        domains += domain(9, "AI Engineering Core", hasAny(sourceRoot, "engine/ai/AiEngine.kt", "engine/ai/OfflineAiAgentEngine.kt", "engine/ai/OfflineAiAppBuilderEngine.kt"), "Offline project-aware AI/agent planning; not represented as an external LLM")
        domains += domain(10, "Runtime & Plugin OS", hasAny(sourceRoot, "engine/plugin/PluginSystem.kt", "engine/plugin/PluginLifecycleEngine.kt", "engine/plugincompiler/PluginCompilerEngine.kt"), "Plugin lifecycle, compiler/runtime loading and permissions")
        domains += domain(11, "Security + DevOps", hasAny(sourceRoot, "engine/security/SecurityEngine.kt", "engine/security/RecoveryTransactionEngine.kt", "engine/endgame/EndgameEvidenceStore.kt"), "Security, recovery and evidence integrity")
        domains += domain(12, "Professional Studio Infrastructure", hasAny(sourceRoot, "engine/studio/StudioUiFinalizer.kt", "engine/theme/ThemeEngine.kt", "engine/completion/StudioCompletionEngine.kt"), "Studio shell, themes, completion and infrastructure")
        domains += certificationDomain(13, "ENDGAME Certification", hasAny(sourceRoot, "engine/endgame/EndgameCertificationEngine.kt", "engine/endgame/EndgameEvidenceStore.kt", "engine/endgame/FunctionalCompletionEngine.kt"), "Certification engine exists; certified status requires fresh real evidence")
        val report = Report(domains, System.currentTimeMillis())
        persist(report)
        return report
    }

    private fun domain(id: Int, title: String, implemented: Boolean, detail: String): Domain = Domain(id, title, if (implemented) Status.COMPLETE else Status.BLOCKED, if (implemented) "IMPLEMENTED • $detail" else "MISSING IMPLEMENTATION • $detail")

    private fun runtimeDomain(id: Int, title: String, implemented: Boolean, detail: String): Domain {
        if (!implemented) return Domain(id, title, Status.BLOCKED, "MISSING IMPLEMENTATION • $detail")
        val tools = AndroidToolchainDiscoveryEngine(context).discover()
        return if (tools.ready) Domain(id, title, Status.COMPLETE, "IMPLEMENTED + local Android toolchain detected • $detail") else Domain(id, title, Status.CONDITIONAL, "IMPLEMENTED • local runtime/toolchain evidence is still required • $detail")
    }

    private fun certificationDomain(id: Int, title: String, implemented: Boolean, detail: String): Domain {
        if (!implemented) return Domain(id, title, Status.BLOCKED, "MISSING CERTIFICATION ENGINE • $detail")
        return Domain(id, title, Status.CONDITIONAL, "ENGINE READY • certification is intentionally not self-awarded; run real build/install/offline/recovery/security evidence • $detail")
    }

    private fun locateSourceRoot(): File {
        val candidates = listOf(
            File(context.filesDir, "__studio_source__"),
            File(context.cacheDir, "__studio_source__")
        )
        for (c in candidates) if (c.isDirectory) return c
        // The installed APK cannot expose its source tree as a normal directory.
        // Use a contract manifest bundled in assets when present; otherwise audit the known feature contract.
        return File(context.filesDir, "__studio_source__")
    }

    private fun hasAny(root: File, vararg paths: String): Boolean {
        if (root.isDirectory && paths.any { File(root, it).exists() }) return true
        return paths.any { contractExists(it) }
    }

    private fun contractExists(path: String): Boolean {
        return try {
            context.assets.open("studio_contract/IMPLEMENTED_DOMAINS.txt").bufferedReader().useLines { lines -> lines.any { it.trim() == path } }
        } catch (_: Exception) { false }
    }

    private fun persist(report: Report) {
        val dir = File(context.filesDir, "endgame").apply { mkdirs() }
        val file = File(dir, "STUDIO_13_DOMAIN_AUDIT.txt")
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(report.generatedAt))
        file.writeText(buildString {
            append("DEVSTUDIO ULTRA PRO MAX+\n13-DOMAIN FINAL COMPLETION AUDIT\n")
            append("Generated: ").append(stamp).append('\n')
            append("Summary: ").append(report.summary()).append("\n\n")
            report.domains.forEach {
                append(String.format(Locale.US, "%02d | %s | %s | %s\n", it.id, it.status.name, it.title, it.detail))
            }
            append("\nRULE: implementation status and real certification evidence are separate.\n")
        })
    }
}
