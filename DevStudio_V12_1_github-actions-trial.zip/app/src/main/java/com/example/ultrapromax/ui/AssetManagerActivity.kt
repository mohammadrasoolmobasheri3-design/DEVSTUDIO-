package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import java.io.File
import java.text.DecimalFormat

class AssetManagerActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var assetsDir: File
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asset_manager)
        project = ProjectStore.getById(this, intent.getLongExtra(EXTRA_PROJECT_ID, -1L)) ?: run { finish(); return }
        assetsDir = File(project.folderPath, "assets").apply { mkdirs() }
        list = findViewById(R.id.assetList); status = findViewById(R.id.assetStatus)
        findViewById<TextView>(R.id.assetBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.assetImport).setOnClickListener { openPicker() }
        findViewById<Button>(R.id.assetFolder).setOnClickListener { createFolder() }
        findViewById<Button>(R.id.assetRefresh).setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        val items = assetsDir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.toLowerCase() })) ?: emptyList()
        list.removeAllViews()
        if (items.isEmpty()) list.addView(TextView(this).apply { text = "No assets yet. Import an image, font, JSON, audio or other project asset."; setTextColor(Color.parseColor("#9AA4C0")); setPadding(dp(8), dp(18), dp(8), dp(18)) })
        items.forEach { addRow(it) }
        var size = 0L; items.forEach { size += sizeOf(it) }
        status.text = "${items.size} top-level items • ${formatBytes(size)} • ${assetsDir.absolutePath}"
    }

    private fun addRow(file: File) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(6), 0); setBackgroundResource(R.drawable.glass_card) }
        val title = TextView(this).apply { text = if (file.isDirectory) "📁 ${file.name}" else "▣ ${file.name}"; setTextColor(Color.WHITE); textSize = 13f }
        row.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        val menu = TextView(this).apply { text = "⋮"; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER; setOnClickListener { actions(file) } }
        row.addView(menu, LinearLayout.LayoutParams(dp(42), dp(48)))
        list.addView(row, LinearLayout.LayoutParams(-1, dp(50)))
    }

    private fun actions(file: File) {
        AlertDialog.Builder(this).setTitle(file.name).setItems(arrayOf("Rename", "Delete", "Inspect")) { _, which ->
            when (which) {
                0 -> rename(file)
                1 -> { file.deleteRecursively(); refresh() }
                2 -> AlertDialog.Builder(this).setTitle("Asset Inspector").setMessage("Name: ${file.name}\nType: ${if (file.isDirectory) "Folder" else "File"}\nSize: ${formatBytes(sizeOf(file))}\nPath: ${file.absolutePath}").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun rename(file: File) {
        val input = EditText(this).apply { setText(file.name); selectAll() }
        AlertDialog.Builder(this).setTitle("Rename Asset").setView(input).setPositiveButton("Save") { _, _ ->
            val n = input.text.toString().trim(); if (n.isNotEmpty() && !n.contains("/") && !n.contains("\\")) file.renameTo(File(file.parentFile, n)); refresh()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun createFolder() {
        val input = EditText(this).apply { hint = "Folder name" }
        AlertDialog.Builder(this).setTitle("New Asset Folder").setView(input).setPositiveButton("Create") { _, _ ->
            val n = input.text.toString().trim(); if (n.isNotEmpty() && !n.contains("/") && !n.contains("\\")) File(assetsDir, n).mkdirs(); refresh()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, REQUEST_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK || resultCode != RESULT_OK || data == null) return
        val uri = data.data ?: return
        val suggested = queryName(uri) ?: "imported_asset"
        val target = uniqueFile(suggested)
        try {
            contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            toast("Imported: ${target.name}"); refresh()
        } catch (e: Exception) { toast("Import failed: ${e.message ?: "unknown error"}") }
    }

    private fun queryName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        return name
    }

    private fun uniqueFile(name: String): File {
        val safe = name.replace("/", "_").replace("\\", "_")
        var f = File(assetsDir, safe); var i = 1
        while (f.exists()) { val dot = safe.lastIndexOf('.'); val base = if (dot > 0) safe.substring(0, dot) else safe; val ext = if (dot > 0) safe.substring(dot) else ""; f = File(assetsDir, "${base}_$i$ext"); i++ }
        return f
    }

    private fun sizeOf(file: File): Long { if (file.isFile) return file.length(); var total = 0L; file.walkTopDown().filter { it.isFile }.forEach { total += it.length() }; return total }
    private fun formatBytes(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> "${DecimalFormat("0.0").format(bytes / 1024.0)} KB"; else -> "${DecimalFormat("0.0").format(bytes / (1024.0 * 1024.0))} MB" }
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    companion object { const val EXTRA_PROJECT_ID = "extra_asset_project_id"; private const val REQUEST_PICK = 4201 }
}
