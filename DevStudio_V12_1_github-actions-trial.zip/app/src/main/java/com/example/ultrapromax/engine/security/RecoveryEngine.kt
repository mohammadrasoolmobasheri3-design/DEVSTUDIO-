package com.example.ultrapromax.engine.security

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * V26.2 local recovery engine.
 * Keeps editor drafts and crash reports inside app-private storage.
 * No network/cloud dependency.
 */
class RecoveryEngine(private val context: Context) {

    private val root: File
        get() = File(context.filesDir, "recovery")

    private val draftsRoot: File
        get() = File(root, "drafts")

    private val crashFile: File
        get() = File(root, "last_crash.txt")

    fun saveDraft(projectId: Long, file: File, content: String) {
        try {
            val dir = File(draftsRoot, projectId.toString())
            dir.mkdirs()
            val target = File(dir, key(file) + ".draft")
            val meta = File(dir, key(file) + ".meta")
            atomicWrite(target, content)
            atomicWrite(meta, file.absolutePath)
        } catch (_: Exception) {
            // Recovery must never crash the editor.
        }
    }

    fun hasDraft(projectId: Long, file: File): Boolean {
        val draft = File(File(draftsRoot, projectId.toString()), key(file) + ".draft")
        return draft.isFile && File(File(draftsRoot, projectId.toString()), key(file) + ".meta").isFile && draft.lastModified() >= file.lastModified()
    }

    fun readDraft(projectId: Long, file: File): String? {
        if (!hasDraft(projectId, file)) return null
        return try { File(File(draftsRoot, projectId.toString()), key(file) + ".draft").readText() } catch (_: Exception) { null }
    }

    fun countDrafts(projectId: Long): Int {
        val dir = File(draftsRoot, projectId.toString())
        return try { dir.listFiles()?.count { it.isFile && it.name.endsWith(".draft") } ?: 0 } catch (_: Exception) { 0 }
    }

    fun clearAllDrafts(projectId: Long): Int {
        val dir = File(draftsRoot, projectId.toString())
        var removed = 0
        try { dir.listFiles()?.forEach { if (it.isFile && it.delete()) removed++ } } catch (_: Exception) { }
        return removed
    }

    fun clearDraft(projectId: Long, file: File) {
        try {
            val dir = File(draftsRoot, projectId.toString())
            val k = key(file)
            File(dir, "$k.draft").delete()
            File(dir, "$k.meta").delete()
        } catch (_: Exception) { }
    }

    fun writeCrashReport(thread: Thread, throwable: Throwable) {
        try {
            root.mkdirs()
            val text = StringBuilder()
                .append("DEVSTUDIO CRASH REPORT\n")
                .append("Time: ").append(System.currentTimeMillis()).append('\n')
                .append("Thread: ").append(thread.name).append('\n')
                .append("Exception: ").append(throwable.javaClass.name).append('\n')
                .append("Message: ").append(throwable.message ?: "").append("\n\n")
            throwable.printStackTrace(java.io.PrintWriter(java.io.StringWriter()))
            text.append(stackTrace(throwable))
            atomicWrite(crashFile, text.toString())
        } catch (_: Exception) { }
    }

    fun hasCrashReport(): Boolean = crashFile.isFile && crashFile.length() > 0L

    fun readCrashReport(): String = try { crashFile.readText() } catch (_: Exception) { "Unable to read crash report." }

    fun clearCrashReport(): Boolean = try { !crashFile.exists() || crashFile.delete() } catch (_: Exception) { false }

    private fun stackTrace(t: Throwable): String {
        val sw = java.io.StringWriter()
        t.printStackTrace(java.io.PrintWriter(sw))
        return sw.toString()
    }

    private fun atomicWrite(target: File, text: String) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp")
        temp.writeText(text)
        if (target.exists() && !target.delete()) return
        if (!temp.renameTo(target)) {
            target.writeText(text)
            temp.delete()
        }
    }

    private fun key(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(file.absolutePath.toByteArray(Charsets.UTF_8))
        val out = StringBuilder()
        bytes.forEach { b -> out.append(String.format("%02x", b.toInt() and 0xff)) }
        return out.toString()
    }
}

/** Application-wide crash capture. Original Android handler still receives the crash. */
class DevStudioApplication : android.app.Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            RecoveryEngine(this).writeCrashReport(thread, throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }
}
