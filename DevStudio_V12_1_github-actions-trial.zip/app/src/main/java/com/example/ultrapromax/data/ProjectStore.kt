package com.example.ultrapromax.data

import android.content.Context
import java.io.File

data class Project(
    val id: Long,
    val name: String,
    val folderPath: String,
    val createdAt: Long,
    val template: String
)

/** Dependency-free, defensive project index for the offline build. */
object ProjectStore {
    private const val INDEX_FILE = "projects.index"

    private fun indexFile(context: Context): File = File(context.filesDir, INDEX_FILE)

    @Synchronized
    fun list(context: Context): List<Project> {
        val file = indexFile(context)
        if (!file.exists()) return emptyList()
        return try {
            file.readLines()
                .filter { it.isNotBlank() }
                .mapNotNull { parse(it) }
                .sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun insert(context: Context, name: String, folderPath: String, template: String): Project {
        var id = System.currentTimeMillis()
        while (getById(context, id) != null) id++
        val now = System.currentTimeMillis()
        val project = Project(id, name, folderPath, now, template)
        val file = indexFile(context)
        file.parentFile?.mkdirs()
        val existing = try { if (file.exists()) file.readText() else "" } catch (_: Exception) { "" }
        atomicWrite(file, existing + serialize(project) + "\n")
        return project
    }

    @Synchronized
    fun getById(context: Context, id: Long): Project? = list(context).firstOrNull { it.id == id }

    @Synchronized
    fun getByFolder(context: Context, folderPath: String): Project? =
        list(context).firstOrNull { File(it.folderPath).absoluteFile == File(folderPath).absoluteFile }

    @Synchronized
    fun touch(context: Context, id: Long) {
        val current = list(context)
        val target = current.firstOrNull { it.id == id } ?: return
        val updated = target.copy(createdAt = System.currentTimeMillis())
        val remaining = current.filter { it.id != id }
        val text = (listOf(updated) + remaining).joinToString("\n") { serialize(it) } + "\n"
        atomicWrite(indexFile(context), text)
    }

    @Synchronized
    fun delete(context: Context, id: Long) {
        val remaining = list(context).filter { it.id != id }
        val text = if (remaining.isEmpty()) "" else remaining.joinToString("\n") { serialize(it) } + "\n"
        atomicWrite(indexFile(context), text)
    }

    private fun serialize(p: Project): String =
        "${p.id}|${p.name.replace("|", "_")}|${p.folderPath}|${p.createdAt}|${p.template.replace("|", "_")}"

    private fun parse(line: String): Project? {
        val parts = line.split("|", limit = 5)
        if (parts.size < 5) return null
        return try {
            Project(parts[0].toLong(), parts[1], parts[2], parts[3].toLong(), parts[4])
        } catch (_: NumberFormatException) {
            null
        }
    }

    private fun atomicWrite(target: File, text: String) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp")
        try {
            temp.writeText(text)
            if (target.exists() && !target.delete()) return
            if (!temp.renameTo(target)) {
                target.writeText(text)
                temp.delete()
            }
        } catch (_: Exception) {
            temp.delete()
        }
    }
}
