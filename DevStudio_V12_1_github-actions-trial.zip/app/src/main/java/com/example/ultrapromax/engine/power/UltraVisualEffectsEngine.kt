package com.example.ultrapromax.engine.power

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Real device-side visual layer for the Ultra UI: glass surfaces, depth and motion.
 * It uses Android primitives only; no network or external UI runtime is required.
 */
class UltraVisualEffectsEngine {
    data class GlassSpec(val cornerDp: Float = 18f, val alpha: Int = 42, val strokeAlpha: Int = 150, val strokeDp: Float = 1f, val elevationDp: Float = 10f)
    data class MotionSpec(val durationMs: Long = 220L, val scaleFrom: Float = 0.96f, val alphaFrom: Float = 0f, val translationYDp: Float = 10f)

    fun applyGlass(view: View, spec: GlassSpec = GlassSpec()) {
        val d = view.resources.displayMetrics.density
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = spec.cornerDp * d
            setColor(Color.argb(spec.alpha.coerceIn(0, 255), 20, 28, 52))
            setStroke((spec.strokeDp * d).toInt().coerceAtLeast(1), Color.argb(spec.strokeAlpha.coerceIn(0, 255), 90, 210, 255))
        }
        view.background = bg
        view.elevation = spec.elevationDp * d
        view.clipToOutline = true
    }

    fun enter(view: View, spec: MotionSpec = MotionSpec()) {
        view.alpha = spec.alphaFrom
        view.scaleX = spec.scaleFrom
        view.scaleY = spec.scaleFrom
        view.translationY = spec.translationYDp * view.resources.displayMetrics.density
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(spec.durationMs).start()
    }

    fun press(view: View, durationMs: Long = 100L) {
        view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(durationMs / 2).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(durationMs / 2).start()
        }.start()
    }
}
