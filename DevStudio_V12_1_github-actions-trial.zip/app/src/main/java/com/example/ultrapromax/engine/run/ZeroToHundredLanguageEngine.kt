package com.example.ultrapromax.engine.run

import android.content.Context
import java.io.File

/**
 * Single gate for true language completeness.
 * A language is COMPLETE only when its real Android-compatible runtime/compiler
 * contract is present and executable. Built-in WebView languages are handled
 * without external binaries.
 */
class ZeroToHundredLanguageEngine(private val context: Context) {

    data class LanguageStatus(
        val id: String,
        val displayName: String,
        val builtIn: Boolean,
        val ready: Boolean,
        val missing: List<String>
    )

    private val root: File = File(context.filesDir, "runtimes")

    private fun exists(path: String): Boolean = File(root, path).exists()

    private fun executable(path: String): Boolean {
        val f = File(root, path)
        return f.exists() && f.isFile && f.canExecute()
    }

    fun inspect(): List<LanguageStatus> {
        val out = ArrayList<LanguageStatus>()
        out.add(LanguageStatus("javascript", "JavaScript", true, true, emptyList()))
        out.add(LanguageStatus("html", "HTML", true, true, emptyList()))
        out.add(LanguageStatus("css", "CSS", true, true, emptyList()))
        out.add(check("kotlin", "Kotlin", listOf("kotlin/bin/kotlinc", "kotlin/bin/kotlin")))
        out.add(check("java", "Java", listOf("java/bin/javac", "java/bin/java")))
        out.add(check("python", "Python 3", listOf("python/python/lib/libpython.so", "python/lib/libdevstudio_python_bridge.so")))
        out.add(check("c", "C", listOf("c/bin/clang")))
        out.add(check("cpp", "C++", listOf("cpp/bin/clang++")))
        out.add(check("dart", "Dart", listOf("dart/bin/dart")))
        out.add(check("flutter", "Flutter", listOf("flutter/bin/flutter")))
        return out
    }

    private fun check(id: String, name: String, required: List<String>): LanguageStatus {
        val missing = required.filterNot { exists(it) }
        val executables = required.filter { it.contains("/bin/") }
        val notExecutable = executables.filter { exists(it) && !executable(it) }
        val allMissing = ArrayList<String>()
        allMissing.addAll(missing)
        notExecutable.forEach { allMissing.add("not-executable:$it") }
        return LanguageStatus(id, name, false, allMissing.isEmpty(), allMissing)
    }

    fun allReady(): Boolean = inspect().all { it.ready }

    fun summary(): String {
        val statuses = inspect()
        val ready = statuses.count { it.ready }
        return "languages=$ready/${statuses.size}; allReady=${ready == statuses.size}"
    }
}
