package com.example.ultrapromax.nextupdate.ai.planner

import com.example.ultrapromax.nextupdate.ai.context.ProjectContext
import com.example.ultrapromax.nextupdate.ai.model.AiPlan
import com.example.ultrapromax.nextupdate.ai.model.AiPlanStep
import com.example.ultrapromax.nextupdate.ai.model.AiTask

class AiPlanner {
    fun createPlan(task: AiTask, context: ProjectContext?): AiPlan {
        val steps = ArrayList<AiPlanStep>()
        steps.add(AiPlanStep("inspect", "Inspect project", "Read project structure and relevant context."))
        if (context != null) {
            steps.add(AiPlanStep("analyze", "Analyze project", "Analyze files, symbols and diagnostics."))
        }
        steps.add(AiPlanStep("propose", "Prepare changes", "Generate a safe change plan before mutation.", true))
        steps.add(AiPlanStep("verify", "Verify result", "Run available diagnostics/build/test checks."))
        return AiPlan(task.id, steps)
    }
}
