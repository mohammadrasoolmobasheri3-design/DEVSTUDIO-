package com.example.ultrapromax.engine.endgame

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.databasestudio.DatabaseStudioEngine
import com.example.ultrapromax.engine.dependency.LocalPackageManager
import com.example.ultrapromax.engine.offline.OfflineNetworkPolicy
import com.example.ultrapromax.engine.workspace.WorkspaceSession
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Real 8-gate functional audit. A gate is PASS only after executing the real local operation.
 * No UI/contract presence is accepted as evidence. No network fallback is used.
 */
class FunctionalCompletionEngine(private val context: Context) {
    enum class Status { PASS, MISSING, FAIL, CONDITIONAL }
    data class Gate(val id: String, val title: String, val status: Status, val detail: String)
    data class Report(val gates: List<Gate>, val passed: Int, val total: Int, val complete: Boolean, val evidence: File?)

    fun audit(projectDir: File? = null): Report {
        val gates = ArrayList<Gate>()
        gates.add(toolchainGate(projectDir))
        gates.add(offlineDependencyGate(projectDir))
        gates.add(buildGate(projectDir))
        gates.add(apkGate(projectDir))
        gates.add(installRunGate(projectDir))
        gates.add(sqliteGate(projectDir))
        gates.add(offlineGate())
        val firstSeven = gates.all { it.status == Status.PASS }
        // Persist independently verifiable evidence for every successful gate.
        val evidenceStore = EndgameEvidenceStore(context)
        gates.filter { it.status == Status.PASS }.forEach { evidenceStore.write(it.id, "PASS", it.detail) }
        gates.add(e2eEvidenceGate(projectDir, firstSeven, gates))
        val passed = gates.count { it.status == Status.PASS }
        val complete = gates.size == 8 && passed == 8
        val evidence = if (complete && projectDir != null) writeEvidence(gates, projectDir) else null
        return Report(gates, passed, gates.size, complete, evidence)
    }

    private fun toolchainGate(projectDir: File?): Gate {
        val r = AndroidToolchainDiscoveryEngine(context).discover()
        if (!r.ready) return Gate("toolchain", "Real Android Toolchain", Status.MISSING, r.details)
        if (!commandWorks(r.java, listOf("-version"))) return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "JDK java was found but could not execute locally.")
        if (!commandWorks(r.javac, listOf("-version"))) return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "JDK javac was found but could not execute locally.")
        if (!commandWorks(r.adb, listOf("version"))) return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "ADB was found but could not execute locally.")
        if (!commandWorks(r.aapt, listOf("version"))) return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "AAPT was found but could not execute locally.")
        if (!commandWorks(r.apksigner, listOf("version"))) return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "apksigner was found but could not execute locally.")
        val wrapper = projectDir?.let { File(it, "gradle/wrapper/gradle-wrapper.properties") }
        val text = if (wrapper != null && wrapper.isFile) read(wrapper) else ""
        if (projectDir != null && !text.contains("gradle-6.1.1-", true)) {
            return Gate("toolchain", "Real Android Toolchain", Status.FAIL, "Project Gradle wrapper is not pinned to Gradle 6.1.1.")
        }
        return Gate("toolchain", "Real Android Toolchain", Status.PASS, r.details + if (projectDir != null) " Gradle 6.1.1 wrapper verified." else "")
    }

    private fun offlineDependencyGate(projectDir: File?): Gate {
        if (projectDir == null) return Gate("dependencies", "Offline Dependencies", Status.CONDITIONAL, "Select a project before resolving dependencies.")
        val gradlew = File(projectDir, "gradlew")
        val gradleBat = File(projectDir, "gradlew.bat")
        if (!gradlew.isFile && !gradleBat.isFile) return Gate("dependencies", "Offline Dependencies", Status.MISSING, "Gradle wrapper is missing.")
        val localArtifacts = LocalPackageManager(projectDir).list()
        val result = runGradle(projectDir, "dependencies")
        if (result.exitCode == 0) {
            return Gate("dependencies", "Offline Dependencies", Status.PASS, "Gradle dependency resolution completed with --offline. Local artifacts: ${localArtifacts.size}.")
        }
        val text = result.output.toLowerCase()
        val missing = text.contains("could not resolve") || text.contains("no cached version") || text.contains("offline mode") || text.contains("not found")
        return if (missing) Gate("dependencies", "Offline Dependencies", Status.MISSING, "Offline dependency resolution reported a missing local artifact. ${tail(result.output)}")
        else Gate("dependencies", "Offline Dependencies", Status.FAIL, "Offline dependency resolution failed. ${tail(result.output)}")
    }

    private fun buildGate(projectDir: File?): Gate {
        if (projectDir == null) return Gate("build", "Real Offline Build", Status.CONDITIONAL, "Select a generated Android project to execute a real build.")
        val result = BuildEngine().buildDebug(projectDir)
        return if (result.success && result.apkFile != null && result.apkFile.isFile) Gate("build", "Real Offline Build", Status.PASS, "assembleDebug --offline succeeded and produced ${result.apkFile.name}.")
        else Gate("build", "Real Offline Build", Status.FAIL, "Real offline Gradle build failed. ${tail(result.output)}")
    }

    private fun apkGate(projectDir: File?): Gate {
        if (projectDir == null) return Gate("apk", "Real APK Validation", Status.CONDITIONAL, "A project with a produced APK is required.")
        val apk = newestApk(projectDir) ?: return Gate("apk", "Real APK Validation", Status.MISSING, "No APK was found under build outputs.")
        val r = ApkValidationEngine().validate(apk)
        return if (r.valid) Gate("apk", "Real APK Validation", Status.PASS, "APK structure and local signing validation passed: ${apk.name} (${apk.length()} bytes).")
        else Gate("apk", "Real APK Validation", Status.FAIL, "APK validation failed: ${r.errors.joinToString("; ")}")
    }

    private fun installRunGate(projectDir: File?): Gate {
        if (projectDir == null) return Gate("install-run", "Install + Run", Status.CONDITIONAL, "A project is required.")
        val apk = newestApk(projectDir) ?: return Gate("install-run", "Install + Run", Status.MISSING, "No real APK available for device validation.")
        val tc = AndroidToolchainDiscoveryEngine(context).discover()
        val adb = tc.adb ?: return Gate("install-run", "Install + Run", Status.MISSING, "ADB is MISSING.")
        val packageName = readPackageName(projectDir) ?: return Gate("install-run", "Install + Run", Status.MISSING, "Application ID could not be resolved locally.")
        val activity = readLaunchActivity(projectDir, packageName) ?: return Gate("install-run", "Install + Run", Status.MISSING, "Launchable activity could not be resolved locally.")
        return try {
            val devices = runCommand(adb, listOf("devices"), 20)
            if (devices.exitCode != 0) return Gate("install-run", "Install + Run", Status.FAIL, "ADB devices failed: ${tail(devices.output)}")
            if (!devices.output.lines().any { it.trim().endsWith("\tdevice") }) return Gate("install-run", "Install + Run", Status.CONDITIONAL, "No Android device/emulator connected to local ADB.")
            val install = runCommand(adb, listOf("install", "-r", apk.absolutePath), 120)
            if (install.exitCode != 0 || !install.output.contains("success", true)) return Gate("install-run", "Install + Run", Status.FAIL, "ADB install failed: ${tail(install.output)}")
            val launch = runCommand(adb, listOf("shell", "am", "start", "-W", "-n", "$packageName/$activity"), 30)
            if (launch.exitCode == 0 && (launch.output.contains("Status: ok") || launch.output.contains("Activity:") || launch.output.contains("Complete"))) Gate("install-run", "Install + Run", Status.PASS, "APK installed and launcher Activity started successfully on a real local device.")
            else Gate("install-run", "Install + Run", Status.FAIL, "Launch command did not report success: ${tail(launch.output)}")
        } catch (t: Throwable) { Gate("install-run", "Install + Run", Status.FAIL, "Local ADB execution failed: ${t.message ?: t.javaClass.simpleName}") }
    }

    private fun sqliteGate(projectDir: File?): Gate {
        val root = projectDir ?: File(context.filesDir, "functional-qa-project")
        return try {
            val engine = DatabaseStudioEngine(root, File(context.filesDir, "runtimes"))
            if (!engine.open()) return Gate("sqlite", "SQLite Real Operations", Status.FAIL, "SQLite could not be opened locally.")
            engine.execute("DROP TABLE IF EXISTS qa_probe")
            val create = engine.createTable("qa_probe", "id INTEGER PRIMARY KEY, value TEXT NOT NULL")
            val inserted = engine.insert("qa_probe", mapOf("id" to "1", "value" to "offline"))
            val selected = engine.execute("SELECT value FROM qa_probe WHERE id=1")
            val updated = engine.execute("UPDATE qa_probe SET value='verified' WHERE id=1")
            val verified = engine.execute("SELECT value FROM qa_probe WHERE id=1")
            engine.close()
            if (create.error == null && inserted.error == null && selected.error == null && updated.error == null && verified.error == null && verified.rows.any { it.firstOrNull() == "verified" }) Gate("sqlite", "SQLite Real Operations", Status.PASS, "CREATE/INSERT/SELECT/UPDATE executed against a real local SQLite database.")
            else Gate("sqlite", "SQLite Real Operations", Status.FAIL, "SQLite CRUD smoke test failed: ${selected.error ?: verified.error ?: "unexpected result"}")
        } catch (t: Throwable) { Gate("sqlite", "SQLite Real Operations", Status.FAIL, "SQLite smoke test failed: ${t.message ?: t.javaClass.simpleName}") }
    }

    private fun offlineGate(): Gate {
        val p = OfflineNetworkPolicy(context)
        val local = p.allow("http://127.0.0.1:8080/health") && p.allow("http://localhost:8080/health") && p.allow("http://[::1]:8080/health") && p.allow("file:///tmp/index.html")
        val external = !p.allow("https://example.com") && !p.allow("http://8.8.8.8") && !p.allow("https://1.1.1.1")
        return if (local && external) Gate("offline", "Offline Enforcement", Status.PASS, "Local/loopback/file destinations allowed; external destinations blocked by strict offline policy.")
        else Gate("offline", "Offline Enforcement", Status.FAIL, "Offline policy boundary did not produce the expected allow/block results.")
    }

    private fun e2eEvidenceGate(projectDir: File?, precedingPassed: Boolean, gates: List<Gate>): Gate {
        if (projectDir == null) return Gate("e2e", "E2E Evidence", Status.CONDITIONAL, "No project supplied for the complete E2E run.")
        return if (precedingPassed && gates.size == 7) Gate("e2e", "E2E Evidence", Status.PASS, "All seven preceding gates passed in this same audit run; evidence can be committed.")
        else Gate("e2e", "E2E Evidence", Status.CONDITIONAL, "E2E cannot pass until all preceding real functional gates pass in the same run.")
    }

    private fun writeEvidence(gates: List<Gate>, projectDir: File): File {
        val root = File(context.filesDir, "endgame/evidence"); root.mkdirs()
        val file = File(root, "functional-8-gates.ok")
        val body = buildString {
            append("DEVSTUDIO FUNCTIONAL 8-GATE EVIDENCE\n")
            append("VERSION=30.1.0\nVERSION_CODE=302\nPROJECT=${projectDir.absolutePath}\n")
            append("TIMESTAMP=${System.currentTimeMillis()}\n")
            gates.forEach { append("${it.id}|${it.status}|${it.detail}\n") }
        }
        file.writeText(body + "SHA256=" + sha256(body) + "\n")
        return file
    }

    private data class Cmd(val exitCode: Int, val output: String)

    private fun runGradle(project: File, task: String): Cmd {
        val wrapper = File(project, "gradlew")
        val command = if (wrapper.isFile) listOf("sh", wrapper.absolutePath, task, "--offline", "--no-daemon") else listOf("gradle", task, "--offline", "--no-daemon")
        return runCommand(command, project, 180)
    }

    private fun commandWorks(file: File?, args: List<String>): Boolean = file != null && runCommand(file, args, 20).exitCode == 0

    private fun runCommand(file: File, args: List<String>, timeoutSeconds: Long): Cmd = runCommand(listOf(file.absolutePath) + args, file.parentFile, timeoutSeconds)

    private fun runCommand(command: List<String>, dir: File?, timeoutSeconds: Long): Cmd {
        return try {
            val p = ProcessBuilder(command).directory(if (dir != null && dir.isDirectory) dir else null).redirectErrorStream(true).start()
            val output = p.inputStream.bufferedReader().use { it.readText() }
            val finished = p.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!finished) { p.destroy(); Cmd(-2, output + "\nTIMEOUT") } else Cmd(p.exitValue(), output)
        } catch (t: Throwable) { Cmd(-1, t.message ?: t.javaClass.simpleName) }
    }

    private fun newestApk(root: File): File? {
        var best: File? = null
        var bestTime = Long.MIN_VALUE
        root.walkTopDown().forEach { f ->
            if (f.isFile && f.extension.equals("apk", true) && f.absolutePath.contains("outputs${File.separator}apk")) {
                if (f.lastModified() > bestTime) { best = f; bestTime = f.lastModified() }
            }
        }
        return best
    }

    private fun readPackageName(project: File): String? {
        val text = read(File(project, "app/build.gradle")) + "\n" + read(File(project, "build.gradle"))
        return Regex("applicationId\\s+[\\\"']([^\\\"']+)[\\\"']").find(text)?.groupValues?.get(1)
    }

    private fun readLaunchActivity(project: File, pkg: String): String? {
        val manifest = File(project, "app/src/main/AndroidManifest.xml")
        if (!manifest.isFile) return null
        val text = read(manifest)
        val activity = Regex("<activity[^>]*>([\\s\\S]*?)</activity>").findAll(text).firstOrNull { it.value.contains("MAIN") && it.value.contains("LAUNCHER") }
        val name = activity?.let { Regex("android:name=\\\"([^\\\"]+)\\\"").find(it.value)?.groupValues?.get(1) } ?: return null
        return if (name.startsWith(".")) pkg + name else name
    }

    private fun read(file: File): String = if (file.isFile) runCatching { file.readText() }.getOrDefault("") else ""
    private fun tail(s: String): String = s.trim().takeLast(900)
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { b -> String.format("%02x", b.toInt() and 0xff) }
}
