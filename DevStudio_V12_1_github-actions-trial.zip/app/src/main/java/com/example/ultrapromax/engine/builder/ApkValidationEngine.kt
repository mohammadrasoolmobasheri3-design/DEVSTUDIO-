package com.example.ultrapromax.engine.builder

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.jar.JarFile
import java.util.zip.ZipFile

/** Strict local APK validator. No synthetic APK is accepted. */
class ApkValidationEngine(private val context: Context? = null) {
    data class Report(val valid: Boolean, val sizeBytes: Long, val packageHint: String?, val errors: List<String>)

    fun validate(apk: File): Report {
        if (!apk.isFile) return Report(false, 0L, null, listOf("APK file not found"))
        if (apk.length() < 1024L) return Report(false, apk.length(), null, listOf("APK is unexpectedly small"))
        try {
            ZipFile(apk).use { zip ->
                val names = zip.entries().asSequence().map { it.name }.toSet()
                val errors = ArrayList<String>()
                if (!names.contains("AndroidManifest.xml")) errors.add("AndroidManifest.xml missing")
                if (!names.any { it == "classes.dex" || (it.startsWith("classes") && it.endsWith(".dex")) }) errors.add("DEX bytecode missing")
                if (!names.contains("resources.arsc") && !names.any { it.startsWith("res/") }) errors.add("Android resources missing")
                if (names.any { it.contains("../") || it.startsWith("/") }) errors.add("Unsafe APK entry path")
                if (errors.isNotEmpty()) return Report(false, apk.length(), null, errors)
            }
        } catch (t: Throwable) {
            return Report(false, apk.length(), null, listOf("Invalid APK/ZIP: " + (t.message ?: "unknown")))
        }

        // A real Android SDK signer is required for a strict validation pass.
        val signer = findApkSigner()
            ?: return Report(false, apk.length(), null, listOf("apksigner is MISSING; cryptographic APK validation cannot be certified"))
        val verify = runCommand(signer, listOf("verify", "--verbose", apk.absolutePath), 30)
        if (verify.exitCode != 0) return Report(false, apk.length(), null, listOf("apksigner verification failed: " + tail(verify.output)))
        return Report(true, apk.length(), null, emptyList())
    }

    private fun findApkSigner(): File? {
        context?.let {
            try {
                val discovered = AndroidToolchainDiscoveryEngine(it).discover().apksigner
                if (discovered != null && discovered.isFile) return discovered
            } catch (_: Throwable) {}
        }
        return findExecutable("apksigner")
    }

    private fun findExecutable(name: String): File? {
        val path = System.getenv("PATH") ?: ""
        for (part in path.split(File.pathSeparator)) {
            val f = File(part, name)
            if (f.isFile && f.canExecute()) return f
            val bat = File(part, "$name.bat")
            if (bat.isFile) return bat
        }
        return null
    }

    private fun runCommand(file: File, args: List<String>, timeout: Long): Cmd {
        return try {
            val p = ProcessBuilder(listOf(file.absolutePath) + args).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().use { it.readText() }
            if (!p.waitFor(timeout, TimeUnit.SECONDS)) { p.destroy(); Cmd(-2, out + " TIMEOUT") } else Cmd(p.exitValue(), out)
        } catch (t: Throwable) { Cmd(-1, t.message ?: t.javaClass.simpleName) }
    }
    private data class Cmd(val exitCode: Int, val output: String)
    private fun tail(s: String): String = s.trim().takeLast(700)
}
