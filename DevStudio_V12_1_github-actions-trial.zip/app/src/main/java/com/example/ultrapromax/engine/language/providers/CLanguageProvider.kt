package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class CLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("c", "C", listOf("c"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("c").parse(source)
}
