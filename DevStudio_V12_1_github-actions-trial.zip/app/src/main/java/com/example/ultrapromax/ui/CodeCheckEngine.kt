package com.example.ultrapromax.ui

data class CodeProblem(
    val line: Int,
    val message: String
)

object CodeCheckEngine {

    fun check(
        source: String,
        language: String
    ): List<CodeProblem> {

        val problems = mutableListOf<CodeProblem>()

        val stack = mutableListOf<Char>()
        val stackLines = mutableListOf<Int>()

        val lines = source.split("\n")

        var inDoubleString = false
        var inSingleString = false
        var escaped = false

        for (lineIndex in lines.indices) {

            val line = lines[lineIndex]
            val lineNumber = lineIndex + 1

            var i = 0

            while (i < line.length) {

                val c = line[i]

                if (escaped) {
                    escaped = false
                    i++
                    continue
                }

                if (
                    (inDoubleString || inSingleString) &&
                    c == '\\'
                ) {
                    escaped = true
                    i++
                    continue
                }

                if (
                    c == '"' &&
                    !inSingleString
                ) {
                    inDoubleString = !inDoubleString
                    i++
                    continue
                }

                if (
                    c == '\'' &&
                    !inDoubleString
                ) {
                    inSingleString = !inSingleString
                    i++
                    continue
                }

                if (
                    !inDoubleString &&
                    !inSingleString
                ) {

                    /*
                     * Ignore // comments.
                     */
                    if (
                        c == '/' &&
                        i + 1 < line.length &&
                        line[i + 1] == '/'
                    ) {
                        break
                    }

                    when (c) {

                        '(',
                        '{',
                        '[' -> {
                            stack.add(c)
                            stackLines.add(lineNumber)
                        }

                        ')',
                        '}',
                        ']' -> {

                            if (stack.isEmpty()) {

                                problems.add(
                                    CodeProblem(
                                        lineNumber,
                                        "Unexpected '$c'"
                                    )
                                )

                            } else {

                                val opening =
                                    stack.removeAt(
                                        stack.size - 1
                                    )

                                val openingLine =
                                    stackLines.removeAt(
                                        stackLines.size - 1
                                    )

                                if (
                                    !matches(
                                        opening,
                                        c
                                    )
                                ) {

                                    problems.add(
                                        CodeProblem(
                                            lineNumber,
                                            "Mismatched '$c' " +
                                                "(opened on line " +
                                                openingLine +
                                                ")"
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                i++
            }
        }

        if (inDoubleString) {

            problems.add(
                CodeProblem(
                    lines.size,
                    "Unclosed double quote"
                )
            )
        }

        if (inSingleString) {

            problems.add(
                CodeProblem(
                    lines.size,
                    "Unclosed single quote"
                )
            )
        }

        while (stack.isNotEmpty()) {

            val opening =
                stack.removeAt(
                    stack.size - 1
                )

            val openingLine =
                stackLines.removeAt(
                    stackLines.size - 1
                )

            problems.add(
                CodeProblem(
                    openingLine,
                    "Unclosed '$opening'"
                )
            )
        }

        checkLanguage(
            source,
            language,
            problems
        )

        return problems
    }

    private fun matches(
        opening: Char,
        closing: Char
    ): Boolean {

        return (
            opening == '(' &&
                closing == ')'
            ) || (
            opening == '{' &&
                closing == '}'
            ) || (
            opening == '[' &&
                closing == ']'
            )
    }

    private fun checkLanguage(
        source: String,
        language: String,
        problems: MutableList<CodeProblem>
    ) {

        val lines =
            source.split("\n")

        when (language) {

            "kt" -> {

                for (index in lines.indices) {

                    val line =
                        lines[index].trim()

                    if (
                        line.startsWith("fun ") &&
                        !line.contains("(")
                    ) {

                        problems.add(
                            CodeProblem(
                                index + 1,
                                "Function declaration appears incomplete"
                            )
                        )
                    }
                }
            }

            "js" -> {

                for (index in lines.indices) {

                    val line =
                        lines[index]

                    if (
                        line.contains("function ") &&
                        !line.contains("(")
                    ) {

                        problems.add(
                            CodeProblem(
                                index + 1,
                                "Function declaration appears incomplete"
                            )
                        )
                    }
                }
            }

            "ts" -> {

                for (index in lines.indices) {

                    val line =
                        lines[index]

                    if (
                        line.contains("function ") &&
                        !line.contains("(")
                    ) {

                        problems.add(
                            CodeProblem(
                                index + 1,
                                "Function declaration appears incomplete"
                            )
                        )
                    }
                }
            }

            "java" -> {

                for (index in lines.indices) {

                    val line =
                        lines[index].trim()

                    if (
                        line.startsWith("class ") &&
                        line.length <= 6
                    ) {

                        problems.add(
                            CodeProblem(
                                index + 1,
                                "Class declaration appears incomplete"
                            )
                        )
                    }
                }
            }
        }
    }
}