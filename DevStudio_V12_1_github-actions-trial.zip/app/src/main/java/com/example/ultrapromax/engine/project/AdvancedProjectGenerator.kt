package com.example.ultrapromax.engine.project

import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.file.FileEngine
import com.example.ultrapromax.engine.file.ProjectTemplate
import java.io.File

/**
 * V30.1.0 Advanced Project Generator.
 * Uses the existing offline FileEngine and legacy toolchain templates.
 * No Gradle/AGP/Kotlin upgrade is performed here.
 */
class AdvancedProjectGenerator(private val fileEngine: FileEngine) {

    data class Options(
        val name: String,
        val packageName: String,
        val template: ProjectTemplate,
        val addReadme: Boolean = true,
        val addGitignore: Boolean = true,
        val addMetadata: Boolean = true,
        val addStudioFolders: Boolean = true
    )

    data class Result(
        val success: Boolean,
        val projectId: Long = -1L,
        val projectDir: File? = null,
        val filesCreated: Int = 0,
        val log: List<String> = emptyList(),
        val error: String? = null
    )

    fun generate(options: Options, context: android.content.Context): Result {
        val log = ArrayList<String>()
        try {
            log.add("PLAN  • ${options.template.displayName}")
            if (ProjectStore.list(context).any { it.name.equals(options.name.trim(), ignoreCase = true) }) {
                return Result(false, log = listOf("FAILED • A project with this name already exists"), error = "A project with this name already exists")
            }
            val folder = uniqueFolderName(options.name)
            val dir = fileEngine.createProject(folder, options.template)
            log.add("SCAFFOLD • ${options.template.id}")

            configureAndroidProject(dir, options, log)
            configureStudioFiles(dir, options, log)

            val count = dir.walkTopDown().count { it.isFile }
            val project = ProjectStore.insert(context, options.name, dir.absolutePath, options.template.id)
            log.add("INDEX • Project #${project.id} registered")
            log.add("VERIFY • $count files ready")
            log.add("COMPLETE • Project generated offline")
            return Result(true, project.id, dir, count, log)
        } catch (e: Exception) {
            log.add("FAILED • ${e.message ?: "Unknown generation error"}")
            return Result(false, error = e.message ?: "Project generation failed", log = log)
        }
    }

    private fun uniqueFolderName(name: String): String {
        val base = name.trim().replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "Project" }
        return System.currentTimeMillis().toString() + "_" + base
    }

    private fun configureAndroidProject(dir: File, options: Options, log: MutableList<String>) {
        val android = options.template == ProjectTemplate.AndroidJava ||
                options.template == ProjectTemplate.AndroidUi ||
                options.template == ProjectTemplate.WebViewApp ||
                options.template == ProjectTemplate.AndroidKotlin
        if (!android) return

        val oldPackage = "com.example.newproject"
        val pkg = options.packageName.trim()
        if (pkg.isNotEmpty()) {
            dir.walkTopDown().filter { it.isFile && (it.extension == "java" || it.extension == "kt" || it.extension == "gradle" || it.extension == "xml") }.forEach { file ->
                val text = try { file.readText() } catch (_: Exception) { return@forEach }
                file.writeText(text.replace(oldPackage, pkg)
                    .replace("rootProject.name = \"NewProject\"", "rootProject.name = \"${escapeGradle(options.name)}\"")
                    .replace("android:label=\"New Project\"", "android:label=\"${xmlEscape(options.name)}\""))
            }
            moveJavaPackage(dir, oldPackage, pkg)
            log.add("CONFIG • Package $pkg")
        }
        log.add("CONFIG • Android toolchain preserved: compileSdk 29 / AGP 3.5.3")
    }

    private fun moveJavaPackage(dir: File, oldPackage: String, newPackage: String) {
        val oldPath = oldPackage.replace('.', File.separatorChar)
        val newPath = newPackage.replace('.', File.separatorChar)
        val roots = listOf(
            File(dir, "app/src/main/java"),
            File(dir, "app/src/test/java"),
            File(dir, "app/src/androidTest/java")
        )
        roots.forEach { root ->
            if (!root.isDirectory) return@forEach
            val oldDir = File(root, oldPath)
            if (!oldDir.isDirectory) return@forEach
            val newDir = File(root, newPath)
            newDir.parentFile?.mkdirs()
            oldDir.listFiles()?.forEach { file -> file.copyTo(File(newDir, file.name), true) }
            oldDir.deleteRecursively()
        }
    }

    private fun configureStudioFiles(dir: File, options: Options, log: MutableList<String>) {
        if (options.addReadme) {
            File(dir, "README.md").writeText(
                "# ${options.name}\n\nGenerated offline by DEVSTUDIO ULTRA PRO MAX+.\n\n" +
                        "Template: ${options.template.displayName}\n" +
                        "Package: ${options.packageName}\n"
            )
            log.add("CREATE • README.md")
        }
        if (options.addGitignore) {
            File(dir, ".gitignore").writeText(
                ".gradle/\nbuild/\n.idea/\n*.iml\nlocal.properties\n.DS_Store\n"
            )
            log.add("CREATE • .gitignore")
        }
        if (options.addMetadata) {
            val meta = File(dir, ".devstudio-project")
            meta.writeText(
                "name=${options.name}\n" +
                        "template=${options.template.id}\n" +
                        "package=${options.packageName}\n" +
                        "version=30.1.0\n" +
                        "generatedOffline=true\n"
            )
            log.add("CREATE • .devstudio-project")
        }
        if (options.addStudioFolders) {
            listOf(".devstudio", ".devstudio/backups", ".devstudio/cache", ".devstudio/tasks").forEach {
                File(dir, it).mkdirs()
            }
            File(dir, ".devstudio/workspace.state").writeText("activeTab=files\nbottomPanel=none\n")
            log.add("CREATE • Studio workspace folders")
        }
    }

    private fun escapeGradle(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun xmlEscape(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}
