package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class JavaLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("java", "Java", listOf("java"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("java").parse(source)
}
