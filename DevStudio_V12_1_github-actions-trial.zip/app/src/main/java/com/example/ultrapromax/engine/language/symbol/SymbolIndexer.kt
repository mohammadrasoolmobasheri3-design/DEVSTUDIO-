package com.example.ultrapromax.engine.language.symbol

import com.example.ultrapromax.engine.language.LanguageRegistry
import java.io.File

class SymbolIndexer(private val index: SymbolIndex) {
    fun indexFile(file: File): Boolean {
        if (!file.isFile) return false
        return try {
            val provider = LanguageRegistry.detect(file.name)
            if (provider == null) {
                index.removeFile(file.absolutePath)
                false
            } else {
                val result = provider.parse(file.readText())
                index.replaceFile(file.absolutePath, result.symbols)
                true
            }
        } catch (_: Exception) { false }
    }

    fun indexProject(root: File): Int {
        if (!root.isDirectory) return 0
        var count = 0
        root.walkTopDown().forEach { file -> if (file.isFile && indexFile(file)) count++ }
        return count
    }

    fun removeFile(file: File) { index.removeFile(file.absolutePath) }
}
