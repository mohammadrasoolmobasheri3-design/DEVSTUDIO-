package com.example.ultrapromax.engine.databasestudio

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.ultrapromax.engine.endgame.UniversalDatabaseRegistry
import java.io.File

/** ENDGAME Stage 7: local-first Database Studio. SQLite is a real built-in engine; other adapters require real local tooling. */
class DatabaseStudioEngine(private val projectDir: File, private val runtimeRoot: File) {
    data class DbProfile(val id: String, val name: String, val engine: String, val notes: String, val native: Boolean)
    data class QueryResult(val columns: List<String>, val rows: List<List<String>>, val affected: Int = 0, val error: String? = null)
    private var db: SQLiteDatabase? = null
    private val dbDir = File(projectDir, ".devstudio/database")
    private var selectedId = "sqlite"
    private var dbFile = File(dbDir, "devstudio.sqlite")

    fun profiles(): List<DbProfile> = UniversalDatabaseRegistry.all().map { p -> DbProfile(p.id, p.name, p.id, if (p.id == "sqlite") "Built-in Android SQLite engine; real local database operations." else "Requires a real local ${p.name} adapter/toolchain.", p.id == "sqlite") }
    fun select(id: String) { if (profiles().any { it.id == id }) selectedId = id }
    fun selected(): String = selectedId
    fun databaseFile(): File = dbFile
    fun readiness(): String = if (selectedId == "sqlite") "[READY] SQLite • built-in local engine" else "[MISSING] ${UniversalDatabaseRegistry.find(selectedId)?.name ?: "Unknown database"}: no real local adapter/toolchain installed"
    fun open(): Boolean { if (selectedId != "sqlite") return false; dbDir.mkdirs(); db?.close(); db = SQLiteDatabase.openOrCreateDatabase(dbFile, null); ensureMeta(); return true }
    private fun ensureMeta() { db?.execSQL("CREATE TABLE IF NOT EXISTS _devstudio_migrations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, applied_at INTEGER NOT NULL)") }
    fun close() { db?.close(); db = null }
    fun isOpen() = db?.isOpen == true

    fun execute(sql: String): QueryResult {
        val d = db ?: return QueryResult(emptyList(), emptyList(), error = "Database is closed")
        if (sql.isBlank()) return QueryResult(emptyList(), emptyList(), error = "SQL is empty")
        return try {
            val trimmed = sql.trim()
            val isQuery = trimmed.startsWith("select", true) || trimmed.startsWith("pragma", true) || trimmed.startsWith("with", true) || trimmed.startsWith("explain", true)
            if (isQuery) queryCursor(d.rawQuery(sql, emptyArray())) else { d.execSQL(sql); QueryResult(emptyList(), emptyList(), affected = 1) }
        } catch (t: Throwable) { QueryResult(emptyList(), emptyList(), error = t.message ?: "SQL execution failed") }
    }
    private fun queryCursor(c: Cursor): QueryResult { c.use { val cols = it.columnNames.toList(); val rows = ArrayList<List<String>>(); while (it.moveToNext()) { val row = ArrayList<String>(); for (i in cols.indices) row.add(if (it.isNull(i)) "NULL" else it.getString(i)); rows.add(row) }; return QueryResult(cols, rows) } }
    fun tables(): List<String> = execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").rows.mapNotNull { it.firstOrNull() }
    fun schema(table: String): QueryResult { if (!table.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) return QueryResult(emptyList(), emptyList(), error = "Invalid table name"); return execute("PRAGMA table_info(\"$table\")") }
    fun createTable(name: String, columns: String): QueryResult { if (!name.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) return QueryResult(emptyList(), emptyList(), error = "Invalid table name"); return execute("CREATE TABLE IF NOT EXISTS \"$name\" ($columns)") }
    fun insert(table: String, values: Map<String, String>): QueryResult { val d = db ?: return QueryResult(emptyList(), emptyList(), error = "Database is closed"); if (!table.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) || values.isEmpty()) return QueryResult(emptyList(), emptyList(), error = "Invalid insert"); return try { val cv = ContentValues(); values.forEach { cv.put(it.key, it.value) }; d.insertOrThrow(table, null, cv); QueryResult(emptyList(), emptyList(), affected = 1) } catch (t: Throwable) { QueryResult(emptyList(), emptyList(), error = t.message ?: "Insert failed") } }
    fun applyMigration(name: String, sql: String): QueryResult { val d = db ?: return QueryResult(emptyList(), emptyList(), error = "Database is closed"); if (!name.matches(Regex("[A-Za-z0-9_.-]+"))) return QueryResult(emptyList(), emptyList(), error = "Invalid migration name"); return try { d.beginTransaction(); val exists = d.rawQuery("SELECT 1 FROM _devstudio_migrations WHERE name=? LIMIT 1", arrayOf(name)).use { it.moveToFirst() }; if (exists) { d.endTransaction(); return QueryResult(emptyList(), emptyList(), error = "Migration already applied: $name") }; sql.split(';').map { it.trim() }.filter { it.isNotEmpty() }.forEach { d.execSQL(it) }; val cv = ContentValues(); cv.put("name", name); cv.put("applied_at", System.currentTimeMillis()); d.insertOrThrow("_devstudio_migrations", null, cv); d.setTransactionSuccessful(); d.endTransaction(); QueryResult(emptyList(), emptyList(), affected = 1) } catch (t: Throwable) { runCatching { d.endTransaction() }; QueryResult(emptyList(), emptyList(), error = t.message ?: "Migration failed") } }
    fun migrations(): QueryResult = execute("SELECT id,name,applied_at FROM _devstudio_migrations ORDER BY id")
    fun exportSchema(): String = execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name").rows.joinToString("\n") { it.firstOrNull() ?: "" } + "\n"
}
