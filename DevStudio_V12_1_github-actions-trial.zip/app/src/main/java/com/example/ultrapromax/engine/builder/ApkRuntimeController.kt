package com.example.ultrapromax.engine.builder

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import java.io.File

/** Real APK lifecycle helper. It never claims an APK is runnable until package metadata is readable. */
object ApkRuntimeController {
    data class Inspection(
        val valid: Boolean,
        val packageName: String?,
        val versionName: String?,
        val versionCode: Long,
        val installed: Boolean,
        val launchable: Boolean,
        val message: String
    )

    fun inspect(context: Context, apk: File): Inspection {
        if (!apk.isFile || apk.length() <= 0L) return Inspection(false, null, null, 0L, false, false, "APK file is missing or empty")
        val pm = context.packageManager
        val info = try {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(apk.absolutePath, PackageManager.GET_ACTIVITIES)
        } catch (e: Exception) {
            return Inspection(false, null, null, 0L, false, false, "APK metadata error: ${e.message}")
        } ?: return Inspection(false, null, null, 0L, false, false, "APK metadata could not be read")
        val pkg = info.packageName
        val installedInfo = try { pm.getPackageInfo(pkg, 0) } catch (_: Exception) { null }
        val launchIntent = pm.getLaunchIntentForPackage(pkg)
        val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong()
        return Inspection(true, pkg, info.versionName, versionCode, installedInfo != null, installedInfo != null && launchIntent != null, "APK metadata verified")
    }

    fun launchInstalled(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun installedPackageInfo(context: Context, packageName: String): PackageInfo? = try {
        context.packageManager.getPackageInfo(packageName, 0)
    } catch (_: Exception) { null }
}
