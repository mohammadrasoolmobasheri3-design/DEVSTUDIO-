package com.example.ultrapromax.engine.security

import java.io.File
import java.security.MessageDigest

/** Transactional local recovery: snapshot -> mutate externally -> verify -> restore on demand. */
class RecoveryTransactionEngine {
    data class Snapshot(val root: File, val snapshotDir: File, val files: Int, val bytes: Long, val fingerprint: String)
    data class Verification(val valid: Boolean, val files: Int, val bytes: Long, val fingerprint: String, val detail: String)

    fun snapshot(root: File, destination: File): Snapshot {
        require(root.isDirectory) { "Project root is not a directory" }
        if (destination.exists()) destination.deleteRecursively()
        if (!destination.mkdirs() && !destination.isDirectory) throw IllegalStateException("Cannot create snapshot")
        var count = 0
        var bytes = 0L
        root.walkTopDown().filter { it.isFile && !ignored(it, root) }.forEach { file ->
            val rel = file.relativeTo(root)
            val target = File(destination, rel.path)
            target.parentFile?.mkdirs()
            file.copyTo(target, true)
            count++
            bytes += file.length()
        }
        return Snapshot(root, destination, count, bytes, fingerprint(destination))
    }

    fun verify(snapshot: Snapshot): Verification {
        val actual = fingerprint(snapshot.snapshotDir)
        val stats = stats(snapshot.snapshotDir)
        val valid = actual == snapshot.fingerprint && stats.first == snapshot.files && stats.second == snapshot.bytes
        return Verification(valid, stats.first, stats.second, actual, if (valid) "Snapshot verified" else "Snapshot integrity mismatch")
    }

    fun restore(snapshot: Snapshot): Boolean {
        if (!verify(snapshot).valid) return false
        val root = snapshot.root
        if (!root.exists() && !root.mkdirs()) return false
        root.walkTopDown().filter { it.isFile && !ignored(it, root) }.forEach { it.delete() }
        snapshot.snapshotDir.walkTopDown().filter { it.isFile }.forEach { file ->
            val target = File(root, file.relativeTo(snapshot.snapshotDir).path)
            target.parentFile?.mkdirs()
            file.copyTo(target, true)
        }
        return true
    }

    private fun stats(root: File): Pair<Int, Long> {
        var count = 0
        var bytes = 0L
        if (!root.exists()) return Pair(0, 0L)
        root.walkTopDown().filter { it.isFile }.forEach { count++; bytes += it.length() }
        return Pair(count, bytes)
    }

    private fun fingerprint(root: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        if (!root.exists()) return "missing"
        root.walkTopDown().filter { it.isFile }.map { it.relativeTo(root).path.replace(File.separatorChar, '/') }.sorted().forEach { rel ->
            val f = File(root, rel)
            digest.update(rel.toByteArray(Charsets.UTF_8))
            digest.update(0)
            digest.update(f.readBytes())
            digest.update(0)
        }
        return digest.digest().joinToString("") { String.format("%02x", it) }
    }

    private fun ignored(file: File, root: File): Boolean {
        val rel = file.relativeTo(root).path
        return rel.startsWith(".gradle${File.separator}") || rel.startsWith("build${File.separator}") || rel.startsWith(".git${File.separator}")
    }
}
