package com.example.ultrapromax.engine.gamify

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * GAMIFIED DEV SYSTEM
 * Real, working local XP/level tracker, plus achievements (unlocked once,
 * persisted) and a simple daily challenge counter that resets every calendar
 * day. Award XP for real actions (file created, project built, N lines
 * written) by calling addXp(...)/recordAction(...) from those engines/activities.
 *
 * Missions and daily streak tracking are now part of the engine. Badge artwork and a
 * dedicated missions UI remain presentation-layer work.
 */
class GamificationEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("gamify_state", Context.MODE_PRIVATE)
    private val dayFormat = SimpleDateFormat("yyyyMMdd", Locale.US)

    var xp: Int
        get() = prefs.getInt("xp", 0)
        private set(value) { prefs.edit().putInt("xp", value).apply() }

    val level: Int get() = 1 + xp / 100
    val xpIntoLevel: Int get() = xp % 100
    val xpForNextLevel: Int get() = 100

    fun addXp(amount: Int) {
        xp += amount
    }

    // ---- Convenience wrappers that track counts + auto-check achievements ----

    fun onFileCreated(): List<Achievement> {
        addXp(XP_FILE_CREATED)
        val count = prefs.getInt("count_files", 0) + 1
        prefs.edit().putInt("count_files", count).apply()
        return checkAchievements(count, prefs.getInt("count_projects", 0), prefs.getInt("count_builds", 0))
    }

    fun onProjectCreated(): List<Achievement> {
        addXp(XP_PROJECT_CREATED)
        val count = prefs.getInt("count_projects", 0) + 1
        prefs.edit().putInt("count_projects", count).apply()
        return checkAchievements(prefs.getInt("count_files", 0), count, prefs.getInt("count_builds", 0))
    }

    fun onBuildExported(): List<Achievement> {
        addXp(XP_BUILD_EXPORTED)
        val count = prefs.getInt("count_builds", 0) + 1
        prefs.edit().putInt("count_builds", count).apply()
        return checkAchievements(prefs.getInt("count_files", 0), prefs.getInt("count_projects", 0), count)
    }

    // ---- Achievements ----

    fun isUnlocked(achievement: Achievement): Boolean =
        prefs.getBoolean("ach_${achievement.id}", false)

    /** Call after relevant actions (e.g. after createProject/createFile). Returns newly unlocked ones. */
    fun checkAchievements(filesCreated: Int, projectsCreated: Int, buildsExported: Int): List<Achievement> {
        val newlyUnlocked = mutableListOf<Achievement>()
        Achievement.ALL.forEach { achievement ->
            if (!isUnlocked(achievement) && achievement.isMet(filesCreated, projectsCreated, buildsExported)) {
                prefs.edit().putBoolean("ach_${achievement.id}", true).apply()
                addXp(achievement.xpReward)
                newlyUnlocked.add(achievement)
            }
        }
        return newlyUnlocked
    }

    // ---- Daily challenge ----

    /** Increments today's action count and returns (count, goalMet). Goal resets automatically each day. */
    fun recordDailyAction(goal: Int = 3): Pair<Int, Boolean> {
        val today = dayFormat.format(Date())
        val storedDay = prefs.getString("daily_day", null)
        var count = if (storedDay == today) prefs.getInt("daily_count", 0) else 0
        count += 1
        prefs.edit().putString("daily_day", today).putInt("daily_count", count).apply()
        val goalMet = count >= goal
        if (goalMet && !prefs.getBoolean("daily_reward_$today", false)) {
            addXp(XP_DAILY_CHALLENGE)
            prefs.edit().putBoolean("daily_reward_$today", true).apply()
        }
        return count to goalMet
    }

    /** Read-only peek at today's daily challenge progress (does not record a new action). */
    fun dailyProgress(goal: Int = 3): Pair<Int, Boolean> {
        val today = dayFormat.format(Date())
        val storedDay = prefs.getString("daily_day", null)
        val count = if (storedDay == today) prefs.getInt("daily_count", 0) else 0
        return count to (count >= goal)
    }


    data class Mission(val id: String, val title: String, val goal: Int, val progress: Int, val rewardXp: Int, val completed: Boolean)

    fun missions(): List<Mission> {
        val files = prefs.getInt("count_files", 0)
        val projects = prefs.getInt("count_projects", 0)
        val builds = prefs.getInt("count_builds", 0)
        return listOf(
            Mission("m_project", "Create 3 projects", 3, projects.coerceAtMost(3), 40, projects >= 3),
            Mission("m_files", "Create 10 files", 10, files.coerceAtMost(10), 50, files >= 10),
            Mission("m_builds", "Complete 5 builds", 5, builds.coerceAtMost(5), 60, builds >= 5)
        )
    }

    /** Claim a completed mission reward once. Returns the awarded XP, or 0 if already claimed/not complete. */
    fun claimMission(missionId: String): Int {
        val mission = missions().firstOrNull { it.id == missionId } ?: return 0
        if (!mission.completed || prefs.getBoolean("mission_claimed_${mission.id}", false)) return 0
        prefs.edit().putBoolean("mission_claimed_${mission.id}", true).apply()
        addXp(mission.rewardXp)
        return mission.rewardXp
    }

    fun isMissionClaimed(missionId: String): Boolean =
        prefs.getBoolean("mission_claimed_$missionId", false)

    fun filesCreated(): Int = prefs.getInt("count_files", 0)
    fun projectsCreated(): Int = prefs.getInt("count_projects", 0)
    fun buildsExported(): Int = prefs.getInt("count_builds", 0)

    fun dailyStreak(): Int = prefs.getInt("daily_streak", 0)

    fun recordDailyActionWithStreak(goal: Int = 3): Pair<Int, Boolean> {
        val today = dayFormat.format(Date())
        val storedDay = prefs.getString("daily_day", null)
        var count = if (storedDay == today) prefs.getInt("daily_count", 0) else 0
        count += 1
        var streak = prefs.getInt("daily_streak", 0)
        if (count == 1 && storedDay != null && isYesterday(storedDay, today)) streak += 1
        else if (count == 1 && storedDay != today) streak = 1
        prefs.edit().putInt("daily_streak", streak).apply()
        return recordDailyAction(goal)
    }

    private fun isYesterday(previous: String, today: String): Boolean {
        return try {
            val prev = dayFormat.parse(previous) ?: return false
            val cur = dayFormat.parse(today) ?: return false
            cur.time - prev.time in 1L..(36L * 60L * 60L * 1000L)
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        const val XP_FILE_CREATED = 5
        const val XP_PROJECT_CREATED = 20
        const val XP_BUILD_EXPORTED = 15
        const val XP_DAILY_CHALLENGE = 25
    }
}

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val xpReward: Int,
    val isMet: (filesCreated: Int, projectsCreated: Int, buildsExported: Int) -> Boolean
) {
    companion object {
        val ALL = listOf(
            Achievement("first_project", "Getting started", "Create your first project", 20) { _, projects, _ -> projects >= 1 },
            Achievement("five_files", "Builder", "Create 5 files", 30) { files, _, _ -> files >= 5 },
            Achievement("first_export", "Shipped it", "Export your first build", 25) { _, _, builds -> builds >= 1 },
            Achievement("ten_projects", "Prolific", "Create 10 projects", 100) { _, projects, _ -> projects >= 10 }
        )
    }
}
