package com.example.ultrapromax.engine.language.parser

import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.language.symbol.SymbolKind
import java.util.regex.Pattern

/** Lightweight, dependency-free structural extractor. It is intentionally not a full compiler parser. */
class SymbolExtractor(private val languageId: String) : ParserProvider {
    override fun parse(source: String): ParseResult {
        val symbols = ArrayList<Symbol>()
        val patterns = patternsFor(languageId)
        for (entry in patterns) {
            val matcher = entry.second.matcher(source)
            while (matcher.find()) {
                val name = matcher.group(1) ?: continue
                if (name.isEmpty()) continue
                val start = matcher.start(1)
                val line = lineOf(source, start)
                val column = columnOf(source, start)
                symbols.add(Symbol(name, entry.first, languageId, null, line, column, line, column + name.length - 1, null, null, null))
            }
        }
        val ordered = symbols.sortedWith(compareBy<Symbol> { it.line }.thenBy { it.column }.thenBy { it.name })
        return ParseResult(ordered.distinctBy { it.kind.name + "|" + it.name + "|" + it.line + "|" + it.column })
    }

    private fun patternsFor(language: String): List<Pair<SymbolKind, Pattern>> {
        val list = ArrayList<Pair<SymbolKind, Pattern>>()
        when (language) {
            "kt" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.OBJECT to Pattern.compile("\\bobject\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.INTERFACE to Pattern.compile("\\binterface\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\bfun\\s+(?:<[^>]+>\\s*)?([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.PROPERTY to Pattern.compile("\\b(?:val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)"))
            }
            "java" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\b(?:class|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.INTERFACE to Pattern.compile("\\binterface\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.METHOD to Pattern.compile("\\b(?:public|private|protected|static|final|synchronized|native|abstract|\\s)+[A-Za-z_$][A-Za-z0-9_$<>\\[\\]]*\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\("))
            }
            "python" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("(?m)^\\s*class\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("(?m)^\\s*def\\s+([A-Za-z_][A-Za-z0-9_]*)"))
            }
            "js", "ts" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_$][A-Za-z0-9_$]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\bfunction\\s+([A-Za-z_$][A-Za-z0-9_$]*)"))
                list.add(SymbolKind.VARIABLE to Pattern.compile("\\b(?:const|let|var)\\s+([A-Za-z_$][A-Za-z0-9_$]*)"))
                if (language == "ts") list.add(SymbolKind.INTERFACE to Pattern.compile("\\binterface\\s+([A-Za-z_$][A-Za-z0-9_$]*)"))
            }
            "c", "cpp" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.STRUCT to Pattern.compile("\\bstruct\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\b[A-Za-z_][A-Za-z0-9_<>:*&\\s]+\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^;{}]*\\)\\s*\\{"))
            }
            "php" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.INTERFACE to Pattern.compile("\\binterface\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\bfunction\\s+([A-Za-z_][A-Za-z0-9_]*)"))
            }
            "dart" -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.MIXIN to Pattern.compile("\\bmixin\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\b(?:[A-Za-z_][A-Za-z0-9_<>?]*\\s+)?([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^;{}]*\\)\\s*\\{"))
            }
            else -> {
                list.add(SymbolKind.CLASS to Pattern.compile("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)"))
                list.add(SymbolKind.FUNCTION to Pattern.compile("\\bfunction\\s+([A-Za-z_][A-Za-z0-9_]*)"))
            }
        }
        return list
    }

    private fun lineOf(text: String, offset: Int): Int {
        var line = 1
        var i = 0
        while (i < offset && i < text.length) {
            if (text[i] == '\n') line++
            i++
        }
        return line
    }

    private fun columnOf(text: String, offset: Int): Int {
        var column = 1
        var i = offset - 1
        while (i >= 0 && text[i] != '\n') { column++; i-- }
        return column
    }
}
