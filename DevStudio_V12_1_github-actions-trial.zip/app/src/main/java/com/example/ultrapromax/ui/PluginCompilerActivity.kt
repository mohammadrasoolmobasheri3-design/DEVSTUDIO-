package com.example.ultrapromax.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.plugincompiler.PluginCompilerEngine
import com.example.ultrapromax.engine.plugincompiler.ToolLocator

class PluginCompilerActivity : AppCompatActivity() {

    private lateinit var engine: PluginCompilerEngine
    private var lastDexJarPath: String? = null
    private var lastClassName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plugin_compiler)

        engine = PluginCompilerEngine(this)

        val classNameInput = findViewById<EditText>(R.id.classNameInput)
        val sourceInput = findViewById<EditText>(R.id.sourceInput)
        val testInput = findViewById<EditText>(R.id.testInput)
        val logOutput = findViewById<TextView>(R.id.logOutput)

        sourceInput.setText(
            """public class MyPlugin {
    public String process(String input) {
        return input.toUpperCase();
    }
}
"""
        )

        findViewById<Button>(R.id.btnCheckToolchain).setOnClickListener {
            logOutput.text = ToolLocator.describeAvailability()
        }

        findViewById<Button>(R.id.btnCompile).setOnClickListener {
            val className = classNameInput.text.toString().trim().ifEmpty { "MyPlugin" }
            val source = sourceInput.text.toString()
            logOutput.text = "Compiling…"
            val result = engine.compile(className, source)
            logOutput.text = result.log
            if (result.success) {
                lastDexJarPath = result.dexJarPath
                lastClassName = result.className
            } else {
                lastDexJarPath = null
                lastClassName = null
            }
        }

        findViewById<Button>(R.id.btnRun).setOnClickListener {
            val jarPath = lastDexJarPath
            val className = lastClassName
            if (jarPath == null || className == null) {
                logOutput.text = "Compile successfully first."
                return@setOnClickListener
            }
            val input = testInput.text.toString()
            val result = engine.run(jarPath, className, input)
            logOutput.text = if (result.success) "Output: ${result.output}" else result.output
        }
    }
}
