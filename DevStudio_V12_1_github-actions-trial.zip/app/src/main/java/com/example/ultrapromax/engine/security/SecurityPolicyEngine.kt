package com.example.ultrapromax.engine.security

import android.content.Context
import com.example.ultrapromax.engine.plugin.ExtensionPermissionEngine
import com.example.ultrapromax.engine.plugin.ExtensionPlatformEngine
import com.example.ultrapromax.engine.plugin.PluginManager
import com.example.ultrapromax.engine.plugin.PluginPermission
import java.io.File
import java.net.URI
import java.security.MessageDigest

/**
 * V30.1.0 Stage 19 — Security / Sandbox policy gate.
 *
 * This is an offline security layer: it audits project files, validates paths,
 * blocks obviously unsafe execution intents, and exposes a single policy state
 * that other Studio systems can consult. It never executes arbitrary project or
 * extension code.
 */
class SecurityPolicyEngine(private val context: Context) {

    data class Finding(val severity: String, val title: String, val detail: String)
    data class AuditReport(
        val projectPath: String,
        val filesScanned: Int,
        val bytesScanned: Long,
        val findings: List<Finding>,
        val blockedOperations: Int,
        val policyLocked: Boolean
    ) {
        fun passed(): Int = findings.count { it.severity == "PASS" }
        fun warnings(): Int = findings.count { it.severity == "WARN" }
        fun critical(): Int = findings.count { it.severity == "BLOCK" }
    }

    private val prefs = context.getSharedPreferences("security_policy", Context.MODE_PRIVATE)

    fun isLocked(): Boolean = prefs.getBoolean("lockdown", false)

    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean("lockdown", locked).apply()
    }

    fun isInside(root: File, target: File): Boolean = SecurityEngine.isInsideSandbox(root, target)

    fun safeResolve(root: File, relativePath: String): File {
        val base = root.canonicalFile
        val target = File(base, relativePath).canonicalFile
        if (!isInside(base, target)) throw SecurityException("Sandbox path escape blocked")
        return target
    }

    fun allowsNetworkUrl(url: String): Boolean {
        return try {
            val uri = URI(url.trim())
            val scheme = (uri.scheme ?: "").toLowerCase()
            if (scheme == "file" || scheme == "content" || scheme == "about" || scheme == "data") return true
            if (scheme != "http" && scheme != "https") return false
            val host = (uri.host ?: "").toLowerCase()
            host == "127.0.0.1" || host == "localhost" || host == "::1"
        } catch (_: Throwable) {
            false
        }
    }

    fun allowsExecution(kind: String): Boolean {
        if (isLocked()) return false
        val k = kind.trim().toLowerCase()
        return k == "preview" || k == "diagnostics" || k == "build" || k == "format" || k == "symbols"
    }

    fun pluginPermissionAllowed(extensionId: String, permission: PluginPermission): Boolean {
        if (isLocked()) return false
        val engine = ExtensionPermissionEngine(context)
        return engine.isGranted(extensionId, permission)
    }

    fun audit(projectRoot: File?): AuditReport {
        val findings = ArrayList<Finding>()
        var scanned = 0
        var bytes = 0L
        var blocked = 0

        if (projectRoot == null || !projectRoot.isDirectory) {
            findings.add(Finding("BLOCK", "Project sandbox", "Project folder is missing or unavailable."))
            return AuditReport(projectRoot?.path ?: "", 0, 0L, findings, 1, isLocked())
        }

        val root = projectRoot.canonicalFile
        findings.add(Finding("PASS", "Sandbox root", "${root.path}"))

        val maxFiles = 5000
        val maxFileBytes = 4L * 1024L * 1024L
        val dangerous = Regex("(?i)(Runtime\\.getRuntime\\s*\\(|ProcessBuilder\\s*\\(|java\\.lang\\.Runtime|DexClassLoader|loadLibrary\\s*\\()")
        val externalUrl = Regex("https?://[^\\s\\\"'<>]+", RegexOption.IGNORE_CASE)

        try {
            root.walkTopDown().forEach { file ->
                if (!file.isFile) return@forEach
                if (scanned >= maxFiles) return@forEach
                scanned++
                bytes += file.length()

                if (file.length() > maxFileBytes) {
                    findings.add(Finding("WARN", "Large file", "${file.relativeTo(root).path} is larger than 4 MB; content scan skipped."))
                    return@forEach
                }

                val ext = file.extension.toLowerCase()
                if (ext in listOf("jar", "dex", "so")) {
                    findings.add(Finding("WARN", "Binary artifact", "${file.relativeTo(root).path} is a binary artifact and is not executed by the security layer."))
                }

                if (ext in listOf("kt", "java", "js", "ts", "cpp", "c", "h", "py", "php", "html", "xml", "gradle")) {
                    val text = try { file.readText() } catch (_: Throwable) { "" }
                    if (dangerous.containsMatchIn(text)) {
                        blocked++
                        findings.add(Finding("BLOCK", "Process / dynamic loading pattern", "Review ${file.relativeTo(root).path}; arbitrary process or dynamic loading is not executed by DEVSTUDIO."))
                    }
                    if (externalUrl.containsMatchIn(text)) {
                        findings.add(Finding("WARN", "External URL", "${file.relativeTo(root).path} contains an external HTTP(S) URL. Offline policy allows only local/loopback services."))
                    }
                }
            }
        } catch (e: Throwable) {
            findings.add(Finding("WARN", "Audit interruption", e.message ?: "Unable to inspect every file."))
        }

        if (scanned >= maxFiles) findings.add(Finding("WARN", "Scan limit", "Audit stopped at $maxFiles files for predictable resource use."))
        findings.add(Finding("PASS", "Path traversal guard", "Canonical-path validation is enabled for sandbox operations."))
        findings.add(Finding("PASS", "Offline execution boundary", "Arbitrary shell, process, DEX/JAR loading and external network execution are not exposed."))

        val manager = PluginManager(context)
        manager.reloadBuiltIns()
        findings.add(Finding("PASS", "Plugin permission gate", "${manager.all().size} built-in extensions are governed by local permission state."))
        val extensionPlatform = ExtensionPlatformEngine(context)
        if (extensionPlatform != null) findings.add(Finding("PASS", "Extension platform", "Extension package validation layer is available."))

        return AuditReport(root.path, scanned, bytes, findings, blocked, isLocked())
    }

    fun policyFingerprint(): String {
        val raw = "lockdown=${isLocked()};offline=true;dynamic_code=false;external_network=false"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it.toInt() and 0xff) }.substring(0, 16)
    }
}
