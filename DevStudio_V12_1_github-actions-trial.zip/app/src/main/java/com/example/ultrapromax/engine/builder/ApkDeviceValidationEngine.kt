package com.example.ultrapromax.engine.builder

import java.io.File

/** Real-device validation through local adb only. It never reports success without a real connected device. */
class ApkDeviceValidationEngine {
    data class Result(val connected: Boolean, val installed: Boolean, val launched: Boolean, val output: String)

    fun validate(adb: File, apk: File, packageName: String, activity: String): Result {
        if (!adb.isFile || !apk.isFile) return Result(false, false, false, "ADB or APK not found.")
        return try {
            val devices = run(adb, "devices").output
            val connected = devices.lines().any { it.trim().endsWith("\tdevice") }
            if (!connected) return Result(false, false, false, "No Android device/emulator is connected to local adb.")
            val install = run(adb, "install", "-r", apk.absolutePath)
            if (install.code != 0) return Result(true, false, false, install.output)
            val launch = run(adb, "shell", "am", "start", "-n", "$packageName/$activity")
            Result(true, true, launch.code == 0, install.output + "\n" + launch.output)
        } catch (e: Exception) {
            Result(false, false, false, "ADB validation failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private data class Cmd(val code: Int, val output: String)
    private fun run(exe: File, vararg args: String): Cmd {
        val p = ProcessBuilder(listOf(exe.absolutePath) + args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        return Cmd(p.waitFor(), out)
    }
}
