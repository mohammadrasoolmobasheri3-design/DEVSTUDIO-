package com.example.ultrapromax.engine.buildrun

import com.example.ultrapromax.engine.diagnostics.StudioOutputStore
import java.io.File

/** Build -> diagnose -> safe fix -> rebuild coordinator. */
class BuildFixCoordinator(private val outputStore: StudioOutputStore) {

    data class Result(
        val success: Boolean,
        val attempts: Int,
        val fixesApplied: Int,
        val report: BuildPipelineCoordinator.Report
    )

    fun execute(projectDir: File, variant: BuildPipelineEngine.Variant, maxAttempts: Int = 2, context: android.content.Context? = null): Result {
        var attempts = 0
        var report = BuildPipelineCoordinator(outputStore).execute(projectDir, variant, context)
        attempts++

        if (report.result.success) return Result(true, attempts, 0, report)

        var fixes = 0
        val fixer = BuildAutoFixEngine()
        while (!report.result.success && attempts < maxAttempts) {
            val applied = fixer.apply(projectDir, report.diagnostics)
            if (applied.isEmpty()) {
                outputStore.appendConsole("[AUTO-FIX] No safe deterministic fix available.")
                break
            }
            fixes += applied.size
            for (fix in applied) outputStore.appendConsole("[AUTO-FIX] ${fix.description}")

            report = BuildPipelineCoordinator(outputStore).execute(projectDir, variant, context)
            attempts++
        }

        outputStore.appendConsole("[BUILD-FIX] attempts=$attempts, fixes=$fixes, success=${report.result.success}")
        return Result(report.result.success, attempts, fixes, report)
    }
}
