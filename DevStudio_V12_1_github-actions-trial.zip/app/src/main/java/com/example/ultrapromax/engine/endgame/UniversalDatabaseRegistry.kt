package com.example.ultrapromax.engine.endgame

/** Built-in database profiles plus an adapter contract for additional local database engines. */
object UniversalDatabaseRegistry {
    private val builtIns = listOf(
        db("sqlite", "SQLite", listOf("sqlite3"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA,
            EndgameAdapterContract.Capability.MIGRATION
        )),
        db("postgresql", "PostgreSQL", listOf("psql"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA,
            EndgameAdapterContract.Capability.MIGRATION
        )),
        db("mysql", "MySQL / MariaDB", listOf("mysql"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA,
            EndgameAdapterContract.Capability.MIGRATION
        )),
        db("mongodb", "MongoDB", listOf("mongosh"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA
        )),
        db("redis", "Redis", listOf("redis-cli"), setOf(
            EndgameAdapterContract.Capability.QUERY
        )),
        db("sqlserver", "SQL Server", listOf("sqlcmd"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA,
            EndgameAdapterContract.Capability.MIGRATION
        )),
        db("oracle", "Oracle", listOf("sqlplus"), setOf(
            EndgameAdapterContract.Capability.QUERY,
            EndgameAdapterContract.Capability.SCHEMA
        ))
    )

    private val custom = LinkedHashMap<String, EndgameAdapterContract>()

    @Synchronized
    fun register(contract: EndgameAdapterContract) {
        require(contract.kind == EndgameAdapterContract.Kind.DATABASE)
        custom[contract.id] = contract
    }

    fun all(): List<EndgameAdapterContract> = builtIns + custom.values

    fun find(id: String): EndgameAdapterContract? = all().firstOrNull { it.id == id }

    private fun db(id: String, name: String, commands: List<String>,
                   capabilities: Set<EndgameAdapterContract.Capability>): EndgameAdapterContract {
        return EndgameAdapterContract(id, name, EndgameAdapterContract.Kind.DATABASE,
            commands, emptyList(), capabilities)
    }
}
