package com.example.ultrapromax.engine.appfactory

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Real, offline-first App Factory orchestration. No fake build/runtime/output. */
class AppFactoryProductionEngine(private val context: Context) {
    data class Check(val name: String, val ok: Boolean, val details: String)
    data class Report(val ok: Boolean, val checks: List<Check>)
    data class AndroidConfig(val appName: String, val applicationId: String, val versionCode: Int = 1, val versionName: String = "1.0", val minSdk: Int = 23, val targetSdk: Int = 29, val compileSdk: Int = 29, val permissions: List<String> = emptyList())
    data class BuildOptions(val release: Boolean = false, val validateApk: Boolean = true, val install: Boolean = false, val launch: Boolean = false)
    data class BuildReport(val success: Boolean, val apk: File?, val steps: List<String>)

    fun audit(projectDir: File): Report {
        val c = ArrayList<Check>()
        c.add(projectContract(projectDir)); c.add(buildConfiguration(projectDir)); c.add(dependencyPreflight(projectDir)); c.add(resourcePipeline(projectDir)); c.add(toolchainGate()); c.add(outputPipelineReadiness(projectDir))
        return Report(c.all { it.ok }, c)
    }

    fun projectContract(projectDir: File): Check {
        if (!projectDir.isDirectory) return Check("ANDROID PROJECT", false, "Project directory is MISSING")
        val required = listOf("settings.gradle", "build.gradle", "gradlew", "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties", "app/build.gradle", "app/src/main/AndroidManifest.xml", "app/src/main/java", "app/src/main/res")
        val missing = required.filter { !File(projectDir, it).exists() }
        if (missing.isNotEmpty()) return Check("ANDROID PROJECT", false, "MISSING: ${missing.joinToString(", ")}")
        val sourceCount = File(projectDir, "app/src/main/java").walkTopDown().count { it.isFile && (it.extension == "kt" || it.extension == "java") }
        return if (sourceCount > 0) Check("ANDROID PROJECT", true, "Complete Android project contract; source files=$sourceCount") else Check("ANDROID PROJECT", false, "No Java/Kotlin source found")
    }

    fun applyAndroidConfig(projectDir: File, config: AndroidConfig): Check {
        if (!validApplicationId(config.applicationId)) return Check("BUILD CONFIG", false, "Invalid applicationId")
        if (config.versionCode < 1 || config.minSdk < 1 || config.targetSdk < config.minSdk || config.compileSdk < config.targetSdk) return Check("BUILD CONFIG", false, "Invalid version/SDK configuration")
        val gradle = File(projectDir, "app/build.gradle")
        val manifest = File(projectDir, "app/src/main/AndroidManifest.xml")
        if (!gradle.isFile || !manifest.isFile) return Check("BUILD CONFIG", false, "app/build.gradle or Manifest is MISSING")
        var g = gradle.readText()
        g = replace(g, "applicationId", "applicationId '${escape(config.applicationId)}'")
        g = replace(g, "versionCode", "versionCode ${config.versionCode}")
        g = replace(g, "versionName", "versionName '${escape(config.versionName)}'")
        g = replace(g, "minSdkVersion", "minSdkVersion ${config.minSdk}")
        g = replace(g, "targetSdkVersion", "targetSdkVersion ${config.targetSdk}")
        g = replace(g, "compileSdkVersion", "compileSdkVersion ${config.compileSdk}")
        gradle.writeText(g)
        var m = manifest.readText().replace("android:label=\"New Project\"", "android:label=\"${xml(config.appName)}\"")
        for (p in config.permissions) if (p.isNotBlank() && !m.contains("android.permission.$p")) m = m.replace("<application", "<uses-permission android:name=\"android.permission.$p\" />\n    <application")
        manifest.writeText(m)
        return Check("BUILD CONFIG", true, "Name, applicationId, versions, SDK levels and permissions configured")
    }

    fun buildConfiguration(projectDir: File): Check {
        val g = File(projectDir, "app/build.gradle")
        if (!g.isFile) return Check("BUILD CONFIG", false, "app/build.gradle is MISSING")
        val text = g.readText()
        val keys = listOf("applicationId", "versionCode", "versionName", "minSdkVersion", "targetSdkVersion", "compileSdkVersion")
        val missing = keys.filter { !text.contains(it) }
        return if (missing.isEmpty()) Check("BUILD CONFIG", true, "Required Android build configuration is present") else Check("BUILD CONFIG", false, "MISSING: ${missing.joinToString(", ")}")
    }

    fun dependencyPreflight(projectDir: File): Check {
        val wrapper = File(projectDir, "gradlew")
        if (!File(projectDir, "settings.gradle").isFile || !File(projectDir, "build.gradle").isFile || !File(projectDir, "app/build.gradle").isFile) return Check("OFFLINE DEPENDENCIES", false, "Gradle project files are incomplete")
        if (!wrapper.isFile) return Check("OFFLINE DEPENDENCIES", false, "Gradle wrapper is MISSING")
        wrapper.setExecutable(true, false)
        val r = command(listOf("sh", wrapper.absolutePath, "dependencies", "--offline", "--no-daemon"), projectDir, 180)
        return if (r.code == 0) Check("OFFLINE DEPENDENCIES", true, "Dependency graph resolved with Gradle --offline") else Check("OFFLINE DEPENDENCIES", false, "Resolution failed: ${tail(r.out)}")
    }

    fun resourcePipeline(projectDir: File): Check {
        val res = File(projectDir, "app/src/main/res")
        val manifest = File(projectDir, "app/src/main/AndroidManifest.xml")
        if (!res.isDirectory || !manifest.isFile) return Check("RESOURCES", false, "res/ or Manifest is MISSING")
        val bad = ArrayList<String>()
        val valid = Pattern.compile("^[a-z0-9_]+$")
        res.walkTopDown().filter { it.isFile }.forEach { f -> if (f.extension != "xml" && !valid.matcher(f.nameWithoutExtension).matches()) bad.add(f.relativeTo(res).path) }
        val assets = File(projectDir, "app/src/main/assets")
        val count = if (assets.isDirectory) assets.walkTopDown().count { it.isFile } else 0
        return if (bad.isEmpty()) Check("RESOURCES", true, "Resource pipeline valid; assets=$count") else Check("RESOURCES", false, "Invalid resource names: ${bad.take(8).joinToString(", ")}")
    }

    fun exportProject(projectDir: File, outputZip: File): Check {
        if (!projectDir.isDirectory) return Check("PROJECT EXPORT", false, "Project directory is MISSING")
        return try {
            outputZip.parentFile?.mkdirs()
            ZipOutputStream(outputZip.outputStream()).use { zos ->
                projectDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entry = file.relativeTo(projectDir).path.replace(File.separatorChar, '/')
                    if (!entry.startsWith(".gradle/") && !entry.startsWith("app/build/")) {
                        zos.putNextEntry(ZipEntry(entry)); file.inputStream().use { it.copyTo(zos) }; zos.closeEntry()
                    }
                }
            }
            if (outputZip.isFile && outputZip.length() > 0L) Check("PROJECT EXPORT", true, "Clean project ZIP exported: ${outputZip.absolutePath}")
            else Check("PROJECT EXPORT", false, "ZIP output is MISSING")
        } catch (e: Exception) { Check("PROJECT EXPORT", false, e.message ?: "Export failed") }
    }

    fun build(projectDir: File, options: BuildOptions = BuildOptions()): BuildReport {
        val steps = ArrayList<String>(); val a = audit(projectDir)
        if (!a.ok) return BuildReport(false, null, a.checks.filter { !it.ok }.map { "BLOCKED • ${it.name}: ${it.details}" })
        val b = if (options.release) BuildEngine().buildRelease(projectDir) else BuildEngine().buildDebug(projectDir)
        steps.add("BUILD • ${if (b.success) "PASS" else "FAIL"}"); steps.add(b.output.takeLast(3000))
        val apk = b.apkFile ?: return BuildReport(false, null, steps + "APK • MISSING")
        if (!apk.isFile) return BuildReport(false, apk, steps + "APK • MISSING")
        if (options.validateApk) { val v = ApkValidationEngine().validate(apk); steps.add("VALIDATE • ${if (v.valid) "PASS" else "FAIL"} ${v.errors.joinToString("; ")}"); if (!v.valid) return BuildReport(false, apk, steps) }
        if (options.install) { val i = install(apk); steps.add("INSTALL • ${if (i.first) "PASS" else "FAIL"} ${i.second}"); if (!i.first) return BuildReport(false, apk, steps) }
        if (options.install && options.launch) { val id = applicationId(projectDir) ?: return BuildReport(false, apk, steps + "RUN • applicationId MISSING"); val r = launch(id); steps.add("RUN • ${if (r.first) "PASS" else "FAIL"} ${r.second}"); if (!r.first) return BuildReport(false, apk, steps) }
        return BuildReport(true, apk, steps + "OUTPUT • REAL APK READY")
    }

    private fun outputPipelineReadiness(projectDir: File) = Check("OUTPUT PIPELINE", true, "APK output path: ${File(projectDir, "app/build/outputs/apk").path}")
    private fun toolchainGate(): Check { val r = AndroidToolchainDiscoveryEngine(context).discover(); return Check("ANDROID TOOLCHAIN", r.ready, r.details) }
    private fun replace(text: String, key: String, value: String): String { val p = Pattern.compile("(?m)^\\s*${Pattern.quote(key)}\\s+.*$"); val m = p.matcher(text); return if (m.find()) m.replaceFirst(value) else text }
    private fun applicationId(d: File): String? { val m = Pattern.compile("applicationId\\s+['\"]([^'\"]+)['\"]").matcher(File(d, "app/build.gradle").readText()); return if (m.find()) m.group(1) else null }
    private fun install(apk: File): Pair<Boolean, String> { val adb = AndroidToolchainDiscoveryEngine(context).discover().adb ?: return Pair(false, "adb is MISSING"); val r = command(listOf(adb.absolutePath, "install", "-r", apk.absolutePath), null, 120); return Pair(r.code == 0, tail(r.out)) }
    private fun launch(pkg: String): Pair<Boolean, String> { val adb = AndroidToolchainDiscoveryEngine(context).discover().adb ?: return Pair(false, "adb is MISSING"); val r = command(listOf(adb.absolutePath, "shell", "monkey", "-p", pkg, "1"), null, 30); return Pair(r.code == 0, tail(r.out)) }
    private data class Cmd(val code: Int, val out: String)
    private fun command(cmd: List<String>, dir: File?, timeout: Long): Cmd { return try { val pb = ProcessBuilder(cmd).redirectErrorStream(true); if (dir != null) pb.directory(dir); val p = pb.start(); val sb = StringBuilder(); val t = Thread(Runnable { try { p.inputStream.bufferedReader().use { r -> var x = r.readLine(); while (x != null) { sb.append(x).append('\n'); x = r.readLine() } } } catch (_: Throwable) {} }); t.start(); if (!p.waitFor(timeout, TimeUnit.SECONDS)) { p.destroy(); return Cmd(-2, sb.toString() + "TIMEOUT") }; t.join(3000); Cmd(p.exitValue(), sb.toString()) } catch (e: Exception) { Cmd(-1, e.message ?: e.javaClass.simpleName) } }
    private fun validApplicationId(id: String) = Pattern.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+", id)
    private fun escape(s: String) = s.replace("\\", "\\\\").replace("'", "\\'")
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun tail(s: String) = s.trim().takeLast(1000)
}
