package com.example.ultrapromax.engine.security

import com.example.ultrapromax.engine.backup.BackupEngine
import com.example.ultrapromax.engine.run.LanguageRuntimeRegistry
import java.io.File

/** Offline diagnostics for project integrity, runtime readiness and safe repair hints. */
class DiagnosticEngine(private val root: File) {
    data class Report(val text: String, val issues: Int, val warnings: Int)

    fun scanProject(projectDir: File?, projectName: String?): Report {
        val lines = ArrayList<String>()
        var issues = 0
        var warnings = 0
        lines.add("DEVSTUDIO v24 • OFFLINE DIAGNOSTICS")
        lines.add("")
        if (projectDir == null) {
            lines.add("[INFO] No project selected.")
        } else {
            if (!SecurityEngine.isInsideSandbox(root, projectDir)) {
                lines.add("[ERROR] Project path is outside DEVSTUDIO sandbox")
                issues++
            } else if (!projectDir.exists()) {
                lines.add("[ERROR] Project directory is missing")
                issues++
            } else {
                val files = projectDir.walkTopDown().filter { it.isFile }.toList()
                val bytes = files.fold(0L) { total, file -> total + file.length() }
                lines.add("[OK] Project sandbox: ${projectDir.canonicalPath}")
                lines.add("[OK] Files: ${files.size} • Size: ${formatBytes(bytes)}")
                val suspicious = files.filter { it.name.contains("..") || it.path.contains("${File.separator}..${File.separator}") }
                if (suspicious.isNotEmpty()) {
                    lines.add("[WARN] Suspicious paths detected: ${suspicious.size}")
                    warnings++
                }
                val empty = files.filter { it.length() == 0L }
                if (empty.isNotEmpty()) {
                    lines.add("[WARN] Empty files: ${empty.size} (may be intentional)")
                    warnings++
                }
            }
        }
        lines.add("")
        lines.add("RUNTIME HEALTH")
        val registry = LanguageRuntimeRegistry(File(root, "runtimes"))
        registry.all().forEach { p ->
            val r = registry.readiness(p)
            if (p.id == "html" || p.id == "css") lines.add("[BUILT-IN] ${p.displayName} • WebView")
            else if (r.ready) lines.add("[READY] ${p.displayName}")
            else lines.add("[NOT READY] ${p.displayName} • ${r.missing.joinToString()}")
        }
        lines.add("")
        lines.add("BACKUP / SELF-HEAL")
        if (projectDir != null && projectName != null) {
            val backups = BackupEngineProxy(root).list(projectName)
            if (backups.isEmpty()) {
                lines.add("[WARN] No backup snapshot found for this project")
                warnings++
            } else {
                lines.add("[OK] Backup snapshots: ${backups.size}")
                lines.add("[OK] Self-healing can use the newest snapshot")
            }
        } else lines.add("[INFO] Select a project to inspect backups")
        lines.add("")
        lines.add("RESULT: ${if (issues == 0) "HEALTHY" else "ACTION REQUIRED"} • $issues errors • $warnings warnings")
        return Report(lines.joinToString("\n"), issues, warnings)
    }

    private fun formatBytes(value: Long): String = when {
        value < 1024L -> "$value B"
        value < 1024L * 1024L -> "${value / 1024L} KB"
        else -> "${value / (1024L * 1024L)} MB"
    }

    private class BackupEngineProxy(private val root: File) {
        fun list(name: String): List<File> = File(root, "backups").listFiles()
            ?.filter { it.isFile && it.extension == "zip" && it.name.startsWith(name) && !it.name.contains("_minified_") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
}
