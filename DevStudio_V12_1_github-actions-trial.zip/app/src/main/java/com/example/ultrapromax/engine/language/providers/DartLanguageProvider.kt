package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class DartLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("dart", "Dart", listOf("dart"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("dart").parse(source)
}
