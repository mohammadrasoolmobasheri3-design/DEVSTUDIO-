package com.example.ultrapromax.engine.run

import java.io.File
import java.util.concurrent.TimeUnit

/** Offline C/C++ compiler runner. Expects an Android-compatible clang/clang++ pack. */
class NativeCppRuntimeEngine(private val runtimeDir: File) {
    data class Result(val success: Boolean, val output: String)

    fun run(sources: List<Pair<String, String>>, language: String, workDir: File): Result {
        if (sources.isEmpty()) return Result(false, "No C/C++ source files found.")
        val compilerName = if (language == "cpp") "clang++" else "clang"
        val compiler = File(runtimeDir, "bin/$compilerName")
        if (!compiler.isFile || !compiler.canExecute()) {
            return Result(false, "${language.toUpperCase()} runtime pack is not installed: expected bin/$compilerName")
        }
        workDir.mkdirs()
        val sourceFiles = sources.map { (name, text) ->
            val file = File(workDir, safeName(name, language)); file.parentFile?.mkdirs(); file.writeText(text); file
        }
        val binary = File(workDir, "devstudio_program")
        val command = ArrayList<String>()
        command.add(compiler.absolutePath)
        command.addAll(sourceFiles.map { it.absolutePath })
        command.add("-o"); command.add(binary.absolutePath)
        val compile = exec(command, workDir)
        if (compile.exit != 0) return Result(false, "C/C++ COMPILE ERROR\n${compile.output}")
        val run = exec(listOf(binary.absolutePath), workDir)
        return Result(run.exit == 0, "${compile.output}\n${run.output}".trim())
    }

    private fun safeName(name: String, language: String): String {
        val ext = if (language == "cpp") ".cpp" else ".c"
        return name.replace(Regex("[^A-Za-z0-9_.-]"), "_").let { if (it.endsWith(ext)) it else "Main$ext" }
    }
    private data class Exec(val exit: Int, val output: String)
    private fun exec(command: List<String>, dir: File): Exec = try {
        val p = ProcessBuilder(command).directory(dir).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().use { it.readText() }
        if (!p.waitFor(60, TimeUnit.SECONDS)) { p.destroy(); Exec(124, text + "\nProcess timed out after 60 seconds.") }
        else Exec(p.exitValue(), text)
    } catch (e: Exception) { Exec(127, "Unable to start compiler/runtime: ${e.message ?: e.javaClass.simpleName}") }
}
