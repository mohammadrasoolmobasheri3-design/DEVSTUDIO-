package com.example.ultrapromax.engine.editor

import android.widget.EditText

/**
 * ENDGAME STAGE 2 - Universal Editor services.
 * Purely local text operations; no network and no artificial source-size limits.
 */
object UniversalEditorEngine {

    fun format(source: String, language: String): String {
        if (source.isEmpty()) return source
        val lines = source.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = StringBuilder()
        var depth = 0
        val braceLanguage = language in setOf("kt", "kts", "java", "js", "ts", "c", "cpp", "csharp", "go", "rust", "swift", "dart", "php")
        for (index in lines.indices) {
            var line = lines[index].trimEnd()
            val trimmed = line.trimStart()
            if (braceLanguage && trimmed.startsWith("}") && depth > 0) depth--
            val indent = if (braceLanguage) "    ".repeat(depth.coerceAtLeast(0)) else ""
            if (trimmed.isNotEmpty()) line = indent + trimmed else line = ""
            out.append(line)
            if (index < lines.lastIndex) out.append('\n')
            if (braceLanguage) {
                var opens = 0
                var closes = 0
                var inDouble = false
                var inSingle = false
                var escaped = false
                for (c in trimmed) {
                    if (escaped) { escaped = false; continue }
                    if (c == '\\') { escaped = true; continue }
                    if (c == '"' && !inSingle) inDouble = !inDouble
                    if (c == '\'' && !inDouble) inSingle = !inSingle
                    if (!inDouble && !inSingle) {
                        if (c == '{') opens++
                        if (c == '}') closes++
                    }
                }
                depth += opens - closes
                if (depth < 0) depth = 0
            }
        }
        return out.toString()
    }

    fun selectCurrentWord(editor: EditText) {
        val text = editor.text.toString()
        if (text.isEmpty()) return
        val cursor = editor.selectionStart.coerceIn(0, text.length)
        var start = cursor
        var end = cursor
        while (start > 0 && isWordChar(text[start - 1])) start--
        while (end < text.length && isWordChar(text[end])) end++
        if (start != end) editor.setSelection(start, end)
    }

    fun matchingBracketPosition(text: String, cursor: Int): Int? {
        if (text.isEmpty()) return null
        val p = cursor.coerceIn(0, text.length)
        val candidates = mutableListOf<Int>()
        if (p < text.length && isBracket(text[p])) candidates.add(p)
        if (p > 0 && isBracket(text[p - 1])) candidates.add(p - 1)
        for (index in candidates) {
            val target = pair(text[index])
            val forward = text[index] == '(' || text[index] == '[' || text[index] == '{'
            var depth = 0
            if (forward) {
                var i = index
                while (i < text.length) {
                    if (text[i] == text[index]) depth++
                    if (text[i] == target) {
                        depth--
                        if (depth == 0) return i
                    }
                    i++
                }
            } else {
                var i = index
                while (i >= 0) {
                    if (text[i] == text[index]) depth++
                    if (text[i] == target) {
                        depth--
                        if (depth == 0) return i
                    }
                    i--
                }
            }
        }
        return null
    }

    private fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || c == '_' || c == '$'
    private fun isBracket(c: Char): Boolean = c == '(' || c == ')' || c == '[' || c == ']' || c == '{' || c == '}'
    private fun pair(c: Char): Char = when (c) {
        '(' -> ')'; ')' -> '('
        '[' -> ']'; ']' -> '['
        '{' -> '}'; '}' -> '{'
        else -> c
    }
}
