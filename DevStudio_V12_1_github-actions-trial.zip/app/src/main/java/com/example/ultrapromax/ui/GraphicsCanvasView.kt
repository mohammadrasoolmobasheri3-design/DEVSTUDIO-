package com.example.ultrapromax.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.sqrt

class GraphicsCanvasView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    var tool: String = "PEN"
    var strokeColor: Int = Color.WHITE
    var strokeWidth: Float = 8f
    var fillShapes: Boolean = false
    var onShapeCommitted: ((String) -> Unit)? = null
    var onEditStarted: (() -> Unit)? = null

    private var bitmap: Bitmap? = null
    private var canvas: Canvas? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var preview: Bitmap? = null

    fun configure() { post { ensureBitmap() } }

    private fun ensureBitmap() {
        if (width <= 0 || height <= 0) return
        if (bitmap == null || bitmap!!.width != width || bitmap!!.height != height) {
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            canvas = Canvas(bitmap!!)
            canvas!!.drawColor(Color.rgb(18, 20, 28))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w, h, oldw, oldh); ensureBitmap() }
    override fun onDraw(c: Canvas) { super.onDraw(c); ensureBitmap(); bitmap?.let { c.drawBitmap(it, 0f, 0f, null) }; preview?.let { c.drawBitmap(it, 0f, 0f, null) } }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        ensureBitmap()
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { onEditStarted?.invoke(); startX=event.x; startY=event.y; lastX=startX; lastY=startY; return true }
            MotionEvent.ACTION_MOVE -> {
                if (tool == "PEN" || tool == "ERASER") {
                    configurePaint()
                    canvas!!.drawLine(lastX,lastY,event.x,event.y,paint)
                    lastX=event.x; lastY=event.y; invalidate()
                } else {
                    preview=exportBitmap(); val pc=Canvas(preview!!); pc.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR); drawShape(pc,startX,startY,event.x,event.y,false); invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (tool != "PEN" && tool != "ERASER" && tool != "TEXT") drawShape(canvas!!,startX,startY,event.x,event.y,true)
                preview=null; invalidate(); return true
            }
        }
        return true
    }

    private fun configurePaint() {
        paint.strokeWidth=strokeWidth; paint.strokeCap=Paint.Cap.ROUND; paint.strokeJoin=Paint.Join.ROUND
        if (tool == "ERASER") { paint.color=Color.TRANSPARENT; paint.style=Paint.Style.STROKE; paint.xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        else { paint.color=strokeColor; paint.style=Paint.Style.STROKE; paint.xfermode=null }
    }

    private fun drawShape(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, record: Boolean) {
        paint.xfermode=null; paint.color=strokeColor; paint.strokeWidth=strokeWidth
        paint.style=if (fillShapes && (tool=="RECT" || tool=="CIRCLE")) Paint.Style.FILL else Paint.Style.STROKE
        when(tool) {
            "LINE" -> { c.drawLine(x1,y1,x2,y2,paint); if(record) onShapeCommitted?.invoke("<line x=\"$x1\" y1=\"$y1\" x2=\"$x2\" y2=\"$y2\" stroke=\"${hex(strokeColor)}\" stroke-width=\"$strokeWidth\" stroke-linecap=\"round\"/>") }
            "RECT" -> { val l=min(x1,x2); val t=min(y1,y2); val r=max(x1,x2); val b=max(y1,y2); c.drawRect(RectF(l,t,r,b),paint); if(record) onShapeCommitted?.invoke("<rect x=\"$l\" y=\"$t\" width=\"${r-l}\" height=\"${b-t}\" ${if(fillShapes) "fill=\"${hex(strokeColor)}\"" else "fill=\"none\" stroke=\"${hex(strokeColor)}\" stroke-width=\"$strokeWidth\""}/>") }
            "CIRCLE" -> { val radius=sqrt(((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)).toDouble()).toFloat(); c.drawCircle(x1,y1,radius,paint); if(record) onShapeCommitted?.invoke("<circle cx=\"$x1\" cy=\"$y1\" r=\"$radius\" ${if(fillShapes) "fill=\"${hex(strokeColor)}\"" else "fill=\"none\" stroke=\"${hex(strokeColor)}\" stroke-width=\"$strokeWidth\""}/>") }
        }
        paint.style=Paint.Style.STROKE
    }

    private fun min(a:Float,b:Float)=if(a<b)a else b
    private fun max(a:Float,b:Float)=if(a>b)a else b
    private fun hex(c:Int)=String.format("#%06X",0xFFFFFF and c)

    fun clear() { ensureBitmap(); canvas!!.drawColor(Color.rgb(18,20,28)); invalidate() }
    fun exportBitmap(): Bitmap { ensureBitmap(); return bitmap!!.copy(Bitmap.Config.ARGB_8888,true) }
    fun setBitmap(bm:Bitmap) { bitmap=bm.copy(Bitmap.Config.ARGB_8888,true); canvas=Canvas(bitmap!!); invalidate() }
    fun addText(text:String,color:Int,size:Float) { paint.xfermode=null; paint.style=Paint.Style.FILL; paint.color=color; paint.textSize=size; canvas!!.drawText(text,40f,80f,paint); paint.style=Paint.Style.STROKE; invalidate() }
    fun addImage(bm:Bitmap) { val scale=minOf(width.toFloat()/bm.width,height.toFloat()/bm.height); val w=bm.width*scale; val h=bm.height*scale; val left=(width-w)/2f; val top=(height-h)/2f; canvas!!.drawBitmap(bm,null,RectF(left,top,left+w,top+h),null); invalidate() }
}
