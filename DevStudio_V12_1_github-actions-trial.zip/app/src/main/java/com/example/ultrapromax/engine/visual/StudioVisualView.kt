package com.example.ultrapromax.engine.visual
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
class StudioVisualView(context:Context):View(context){
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private val rect=RectF()
 var glow:Int=0xFF9B5CFF.toInt(); var glass:Int=0x66141A2E; var depth:Float=18f
 override fun onDraw(canvas:Canvas){super.onDraw(canvas);rect.set(8f,8f,width-8f,height-8f);setLayerType(View.LAYER_TYPE_SOFTWARE,null);paint.setShadowLayer(depth,0f,depth/2f,glow);paint.color=glass;canvas.drawRoundRect(rect,24f,24f,paint);paint.clearShadowLayer();paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=glow;canvas.drawRoundRect(rect,24f,24f,paint);paint.style=Paint.Style.FILL}
}
