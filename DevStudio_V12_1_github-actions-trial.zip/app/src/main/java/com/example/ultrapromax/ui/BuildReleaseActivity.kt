package com.example.ultrapromax.ui

import android.content.Intent
import android.provider.DocumentsContract
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.builder.ApkInstaller
import com.example.ultrapromax.engine.builder.ApkRuntimeController
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.builder.LocalToolchainResolver
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.GooglePlatform29Downloader
import com.example.ultrapromax.engine.buildrun.BuildPipelineCoordinator
import com.example.ultrapromax.engine.buildrun.BuildFixCoordinator
import com.example.ultrapromax.engine.buildrun.BuildPipelineEngine
import com.example.ultrapromax.engine.diagnostics.StudioOutputStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BuildReleaseActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var status: TextView
    private lateinit var apkInfo: TextView
    private lateinit var console: TextView
    private lateinit var history: TextView
    private var lastApk: File? = null
    private var building = false
    private lateinit var outputStore: StudioOutputStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_build_release)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        outputStore = StudioOutputStore(this)
        status = findViewById(R.id.buildStatus)
        apkInfo = findViewById(R.id.apkInfo)
        console = findViewById(R.id.buildConsole)
        history = findViewById(R.id.buildHistory)
        findViewById<TextView>(R.id.buildSubtitle).text = "Release Manager • ${project.template}"
        findViewById<TextView>(R.id.projectInfo).text = "${project.name}\n${project.template}\n${project.folderPath}"
        findViewById<View>(R.id.buildBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.debugButton).setOnClickListener { build(false) }
        findViewById<Button>(R.id.releaseButton).setOnClickListener { build(true) }
        findViewById<Button>(R.id.rebuildButton).setOnClickListener { build(lastApk?.path?.contains("/release/") == true) }
        findViewById<Button>(R.id.autoFixButton).setOnClickListener { autoFixAndRebuild() }
        findViewById<Button>(R.id.cleanButton).setOnClickListener { cleanBuild() }
        findViewById<Button>(R.id.installButton).setOnClickListener { installLast() }
        findViewById<Button>(R.id.inspectButton).setOnClickListener { inspectLast() }
        findViewById<Button>(R.id.runApkButton).setOnClickListener { runLastInstalled() }
        findViewById<Button>(R.id.openFolderButton).setOnClickListener { showReleaseFolder() }
        setupGooglePlatform29Download()
        findViewById<Button>(R.id.importToolchainButton).setOnClickListener { chooseToolchainFolder() }
        findViewById<Button>(R.id.outputButton).setOnClickListener { openStudioOutput() }
        findViewById<Button>(R.id.analyzeButton).setOnClickListener { analyzeLastBuild() }
        loadHistory()
    }

    private fun build(release: Boolean) {
        if (building) { Toast.makeText(this, "A build is already running.", Toast.LENGTH_SHORT).show(); return }
        val root = File(project.folderPath)
        building = true
        setButtons(false)
        status.text = if (release) "BUILDING RELEASE" else "BUILDING DEBUG"
        status.setTextColor(Color.parseColor("#FFC857"))
        console.text = "DEVSTUDIO BUILD\n> ${if (release) "assembleRelease" else "assembleDebug"}\n\nStarting Gradle…\n"
        Thread {
            val variant = if (release) BuildPipelineEngine.Variant.RELEASE else BuildPipelineEngine.Variant.DEBUG
            val report = BuildPipelineCoordinator(outputStore).execute(root, variant, this@BuildReleaseActivity)
            val result = report.result
            runOnUiThread {
                building = false
                setButtons(true)
                console.text = result.output
                if (report.verified && result.apkFile != null) {
                    lastApk = archiveApk(result.apkFile, release)
                    status.text = "BUILD + VERIFY SUCCESS"
                    status.setTextColor(Color.parseColor("#4CD964"))
                    apkInfo.text = "${lastApk?.name}\n${formatBytes(lastApk?.length() ?: 0L)}\n${lastApk?.absolutePath ?: result.apkFile.absolutePath}"
                    appendHistory(if (release) "RELEASE" else "DEBUG", lastApk!!)
                    Toast.makeText(this, "APK built and verified.", Toast.LENGTH_LONG).show()
                } else {
                    status.text = "BUILD FAILED"
                    status.setTextColor(Color.parseColor("#FF5B6E"))
                    apkInfo.text = if (result.apkFile != null) "Partial APK: ${result.apkFile.absolutePath}" else "No APK generated."
                    if (report.diagnostics.isNotEmpty()) {
                        apkInfo.text = apkInfo.text.toString() + "\nProblems: ${report.diagnostics.size}"
                    }
                }
            }
        }.start()
    }


    private fun autoFixAndRebuild() {
        if (building) {
            Toast.makeText(this, "A build is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        val root = File(project.folderPath)
        val release = lastApk?.path?.contains("/release/") == true
        building = true
        setButtons(false)
        findViewById<Button>(R.id.autoFixButton).isEnabled = false
        status.text = "DIAGNOSE → AUTO-FIX → REBUILD"
        status.setTextColor(Color.parseColor("#FFC857"))
        console.text = """DEVSTUDIO BUILD FIX
> Diagnose current project
> Apply only safe deterministic fixes
> Rebuild automatically

"""
        Thread {
            val variant = if (release) BuildPipelineEngine.Variant.RELEASE else BuildPipelineEngine.Variant.DEBUG
            val result = BuildFixCoordinator(outputStore).execute(root, variant, 2, this@BuildReleaseActivity)
            runOnUiThread {
                building = false
                setButtons(true)
                findViewById<Button>(R.id.autoFixButton).isEnabled = true
                console.text = result.report.result.output
                if (result.success && result.report.result.apkFile != null && result.report.verified) {
                    lastApk = archiveApk(result.report.result.apkFile, release)
                    status.text = "AUTO-FIX + REBUILD SUCCESS"
                    status.setTextColor(Color.parseColor("#4CD964"))
                    apkInfo.text = "${lastApk?.name}\n${formatBytes(lastApk?.length() ?: 0L)}\nFixes applied: ${result.fixesApplied}\nAttempts: ${result.attempts}"
                    appendHistory(if (release) "RELEASE-AUTOFIX" else "DEBUG-AUTOFIX", lastApk!!)
                    Toast.makeText(this, "Build fixed and verified.", Toast.LENGTH_LONG).show()
                } else {
                    status.text = "AUTO-FIX STOPPED"
                    status.setTextColor(Color.parseColor("#FF5B6E"))
                    apkInfo.text = "No verified APK.\nFixes applied: ${result.fixesApplied}\nAttempts: ${result.attempts}\nProblems: ${result.report.diagnostics.size}"
                    Toast.makeText(this, "No safe fix completed the build.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun setupGooglePlatform29Download() {
        val statusView = findViewById<TextView>(R.id.toolchainStatus)
        val downloadButton = findViewById<Button>(R.id.downloadPlatform29Button)
        val downloader = GooglePlatform29Downloader(this)

        fun refreshToolchainStatus() {
            val result = LocalToolchainResolver(this).resolve()
            val platformReady = result.sdk?.let { File(it, "platforms/android-29/android.jar").isFile } == true
            statusView.text = if (result.ready) "TOOLCHAIN READY\n${result.details}" else "TOOLCHAIN INCOMPLETE\n${result.details}"
            statusView.setTextColor(Color.parseColor(if (result.ready) "#4CD964" else "#FFC857"))
            downloadButton.text = if (platformReady) "Android SDK Platform 29 Detected" else "Download Android SDK Platform 29"
            downloadButton.isEnabled = !platformReady
        }

        downloadButton.setOnClickListener {
            if (building) {
                Toast.makeText(this, "Wait for the current build operation to finish.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            downloadButton.isEnabled = false
            statusView.text = "TOOLCHAIN: downloading…"
            statusView.setTextColor(Color.parseColor("#FFC857"))
            console.text = "DEVSTUDIO TOOLCHAIN\n> Android SDK Platform 29\n" +
                "> Tries Google first, then Tsinghua/Aliyun mirrors of the same repository\n" +
                "> if Google is unreachable (its checksum is verified either way).\n" +
                "> This is the only online operation in this installer.\n\nStarting download…"

            downloader.downloadAndInstall(object : GooglePlatform29Downloader.Listener {
                override fun onProgress(downloaded: Long, total: Long) {
                    runOnUiThread {
                        val percent = if (total > 0L) (downloaded * 100L / total).toInt() else 0
                        statusView.text = "TOOLCHAIN: downloading Platform 29… $percent%"
                        console.text = "DEVSTUDIO TOOLCHAIN\n> Android SDK Platform 29\n> Progress: $percent%\n> ${formatBytes(downloaded)} / ${formatBytes(total)}"
                    }
                }

                override fun onFinished(result: GooglePlatform29Downloader.Result) {
                    runOnUiThread {
                        console.text = "DEVSTUDIO TOOLCHAIN\n> Android SDK Platform 29\n\n${result.message}"
                        if (result.success) {
                            Toast.makeText(this@BuildReleaseActivity, "Platform 29 installed. Build is still offline.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@BuildReleaseActivity, result.message, Toast.LENGTH_LONG).show()
                        }
                        refreshToolchainStatus()
                    }
                }
            })
        }

        refreshToolchainStatus()
    }

    private fun chooseToolchainFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, REQUEST_IMPORT_TOOLCHAIN)
    }

    @Deprecated("Deprecated in Android API; retained for minSdk 23 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_IMPORT_TOOLCHAIN || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {}
        status.text = "IMPORTING TOOLCHAIN"
        console.text = "Copying selected toolchain folder into app-private storage…"
        Thread {
            val destination = File(filesDir, "internal-toolchain")
            val result = try {
                if (destination.exists()) destination.deleteRecursively()
                destination.mkdirs()
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                val rootUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
                copyTreeDocument(treeUri, rootUri, destination)
                makeToolchainExecutables(destination)
                "Toolchain folder copied to ${destination.absolutePath}. Rechecking local tools…"
            } catch (e: Exception) {
                "Toolchain import failed: ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread {
                console.text = result
                status.text = "TOOLCHAIN CHECK"
                setupGooglePlatform29Download()
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun copyTreeDocument(treeUri: Uri, documentUri: Uri, target: File) {
        val mime = queryDocumentValue(treeUri, documentUri, DocumentsContract.Document.COLUMN_MIME_TYPE)
        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
            if (!target.exists() && !target.mkdirs()) throw IllegalStateException("Cannot create ${target.path}")
            val documentId = DocumentsContract.getDocumentId(documentUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
            val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE)
            contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getString(0)
                    val name = cursor.getString(1) ?: continue
                    val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                    copyTreeDocument(treeUri, childUri, File(target, name))
                }
            }
        } else {
            target.parentFile?.mkdirs()
            contentResolver.openInputStream(documentUri).use { input ->
                if (input == null) throw IllegalStateException("Cannot read ${target.name}")
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
        }
    }

    private fun queryDocumentValue(treeUri: Uri, documentUri: Uri, column: String): String? {
        contentResolver.query(documentUri, arrayOf(column), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private fun makeToolchainExecutables(root: File) {
        val executableNames = setOf("java", "javac", "gradle", "aapt", "aapt2", "d8", "zipalign", "apksigner", "aidl", "adb")
        root.walkTopDown().filter { it.isFile && it.name in executableNames }.forEach {
            try { it.setExecutable(true, false) } catch (_: SecurityException) {}
        }
    }

    private fun openStudioOutput() {
        startActivity(Intent(this, StudioDiagnosticsActivity::class.java))
    }

    private fun analyzeLastBuild() {
        val problems = outputStore.problems()
        if (problems.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Build Analysis").setMessage("No stored build problems. Run a build to generate diagnostics.").setPositiveButton("OK", null).show()
            return
        }
        val text = problems.take(30).joinToString("\n\n") {
            "${it.severity} • ${it.filePath.substringAfterLast(File.separator)}:${it.line}:${it.column}\n${it.message}"
        }
        AlertDialog.Builder(this).setTitle("Build Problems (${problems.size})").setMessage(text).setPositiveButton("Open Output") { _, _ -> openStudioOutput() }.setNegativeButton("OK", null).show()
    }

    private fun archiveApk(apk: File, release: Boolean): File {
        val dir = File(project.folderPath, "devstudio/releases")
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val prefix = if (release) "release" else "debug"
        val target = File(dir, "${project.name}_${prefix}_${stamp}.apk")
        apk.copyTo(target, overwrite = true)
        return target
    }

    private fun cleanBuild() {
        val buildDir = File(project.folderPath, "build")
        if (buildDir.exists()) buildDir.deleteRecursively()
        appendConsoleLine("Cleaned project build directory.")
        Toast.makeText(this, "Build directory cleaned.", Toast.LENGTH_SHORT).show()
    }

    private fun installLast() {
        val apk = lastApk
        if (apk == null || !apk.exists()) { Toast.makeText(this, "Build an APK first.", Toast.LENGTH_SHORT).show(); return }
        try { ApkInstaller.install(this, apk) } catch (e: Exception) { Toast.makeText(this, "Installer unavailable: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun inspectLast() {
        val apk = lastApk
        if (apk == null || !apk.exists()) { Toast.makeText(this, "Build an APK first.", Toast.LENGTH_SHORT).show(); return }
        val i = ApkRuntimeController.inspect(this, apk)
        val text = "Valid: ${i.valid}\nPackage: ${i.packageName ?: "-"}\nVersion: ${i.versionName ?: "-"} (${i.versionCode})\nInstalled: ${i.installed}\nLaunchable: ${i.launchable}\n\n${i.message}"
        AlertDialog.Builder(this).setTitle("APK Verification").setMessage(text).setPositiveButton("OK", null).show()
    }

    private fun runLastInstalled() {
        val apk = lastApk
        if (apk == null || !apk.exists()) { Toast.makeText(this, "Build an APK first.", Toast.LENGTH_SHORT).show(); return }
        val i = ApkRuntimeController.inspect(this, apk)
        val pkg = i.packageName
        if (!i.valid || pkg == null) { Toast.makeText(this, "APK is not valid.", Toast.LENGTH_LONG).show(); return }
        if (!i.installed) {
            Toast.makeText(this, "APK is not installed yet. Tap Install APK first.", Toast.LENGTH_LONG).show()
            return
        }
        if (!i.launchable || !ApkRuntimeController.launchInstalled(this, pkg)) {
            Toast.makeText(this, "Installed APK has no launchable activity.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "● APP RUNNING"
        status.setTextColor(Color.parseColor("#4CD964"))
        appendConsoleLine("RUN: launched $pkg")
    }

    private fun showReleaseFolder() {
        val dir = File(project.folderPath, "devstudio/releases")
        if (!dir.exists()) dir.mkdirs()
        val items = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        AlertDialog.Builder(this).setTitle("Release Folder")
            .setMessage(if (items.isEmpty()) "No archived APKs yet.\n\n${dir.absolutePath}" else items.joinToString("\n\n") { it.name + "\n" + formatBytes(it.length()) })
            .setPositiveButton("OK", null).show()
    }

    private fun appendHistory(type: String, apk: File) {
        val file = File(project.folderPath, "devstudio/build_history.log")
        if (!file.parentFile.exists()) file.parentFile.mkdirs()
        file.appendText("${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())} | $type | ${apk.name} | ${apk.length()} bytes\n")
        loadHistory()
    }

    private fun loadHistory() {
        val file = File(project.folderPath, "devstudio/build_history.log")
        history.text = if (file.exists() && file.readText().isNotBlank()) file.readLines().asReversed().take(20).joinToString("\n") else "No builds recorded."
    }

    private fun appendConsoleLine(text: String) { console.append("\n$text\n") }
    private fun setButtons(enabled: Boolean) { findViewById<Button>(R.id.debugButton).isEnabled = enabled; findViewById<Button>(R.id.releaseButton).isEnabled = enabled; findViewById<Button>(R.id.rebuildButton).isEnabled = enabled; findViewById<Button>(R.id.autoFixButton).isEnabled = enabled }
    private fun formatBytes(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> "${bytes / 1024} KB"; else -> "${String.format(Locale.US, "%.2f", bytes / 1048576.0)} MB" }

    companion object {
        private const val REQUEST_IMPORT_TOOLCHAIN = 7104
        const val EXTRA_PROJECT_ID = "extra_build_release_project_id" }
}
