package com.example.ultrapromax.ui

import android.content.Context
import android.view.KeyEvent
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SearchReplaceManager(
    private val context: Context,
    private val editor: EditText
) {

    fun show() {

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 8)
        }

        val searchInput = EditText(context).apply {
            hint = "Find"
            setSingleLine(true)
        }

        val replaceInput = EditText(context).apply {
            hint = "Replace with"
            setSingleLine(true)
        }

        val resultText = TextView(context).apply {
            text = "0 matches"
            setPadding(0, 12, 0, 8)
        }

        container.addView(searchInput)
        container.addView(replaceInput)
        container.addView(resultText)

        val dialog = androidx.appcompat.app.AlertDialog.Builder(context)
            .setTitle("Find & Replace")
            .setView(container)
            .setNeutralButton("Replace All", null)
            .setNegativeButton("Close", null)
            .create()

        dialog.setOnShowListener {

            val replaceAllButton =
                dialog.getButton(
                    androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL
                )

            replaceAllButton.setOnClickListener {

                val search = searchInput.text.toString()
                val replacement = replaceInput.text.toString()

                if (search.isEmpty()) {
                    Toast.makeText(
                        context,
                        "Enter text to find",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }

                val text = editor.text.toString()

                val count = countMatches(text, search)

                if (count == 0) {
                    Toast.makeText(
                        context,
                        "No matches found",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }

                val updated = text.replace(
                    search,
                    replacement
                )

                editor.setText(updated)
                editor.setSelection(editor.text.length)

                resultText.text =
                    "Replaced $count matches"

                Toast.makeText(
                    context,
                    "$count matches replaced",
                    Toast.LENGTH_SHORT
                ).show()
            }

            searchInput.setOnEditorActionListener { _, _, _ ->

                val search = searchInput.text.toString()

                if (search.isEmpty()) {
                    false
                } else {
                    findNext(search)
                    true
                }
            }

            searchInput.setOnKeyListener { _, keyCode, event ->

                if (
                    keyCode == KeyEvent.KEYCODE_ENTER &&
                    event.action == KeyEvent.ACTION_DOWN
                ) {

                    val search =
                        searchInput.text.toString()

                    if (search.isNotEmpty()) {
                        findNext(search)
                    }

                    true
                } else {
                    false
                }
            }

            searchInput.addTextChangedListener(
                object : android.text.TextWatcher {

                    override fun beforeTextChanged(
                        s: CharSequence?,
                        start: Int,
                        count: Int,
                        after: Int
                    ) {
                    }

                    override fun onTextChanged(
                        s: CharSequence?,
                        start: Int,
                        before: Int,
                        count: Int
                    ) {

                        val query =
                            s?.toString() ?: ""

                        val matches =
                            if (query.isEmpty()) {
                                0
                            } else {
                                countMatches(
                                    editor.text.toString(),
                                    query
                                )
                            }

                        resultText.text =
                            "$matches matches"
                    }

                    override fun afterTextChanged(
                        s: android.text.Editable?
                    ) {
                    }
                }
            )
        }

        dialog.show()
    }

    private fun findNext(search: String) {

        val text = editor.text.toString()

        if (text.isEmpty()) return

        val start =
            editor.selectionEnd.coerceAtLeast(0)

        var index =
            text.indexOf(
                search,
                start
            )

        if (index == -1) {
            index =
                text.indexOf(
                    search,
                    0
                )
        }

        if (index == -1) {

            Toast.makeText(
                context,
                "No matches found",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        editor.requestFocus()

        editor.setSelection(
            index,
            index + search.length
        )
    }

    private fun countMatches(
        text: String,
        search: String
    ): Int {

        if (search.isEmpty()) return 0

        var count = 0
        var start = 0

        while (true) {

            val index =
                text.indexOf(
                    search,
                    start
                )

            if (index == -1) break

            count++

            start =
                index + search.length

            if (start >= text.length) break
        }

        return count
    }
}