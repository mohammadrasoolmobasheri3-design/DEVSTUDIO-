package com.example.ultrapromax.engine.visual

/** Device-local design tokens used by the UI Builder and Studio visual layer. */
class StudioDesignSystemEngine {
    data class Tokens(
        val spacing: IntArray,
        val cornerRadiusDp: Float,
        val elevationDp: Float,
        val glassAlpha: Int,
        val motionDurationMs: Long
    )
    data class ComponentSpec(val id: String, val category: String, val defaultWidthDp: Int, val defaultHeightDp: Int, val supportsMotion: Boolean, val supportsGlass: Boolean)
    data class AnimationSpec(val name: String, val durationMs: Long, val fromAlpha: Float, val toAlpha: Float, val fromScale: Float, val toScale: Float, val translationYDp: Float = 0f)
    data class SurfaceSpec(val name: String, val glass: Boolean, val depthDp: Float, val borderWidthDp: Float, val blurHint: Float)

    fun tokens(): Tokens = Tokens(intArrayOf(4, 8, 12, 16, 24, 32), 14f, 8f, 150, 180L)

    fun components(): List<ComponentSpec> = listOf(
        ComponentSpec("text", "Content", 240, 48, true, true),
        ComponentSpec("button", "Controls", 180, 52, true, true),
        ComponentSpec("image", "Media", 220, 160, true, true),
        ComponentSpec("input", "Forms", 240, 52, true, true),
        ComponentSpec("card", "Layout", 280, 180, true, true),
        ComponentSpec("container", "Layout", 300, 220, false, true),
        ComponentSpec("chip", "Controls", 96, 40, true, true),
        ComponentSpec("toolbar", "Navigation", 320, 56, true, true),
        ComponentSpec("list", "Layout", 320, 240, true, true),
        ComponentSpec("dialog", "Overlay", 300, 180, true, true)
    )

    fun animations(): List<AnimationSpec> = listOf(
        AnimationSpec("fadeIn", 180L, 0f, 1f, 1f, 1f),
        AnimationSpec("scaleIn", 220L, 0f, 1f, 0.94f, 1f),
        AnimationSpec("slideIn", 240L, 0f, 1f, 0.98f, 1f, 12f),
        AnimationSpec("press", 100L, 1f, 1f, 1f, 0.97f),
        AnimationSpec("pulse", 600L, 0.75f, 1f, 0.98f, 1f)
    )

    fun surfaces(): List<SurfaceSpec> = listOf(
        SurfaceSpec("glass-card", true, 8f, 1f, 18f),
        SurfaceSpec("glass-deep", true, 18f, 1.5f, 24f),
        SurfaceSpec("elevated", false, 10f, 1f, 0f)
    )

    fun validate(): Boolean = tokens().spacing.isNotEmpty() && components().size >= 6 && animations().size >= 5 && surfaces().size >= 3 && animations().all { it.durationMs > 0L }
}
