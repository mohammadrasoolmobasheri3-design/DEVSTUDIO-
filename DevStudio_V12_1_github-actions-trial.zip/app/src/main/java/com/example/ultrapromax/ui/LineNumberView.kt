package com.example.ultrapromax.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.View
import android.widget.EditText

class LineNumberView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var editor: EditText? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF777777.toInt()
        textSize = 14f * resources.displayMetrics.scaledDensity
        typeface = Typeface.MONOSPACE
    }

    private val watcher = object : TextWatcher {

        override fun beforeTextChanged(
            s: CharSequence?,
            start: Int,
            count: Int,
            after: Int
        ) {
        }

        override fun onTextChanged(
            s: CharSequence?,
            start: Int,
            before: Int,
            count: Int
        ) {
            invalidate()
        }

        override fun afterTextChanged(
            s: Editable?
        ) {
            invalidate()
        }
    }

    fun bindTo(editText: EditText) {
        editor = editText

        editText.addTextChangedListener(watcher)

        editText.viewTreeObserver.addOnScrollChangedListener {
            scrollTo(
                0,
                editText.scrollY
            )
            invalidate()
        }

        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val editText = editor ?: return
        val layout = editText.layout ?: return

        canvas.save()

        canvas.translate(
            0f,
            -editText.scrollY.toFloat()
        )

        val text = editText.text
        val lineCount = layout.lineCount

        var logicalLine = 1

        for (visualLine in 0 until lineCount) {

            val start = layout.getLineStart(
                visualLine
            )

            val isNewLogicalLine =
                visualLine == 0 ||
                (start > 0 &&
                    start <= text.length &&
                    text[start - 1] == '\n')

            if (isNewLogicalLine) {

                val baseline =
                    layout.getLineBaseline(
                        visualLine
                    ).toFloat()

                val number = logicalLine.toString()

                canvas.drawText(
                    number,
                    width -
                        paint.measureText(number) -
                        12f,
                    baseline,
                    paint
                )

                logicalLine++
            }
        }

        canvas.restore()
    }
}