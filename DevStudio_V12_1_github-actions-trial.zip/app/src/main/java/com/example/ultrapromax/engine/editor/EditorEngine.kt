package com.example.ultrapromax.engine.editor

import android.graphics.Color
import android.text.Editable
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.widget.EditText

/**
 * EDITOR ENGINE
 *
 * Lightweight regex-based syntax highlighting.
 * Compatible with Kotlin 1.3.72.
 */
object EditorEngine {

    private val attachedEditors = java.util.WeakHashMap<EditText, TextWatcher>()

    private val keywordSets = mapOf(
        "html" to listOf(
            "html", "head", "body", "div", "span",
            "script", "style", "link", "meta", "title"
        ),
        "css" to listOf(
            "color", "background", "margin", "padding",
            "display", "flex", "font-size", "border"
        ),
        "js" to listOf(
            "function", "var", "let", "const",
            "if", "else", "for", "while", "return", "console"
        ),
        "kt" to listOf(
            "fun", "val", "var", "class", "object",
            "if", "else", "for", "while",
            "return", "import", "package"
        )
,        "java" to listOf(
            "public", "private", "protected", "class", "interface", "extends",
            "implements", "static", "final", "void", "new", "return", "if", "else",
            "for", "while", "try", "catch", "import", "package", "this", "super", "null"
        ),
        "python" to listOf(
            "def", "class", "import", "from", "as", "if", "elif", "else", "for",
            "while", "in", "return", "try", "except", "finally", "with", "lambda", "None", "True", "False"
        ),
        "ts" to listOf(
            "function", "const", "let", "var", "class", "interface", "type", "extends",
            "implements", "if", "else", "for", "while", "return", "import", "from", "export", "async", "await"
        ),
        "c" to listOf(
            "include", "define", "int", "char", "float", "double", "void", "struct",
            "return", "if", "else", "for", "while", "switch", "case", "break", "const"
        ),
        "cpp" to listOf(
            "include", "define", "int", "char", "float", "double", "void", "class",
            "namespace", "using", "return", "if", "else", "for", "while", "switch", "case", "break", "const"
        ),
        "kts" to listOf("val", "var", "fun", "class", "object", "if", "else", "for", "while", "return", "import", "package"),
        "go" to listOf("package", "import", "func", "type", "struct", "interface", "return", "if", "else", "for", "range", "go", "defer", "var", "const"),
        "rust" to listOf("fn", "let", "mut", "struct", "enum", "trait", "impl", "use", "mod", "pub", "return", "if", "else", "match", "loop", "for", "while"),
        "swift" to listOf("import", "class", "struct", "enum", "protocol", "func", "let", "var", "if", "else", "for", "while", "return", "guard", "switch"),
        "dart" to listOf("import", "class", "extends", "implements", "mixin", "void", "final", "const", "var", "late", "if", "else", "for", "while", "return", "async", "await"),
        "php" to listOf("function", "class", "interface", "extends", "implements", "public", "private", "protected", "return", "if", "else", "foreach", "while", "new", "namespace", "use"),
        "csharp" to listOf("using", "namespace", "class", "struct", "interface", "public", "private", "protected", "static", "void", "new", "return", "if", "else", "for", "foreach", "while", "async", "await"),
        "ruby" to listOf("def", "class", "module", "require", "include", "if", "elsif", "else", "unless", "while", "until", "do", "end", "return"),
        "shell" to listOf("if", "then", "else", "fi", "for", "in", "do", "done", "while", "case", "esac", "function", "export"),
        "sql" to listOf("SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE", "CREATE", "TABLE", "ALTER", "DROP", "JOIN", "LEFT", "RIGHT", "INNER", "GROUP", "ORDER", "BY", "LIMIT")
    )

    // Must NOT be const because Color.parseColor() is not a compile-time constant
    private val KEYWORD_COLOR = Color.parseColor("#C678DD")
    private val STRING_COLOR = Color.parseColor("#98C379")
    private val COMMENT_COLOR = Color.parseColor("#5C6370")

    fun languageForFileName(name: String): String {
        return when {
            name.endsWith(".html", true) || name.endsWith(".htm", true) -> "html"
            name.endsWith(".css", true) -> "css"
            name.endsWith(".js", true) || name.endsWith(".mjs", true) -> "js"
            name.endsWith(".ts", true) || name.endsWith(".tsx", true) -> "ts"
            name.endsWith(".kt", true) -> "kt"
            name.endsWith(".kts", true) -> "kts"
            name.endsWith(".java", true) -> "java"
            name.endsWith(".py", true) -> "python"
            name.endsWith(".c", true) -> "c"
            name.endsWith(".cc", true) || name.endsWith(".cpp", true) || name.endsWith(".cxx", true) -> "cpp"
            name.endsWith(".go", true) -> "go"
            name.endsWith(".rs", true) -> "rust"
            name.endsWith(".swift", true) -> "swift"
            name.endsWith(".dart", true) -> "dart"
            name.endsWith(".php", true) -> "php"
            name.endsWith(".rb", true) -> "ruby"
            name.endsWith(".pl", true) -> "perl"
            name.endsWith(".lua", true) -> "lua"
            name.endsWith(".sh", true) || name.endsWith(".bash", true) -> "shell"
            name.endsWith(".sql", true) -> "sql"
            else -> "text"
        }
    }

    /**
     * Attaches live syntax highlighting.
     */
    fun attachHighlighting(
        editText: EditText,
        language: String
    ) {
        // One watcher per editor. Opening another file must never stack
        // additional syntax-highlighting watchers on the same EditText.
        attachedEditors.remove(editText)?.let { editText.removeTextChangedListener(it) }

        val watcher = object : TextWatcher {
            private var isEditing = false

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (isEditing || s == null) return
                isEditing = true
                try {
                    highlight(s, language)
                } finally {
                    isEditing = false
                }
            }
        }

        attachedEditors[editText] = watcher
        editText.addTextChangedListener(watcher)
        if (editText.text.length > 0) highlight(editText.text, language)
    }

    private fun highlight(
        editable: Editable,
        language: String
    ) {
        if (editable.length == 0) {
            return
        }

        // Remove previous foreground-color spans
        val oldSpans = editable.getSpans(
            0,
            editable.length,
            ForegroundColorSpan::class.java
        )

        for (span in oldSpans) {
            editable.removeSpan(span)
        }

        val text = editable.toString()

        // Keywords
        val keywords = keywordSets[language]

        if (keywords != null) {
            for (keyword in keywords) {

                val escapedKeyword = Regex.escape(keyword)
                val regex = Regex("\\b$escapedKeyword\\b")

                for (match in regex.findAll(text)) {
                    editable.setSpan(
                        ForegroundColorSpan(KEYWORD_COLOR),
                        match.range.first,
                        match.range.last + 1,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
        }

        // Strings
        val stringRegex = Regex("\"[^\"]*\"|'[^']*'")

        for (match in stringRegex.findAll(text)) {
            editable.setSpan(
                ForegroundColorSpan(STRING_COLOR),
                match.range.first,
                match.range.last + 1,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        // Comments
        val commentRegex = Regex("""//[^\n]*|/\*[\s\S]*?\*/|<!--[^>]*-->|#[^\n]*""")

        for (match in commentRegex.findAll(text)) {
            editable.setSpan(
                ForegroundColorSpan(COMMENT_COLOR),
                match.range.first,
                match.range.last + 1,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }
}