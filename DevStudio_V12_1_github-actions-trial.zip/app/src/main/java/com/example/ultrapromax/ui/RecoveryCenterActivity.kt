package com.example.ultrapromax.ui

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.backup.BackupEngine
import com.example.ultrapromax.engine.security.RecoveryEngine
import com.example.ultrapromax.engine.selfhealing.SelfHealingEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * V30.1.0 Stage 20 — Recovery / Backup / Self-Healing Center.
 * All operations are local and conservative: backups are explicit, restores
 * require confirmation, and self-healing only repairs missing/empty files
 * using a verified local backup manifest.
 */
class RecoveryCenterActivity : Activity() {
    private lateinit var project: Project
    private lateinit var backup: BackupEngine
    private lateinit var recovery: RecoveryEngine
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        backup = BackupEngine(this)
        recovery = RecoveryEngine(this)
        setContentView(buildUi())
        refreshStatus()
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
            setBackgroundColor(0xff070b12.toInt())
        }
        val title = TextView(this).apply {
            text = "RECOVERY / SELF-HEALING"
            textSize = 20f
            setTextColor(0xffe8f0ff.toInt())
            setTypeface(null, 1)
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Offline protection center • ${project.name}"
            textSize = 11f
            setTextColor(0xff8ea3bd.toInt())
            setPadding(0, 6, 0, 16)
        })
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(0xff64e8b4.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xff0d1622.toInt())
        }
        root.addView(status)

        addButton(root, "CREATE BACKUP", 0xff4dd8ff.toInt()) { createBackup() }
        addButton(root, "VERIFY LATEST BACKUP", 0xff8ca7ff.toInt()) { verifyBackup() }
        addButton(root, "SELF-HEAL PROJECT", 0xff64e8b4.toInt()) { selfHeal() }
        addButton(root, "RESTORE LATEST BACKUP", 0xffffc857.toInt()) { confirmRestore() }
        addButton(root, "ROTATE BACKUPS • KEEP 10", 0xffc6a0ff.toInt()) {
            val removed = backup.rotateBackups(project.name, 10)
            toast("Removed $removed old backup(s)")
            refreshStatus()
        }
        addButton(root, "CLEAR SAVED DRAFTS", 0xffff8f8f.toInt()) { clearDrafts() }
        addButton(root, "CLEAR CRASH REPORT", 0xffff8f8f.toInt()) {
            val ok = recovery.clearCrashReport()
            toast(if (ok) "Crash report cleared" else "Nothing cleared")
            refreshStatus()
        }
        addButton(root, "CLOSE", 0xffaebbd0.toInt()) { finish() }
        scroll.addView(root)
        return scroll
    }

    private fun addButton(root: LinearLayout, text: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 10f
            setTextColor(color)
            minHeight = 0
            minWidth = 0
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 8 })
    }

    private fun createBackup() {
        runCatching {
            val dir = File(project.folderPath)
            if (!dir.isDirectory) throw IllegalStateException("Project folder is unavailable")
            val file = backup.backupAndRotate(dir, project.name, 10)
            toast("Backup created: ${file.name}")
            refreshStatus()
        }.onFailure { toast("Backup failed: ${it.message ?: "unknown error"}") }
    }

    private fun verifyBackup() {
        runCatching {
            val r = backup.verifyLatest(project.name)
            if (r.backup == null) {
                toast("No backup found")
            } else {
                status.text = "INTEGRITY CHECK\nChecked: ${r.checked}\nValid: ${r.valid}\nMissing: ${r.missing}\nInvalid: ${r.invalid}"
                toast(if (r.invalid == 0 && r.missing == 0) "Backup integrity OK" else "Backup needs attention")
            }
        }.onFailure { toast("Verification failed: ${it.message ?: "unknown error"}") }
    }

    private fun selfHeal() {
        AlertDialog.Builder(this)
            .setTitle("Self-Heal Project")
            .setMessage("Only missing or zero-byte files will be restored from the newest local backup. Continue?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("HEAL") { _, _ ->
                runCatching {
                    val healed = backup.autoHealIfCorrupted(File(project.folderPath), project.name)
                    toast("Self-healing complete • repaired $healed file(s)")
                    refreshStatus()
                }.onFailure { toast("Self-healing failed: ${it.message ?: "unknown error"}") }
            }.show()
    }

    private fun confirmRestore() {
        val latest = backup.latestBackup(project.name)
        if (latest == null) { toast("No backup found"); return }
        AlertDialog.Builder(this)
            .setTitle("Restore Latest Backup")
            .setMessage("This overwrites files in the project folder with the selected local backup. Create a fresh backup first if needed.\n\n${latest.name}")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("RESTORE") { _, _ ->
                runCatching {
                    backup.restore(latest, File(project.folderPath))
                    toast("Restore completed")
                    refreshStatus()
                }.onFailure { toast("Restore failed: ${it.message ?: "unknown error"}") }
            }.show()
    }

    private fun clearDrafts() {
        AlertDialog.Builder(this)
            .setTitle("Clear Saved Drafts")
            .setMessage("Remove editor recovery drafts for this project?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CLEAR") { _, _ ->
                val removed = recovery.clearAllDrafts(project.id)
                toast("Removed $removed draft file(s)")
                refreshStatus()
            }.show()
    }

    private fun refreshStatus() {
        val backups = backup.listBackups(project.name)
        val latest = backups.firstOrNull()
        val drafts = recovery.countDrafts(project.id)
        val crash = recovery.hasCrashReport()
        status.text = buildString {
            append("BACKUP COUNT: ").append(backups.size).append('\n')
            append("LATEST: ").append(latest?.let { formatTime(it.lastModified()) } ?: "NONE").append('\n')
            append("RECOVERY DRAFTS: ").append(drafts).append('\n')
            append("CRASH REPORT: ").append(if (crash) "AVAILABLE" else "CLEAR")
        }
    }

    private fun formatTime(time: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(time))

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    companion object {
        const val EXTRA_PROJECT_ID = "project_id"
    }
}
