package com.example.ultrapromax.engine.power

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.webapp.WebAppApkPipelineEngine
import java.io.File

/** Full offline Web -> Android -> APK orchestration. Never reports success without a real APK. */
class WebToApkProductionEngine(private val context: Context) {
    data class Result(val success: Boolean, val projectDir: File?, val apk: File?, val log: List<String>)

    fun build(webRoot: File, outputRoot: File, appName: String, release: Boolean = false): Result {
        val log = ArrayList<String>()
        val tool = AndroidToolchainDiscoveryEngine(context).discover()
        if (!tool.ready) return Result(false, null, null, listOf("TOOLCHAIN • ${tool.details}"))
        if (!webRoot.isDirectory || !File(webRoot, "index.html").isFile) return Result(false, null, null, listOf("PREFLIGHT • index.html is required"))
        return try {
            val pipeline = WebAppApkPipelineEngine(tool.sdk)
            val r = if (release) pipeline.release(webRoot, outputRoot, appName) else pipeline.build(webRoot, outputRoot, appName)
            log.add("PROJECT • ${r.projectDir.absolutePath}")
            log.add("PIPELINE • ${r.output}")
            val apk = r.apk
            if (!r.success || apk == null || !apk.isFile || apk.length() == 0L) return Result(false, r.projectDir, apk, log + "VERIFY • no real APK artifact")
            val validation = ApkValidationEngine().validate(apk)
            log.add("APK VALIDATION • ${if (validation.valid) "PASS" else "FAIL"} ${validation.errors.joinToString("; ")}")
            Result(validation.valid, r.projectDir, apk.takeIf { validation.valid }, log)
        } catch (e: Exception) {
            Result(false, null, null, log + "FAILED • ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
