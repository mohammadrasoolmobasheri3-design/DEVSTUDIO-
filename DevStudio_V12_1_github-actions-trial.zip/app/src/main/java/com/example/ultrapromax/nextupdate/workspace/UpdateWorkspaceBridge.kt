package com.example.ultrapromax.nextupdate.workspace

/** Adapter boundary for connecting the next-update systems to the existing V30 engines. */
interface UpdateWorkspaceBridge {
    fun projectRoot(projectId: String): String?
    fun listProjectFiles(projectId: String): List<String>
}
