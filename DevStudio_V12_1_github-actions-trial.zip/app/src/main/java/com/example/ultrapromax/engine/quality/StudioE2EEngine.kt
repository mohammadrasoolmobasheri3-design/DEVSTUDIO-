package com.example.ultrapromax.engine.quality

import com.example.ultrapromax.engine.ai.CodeStructureEngine
import com.example.ultrapromax.engine.ai.RuleBasedAiEngine
import com.example.ultrapromax.engine.offline.OfflineInternetSimulationEngine
import com.example.ultrapromax.engine.security.RecoveryTransactionEngine
import java.io.File

/** Full deterministic workflow test: create → edit → analyze → persist → recover → local API. */
class StudioE2EEngine {
    data class Result(val passed: Boolean, val steps: List<String>)
    fun run(root: File): Result {
        val steps = ArrayList<String>()
        try {
            root.deleteRecursively(); root.mkdirs(); steps += "workspace-created"
            val source = File(root, "src/main.kt"); source.parentFile.mkdirs(); source.writeText("fun main(){ println(\"DEVSTUDIO\") }"); steps += "file-created"
            val ai = RuleBasedAiEngine(); val scan = CodeStructureEngine().scan(source.readText(), "kt")
            if (scan.braces != 0 || ai.lint(source.readText(), "kt").isNotEmpty()) return Result(false, steps + "analysis-failed")
            steps += "ai-analysis"
            val state = File(root, ".devstudio/workspace.state"); state.parentFile.mkdirs(); state.writeText("activeFile=src/main.kt\nactiveTab=code\ndirty=false\n"); steps += "state-persisted"
            val txDir = File(root.parentFile ?: root, ".e2e-snapshot"); txDir.deleteRecursively()
            val tx = RecoveryTransactionEngine(); val snap = tx.snapshot(root, txDir); source.writeText("broken"); tx.restore(snap)
            if (source.readText().contains("DEVSTUDIO").not()) return Result(false, steps + "recovery-failed")
            steps += "recovery-verified"
            if (OfflineInternetSimulationEngine().request("/api/health").status != 200) return Result(false, steps + "local-api-failed")
            steps += "offline-api"
            txDir.deleteRecursively(); root.deleteRecursively(); return Result(true, steps)
        } catch (t: Throwable) { root.deleteRecursively(); return Result(false, steps + ("error:" + (t.message ?: "unknown"))) }
    }
}
