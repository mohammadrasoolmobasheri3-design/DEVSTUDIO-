package com.example.ultrapromax.engine.webapp
import com.example.ultrapromax.engine.builder.BuildEngine
import java.io.File
class WebAppApkPipelineEngine(private val toolchainRoot: File? = null){
 data class Result(val success:Boolean,val projectDir:File,val apk:File?,val output:String,val preflight:String = "")
 fun build(webRoot:File,outputRoot:File,appName:String):Result {
  val pre = WebAppPreflightEngine().inspect(webRoot); if (!pre.valid) return Result(false,outputRoot,null,"Web preflight failed: ${pre.errors.joinToString()}","${pre.files} files; ${pre.warnings.size} warnings")
  val g=WebAppProjectEngine().generateWebViewProject(webRoot,outputRoot,appName,toolchainRoot); val b=BuildEngine().buildDebug(g.projectDir); return Result(b.success,g.projectDir,b.apkFile,b.output,"preflight PASS")
 }
 fun release(webRoot:File,outputRoot:File,appName:String):Result {
  val pre = WebAppPreflightEngine().inspect(webRoot); if (!pre.valid) return Result(false,outputRoot,null,"Web preflight failed: ${pre.errors.joinToString()}","${pre.files} files; ${pre.warnings.size} warnings")
  val g=WebAppProjectEngine().generateWebViewProject(webRoot,outputRoot,appName,toolchainRoot); val b=BuildEngine().buildRelease(g.projectDir); return Result(b.success,g.projectDir,b.apkFile,b.output,"preflight PASS")
 }
}
