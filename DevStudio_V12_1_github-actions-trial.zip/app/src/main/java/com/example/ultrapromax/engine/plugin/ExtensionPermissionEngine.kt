package com.example.ultrapromax.engine.plugin

import android.content.Context

/**
 * V26.9 permission gate for extension metadata.
 * Permissions are deny-by-default at the platform boundary.
 */
class ExtensionPermissionEngine(private val context: Context) {

    private val prefs = context.getSharedPreferences(
        "extension_permission_policy",
        Context.MODE_PRIVATE
    )

    fun isGranted(extensionId: String, permission: PluginPermission): Boolean {
        return prefs.getBoolean(key(extensionId, permission), false)
    }

    fun grant(extensionId: String, permission: PluginPermission): Boolean {
        prefs.edit().putBoolean(key(extensionId, permission), true).apply()
        return true
    }

    fun revoke(extensionId: String, permission: PluginPermission): Boolean {
        prefs.edit().putBoolean(key(extensionId, permission), false).apply()
        return true
    }

    fun grantAll(extension: ExtensionDescriptor): Int {
        var count = 0
        for (permission in extension.permissions) {
            if (grant(extension.id, permission)) count++
        }
        return count
    }

    fun revokeAll(extension: ExtensionDescriptor): Int {
        var count = 0
        for (permission in extension.permissions) {
            if (revoke(extension.id, permission)) count++
        }
        return count
    }

    fun allowed(extension: ExtensionDescriptor): Boolean {
        return extension.permissions.all { isGranted(extension.id, it) }
    }

    private fun key(id: String, permission: PluginPermission): String {
        return id + ":" + permission.name
    }
}
