package com.example.ultrapromax.nextupdate.project

data class ProjectGenerationSpec(
    val name: String,
    val packageName: String,
    val platform: String,
    val features: List<String> = emptyList()
)
