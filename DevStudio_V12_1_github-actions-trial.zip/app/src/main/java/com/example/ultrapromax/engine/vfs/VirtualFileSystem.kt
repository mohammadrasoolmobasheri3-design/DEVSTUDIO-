package com.example.ultrapromax.engine.vfs

import java.io.File

/**
 * DEVSTUDIO v20 Virtual File System.
 * Keeps all project paths inside the selected project root and provides
 * safe project-relative file operations.
 * Kotlin 1.3.72 compatible.
 */
class VirtualFileSystem(private val root: File) {

    init { root.mkdirs() }

    fun root(): File = root

    fun resolve(relativePath: String): File? {
        val clean = relativePath.trim().replace('\\', '/')
        if (clean.startsWith("/") || clean.contains("../") || clean == ".." || clean.contains(":") ) return null
        val target = File(root, clean).canonicalFile
        val base = root.canonicalFile
        val basePath = if (base.path.endsWith(File.separator)) base.path else base.path + File.separator
        return if (target.path == base.path || target.path.startsWith(basePath)) target else null
    }

    fun relative(file: File): String {
        val base = root.canonicalFile.path
        val path = file.canonicalFile.path
        if (path == base) return ""
        return path.removePrefix(base).trimStart(File.separatorChar).replace(File.separatorChar, '/')
    }

    fun list(relativePath: String = ""): List<File> {
        val dir = resolve(relativePath) ?: return emptyList()
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.toLowerCase() })) ?: emptyList()
    }

    fun createFolder(relativePath: String): File? {
        val f = resolve(relativePath) ?: return null
        if (f.exists()) return null
        return if (f.mkdirs()) f else null
    }

    fun createFile(relativePath: String, content: String = ""): File? {
        val f = resolve(relativePath) ?: return null
        if (f.exists()) return null
        f.parentFile?.mkdirs()
        f.writeText(content)
        return f
    }

    fun delete(relativePath: String): Boolean {
        val f = resolve(relativePath) ?: return false
        if (f == root.canonicalFile) return false
        return if (f.isDirectory) f.deleteRecursively() else f.delete()
    }

    fun rename(relativePath: String, newName: String): File? {
        if (newName.isBlank() || newName.contains("/") || newName.contains("\\") || newName == "." || newName == "..") return null
        val f = resolve(relativePath) ?: return null
        if (f == root.canonicalFile || !f.exists()) return null
        val target = File(f.parentFile, newName)
        if (target.exists()) return null
        return if (f.renameTo(target)) target else null
    }

    fun duplicate(relativePath: String): File? {
        val source = resolve(relativePath) ?: return null
        if (!source.exists() || source == root.canonicalFile) return null
        var index = 1
        var name = source.nameWithoutExtension + "_copy"
        if (source.extension.isNotEmpty()) name += "." + source.extension
        var target = File(source.parentFile, name)
        while (target.exists()) {
            index++
            val base = source.nameWithoutExtension + "_copy" + index
            name = if (source.extension.isEmpty()) base else base + "." + source.extension
            target = File(source.parentFile, name)
        }
        return try {
            if (source.isDirectory) source.copyRecursively(target, overwrite = false) else source.copyTo(target, overwrite = false)
            target
        } catch (e: Exception) { null }
    }

    fun size(relativePath: String = ""): Long {
        val f = resolve(relativePath) ?: return 0L
        if (!f.exists()) return 0L
        if (f.isFile) return f.length()
        var total = 0L
        f.walkTopDown().filter { it.isFile }.forEach { total += it.length() }
        return total
    }

    fun countFiles(relativePath: String = ""): Int {
        val f = resolve(relativePath) ?: return 0
        if (!f.exists()) return 0
        return if (f.isFile) 1 else f.walkTopDown().count { it.isFile }
    }
}
