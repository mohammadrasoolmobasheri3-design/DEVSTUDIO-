package com.example.ultrapromax.engine.search

import java.io.File
import java.util.regex.Pattern

/**
 * SMART SEARCH
 * Full-project search with literal, regex, filename and replace-all support.
 * All operations are local and bounded to the supplied project root.
 */
data class SearchResult(val file: File, val lineNumber: Int, val lineText: String)

data class ReplaceResult(
    val filesChanged: Int,
    val replacements: Int
)

object SearchEngine {

    fun searchInFiles(root: File, query: String, ignoreCase: Boolean = true): List<SearchResult> {
        if (query.isBlank()) return emptyList()
        val results = mutableListOf<SearchResult>()
        root.walkTopDown()
            .filter { it.isFile && it.length() < 2_000_000 }
            .forEach { file ->
                runCatching {
                    file.readLines().forEachIndexed { index, line ->
                        if (line.contains(query, ignoreCase)) {
                            results.add(SearchResult(file, index + 1, line.trim()))
                        }
                    }
                }
            }
        return results
    }

    fun searchRegex(root: File, regex: String, ignoreCase: Boolean = true): List<SearchResult> {
        if (regex.isBlank()) return emptyList()
        val flags = if (ignoreCase) Pattern.CASE_INSENSITIVE else 0
        val pattern = runCatching { Pattern.compile(regex, flags) }.getOrNull() ?: return emptyList()
        val results = mutableListOf<SearchResult>()
        root.walkTopDown()
            .filter { it.isFile && it.length() < 2_000_000 }
            .forEach { file ->
                runCatching {
                    file.readLines().forEachIndexed { index, line ->
                        if (pattern.matcher(line).find()) {
                            results.add(SearchResult(file, index + 1, line.trim()))
                        }
                    }
                }
            }
        return results
    }

    fun replaceAll(
        root: File,
        search: String,
        replacement: String,
        ignoreCase: Boolean = true,
        regex: Boolean = false
    ): ReplaceResult {
        if (search.isBlank()) return ReplaceResult(0, 0)
        var filesChanged = 0
        var replacements = 0

        root.walkTopDown()
            .filter { it.isFile && it.length() < 2_000_000 }
            .forEach { file ->
                runCatching {
                    val original = file.readText()
                    val updated: String
                    if (regex) {
                        val flags = if (ignoreCase) Pattern.CASE_INSENSITIVE else 0
                        val p = Pattern.compile(search, flags)
                        val matcher = p.matcher(original)
                        var count = 0
                        while (matcher.find()) count++
                        updated = matcher.replaceAll(replacement)
                        replacements += count
                    } else {
                        val pattern = Pattern.quote(search)
                        val flags = if (ignoreCase) Pattern.CASE_INSENSITIVE else 0
                        val matcher = Pattern.compile(pattern, flags).matcher(original)
                        var count = 0
                        while (matcher.find()) count++
                        updated = matcher.replaceAll(java.util.regex.Matcher.quoteReplacement(replacement))
                        replacements += count
                    }
                    if (updated != original) {
                        file.writeText(updated)
                        filesChanged++
                    }
                }
            }
        return ReplaceResult(filesChanged, replacements)
    }

    fun searchFileNames(root: File, query: String): List<File> {
        if (query.isBlank()) return emptyList()
        return root.walkTopDown()
            .filter { it.isFile && it.name.contains(query, ignoreCase = true) }
            .toList()
    }

    fun fuzzyFileNames(root: File, query: String): List<File> {
        if (query.isBlank()) return emptyList()
        val q = query.toLowerCase()
        return root.walkTopDown()
            .filter { it.isFile && fuzzyScore(it.name.toLowerCase(), q) > 0 }
            .sortedByDescending { fuzzyScore(it.name.toLowerCase(), q) }
            .toList()
    }

    private fun fuzzyScore(text: String, query: String): Int {
        var qi = 0
        var score = 0
        var previous = '\u0000'
        for (c in text) {
            if (qi < query.length && c == query[qi]) {
                score += if (qi == 0 || previous == '.' || previous == '/' || previous == '-' || previous == '_') 3 else 1
                qi++
            }
            previous = c
        }
        return if (qi == query.length) score else 0
    }
}
