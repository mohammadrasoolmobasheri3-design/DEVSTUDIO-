package com.example.ultrapromax.ui

import com.example.ultrapromax.engine.workspace.WorkspaceSession

import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.ui.DesignCodePreviewBridge
import java.io.File

/**
 * DEVSTUDIO v17 - Visual UI Builder.
 * Real Android drag/drop palette, selectable components, movable canvas items,
 * hierarchy, property inspector, persistence and HTML generation.
 * Kept compatible with Kotlin 1.3.72 / old Android toolchain.
 */
class UiBuilderActivity : AppCompatActivity() {

    private lateinit var canvas: FrameLayout
    private lateinit var palette: LinearLayout
    private lateinit var hierarchy: LinearLayout
    private lateinit var inspector: LinearLayout
    private lateinit var status: TextView

    private var project: Project? = null
    private var selected: View? = null
    private var componentCounter = 0
    private var movingView: View? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var startLeft = 0
    private var startTop = 0
    private var moved = false
    private var selectedTheme = "dark"
    private var selectedAnimation = "scaleIn"
    private var selectedBreakpoint = "medium"
    private val uiUxFactory = com.example.ultrapromax.engine.visual.UiUxFactoryEngine()

    private val undoStack = mutableListOf<List<String>>()
    private val maxUndoDepth = 30

    private data class ComponentSpec(val type: String, val label: String, val html: String)

    private val components = listOf(
        ComponentSpec("Text", "Text", "<h2 class=\"ds-text\">Text</h2>"),
        ComponentSpec("Button", "Button", "<button type=\"button\">Button</button>"),
        ComponentSpec("Input", "Input", "<input type=\"text\" placeholder=\"Input\">"),
        ComponentSpec("Image", "Image", "<img src=\"\" alt=\"Image\">"),
        ComponentSpec("Card", "Card", "<div class=\"ds-card\"><h3>Card</h3><p>Content</p></div>"),
        ComponentSpec("Container", "Container", "<div class=\"ds-container\"></div>"),
        ComponentSpec("Row", "Row", "<div class=\"ds-row\"></div>"),
        ComponentSpec("Divider", "Divider", "<hr>")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ui_builder)

        canvas = findViewById(R.id.canvas)
        palette = findViewById(R.id.palette)
        hierarchy = findViewById(R.id.hierarchy)
        inspector = findViewById(R.id.inspector)
        status = findViewById(R.id.builderStatus)

        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        if (id != -1L) project = ProjectStore.getById(this, id)
        loadFactoryProfile()

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveLayout(false) }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener { generateAndReturn() }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { openLivePreview() }
        findViewById<Button>(R.id.btnImport).setOnClickListener { importGeneratedHtml() }
        findViewById<Button>(R.id.btnCode).setOnClickListener { openGeneratedCode() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearCanvas() }
        findViewById<Button>(R.id.btnUndo).setOnClickListener { undo() }
        findViewById<Button>(R.id.btnTheme).setOnClickListener { chooseTheme() }
        findViewById<Button>(R.id.btnMotion).setOnClickListener { chooseMotion() }
        findViewById<Button>(R.id.btnResponsive).setOnClickListener { chooseResponsive() }

        buildPalette()
        setupCanvasDrop()
        loadLayout()
        refreshHierarchy()
        showEmptyInspector()
    }

    private fun buildPalette() {
        palette.removeAllViews()
        components.forEach { spec ->
            val chip = TextView(this).apply {
                text = spec.label
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                textSize = 12f
                setPadding(dp(15), dp(8), dp(15), dp(8))
                background = rounded("#242044", "#664DFF", 1)
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38))
                lp.setMargins(0, 0, dp(8), 0)
                layoutParams = lp
                setOnLongClickListener { view ->
                    val clip = ClipData.newPlainText("component", spec.type)
                    @Suppress("DEPRECATION")
                    view.startDrag(clip, View.DragShadowBuilder(view), spec.type, 0)
                    true
                }
                setOnClickListener { pushUndo(); addComponent(spec.type, dp(20), dp(20)) }
            }
            palette.addView(chip)
        }
    }

    private fun setupCanvasDrop() {
        canvas.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> event.clipDescription != null
                DragEvent.ACTION_DROP -> {
                    val type = event.localState as? String
                    if (type != null) { pushUndo(); addComponent(type, event.x.toInt(), event.y.toInt()) }
                    true
                }
                else -> true
            }
        }
    }

    private fun addComponent(type: String, x: Int, y: Int, savedId: String? = null,
                             savedText: String? = null, savedWidth: Int = 0, savedHeight: Int = 0) {
        val spec = components.firstOrNull { it.type == type } ?: return
        componentCounter += 1
        val id = savedId ?: "${type.toLowerCase()}_$componentCounter"
        val view = TextView(this).apply {
            text = savedText ?: spec.label
            tag = ComponentTag(id, type)
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded("#28324A", "#5D72FF", 1)
            isClickable = true
            setOnClickListener { selectComponent(this) }
            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    selectComponent(v)
                    movingView = v
                    downRawX = event.rawX
                    downRawY = event.rawY
                    val p = v.layoutParams as FrameLayout.LayoutParams
                    startLeft = p.leftMargin
                    startTop = p.topMargin
                    moved = false
                    pushUndo()
                    false
                } else if (event.action == MotionEvent.ACTION_MOVE && movingView === v) {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dx) > dp(3) || kotlin.math.abs(dy) > dp(3)) moved = true
                    if (moved) {
                        val p = v.layoutParams as FrameLayout.LayoutParams
                        p.leftMargin = (startLeft + dx).coerceAtLeast(0).coerceAtMost((canvas.width - v.width).coerceAtLeast(0))
                        p.topMargin = (startTop + dy).coerceAtLeast(0).coerceAtMost((canvas.height - v.height).coerceAtLeast(0))
                        v.layoutParams = p
                        refreshHierarchy()
                    }
                    true
                } else if (event.action == MotionEvent.ACTION_UP) {
                    if (!moved) selectComponent(v)
                    movingView = null
                    true
                } else false
            }
        }
        val defaultW = if (savedWidth > 0) dp(savedWidth) else componentDefaultWidth(type)
        val defaultH = if (savedHeight > 0) dp(savedHeight) else componentDefaultHeight(type)
        val params = FrameLayout.LayoutParams(defaultW, defaultH)
        params.leftMargin = x.coerceAtLeast(0)
        params.topMargin = y.coerceAtLeast(0)
        view.alpha = 0f
        view.scaleX = 0.94f
        view.scaleY = 0.94f
        canvas.addView(view, params)
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(com.example.ultrapromax.engine.visual.StudioDesignSystemEngine().tokens().motionDurationMs).start()
        selectComponent(view)
        updateStatus("Added $type")
    }

    private fun selectComponent(view: View) {
        selected = view
        for (i in 0 until canvas.childCount) {
            val child = canvas.getChildAt(i)
            child.background = if (child === view) rounded("#303B61", "#B47CFF", 2) else rounded("#28324A", "#5D72FF", 1)
        }
        refreshHierarchy()
        showInspector(view)
    }

    private fun refreshHierarchy() {
        hierarchy.removeAllViews()
        for (i in 0 until canvas.childCount) {
            val child = canvas.getChildAt(i)
            val tag = child.tag as? ComponentTag ?: continue
            val row = TextView(this).apply {
                text = "${if (child === selected) "● " else "○ "}${tag.type}  •  ${tag.id}"
                setTextColor(if (child === selected) Color.WHITE else Color.parseColor("#AAB5CE"))
                textSize = 11f
                setPadding(dp(10), dp(7), dp(10), dp(7))
                setOnClickListener { selectComponent(child) }
            }
            hierarchy.addView(row)
        }
        if (canvas.childCount == 0) {
            val empty = TextView(this).apply { text = "No components — drag or tap a component above."; setTextColor(Color.parseColor("#77829C")); setPadding(dp(10), dp(7), dp(10), dp(7)) }
            hierarchy.addView(empty)
        }
    }

    private fun showEmptyInspector() {
        inspector.removeAllViews()
        inspector.addView(label("Select a component to edit its properties."))
    }

    private fun showInspector(view: View) {
        val tag = view.tag as? ComponentTag ?: return
        inspector.removeAllViews()
        inspector.addView(section("INSPECTOR  •  ${tag.type}"))

        val textInput = EditText(this).apply {
            setText((view as? TextView)?.text?.toString() ?: "")
            hint = "Text / content"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6F7A92"))
            setSingleLine(true)
            setPadding(dp(10), 0, dp(10), 0)
            background = rounded("#151C2B", "#384661", 1)
        }
        inspector.addView(textInput, fieldParams())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val width = numberInput("Width", pxToDp(view.layoutParams.width).toString())
        val height = numberInput("Height", pxToDp(view.layoutParams.height).toString())
        row.addView(width, weightParams())
        row.addView(height, weightParams())
        inspector.addView(row)

        val apply = Button(this).apply {
            text = "Apply Properties"
            textSize = 11f
            setOnClickListener {
                pushUndo()
                (view as? TextView)?.text = textInput.text.toString()
                val w = width.text.toString().trim().toIntOrNull()
                val h = height.text.toString().trim().toIntOrNull()
                val p = view.layoutParams as FrameLayout.LayoutParams
                if (w != null && w > 0) p.width = dp(w)
                if (h != null && h > 0) p.height = dp(h)
                view.layoutParams = p
                selectComponent(view)
                updateStatus("Properties applied")
            }
        }
        inspector.addView(apply, fieldParams())

        val duplicate = Button(this).apply {
            text = "Duplicate Component"
            textSize = 11f
            setOnClickListener { duplicateComponent(view) }
        }
        val delete = Button(this).apply {
            text = "Delete Component"
            textSize = 11f
            setOnClickListener { deleteComponent(view) }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(duplicate, weightParams())
        actions.addView(delete, weightParams())
        inspector.addView(actions)
    }

    private fun numberInput(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        tag = value
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#6F7A92"))
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setSingleLine(true)
        setPadding(dp(10), 0, dp(10), 0)
        background = rounded("#151C2B", "#384661", 1)
    }

    private fun duplicateComponent(view: View) {
        val tag = view.tag as? ComponentTag ?: return
        val p = view.layoutParams as FrameLayout.LayoutParams
        val text = (view as? TextView)?.text?.toString()
        pushUndo()
        addComponent(tag.type, p.leftMargin + dp(20), p.topMargin + dp(20), null, text, pxToDp(p.width), pxToDp(p.height))
    }

    private fun deleteComponent(view: View) {
        pushUndo()
        canvas.removeView(view)
        if (selected === view) selected = null
        refreshHierarchy()
        showEmptyInspector()
        updateStatus("Component deleted")
    }

    private fun clearCanvas() {
        if (canvas.childCount == 0) return
        AlertDialog.Builder(this).setTitle("Clear Design?")
            .setMessage("Remove all components from this design?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ -> pushUndo(); canvas.removeAllViews(); selected = null; refreshHierarchy(); showEmptyInspector(); updateStatus("Canvas cleared") }
            .show()
    }

    private fun saveLayout(silent: Boolean) {
        val root = project?.folderPath?.let { File(it) }
        if (root == null) {
            if (!silent) Toast.makeText(this, "Open this builder from a project to save the design.", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(root, "devstudio/ui_layout.dsl")
        file.parentFile?.mkdirs()
        val out = StringBuilder()
        out.append("DEVSTUDIO_UI_V17\n")
        for (i in 0 until canvas.childCount) {
            val child = canvas.getChildAt(i)
            val tag = child.tag as? ComponentTag ?: continue
            val p = child.layoutParams as FrameLayout.LayoutParams
            val text = (child as? TextView)?.text?.toString()?.replace("|", " ")?.replace("\n", " ") ?: ""
            out.append(listOf(tag.id, tag.type, text, p.leftMargin, p.topMargin, pxToDp(p.width), pxToDp(p.height)).joinToString("|"))
            out.append("\n")
        }
        file.writeText(out.toString())
        writeFactoryManifest(root)
        updateStatus("Design saved • $selectedTheme • $selectedBreakpoint • $selectedAnimation")
        if (!silent) Toast.makeText(this, "UI design saved.", Toast.LENGTH_SHORT).show()
    }

    private fun loadLayout() {
        val root = project?.folderPath?.let { File(it) } ?: return
        val file = File(root, "devstudio/ui_layout.dsl")
        if (!file.exists()) return
        try {
            restoreFromLines(file.readLines().drop(1))
            updateStatus("Saved design loaded")
        } catch (e: Exception) {
            updateStatus("Could not load saved design")
        }
    }

    /** Serializes the current canvas into the same line format used by saveLayout(). */
    private fun snapshotLines(): List<String> {
        val lines = mutableListOf<String>()
        for (i in 0 until canvas.childCount) {
            val child = canvas.getChildAt(i)
            val tag = child.tag as? ComponentTag ?: continue
            val p = child.layoutParams as FrameLayout.LayoutParams
            val text = (child as? TextView)?.text?.toString()?.replace("|", " ")?.replace("\n", " ") ?: ""
            lines.add(listOf(tag.id, tag.type, text, p.leftMargin, p.topMargin, pxToDp(p.width), pxToDp(p.height)).joinToString("|"))
        }
        return lines
    }

    /** Rebuilds canvas components from serialized lines (shared by loadLayout() and undo()). */
    private fun restoreFromLines(lines: List<String>) {
        lines.forEach { line ->
            val parts = line.split("|", limit = 7)
            if (parts.size < 7) return@forEach
            val type = parts[1]
            val x = parts[3].toIntOrNull() ?: 0
            val y = parts[4].toIntOrNull() ?: 0
            val w = parts[5].toIntOrNull() ?: 120
            val h = parts[6].toIntOrNull() ?: 48
            addComponent(type, dp(x), dp(y), parts[0], parts[2], w, h)
        }
    }

    /** Call before any user action that mutates the canvas, so Undo can restore the prior state. */
    private fun pushUndo() {
        undoStack.add(snapshotLines())
        if (undoStack.size > maxUndoDepth) undoStack.removeAt(0)
    }

    private fun undo() {
        if (undoStack.isEmpty()) {
            Toast.makeText(this, "Nothing to undo", Toast.LENGTH_SHORT).show()
            return
        }
        val previous = undoStack.removeAt(undoStack.size - 1)
        canvas.removeAllViews()
        selected = null
        restoreFromLines(previous)
        refreshHierarchy()
        showEmptyInspector()
        updateStatus("Undo")
    }

    private fun chooseTheme() {
        val names = uiUxFactory.themes().map { it.id }.toTypedArray()
        AlertDialog.Builder(this).setTitle("UI Theme")
            .setSingleChoiceItems(names, names.indexOf(selectedTheme).coerceAtLeast(0)) { dialog, which ->
                selectedTheme = names[which]
                persistFactoryProfile()
                dialog.dismiss()
                updateStatus("Theme: $selectedTheme")
            }.show()
    }

    private fun chooseMotion() {
        val names = uiUxFactory.animations().map { it.id }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Component Animation")
            .setSingleChoiceItems(names, names.indexOf(selectedAnimation).coerceAtLeast(0)) { dialog, which ->
                selectedAnimation = names[which]
                persistFactoryProfile()
                dialog.dismiss()
                updateStatus("Motion: $selectedAnimation")
            }.show()
    }

    private fun chooseResponsive() {
        val names = uiUxFactory.breakpoints().map { it.id }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Responsive Profile")
            .setSingleChoiceItems(names, names.indexOf(selectedBreakpoint).coerceAtLeast(0)) { dialog, which ->
                selectedBreakpoint = names[which]
                persistFactoryProfile()
                dialog.dismiss()
                updateStatus("Responsive: $selectedBreakpoint")
            }.show()
    }

    private fun persistFactoryProfile() {
        getSharedPreferences("uiux_factory", MODE_PRIVATE).edit()
            .putString("theme", selectedTheme)
            .putString("motion", selectedAnimation)
            .putString("breakpoint", selectedBreakpoint)
            .apply()
        project?.folderPath?.let { writeFactoryManifest(File(it)) }
    }

    private fun loadFactoryProfile() {
        val prefs = getSharedPreferences("uiux_factory", MODE_PRIVATE)
        selectedTheme = prefs.getString("theme", "dark") ?: "dark"
        selectedAnimation = prefs.getString("motion", "scaleIn") ?: "scaleIn"
        selectedBreakpoint = prefs.getString("breakpoint", "medium") ?: "medium"
    }

    private fun writeFactoryManifest(root: File) {
        val file = File(root, "devstudio/uiux/design_manifest.dsl")
        file.parentFile?.mkdirs()
        val out = StringBuilder()
        out.append("DEVSTUDIO_UIUX_V35_STAGE4\n")
        out.append("theme=$selectedTheme\n")
        out.append("motion=$selectedAnimation\n")
        out.append("responsive=$selectedBreakpoint\n")
        out.append("components=${canvas.childCount}\n")
        out.append("factoryValid=${uiUxFactory.validate()}\n")
        file.writeText(out.toString())
    }

    private fun buildGeneratedHtml(): String {
        val builder = StringBuilder()
        builder.append("<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>")
        builder.append(uiUxFactory.css(selectedTheme, selectedAnimation))
        builder.append(".ds-container,.ds-card{padding:12px;border-radius:10px}.ds-row{display:flex;gap:8px}.ds-button,.ds-input{font:inherit}")
        builder.append("</style></head><body><main class=\"ds-root\" data-ds-breakpoint=\"$selectedBreakpoint\" data-ds-theme=\"$selectedTheme\">")
        for (i in 0 until canvas.childCount) {
            val child = canvas.getChildAt(i)
            val tag = child.tag as? ComponentTag ?: continue
            val p = child.layoutParams as FrameLayout.LayoutParams
            val spec = components.firstOrNull { it.type == tag.type } ?: continue
            val content = if (tag.type == "Text" || tag.type == "Button" || tag.type == "Input") {
                val text = (child as? TextView)?.text?.toString() ?: spec.label
                if (tag.type == "Button") "<button class=\"ds-button\" type=\"button\" aria-label=\"${escapeHtml(text)}\">${escapeHtml(text)}</button>"
                else if (tag.type == "Input") "<input class=\"ds-input\" type=\"text\" aria-label=\"${escapeHtml(text)}\" placeholder=\"${escapeHtml(text)}\">"
                else "<h2>${escapeHtml(text)}</h2>"
            } else if (tag.type == "Switch") "<label><input class=\"ds-switch\" type=\"checkbox\" aria-label=\"Switch\"> Switch</label>"
            else if (tag.type == "Checkbox") "<label><input class=\"ds-check\" type=\"checkbox\" aria-label=\"Checkbox\"> Checkbox</label>"
            else if (tag.type == "Progress") "<div class=\"ds-progress\" role=\"progressbar\" aria-valuemin=\"0\" aria-valuemax=\"100\" aria-valuenow=\"50\"></div>"
            else if (tag.type == "Spacer") "<div aria-hidden=\"true\"></div>"
            else spec.html
            builder.append("<div class=\"ds-component ds-animated\" data-ds-id=\"${tag.id}\" data-ds-type=\"${tag.type}\" style=\"left:${pxToDp(p.leftMargin)}px;top:${pxToDp(p.topMargin)}px;width:${pxToDp(p.width)}px;height:${pxToDp(p.height)}px\">$content</div>")
        }
        builder.append("</main></body></html>")
        return builder.toString()
    }

    private fun writeGeneratedHtml(html: String) {
        project?.folderPath?.let { projectPath ->
            DesignCodePreviewBridge.writeGeneratedHtml(File(projectPath), html)
        }
    }

    private fun openGeneratedCode() {
        val root = project?.folderPath?.let { File(it) } ?: return
        val generated = DesignCodePreviewBridge.generatedHtmlFile(root)
        if (!generated.exists()) {
            val html = buildGeneratedHtml()
            writeGeneratedHtml(html)
        }
        WorkspaceSession.update(this, project!!, "code", generated)
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra(EditorActivity.EXTRA_PROJECT_ID, project!!.id)
        i.putExtra(EditorActivity.EXTRA_FILE_PATH, generated.absolutePath)
        startActivity(i)
        updateStatus("Generated HTML opened in Editor")
    }

    private fun generateAndReturn() {
        saveLayout(true)
        val html = buildGeneratedHtml()
        writeGeneratedHtml(html)
        val result = Intent()
        result.putExtra(EXTRA_GENERATED_HTML, html)
        setResult(RESULT_OK, result)
        Toast.makeText(this, "Design generated and saved.", Toast.LENGTH_SHORT).show()
    }

    private fun openLivePreview() {
        val html = buildGeneratedHtml()
        writeGeneratedHtml(html)
        saveLayout(true)
        val i = Intent(this, UiBuilderPreviewActivity::class.java)
        i.putExtra(UiBuilderPreviewActivity.EXTRA_HTML, html)
        i.putExtra(UiBuilderPreviewActivity.EXTRA_PROJECT_DIR, project?.folderPath)
        startActivity(i)
        updateStatus("Live preview opened")
    }

    private fun importGeneratedHtml() {
        val root = project?.folderPath?.let { File(it) }
        if (root == null) {
            Toast.makeText(this, "Open this builder from a project first.", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(root, "devstudio/generated/index.html")
        if (!file.exists()) {
            Toast.makeText(this, "No generated HTML found yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val html = file.readText()
        val regex = Regex("""data-ds-id=\"([^\"]+)\"\s+data-ds-type=\"([^\"]+)\"\s+style=\"([^\"]*)\"[^>]*>(.*?)</div>""", RegexOption.DOT_MATCHES_ALL)
        val imported = mutableListOf<String>()
        for (m in regex.findAll(html)) {
            val id = m.groupValues[1]
            val type = m.groupValues[2]
            val style = m.groupValues[3]
            val x = Regex("left:([0-9]+)px").find(style)?.groupValues?.get(1)?.toIntOrNull() ?: 20
            val y = Regex("top:([0-9]+)px").find(style)?.groupValues?.get(1)?.toIntOrNull() ?: 20
            val w = Regex("width:([0-9]+)px").find(style)?.groupValues?.get(1)?.toIntOrNull() ?: 120
            val h = Regex("height:([0-9]+)px").find(style)?.groupValues?.get(1)?.toIntOrNull() ?: 48
            val raw = m.groupValues[4].replace(Regex("<[^>]+>"), "").trim()
            val text = raw.replace("&quot;", "\"").replace("&gt;", ">")
                .replace("&lt;", "<").replace("&amp;", "&")
            imported.add(listOf(id, type, text, x, y, w, h).joinToString("|"))
        }
        if (imported.isEmpty()) {
            Toast.makeText(this, "No DEVSTUDIO components found in HTML.", Toast.LENGTH_SHORT).show()
            return
        }
        pushUndo()
        canvas.removeAllViews()
        selected = null
        restoreFromLines(imported)
        refreshHierarchy()
        showEmptyInspector()
        saveLayout(true)
        updateStatus("HTML imported into Design Canvas")
        Toast.makeText(this, "Generated HTML imported.", Toast.LENGTH_SHORT).show()
    }

    private fun escapeHtml(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun section(text: String): TextView = TextView(this).apply { this.text = text; setTextColor(Color.parseColor("#B47CFF")); textSize = 11f; setPadding(dp(4), dp(6), dp(4), dp(6)) }
    private fun label(text: String): TextView = TextView(this).apply { this.text = text; setTextColor(Color.parseColor("#77829C")); textSize = 11f; setPadding(dp(4), dp(6), dp(4), dp(6)) }
    private fun fieldParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { setMargins(0, dp(4), 0, dp(4)) }
    private fun weightParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    private fun componentDefaultWidth(type: String): Int = when (type) { "Button" -> dp(130); "Input" -> dp(190); "Image" -> dp(150); "Card" -> dp(210); else -> dp(150) }
    private fun componentDefaultHeight(type: String): Int = when (type) { "Input" -> dp(48); "Image" -> dp(100); "Card" -> dp(110); "Divider" -> dp(24); else -> dp(48) }
    private fun rounded(fill: String, stroke: String, width: Int): GradientDrawable = GradientDrawable().apply { setColor(Color.parseColor(fill)); cornerRadius = dp(8).toFloat(); setStroke(dp(width), Color.parseColor(stroke)) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt().coerceAtLeast(1)
    private fun pxToDp(v: Int): Int = (v / resources.displayMetrics.density).toInt().coerceAtLeast(1)
    private fun updateStatus(text: String) { status.text = if (project == null) "$text • No project" else "$text • ${project!!.name}" }

    private data class ComponentTag(val id: String, val type: String)

    companion object {
        const val EXTRA_GENERATED_HTML = "extra_generated_html"
        const val REQUEST_CODE = 4201
        const val EXTRA_PROJECT_ID = "extra_ui_builder_project_id"
    }
}
