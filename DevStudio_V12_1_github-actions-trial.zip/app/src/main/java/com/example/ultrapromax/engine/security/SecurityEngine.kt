package com.example.ultrapromax.engine.security

import java.io.File
import java.security.MessageDigest

/** Security primitives: canonical sandbox checks, checksums and verified file-level healing.
 * Periodic snapshots are governed by WorkspaceSnapshotScheduler and executed by the host workflow. */
object SecurityEngine {

    fun isInsideSandbox(root: File, target: File): Boolean {
        val rootPath = root.canonicalFile.path
        val targetPath = target.canonicalFile.path
        return targetPath == rootPath || targetPath.startsWith(rootPath + File.separator)
    }

    fun checksum(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } != -1) {
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * If [file]'s checksum differs from [knownGoodChecksum], extract just that
     * file's bytes back out of [backupZip] and overwrite it. Returns true if a
     * heal happened.
     */
    fun selfHealIfNeeded(
        file: File,
        knownGoodChecksum: String,
        backupZip: File,
        relativePathInZip: String
    ): Boolean {
        if (!file.exists() || checksum(file) == knownGoodChecksum) return false

        java.util.zip.ZipInputStream(backupZip.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name == relativePathInZip) {
                    file.outputStream().use { out -> zis.copyTo(out) }
                    return true
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return false
    }

    fun checksumBytes(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(bytes).joinToString("") { "%02x".format(it) }
    }
}
