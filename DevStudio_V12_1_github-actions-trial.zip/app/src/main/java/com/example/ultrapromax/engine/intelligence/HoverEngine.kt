package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.language.symbol.SymbolIndex

class HoverEngine(private val index: SymbolIndex) {
    fun info(name: String): String? {
        val symbol = index.allSymbols().firstOrNull { it.name == name.trim() } ?: return null
        return format(symbol)
    }

    fun info(symbol: Symbol): String = format(symbol)

    private fun format(symbol: Symbol): String {
        val kind = symbol.kind.name.toLowerCase()
        val signature = symbol.signature
        val location = symbol.filePath ?: "buffer"
        return if (signature.isNullOrEmpty()) {
            "$kind ${symbol.name}\n$location:${symbol.line}:${symbol.column}"
        } else {
            "$kind ${symbol.name}\n$signature\n$location:${symbol.line}:${symbol.column}"
        }
    }
}
