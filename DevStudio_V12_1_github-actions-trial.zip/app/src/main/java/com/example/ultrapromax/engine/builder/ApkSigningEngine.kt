package com.example.ultrapromax.engine.builder

import java.io.File

/** Local APK signing bridge. Uses an existing apksigner + keystore; never fakes a signed APK. */
class ApkSigningEngine {
    data class Result(val success: Boolean, val apk: File?, val output: String)

    fun sign(apk: File, keystore: File, alias: String, storePassword: String, keyPassword: String): Result {
        if (!apk.isFile) return Result(false, null, "APK not found")
        if (!keystore.isFile) return Result(false, null, "Keystore not found")
        val signer = findExecutable("apksigner") ?: return Result(false, null, "apksigner is not available on this device")
        val command = listOf(signer.absolutePath, "sign", "--ks", keystore.absolutePath, "--ks-key-alias", alias,
            "--ks-pass", "pass:$storePassword", "--key-pass", "pass:$keyPassword", apk.absolutePath)
        return run(command, apk)
    }

    private fun findExecutable(name: String): File? {
        val candidates = listOf("/usr/bin/$name", "/system/bin/$name", "/data/data/com.itsaky.androidide/files/usr/bin/$name")
        return candidates.map { File(it) }.firstOrNull { it.canExecute() }
    }

    private fun run(command: List<String>, apk: File): Result {
        return try {
            val p = ProcessBuilder(command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().use { it.readText() }
            val code = p.waitFor()
            Result(code == 0, if (code == 0) apk else null, out)
        } catch (e: Exception) {
            Result(false, null, e.message ?: "Signing failed")
        }
    }
}
