package com.example.ultrapromax.engine.languagecatalog

/**
 * V32 first-class offline language catalog.
 * This catalog describes product-level language support; actual compiler/runtime
 * readiness remains governed by the runtime contract engine.
 */
object FirstClassLanguageCatalog {
    data class Entry(
        val id: String,
        val name: String,
        val category: String,
        val extensions: List<String>,
        val editor: Boolean = true,
        val projectSupport: Boolean = true,
        val diagnostics: Boolean = true,
        val runIntegration: Boolean = true,
        val buildIntegration: Boolean = true
    )

    val all: List<Entry> = listOf(
        Entry("kotlin", "Kotlin", "JVM/Android", listOf("kt", "kts")),
        Entry("kotlin-script", "Kotlin Script", "Build/Scripting", listOf("kts")),
        Entry("java", "Java", "JVM/Android", listOf("java")),
        Entry("python", "Python 3", "Scripting/AI", listOf("py", "pyw")),
        Entry("c", "C", "Native/Systems", listOf("c", "h")),
        Entry("cpp", "C++", "Native/Games", listOf("cpp", "cc", "cxx", "hpp", "hh", "hxx")),
        Entry("dart", "Dart", "Application", listOf("dart")),
        Entry("flutter", "Flutter", "Cross-platform UI", listOf("dart")),
        Entry("javascript", "JavaScript", "Web/Runtime", listOf("js", "mjs", "cjs")),
        Entry("typescript", "TypeScript", "Web/Backend", listOf("ts", "tsx")),
        Entry("html", "HTML", "Web", listOf("html", "htm")),
        Entry("css", "CSS", "Web/UI", listOf("css", "scss", "sass")),
        Entry("csharp", "C#", ".NET", listOf("cs")),
        Entry("go", "Go", "Server/Systems", listOf("go")),
        Entry("rust", "Rust", "Systems/Security", listOf("rs")),
        Entry("php", "PHP", "Web/Backend", listOf("php")),
        Entry("sql", "SQL", "Database", listOf("sql")),
        Entry("shell", "Shell", "Automation/DevOps", listOf("sh", "bash")),
        Entry("swift", "Swift", "Apple", listOf("swift")),
        Entry("ruby", "Ruby", "Web/Scripting", listOf("rb"))
    )

    fun byId(id: String): Entry? = all.firstOrNull { it.id == id.toLowerCase() }

    fun fromExtension(extension: String): Entry? {
        val ext = extension.removePrefix(".").toLowerCase()
        return all.firstOrNull { ext in it.extensions }
    }
}
