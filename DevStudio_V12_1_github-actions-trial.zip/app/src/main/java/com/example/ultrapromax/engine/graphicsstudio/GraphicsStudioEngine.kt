package com.example.ultrapromax.engine.graphicsstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import java.io.File
import java.io.FileOutputStream

/** Offline graphics document engine: raster canvas + deterministic SVG export. */
class GraphicsStudioEngine(private val projectRoot: File) {
    data class Document(val width: Int, val height: Int, val background: Int)

    fun document(width: Int, height: Int, background: Int): Document = Document(width, height, background)

    fun savePng(bitmap: Bitmap, name: String): File {
        val dir = File(projectRoot, ".devstudio/graphics")
        if (!dir.exists()) dir.mkdirs()
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val file = File(dir, if (safe.endsWith(".png")) safe else "$safe.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return file
    }

    fun saveSvg(width: Int, height: Int, background: Int, commands: List<String>, name: String): File {
        val dir = File(projectRoot, ".devstudio/graphics")
        if (!dir.exists()) dir.mkdirs()
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val file = File(dir, if (safe.endsWith(".svg")) safe else "$safe.svg")
        val out = StringBuilder()
        out.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        out.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(width).append("\" height=\"").append(height).append("\" viewBox=\"0 0 ").append(width).append(" ").append(height).append("\">\n")
        out.append("<rect width=\"100%\" height=\"100%\" fill=\"").append(colorHex(background)).append("\"/>\n")
        commands.forEach { out.append(it).append('\n') }
        out.append("</svg>\n")
        file.writeText(out.toString(), Charsets.UTF_8)
        return file
    }

    fun colorHex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)

    fun svgPath(points: List<Pair<Float, Float>>, color: Int, stroke: Float): String {
        if (points.isEmpty()) return ""
        val d = StringBuilder("M ").append(points[0].first).append(' ').append(points[0].second)
        for (i in 1 until points.size) d.append(" L ").append(points[i].first).append(' ').append(points[i].second)
        return "<path d=\"$d\" fill=\"none\" stroke=\"${colorHex(color)}\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
    }

    fun svgLine(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, stroke: Float): String =
        "<line x1=\"$x1\" y1=\"$y1\" x2=\"$x2\" y2=\"$y2\" stroke=\"${colorHex(color)}\" stroke-width=\"$stroke\" stroke-linecap=\"round\"/>"

    fun svgRect(l: Float, t: Float, r: Float, b: Float, color: Int, stroke: Float, fill: Boolean): String =
        "<rect x=\"$l\" y=\"$t\" width=\"${r-l}\" height=\"${b-t}\" ${if (fill) "fill=\"${colorHex(color)}\" stroke=\"none\"" else "fill=\"none\" stroke=\"${colorHex(color)}\" stroke-width=\"$stroke\""}/>"

    fun svgCircle(cx: Float, cy: Float, radius: Float, color: Int, stroke: Float, fill: Boolean): String =
        "<circle cx=\"$cx\" cy=\"$cy\" r=\"$radius\" ${if (fill) "fill=\"${colorHex(color)}\" stroke=\"none\"" else "fill=\"none\" stroke=\"${colorHex(color)}\" stroke-width=\"$stroke\""}/>"
}
