package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.LanguageRegistry

class CodeActionEngine {
    data class CodeAction(val id: String, val title: String, val kind: String)

    fun actionsFor(fileName: String, source: String, line: Int): List<CodeAction> {
        val result = ArrayList<CodeAction>()
        if (LanguageRegistry.detect(fileName) == null) return result
        if (line < 1) return result
        result.add(CodeAction("format_line", "Format current line", "source.format"))
        if (source.isNotEmpty()) result.add(CodeAction("organize_symbols", "Refresh symbols", "source.symbols"))
        return result
    }
}
