package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import java.io.File

/** Lightweight offline preview for the visual builder. */
class UiBuilderPreviewActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var watch: Runnable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ui_builder_preview)
        findViewById<TextView>(R.id.btnClosePreview).setOnClickListener { finish() }
        val projectDirPath = intent.getStringExtra(EXTRA_PROJECT_DIR)
        val projectDir = projectDirPath?.let { File(it) }
        val generated = projectDir?.let { File(it, "devstudio/generated/index.html") }
        val html = if (generated != null && generated.exists()) generated.readText() else (intent.getStringExtra(EXTRA_HTML) ?: "<html><body></body></html>")
        val webView = findViewById<WebView>(R.id.builderPreviewWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.setBackgroundColor(Color.rgb(11, 15, 23))
        webView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
        if (generated != null) {
            var lastModified = generated.lastModified()
            val task = object : Runnable {
                override fun run() {
                    if (generated.exists()) {
                        val modified = generated.lastModified()
                        if (modified != lastModified) {
                            lastModified = modified
                            webView.loadDataWithBaseURL("file:///android_asset/", generated.readText(), "text/html", "UTF-8", null)
                        }
                    }
                    handler.postDelayed(this, 500L)
                }
            }
            watch = task
            handler.postDelayed(task, 500L)
        }
    }
    override fun onDestroy() {
        watch?.let { handler.removeCallbacks(it) }
        watch = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_HTML = "extra_builder_html"
        const val EXTRA_PROJECT_DIR = "extra_builder_project_dir"
    }
}
