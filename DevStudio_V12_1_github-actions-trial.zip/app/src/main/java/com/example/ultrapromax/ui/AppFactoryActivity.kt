package com.example.ultrapromax.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.appfactory.AppFactoryEngine
import com.example.ultrapromax.engine.appfactory.AppFactoryProductionEngine
import com.example.ultrapromax.data.ProjectStore

class AppFactoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_factory)
        val engine = AppFactoryEngine(this)
        val container = findViewById<LinearLayout>(R.id.factoryProfiles)
        findViewById<Button>(R.id.btnFactoryBack).setOnClickListener { finish() }
        engine.profiles().forEach { profile ->
            val button = Button(this)
            button.text = "${profile.title}\n${profile.description}"
            button.setAllCaps(false)
            button.setTextColor(getColor(R.color.text_primary))
            button.setOnClickListener { openProfile(profile.kind) }
            container.addView(button)
        }
        findViewById<Button>(R.id.btnFactoryCoreAudit).setOnClickListener {
            val projects = ProjectStore.list(this)
            if (projects.isEmpty()) {
                findViewById<TextView>(R.id.factoryStatus).text = "APP FACTORY CORE • READY\nNo generated project exists yet. Create an Android project, then run this audit."
            } else {
                val project = projects.first()
                val report = AppFactoryProductionEngine(this).audit(java.io.File(project.folderPath))
                val header = "APP FACTORY CORE • ${if (report.ok) "PASS" else "BLOCKED"}\nPROJECT • ${project.name}\n\n"
                val body = report.checks.joinToString("\n") { "${if (it.ok) "✓" else "✗"} ${it.name} • ${it.details}" }
                findViewById<TextView>(R.id.factoryStatus).text = header + body
            }
        }

        findViewById<Button>(R.id.btnFactoryCheck).setOnClickListener {
            val lines = engine.profiles().map { p ->
                val r = engine.readiness(p.kind)
                "${p.title}: ${if (r.ready) "READY" else "MISSING"} • ${r.details}"
            }
            findViewById<TextView>(R.id.factoryStatus).text = lines.joinToString("\n\n")
        }
    }

    private fun openProfile(kind: AppFactoryEngine.Kind) {
        when (kind) {
            AppFactoryEngine.Kind.ANDROID -> startActivity(Intent(this, AdvancedNewProjectActivity::class.java))
            AppFactoryEngine.Kind.WEB -> startActivity(Intent(this, AdvancedNewProjectActivity::class.java).putExtra(AdvancedNewProjectActivity.EXTRA_TEMPLATE_ID, "html_css_js"))
            else -> findViewById<TextView>(R.id.factoryStatus).text = "PROFILE SELECTED • ${kind.name}\nSelect the language/runtime inside the project workflow."
        }
    }
}
