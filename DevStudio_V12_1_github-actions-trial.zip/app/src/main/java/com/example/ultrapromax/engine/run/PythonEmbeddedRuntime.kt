package com.example.ultrapromax.engine.run

import java.io.File

/**
 * Android embedded-Python bridge contract.
 *
 * Android Python is not launched as a desktop `python` executable. A real pack
 * must provide libpython + the standard library + DEVSTUDIO's JNI bridge.
 * This class deliberately refuses to report success until that bridge exists.
 */
class PythonEmbeddedRuntime(private val runtimeDir: File) {

    data class Check(
        val ready: Boolean,
        val message: String,
        val pythonHome: File? = null,
        val bridge: File? = null
    )

    fun check(): Check {
        if (!runtimeDir.isDirectory) {
            return Check(false, "Python embedded runtime pack is not installed.")
        }

        val home = File(runtimeDir, "python")
        val libDir = File(home, "lib")
        val bridge = File(runtimeDir, "lib/libdevstudio_python_bridge.so")
        val hasPythonLib = libDir.listFiles()?.any {
            it.isFile && it.name.startsWith("libpython") && it.name.endsWith(".so")
        } == true
        val hasStdlib = libDir.listFiles()?.any {
            it.isDirectory && it.name.startsWith("python3.")
        } == true

        if (!hasPythonLib) return Check(false, "Python pack is missing libpython.")
        if (!hasStdlib) return Check(false, "Python pack is missing the Python standard library.")
        if (!bridge.isFile) return Check(false, "Python pack is missing the DEVSTUDIO JNI bridge.")

        return Check(true, "Python embedded runtime is ready.", home, bridge)
    }

    fun run(script: File, workingDir: File): Result {
        val check = check()
        if (!check.ready || check.pythonHome == null || check.bridge == null) {
            return Result(false, check.message)
        }
        return try {
            System.load(check.bridge.absolutePath)
            val output = NativeBridge.run(
                check.pythonHome.absolutePath,
                script.absolutePath,
                workingDir.absolutePath
            )
            Result(true, output)
        } catch (e: Throwable) {
            Result(false, "Python embedded runtime failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    data class Result(val success: Boolean, val output: String)

    private object NativeBridge {
        external fun run(pythonHome: String, script: String, workingDir: String): String
    }
}
