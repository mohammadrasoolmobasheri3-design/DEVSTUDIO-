package com.example.ultrapromax.engine.buildrun

import java.io.File

/** Tracks real run/build sessions without pretending a missing runtime exists. */
class RunSessionEngine(private val root: File) {
    data class Session(
        val id: String,
        val projectPath: String,
        val filePath: String,
        val language: String,
        val mode: String,
        val startedAt: Long,
        val finishedAt: Long,
        val success: Boolean,
        val output: String
    )

    private fun file(id: String): File = File(root, "sessions/$id.txt")

    fun record(session: Session): Boolean {
        return try {
            file(session.id).parentFile?.mkdirs()
            val f = file(session.id)
            val text = listOf(
                session.id,
                session.projectPath,
                session.filePath,
                session.language,
                session.mode,
                session.startedAt.toString(),
                session.finishedAt.toString(),
                session.success.toString(),
                session.output
            ).joinToString("\n")
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(text)
            if (f.exists()) f.delete()
            tmp.renameTo(f)
        } catch (_: Exception) { false }
    }

    fun list(): List<Session> {
        val dir = File(root, "sessions")
        val files = dir.listFiles() ?: return emptyList()
        return files.filter { it.isFile && it.extension == "txt" }
            .sortedByDescending { it.lastModified() }
            .mapNotNull { read(it) }
    }

    fun clear() {
        File(root, "sessions").deleteRecursively()
    }

    private fun read(f: File): Session? {
        return try {
            val p = f.readLines()
            if (p.size < 9) return null
            Session(p[0], p[1], p[2], p[3], p[4], p[5].toLong(), p[6].toLong(), p[7].toBoolean(), p.drop(8).joinToString("\n"))
        } catch (_: Exception) { null }
    }
}
