package com.example.ultrapromax.nextupdate.ai.tools

interface AiTool {
    val id: String
    val requiresApproval: Boolean
    fun execute(input: String): ToolResult
}

data class ToolResult(
    val success: Boolean,
    val output: String,
    val changed: Boolean = false
)
