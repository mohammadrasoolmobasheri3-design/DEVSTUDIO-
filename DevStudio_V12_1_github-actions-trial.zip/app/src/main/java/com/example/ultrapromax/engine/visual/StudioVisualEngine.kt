package com.example.ultrapromax.engine.visual

import android.graphics.Color
import com.example.ultrapromax.engine.theme.ThemeId
import com.example.ultrapromax.engine.theme.ThemePalette
import com.example.ultrapromax.engine.theme.ThemeEngine

/** V30 visual system: shared palette, glass and motion metadata for Studio UI. */
class StudioVisualEngine {
    enum class Surface { FLAT, GLASS, ELEVATED }
    enum class Motion { NONE, SUBTLE, STANDARD }

    data class VisualProfile(
        val theme: ThemeId,
        val palette: ThemePalette,
        val surface: Surface,
        val motion: Motion,
        val cornerRadiusDp: Float,
        val elevationDp: Float
    )

    fun profile(theme: ThemeId = ThemeId.CYBERPUNK): VisualProfile {
        return VisualProfile(
            theme = theme,
            palette = ThemeEngine.paletteFor(theme),
            surface = Surface.GLASS,
            motion = Motion.STANDARD,
            cornerRadiusDp = 14f,
            elevationDp = 8f
        )
    }

    fun blend(base: Int, overlay: Int, amount: Float): Int {
        val a = if (amount < 0f) 0f else if (amount > 1f) 1f else amount
        val r = (Color.red(base) * (1f - a) + Color.red(overlay) * a).toInt()
        val g = (Color.green(base) * (1f - a) + Color.green(overlay) * a).toInt()
        val b = (Color.blue(base) * (1f - a) + Color.blue(overlay) * a).toInt()
        return Color.rgb(r, g, b)
    }
}
