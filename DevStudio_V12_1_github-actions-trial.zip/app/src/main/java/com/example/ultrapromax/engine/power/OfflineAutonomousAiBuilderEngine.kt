package com.example.ultrapromax.engine.power

import android.content.Context
import com.example.ultrapromax.engine.ai.OfflineAiAppBuilderEngine
import com.example.ultrapromax.engine.ai.OfflineAiFeaturePlannerEngine
import java.io.File

/**
 * Offline autonomous build orchestrator: prompt -> feature plan -> real project generation -> verification.
 * It performs deterministic local actions and records every action for audit/recovery.
 */
class OfflineAutonomousAiBuilderEngine(private val context: Context) {
    data class Step(val name: String, val ok: Boolean, val detail: String)
    data class Result(val success: Boolean, val projectDir: File?, val steps: List<Step>)

    fun generate(prompt: String): Result {
        val steps = ArrayList<Step>()
        val p = prompt.trim()
        if (p.isEmpty()) return Result(false, null, listOf(Step("prompt", false, "Prompt is empty")))
        return try {
            val planner = OfflineAiFeaturePlannerEngine()
            val features = planner.plan(p)
            steps += Step("plan", features.isNotEmpty(), "${features.size} local features: ${features.joinToString { it.id }}")
            val engine = OfflineAiAppBuilderEngine(context)
            val result = engine.generate(p)
            steps += Step("generate", result.success, result.log.joinToString("\n"))
            val root = result.projectDir
            val valid = result.success && root != null && root.isDirectory && root.walkTopDown().any { it.isFile }
            steps += Step("verify", valid, if (valid) "Generated project contains real files" else "Generated project verification failed")
            if (valid) File(root, ".devstudio-autonomous-audit").writeText(
                "offline=true\nfeatures=${features.joinToString(",") { it.id }}\nsteps=${steps.size + 1}\n"
            )
            Result(valid, root, steps)
        } catch (e: Exception) {
            Result(false, null, steps + Step("exception", false, e.message ?: e.javaClass.simpleName))
        }
    }
}
