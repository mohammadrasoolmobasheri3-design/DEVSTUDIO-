package com.example.ultrapromax.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.engine.plugin.BuiltInPlugins
import com.example.ultrapromax.engine.plugin.ExtensionPlatformEngine
import com.example.ultrapromax.engine.plugin.ExtensionPermissionEngine
import com.example.ultrapromax.engine.plugin.LocalPluginCatalogEngine
import com.example.ultrapromax.engine.plugin.Plugin
import com.example.ultrapromax.engine.plugin.PluginManager
import com.example.ultrapromax.engine.plugin.PluginPackageInstaller
import com.example.ultrapromax.engine.plugin.PluginPackageRuntime
import com.example.ultrapromax.engine.plugin.PluginPermission
import com.example.ultrapromax.engine.theme.ThemeEngine
import java.io.File

/**
 * V30.1.0 Stage 17 — Plugin OS.
 *
 * Offline-first plugin/extension center. Built-in plugins run in-process;
 * imported packages are declarative and are never loaded as arbitrary DEX/JAR.
 */
class PluginsActivity : AppCompatActivity() {

    companion object { const val REQUEST_PLUGIN = 401 }

    private lateinit var manager: PluginManager
    private lateinit var extensionEngine: ExtensionPlatformEngine
    private lateinit var permissionEngine: ExtensionPermissionEngine
    private lateinit var packageRuntime: PluginPackageRuntime
    private lateinit var localRoot: File
    private lateinit var content: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeEngine.applyTo(this)

        manager = PluginManager(this)
        manager.reloadBuiltIns()
        extensionEngine = ExtensionPlatformEngine(this)
        permissionEngine = ExtensionPermissionEngine(this)
        packageRuntime = PluginPackageRuntime()
        localRoot = File(filesDir, "plugins")
        if (!localRoot.exists()) localRoot.mkdirs()

        buildUi()
        refreshUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = resources.getDrawable(com.example.ultrapromax.R.drawable.studio_background)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = resources.getDrawable(com.example.ultrapromax.R.drawable.studio_panel)
        }
        val title = TextView(this).apply {
            text = "PLUGIN OS"
            textSize = 19f
            setTextColor(Color.parseColor("#B47CFF"))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        summary = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#9AA4C0"))
            setPadding(0, dp(4), 0, 0)
        }
        header.addView(title)
        header.addView(summary)
        root.addView(header)

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        toolbar.addView(actionButton("IMPORT", Color.parseColor("#00E5FF")) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
            }, REQUEST_PLUGIN)
        })
        toolbar.addView(actionButton("DISABLE ALL", Color.parseColor("#FFB74D")) {
            manager.all().forEach { plugin -> manager.setEnabled(this, plugin, false) }
            extensionEngine.disableAll()
            refreshUi()
        })
        toolbar.addView(actionButton("REFRESH", Color.parseColor("#7CFF9B")) { refreshUi() })
        toolbar.addView(actionButton("COMPILE", Color.parseColor("#B47CFF")) {
            startActivity(Intent(this, PluginCompilerActivity::class.java))
        })
        root.addView(toolbar)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun refreshUi() {
        manager.reloadBuiltIns()
        extensionEngine.discover(localRoot)
        content.removeAllViews()

        summary.text = "Built-in: ${manager.all().size} • Enabled: ${manager.enabledCount()} • Local packages: ${extensionEngine.all().size} • OFFLINE"

        addSection("BUILT-IN PLUGINS")
        manager.all().forEach { addBuiltInCard(it) }

        addSection("LOCAL EXTENSIONS")
        val records = extensionEngine.all()
        if (records.isEmpty()) {
            addInfo("No imported extensions yet. Import a validated .zip package to add one.")
        } else {
            records.forEach { record -> addExtensionCard(record) }
        }
    }

    private fun addBuiltInCard(plugin: Plugin) {
        val card = card()
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply {
            text = plugin.displayName + "\n" + plugin.description
            textSize = 12f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val toggle = Switch(this).apply {
            isChecked = manager.isEnabled(plugin)
            setOnCheckedChangeListener { _, checked -> manager.setEnabled(this@PluginsActivity, plugin, checked) }
        }
        row.addView(label)
        row.addView(toggle)
        body.addView(row)
        val permissions = TextView(this).apply {
            text = "Permissions: " + plugin.permissions.joinToString { it.name }
            textSize = 10f
            setTextColor(Color.parseColor("#9AA4C0"))
            setPadding(0, dp(7), 0, 0)
        }
        body.addView(permissions)
        card.addView(body)
        content.addView(card)
    }

    private fun addExtensionCard(record: com.example.ultrapromax.engine.plugin.ExtensionRecord) {
        val card = card()
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val d = record.descriptor
        val status = record.state.name
        val title = TextView(this).apply {
            text = "${d.name}  v${d.version}\n${d.description}\nID: ${d.id}\nState: $status"
            textSize = 12f
            setTextColor(if (status == "INVALID" || status == "BLOCKED") Color.parseColor("#FF6B7A") else Color.WHITE)
        }
        body.addView(title)

        val permissions = TextView(this).apply {
            text = "Permissions: " + if (d.permissions.isEmpty()) "none" else d.permissions.joinToString { it.name }
            textSize = 10f
            setTextColor(Color.parseColor("#9AA4C0"))
            setPadding(0, dp(7), 0, dp(4))
        }
        body.addView(permissions)

        if (record.error.isNotEmpty()) {
            val error = TextView(this).apply {
                text = "⚠ ${record.error}"
                textSize = 10f
                setTextColor(Color.parseColor("#FF6B7A"))
            }
            body.addView(error)
        }

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (record.state != com.example.ultrapromax.engine.plugin.ExtensionState.INVALID) {
            buttons.addView(actionButton(if (record.state == com.example.ultrapromax.engine.plugin.ExtensionState.ENABLED) "DISABLE" else "ENABLE", Color.parseColor("#7CFF9B")) {
                val enabled = record.state != com.example.ultrapromax.engine.plugin.ExtensionState.ENABLED
                if (!extensionEngine.setEnabled(d.id, enabled)) {
                    Toast.makeText(this, "Extension could not be enabled", Toast.LENGTH_SHORT).show()
                }
                refreshUi()
            })
        }
        buttons.addView(actionButton("PERMISSIONS", Color.parseColor("#B47CFF")) { showPermissions(d) })
        buttons.addView(actionButton("ACTIONS", Color.parseColor("#00E5FF")) { showActions(d.sourceFile?.parentFile) })
        buttons.addView(actionButton("REMOVE", Color.parseColor("#FF6B7A")) { removeExtension(d.id) })
        body.addView(buttons)
        card.addView(body)
        content.addView(card)
    }

    private fun showPermissions(d: com.example.ultrapromax.engine.plugin.ExtensionDescriptor) {
        if (d.permissions.isEmpty()) {
            Toast.makeText(this, "This extension requests no permissions", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = d.permissions.map { it.name }.toTypedArray()
        val checked = BooleanArray(labels.size) { permissionEngine.isGranted(d.id, d.permissions.elementAt(it)) }
        AlertDialog.Builder(this)
            .setTitle("Permissions • ${d.name}")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                val permission = d.permissions.elementAt(which)
                if (isChecked) permissionEngine.grant(d.id, permission) else permissionEngine.revoke(d.id, permission)
            }
            .setPositiveButton("DONE", null)
            .show()
    }

    private fun showActions(packageDir: File?) {
        if (packageDir == null || !packageDir.isDirectory) return
        val actions = packageRuntime.actions(packageDir)
        if (actions.isEmpty()) {
            Toast.makeText(this, "No declared actions", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Extension Actions")
            .setItems(actions.toTypedArray()) { _, which ->
                val result = packageRuntime.execute(packageDir, actions[which])
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun removeExtension(id: String) {
        AlertDialog.Builder(this)
            .setTitle("Remove extension?")
            .setMessage(id)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("REMOVE") { _, _ ->
                val dir = File(localRoot, id).canonicalFile
                val root = localRoot.canonicalFile
                if (dir.absolutePath.startsWith(root.absolutePath + File.separator)) {
                    deleteRecursively(dir)
                }
                permissionEngine.revokeAll(com.example.ultrapromax.engine.plugin.ExtensionDescriptor(id, id, "", "", "", emptySet(), emptyList(), null))
                refreshUi()
            }
            .show()
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteRecursively(it) }
        file.delete()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PLUGIN || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val incoming = File(cacheDir, "plugin_import_${System.currentTimeMillis()}.zip")
            contentResolver.openInputStream(uri)?.use { input -> incoming.outputStream().use { output -> input.copyTo(output) } }
            if (!LocalPluginCatalogEngine().validatePackage(incoming)) {
                incoming.delete()
                Toast.makeText(this, "Invalid Plugin OS package", Toast.LENGTH_LONG).show()
                return
            }
            val result = PluginPackageInstaller().install(incoming, localRoot)
            incoming.delete()
            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
            refreshUi()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Plugin import failed", Toast.LENGTH_LONG).show()
        }
    }

    private fun addSection(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(dp(4), dp(12), dp(4), dp(8))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
    }

    private fun addInfo(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(Color.parseColor("#9AA4C0"))
            setPadding(dp(8), dp(8), dp(8), dp(14))
        })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#33151C2B"))
            cornerRadius = dp(12).toFloat()
            setStroke(1, Color.parseColor("#406E5CFF"))
        }
        background = bg
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 0, 0, dp(10))
        layoutParams = p
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 9f
        setTextColor(color)
        setOnClickListener { click() }
        minHeight = 0
        minimumHeight = dp(36)
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
