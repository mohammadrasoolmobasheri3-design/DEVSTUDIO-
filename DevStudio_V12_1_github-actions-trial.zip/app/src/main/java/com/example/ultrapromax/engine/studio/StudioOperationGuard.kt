package com.example.ultrapromax.engine.studio

/** Serializes destructive/expensive Studio operations without threads or external services. */
class StudioOperationGuard {
    enum class Operation { SAVE, PREVIEW, RUN, BUILD, INSTALL, AI_EDIT, RECOVERY }
    data class Token(val operation: Operation, val startedAt: Long, val id: Long)

    @Volatile private var active: Token? = null

    @Synchronized fun tryAcquire(operation: Operation): Token? {
        if (active != null) return null
        val token = Token(operation, System.currentTimeMillis(), System.nanoTime())
        active = token
        return token
    }

    @Synchronized fun release(token: Token) {
        if (active?.id == token.id) active = null
    }

    @Synchronized fun cancel(token: Token): Boolean {
        if (active?.id != token.id) return false
        active = null
        return true
    }

    fun current(): Token? = active
    fun isBusy(): Boolean = active != null
}
