package com.example.ultrapromax.engine.offline

import android.content.Context
import java.io.File

/** V30.1.0 Stage 23 — central registry for on-device/local services. */
class LocalServicesEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("devstudio_local_services", Context.MODE_PRIVATE)

    data class ServiceInfo(val id: String, val title: String, val detail: String, val enabled: Boolean)

    fun services(): List<ServiceInfo> = listOf(
        ServiceInfo("mini_server", "Mini Server", "HTTP + WebSocket on 127.0.0.1 only", enabled("mini_server", true)),
        ServiceInfo("preview", "Offline Preview", "Local HTML/CSS/JS WebView preview", enabled("preview", true)),
        ServiceInfo("workspace", "Workspace Store", "Local project/session state", enabled("workspace", true)),
        ServiceInfo("cache", "Local Cache", "App-private cache and temporary build data", enabled("cache", true))
    )

    fun setEnabled(id: String, value: Boolean) {
        prefs.edit().putBoolean(id, value).apply()
    }

    fun isEnabled(id: String): Boolean = enabled(id, true)

    fun localRoot(): File = context.filesDir
    fun cacheRoot(): File = context.cacheDir

    fun summary(): String {
        val list = services()
        val active = list.count { it.enabled }
        return "$active/${list.size} local services enabled • external network remains policy-controlled"
    }

    fun storageSummary(): String {
        return "Files: ${human(localRoot().length())} • Cache: ${human(cacheRoot().length())}"
    }

    private fun enabled(id: String, defaultValue: Boolean): Boolean = prefs.getBoolean(id, defaultValue)

    private fun human(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        if (bytes < 1024L * 1024L) return "${bytes / 1024L} KB"
        return "${bytes / (1024L * 1024L)} MB"
    }
}
