package com.example.ultrapromax.engine.ai

/** Lightweight offline lexical parser shared by AI, diagnostics and formatting. */
class CodeStructureEngine {
    data class Scan(val braces: Int, val brackets: Int, val parens: Int, val tags: List<String>, val lines: Int, val safe: Boolean)

    fun scan(text: String, language: String): Scan {
        var braces = 0; var brackets = 0; var parens = 0
        var quote: Char? = null; var escaped = false; var lineComment = false; var blockComment = false
        val tags = ArrayList<String>()
        var i = 0
        while (i < text.length) {
            val c = text[i]; val n = if (i + 1 < text.length) text[i + 1] else '\u0000'
            if (lineComment) { if (c == '\n') lineComment = false; i++; continue }
            if (blockComment) { if (c == '*' && n == '/') { blockComment = false; i += 2 } else i++; continue }
            if (quote != null) { if (escaped) escaped = false else if (c == '\\') escaped = true else if (c == quote) quote = null; i++; continue }
            if ((language == "js" || language == "kt" || language == "css") && c == '/' && n == '/') { lineComment = true; i += 2; continue }
            if ((language == "js" || language == "kt" || language == "css") && c == '/' && n == '*') { blockComment = true; i += 2; continue }
            if (c == '"' || c == '\'') quote = c
            else when (c) { '{' -> braces++; '}' -> braces--; '[' -> brackets++; ']' -> brackets--; '(' -> parens++; ')' -> parens-- }
            if (language == "html" && c == '<') {
                val m = Regex("<\\s*(/?)\\s*([A-Za-z][A-Za-z0-9-]*)").find(text.substring(i))
                if (m != null) tags += (if (m.groupValues[1].isEmpty()) "+" else "-") + m.groupValues[2].toLowerCase()
            }
            i++
        }
        return Scan(braces, brackets, parens, tags, if (text.isEmpty()) 0 else text.count { it == '\n' } + 1, quote == null && !blockComment)
    }
}
