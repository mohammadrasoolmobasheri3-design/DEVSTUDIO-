package com.example.ultrapromax.engine.visual

/**
 * ENDGAME Stage 4: UI/UX Factory contract and deterministic design data.
 * Device-local, framework-free so the same model can feed Design, Preview and Code generation.
 */
class UiUxFactoryEngine {
    data class Component(
        val type: String,
        val category: String,
        val defaultWidthDp: Int,
        val defaultHeightDp: Int,
        val interactive: Boolean,
        val accessible: Boolean,
        val motion: Boolean
    )

    data class Breakpoint(val id: String, val minWidthDp: Int, val maxWidthDp: Int, val columns: Int, val gapDp: Int)
    data class Animation(val id: String, val durationMs: Long, val description: String)
    data class Theme(val id: String, val background: String, val surface: String, val text: String, val secondary: String, val accent: String)

    fun components(): List<Component> = listOf(
        Component("Text", "Content", 240, 48, false, true, true),
        Component("Button", "Controls", 180, 52, true, true, true),
        Component("Input", "Forms", 240, 52, true, true, true),
        Component("Image", "Media", 220, 160, false, true, true),
        Component("Card", "Layout", 280, 180, false, true, true),
        Component("Container", "Layout", 300, 220, false, true, false),
        Component("Row", "Layout", 320, 64, false, true, false),
        Component("Divider", "Layout", 240, 24, false, true, false),
        Component("Switch", "Controls", 120, 48, true, true, true),
        Component("Checkbox", "Controls", 180, 48, true, true, true),
        Component("Progress", "Feedback", 240, 24, false, true, true),
        Component("Spacer", "Layout", 120, 24, false, true, false)
    )

    fun breakpoints(): List<Breakpoint> = listOf(
        Breakpoint("compact", 0, 599, 1, 12),
        Breakpoint("medium", 600, 839, 2, 16),
        Breakpoint("expanded", 840, 1199, 3, 20),
        Breakpoint("wide", 1200, 10000, 4, 24)
    )

    fun animations(): List<Animation> = listOf(
        Animation("fadeIn", 180L, "Opacity entrance"),
        Animation("scaleIn", 220L, "Scale entrance"),
        Animation("slideUp", 240L, "Vertical entrance"),
        Animation("press", 100L, "Interactive press"),
        Animation("pulse", 600L, "Attention pulse"),
        Animation("lift", 220L, "Depth hover/selection"),
        Animation("shake", 260L, "Validation feedback"),
        Animation("shimmer", 900L, "Loading emphasis")
    )

    fun themes(): List<Theme> = listOf(
        Theme("dark", "#0B0E1A", "#141A2E", "#FFFFFF", "#9AA4C0", "#9B5CFF"),
        Theme("light", "#F7F8FC", "#FFFFFF", "#14161D", "#5B6475", "#6750A4"),
        Theme("cyberpunk", "#050014", "#160029", "#00F6FF", "#FF2DA8", "#FFEA00"),
        Theme("ocean", "#06131D", "#0D2633", "#F3FBFF", "#9BC7D9", "#22D3EE"),
        Theme("forest", "#07130D", "#10261A", "#F2FFF6", "#A5C7AE", "#4ADE80")
    )

    fun validate(): Boolean = components().size >= 12 && breakpoints().size >= 4 && animations().size >= 8 && themes().size >= 5 && components().all { it.accessible }

    fun css(themeId: String, animationId: String): String {
        val theme = themes().firstOrNull { it.id == themeId } ?: themes()[0]
        val animation = animations().firstOrNull { it.id == animationId } ?: animations()[0]
        return """
            :root{--ds-bg:${theme.background};--ds-surface:${theme.surface};--ds-text:${theme.text};--ds-secondary:${theme.secondary};--ds-accent:${theme.accent};--ds-gap:12px}
            *{box-sizing:border-box} body{margin:0;min-height:100vh;background:var(--ds-bg);color:var(--ds-text);font-family:sans-serif}
            .ds-root{position:relative;min-height:100vh;padding:var(--ds-gap)}
            .ds-component{position:absolute;overflow:hidden;transition:transform .22s ease,opacity .22s ease,box-shadow .22s ease}
            .ds-component:focus-visible{outline:2px solid var(--ds-accent);outline-offset:2px}
            .ds-animated{animation:ds_${animation.id} ${animation.durationMs}ms ease both}
            .ds-button,.ds-input{font:inherit;padding:10px;border-radius:10px;border:1px solid var(--ds-accent);background:var(--ds-surface);color:var(--ds-text)}
            .ds-card{padding:12px;border-radius:14px;background:var(--ds-surface);border:1px solid var(--ds-accent)}
            .ds-image{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--ds-surface);border-radius:12px}
            .ds-progress{height:100%;background:linear-gradient(90deg,var(--ds-accent),transparent);border-radius:999px}
            .ds-switch,.ds-check{accent-color:var(--ds-accent)}
            @keyframes ds_fadeIn{from{opacity:0}to{opacity:1}}
            @keyframes ds_scaleIn{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:scale(1)}}
            @keyframes ds_slideUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
            @keyframes ds_press{from{transform:scale(1)}to{transform:scale(.97)}}
            @keyframes ds_pulse{0%,100%{opacity:.72;transform:scale(.98)}50%{opacity:1;transform:scale(1)}}
            @keyframes ds_lift{from{transform:translateY(0)}to{transform:translateY(-4px)}}
            @keyframes ds_shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}
            @keyframes ds_shimmer{from{filter:brightness(.9)}50%{filter:brightness(1.3)}to{filter:brightness(.9)}}
            @media(min-width:600px){:root{--ds-gap:16px}.ds-root{padding:16px}}
            @media(min-width:840px){:root{--ds-gap:20px}.ds-root{padding:20px}}
            @media(min-width:1200px){:root{--ds-gap:24px}.ds-root{padding:24px}}
        """.trimIndent()
    }
}
