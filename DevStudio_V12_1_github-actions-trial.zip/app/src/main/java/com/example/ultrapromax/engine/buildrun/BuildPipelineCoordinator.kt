package com.example.ultrapromax.engine.buildrun

import com.example.ultrapromax.engine.diagnostics.StudioDiagnostic
import com.example.ultrapromax.engine.diagnostics.StudioOutputStore
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import java.io.File
import com.example.ultrapromax.engine.studio.StudioOperationGuard

/** One local bridge for Build -> Console -> Problems -> verification. */
class BuildPipelineCoordinator(private val outputStore: StudioOutputStore, private val operationGuard: StudioOperationGuard = StudioOperationGuard()) {
    data class Report(
        val result: BuildPipelineEngine.Result,
        val diagnostics: List<StudioDiagnostic>,
        val verified: Boolean
    )

    fun execute(projectDir: File, variant: BuildPipelineEngine.Variant, context: android.content.Context? = null): Report {
        val token = operationGuard.tryAcquire(StudioOperationGuard.Operation.BUILD)
        if (token == null) {
            val now = System.currentTimeMillis()
            val result = BuildPipelineEngine.Result(false, variant, null, "BUILD BLOCKED: another Studio operation is already active", now, now)
            outputStore.appendConsole("[BUILD] blocked by active Studio operation")
            return Report(result, emptyList(), false)
        }
        return try {
            outputStore.appendConsole("[BUILD] ${variant.name} started for ${projectDir.name}")
            val result = BuildPipelineEngine(context).build(BuildPipelineEngine.Request(projectDir, variant))
            val diagnostics = BuildDiagnosticsParser.parse(result.output, projectDir)
            outputStore.setProblems(diagnostics)
            outputStore.appendConsole("[BUILD] ${variant.name}: ${if (result.success) "SUCCESS" else "FAILED"}")
            if (diagnostics.isNotEmpty()) outputStore.appendConsole("[BUILD] Problems detected: ${diagnostics.size}")
            val verification = verifyApk(result.apkFile, result.success, context)
            if (verification.valid) {
                outputStore.appendConsole("[VERIFY] Cryptographic APK verification passed: ${result.apkFile?.name}")
            } else if (result.success) {
                outputStore.appendConsole("[VERIFY] FAILED: ${verification.errors.joinToString(" | ")}")
            }
            Report(result, diagnostics, verification.valid)
        } finally { operationGuard.release(token) }
    }

    private fun verifyApk(
        apk: File?,
        buildSuccess: Boolean,
        context: android.content.Context?
    ): ApkValidationEngine.Report {
        if (!buildSuccess || apk == null) {
            return ApkValidationEngine.Report(false, apk?.length() ?: 0L, null, listOf("Build did not produce a successful APK result"))
        }
        return ApkValidationEngine(context).validate(apk)
    }
}
