package com.example.ultrapromax.engine.analysis

import com.example.ultrapromax.engine.language.LanguageRegistry
import com.example.ultrapromax.engine.language.LanguageService
import com.example.ultrapromax.ui.CodeCheckEngine
import java.io.File

/** Offline, dependency-free diagnostics built on the V26.4 language core and V26.5 intelligence. */
class DiagnosticEngine(private val languageService: LanguageService = LanguageService()) {

    fun analyzeBuffer(fileName: String, source: String): List<Diagnostic> {
        val result = ArrayList<Diagnostic>()
        val language = LanguageRegistry.detectId(fileName)
        val legacyProblems = CodeCheckEngine.check(source, language)

        for (problem in legacyProblems) {
            result.add(
                Diagnostic(
                    severity = DiagnosticSeverity.ERROR,
                    source = DiagnosticSource.SYNTAX,
                    code = "SYNTAX",
                    message = problem.message,
                    filePath = fileName,
                    line = problem.line
                )
            )
        }

        if (LanguageRegistry.detect(fileName) == null && language != "text") {
            result.add(
                Diagnostic(
                    DiagnosticSeverity.INFO,
                    DiagnosticSource.LANGUAGE,
                    "LANG001",
                    "No language provider is registered for this file",
                    fileName,
                    1
                )
            )
        }

        val symbols = languageService.analyzeBuffer(fileName, source)
        val duplicateNames = symbols.groupBy { it.name }
            .filter { it.key.isNotEmpty() && it.value.size > 1 }
        for ((name, matches) in duplicateNames) {
            val first = matches.first()
            result.add(
                Diagnostic(
                    DiagnosticSeverity.WARNING,
                    DiagnosticSource.SYMBOL,
                    "SYM001",
                    "Duplicate symbol '$name' detected in the same buffer",
                    fileName,
                    first.line,
                    first.column
                )
            )
        }

        return result
    }

    fun analyzeFile(file: File): List<Diagnostic> {
        if (!file.isFile) return emptyList()
        return try {
            analyzeBuffer(file.name, file.readText())
        } catch (e: Exception) {
            listOf(
                Diagnostic(
                    DiagnosticSeverity.ERROR,
                    DiagnosticSource.PROJECT,
                    "FILE001",
                    "Unable to read file: " + (e.message ?: "unknown error"),
                    file.absolutePath,
                    1
                )
            )
        }
    }

    fun analyzeProject(root: File, maxFileSize: Long = 5L * 1024L * 1024L): List<Diagnostic> {
        if (!root.isDirectory) return emptyList()
        val result = ArrayList<Diagnostic>()
        root.walkTopDown().forEach { file ->
            if (!file.isFile || file.length() > maxFileSize) return@forEach
            val language = LanguageRegistry.detect(file.name)
            if (language != null) {
                result.addAll(analyzeFile(file))
            }
        }
        return result
    }

    fun summarize(root: File, diagnostics: List<Diagnostic>): AnalysisSummary {
        var files = 0
        var lines = 0
        if (root.isDirectory) {
            root.walkTopDown().forEach { file ->
                if (file.isFile && LanguageRegistry.detect(file.name) != null) {
                    files++
                    try {
                        lines += file.readLines().size
                    } catch (_: Exception) { }
                }
            }
        }
        return AnalysisSummary(
            files = files,
            lines = lines,
            errors = diagnostics.count { it.severity == DiagnosticSeverity.ERROR },
            warnings = diagnostics.count { it.severity == DiagnosticSeverity.WARNING },
            infos = diagnostics.count { it.severity == DiagnosticSeverity.INFO },
            indexedSymbols = languageService.index.symbolCount()
        )
    }
}
