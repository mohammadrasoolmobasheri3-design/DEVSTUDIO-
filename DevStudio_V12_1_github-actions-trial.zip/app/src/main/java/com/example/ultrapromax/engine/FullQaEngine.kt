package com.example.ultrapromax.engine

import android.content.Context
import java.io.File
import java.util.Locale

data class QaCheck(
    val id: String,
    val title: String,
    val status: String,
    val detail: String
)

data class QaReport(
    val timestamp: Long,
    val checks: List<QaCheck>
) {
    val passed: Int get() = checks.count { it.status == "PASS" }
    val warnings: Int get() = checks.count { it.status == "WARN" }
    val failed: Int get() = checks.count { it.status == "FAIL" }
}

class FullQaEngine(private val context: Context) {

    fun run(): QaReport {
        val checks = mutableListOf<QaCheck>()
        checkCore(checks)
        checkStorage(checks)
        checkManifest(checks)
        checkOfflinePolicy(checks)
        checkWorkspace(checks)
        checkRuntimeArtifacts(checks)
        checkCompletionAudit(checks)
        checkTenDomainCompletion(checks)
        return QaReport(System.currentTimeMillis(), checks)
    }

    private fun checkCore(out: MutableList<QaCheck>) {
        val app = context.packageName
        out += if (app.isNotBlank()) {
            QaCheck("core.package", "Application identity", "PASS", app)
        } else {
            QaCheck("core.package", "Application identity", "FAIL", "Package name is empty")
        }
    }

    private fun checkStorage(out: MutableList<QaCheck>) {
        val files = context.filesDir
        out += if (files.exists() && files.isDirectory) {
            QaCheck("storage.private", "Private storage", "PASS", files.absolutePath)
        } else {
            QaCheck("storage.private", "Private storage", "FAIL", "Private storage is unavailable")
        }

        val cache = context.cacheDir
        out += if (cache.exists() && cache.isDirectory) {
            QaCheck("storage.cache", "Cache storage", "PASS", cache.absolutePath)
        } else {
            QaCheck("storage.cache", "Cache storage", "WARN", "Cache directory will be recreated when needed")
        }
    }

    private fun checkManifest(out: MutableList<QaCheck>) {
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            out += QaCheck(
                "manifest.package",
                "Installed package metadata",
                "PASS",
                "versionCode=${info.versionCode}, versionName=${info.versionName ?: "unknown"}"
            )
        } catch (t: Throwable) {
            out += QaCheck("manifest.package", "Installed package metadata", "FAIL",
                t.message ?: "Unable to read package metadata")
        }
    }

    private fun checkOfflinePolicy(out: MutableList<QaCheck>) {
        // QA policy check only: the Studio's offline mode must not require network access.
        // This does not claim that every generated project is network-free.
        out += QaCheck(
            "offline.policy",
            "Offline-first policy",
            "PASS",
            "QA mode does not perform network requests"
        )
    }

    private fun checkWorkspace(out: MutableList<QaCheck>) {
        val base = context.filesDir
        val candidates = arrayOf(
            File(base, "devstudio"),
            File(base, "projects"),
            File(base, "workspace")
        )
        val existing = candidates.firstOrNull { it.exists() }
        out += if (existing != null) {
            QaCheck("workspace.local", "Local workspace", "PASS", existing.absolutePath)
        } else {
            QaCheck(
                "workspace.local",
                "Local workspace",
                "WARN",
                "No workspace folder exists yet; this is valid before first project creation"
            )
        }
    }

    private fun checkCompletionAudit(out: MutableList<QaCheck>) {
        try {
            val report = com.example.ultrapromax.engine.completion.StudioCompletionEngine(context).run()
            val status = if (report.failed() == 0) "PASS" else "FAIL"
            out += QaCheck("completion.audit", "Final completion workflow", status, "PASS ${report.passed()} / WARN ${report.warnings()} / FAIL ${report.failed()}")
        } catch (e: Throwable) {
            out += QaCheck("completion.audit", "Final completion workflow", "FAIL", e.message ?: "Completion audit failed")
        }
    }

    private fun checkTenDomainCompletion(out: MutableList<QaCheck>) {
        try {
            val report = com.example.ultrapromax.engine.finalcompletion.StudioFeatureCompletionEngine(context).run()
            val status = if (report.failed() == 0) "PASS" else "FAIL"
            out += QaCheck("completion.ten-domain", "10-domain feature completion", status, "PASS ${report.passed()} / WARN ${report.warnings()} / FAIL ${report.failed()}")
        } catch (e: Throwable) {
            out += QaCheck("completion.ten-domain", "10-domain feature completion", "FAIL", e.message ?: "10-domain audit failed")
        }
    }

    private fun checkRuntimeArtifacts(out: MutableList<QaCheck>) {
        val apkDirs = arrayOf(
            File(context.filesDir, "build"),
            File(context.filesDir, "apk"),
            File(context.cacheDir, "apk")
        )
        val apk = apkDirs.asSequence()
            .filter { it.exists() }
            .flatMap { it.walkTopDown().asSequence() }
            .firstOrNull { it.isFile && it.extension.toLowerCase(Locale.US) == "apk" }

        out += if (apk != null && apk.length() > 0L) {
            QaCheck("runtime.apk", "Local APK artifact", "PASS",
                "${apk.name} (${apk.length()} bytes)")
        } else {
            QaCheck(
                "runtime.apk",
                "Local APK artifact",
                "WARN",
                "No APK artifact exists yet; run a real build before APK verification"
            )
        }
    }
}
