package com.example.ultrapromax.engine.analysis

enum class DiagnosticSeverity {
    INFO,
    WARNING,
    ERROR
}

enum class DiagnosticSource {
    SYNTAX,
    LANGUAGE,
    SYMBOL,
    PROJECT,
    STYLE,
    PERFORMANCE,
    SECURITY
}

data class Diagnostic(
    val severity: DiagnosticSeverity,
    val source: DiagnosticSource,
    val code: String,
    val message: String,
    val filePath: String?,
    val line: Int,
    val column: Int = 1
)

data class AnalysisSummary(
    val files: Int,
    val lines: Int,
    val errors: Int,
    val warnings: Int,
    val infos: Int,
    val indexedSymbols: Int
)
