package com.example.ultrapromax.engine.language.symbol

import java.io.File
import java.security.MessageDigest

class SymbolCache(private val root: File) {
    init { root.mkdirs() }

    fun key(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(file.absolutePath.toByteArray(Charsets.UTF_8))
        val out = StringBuilder()
        for (b in digest) out.append(String.format("%02x", b.toInt() and 0xff))
        return out.toString()
    }

    fun marker(file: File): File = File(root, key(file) + ".meta")

    fun isFresh(file: File): Boolean {
        val marker = marker(file)
        if (!file.exists() || !marker.exists()) return false
        return try { marker.readText() == file.length().toString() + ":" + file.lastModified() } catch (_: Exception) { false }
    }

    fun markFresh(file: File) {
        try { marker(file).writeText(file.length().toString() + ":" + file.lastModified()) } catch (_: Exception) { }
    }

    fun invalidate(file: File) { try { marker(file).delete() } catch (_: Exception) { } }
}
