package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.vfs.VirtualFileSystem
import java.io.File
import java.text.DecimalFormat

class VirtualFileSystemActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var vfs: VirtualFileSystem
    private lateinit var list: LinearLayout
    private lateinit var pathText: TextView
    private var currentPath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_virtual_fs)
        project = ProjectStore.getById(this, intent.getLongExtra(EXTRA_PROJECT_ID, -1L)) ?: run { finish(); return }
        vfs = VirtualFileSystem(File(project.folderPath))
        list = findViewById(R.id.vfsList)
        pathText = findViewById(R.id.vfsPath)
        findViewById<TextView>(R.id.vfsBack).setOnClickListener { if (currentPath.isEmpty()) finish() else goParent() }
        findViewById<Button>(R.id.vfsUp).setOnClickListener { goParent() }
        findViewById<Button>(R.id.vfsNew).setOnClickListener { chooseCreate() }
        findViewById<Button>(R.id.vfsRefresh).setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        pathText.text = if (currentPath.isEmpty()) "/" else "/$currentPath"
        list.removeAllViews()
        val children = vfs.list(currentPath)
        if (children.isEmpty()) addMessage("Folder is empty")
        children.forEach { addRow(it) }
        val footer = TextView(this).apply {
            text = "${children.size} items • ${vfs.countFiles(currentPath)} files • ${formatBytes(vfs.size(currentPath))}"
            setTextColor(Color.parseColor("#7F8AA6")); textSize = 10f; setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        list.addView(footer)
    }

    private fun addRow(file: File) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(6), 0); setBackgroundResource(R.drawable.glass_card) }
        val title = TextView(this).apply { text = if (file.isDirectory) "📁 ${file.name}" else "▣ ${file.name}"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER_VERTICAL }
        row.addView(title, LinearLayout.LayoutParams(0, dp(46), 1f))
        val more = TextView(this).apply { text = "⋮"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setOnClickListener { showActions(file) } }
        row.addView(more, LinearLayout.LayoutParams(dp(42), dp(46)))
        row.setOnClickListener { if (file.isDirectory) { currentPath = vfs.relative(file); refresh() } else openFile(file) }
        val lp = LinearLayout.LayoutParams(-1, dp(48)); lp.setMargins(0, 0, 0, dp(5)); list.addView(row, lp)
    }

    private fun openFile(file: File) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id).putExtra(EditorActivity.EXTRA_FILE_PATH, file.absolutePath))
    }

    private fun showActions(file: File) {
        val options = arrayOf("Open", "Rename", "Duplicate", "Delete", "Inspect")
        AlertDialog.Builder(this).setTitle(file.name).setItems(options) { _, which ->
            when (which) {
                0 -> if (file.isDirectory) { currentPath = vfs.relative(file); refresh() } else openFile(file)
                1 -> rename(file)
                2 -> if (vfs.duplicate(vfs.relative(file)) != null) refresh() else toast("Duplicate failed")
                3 -> { if (vfs.delete(vfs.relative(file))) refresh() else toast("Delete failed") }
                4 -> AlertDialog.Builder(this).setTitle("VFS Inspector").setMessage("Path: /${vfs.relative(file)}\nType: ${if (file.isDirectory) "Folder" else "File"}\nSize: ${formatBytes(vfs.size(vfs.relative(file)))}\nFiles: ${vfs.countFiles(vfs.relative(file))}").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun rename(file: File) {
        val input = EditText(this).apply { setText(file.name); selectAll() }
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setPositiveButton("Save") { _, _ ->
            if (vfs.rename(vfs.relative(file), input.text.toString().trim()) == null) toast("Rename failed or name already exists") else refresh()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseCreate() {
        AlertDialog.Builder(this).setTitle("Create in Virtual FS").setItems(arrayOf("New File", "New Folder")) { _, which -> create(which == 1) }.show()
    }

    private fun create(folder: Boolean) {
        val input = EditText(this).apply { hint = if (folder) "Folder name" else "File name" }
        AlertDialog.Builder(this).setTitle(if (folder) "New Folder" else "New File").setView(input).setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().trim()
            val rel = if (currentPath.isEmpty()) name else "$currentPath/$name"
            val created = if (folder) vfs.createFolder(rel) else vfs.createFile(rel)
            if (created == null) toast("Could not create item") else refresh()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun goParent() {
        if (currentPath.isEmpty()) { finish(); return }
        val parts = currentPath.split("/").filter { it.isNotEmpty() }.toMutableList()
        if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
        currentPath = parts.joinToString("/"); refresh()
    }

    private fun addMessage(message: String) { list.addView(TextView(this).apply { text = message; setTextColor(Color.parseColor("#9AA4C0")); setPadding(dp(8), dp(16), dp(8), dp(16)) }) }
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun formatBytes(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> "${DecimalFormat("0.0").format(bytes / 1024.0)} KB"; else -> "${DecimalFormat("0.0").format(bytes / (1024.0 * 1024.0))} MB" }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    companion object { const val EXTRA_PROJECT_ID = "extra_vfs_project_id" }
}
