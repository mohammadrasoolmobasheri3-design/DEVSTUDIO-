package com.example.ultrapromax.engine.offline

import android.content.Context
import java.net.URI

/** Permanent application boundary: DEVSTUDIO never permits external network destinations. */
class OfflineNetworkPolicy(private val context: Context) {
    fun allow(url: String): Boolean {
        return try {
            val value = url.trim()
            if (value.startsWith("file:", ignoreCase = true)) return true
            val host = URI(value).host ?: return false
            host == "127.0.0.1" || host == "localhost" || host == "::1"
        } catch (_: Exception) {
            false
        }
    }

    fun isExternal(url: String): Boolean = !allow(url)
    fun mode(): String = "STRICT OFFLINE"
}
