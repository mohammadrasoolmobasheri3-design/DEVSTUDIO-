package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.language.symbol.SymbolIndex

class DefinitionResolver(private val index: SymbolIndex) {
    fun resolve(name: String, filePath: String? = null): Symbol? {
        val query = name.trim()
        if (query.isEmpty()) return null
        val candidates = index.findByName(query)
        if (candidates.isEmpty()) return null
        if (filePath != null) {
            val local = candidates.firstOrNull { it.filePath == filePath }
            if (local != null) return local
        }
        return candidates.firstOrNull()
    }
}
