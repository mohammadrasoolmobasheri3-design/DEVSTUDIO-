package com.example.ultrapromax.engine.dependency

import java.io.File

class DependencyLock(private val lockFile: File) {
    fun read(): Map<String, String> {
        if (!lockFile.exists()) return emptyMap()
        val result = LinkedHashMap<String, String>()
        return try {
            for (line in lockFile.readLines()) {
                val value = line.trim()
                if (value.isEmpty() || value.startsWith("#")) continue
                val index = value.indexOf('=')
                if (index > 0) result[value.substring(0, index)] = value.substring(index + 1)
            }
            result
        } catch (_: Exception) { emptyMap() }
    }

    fun write(dependencies: List<DependencyCoordinate>): Boolean = try {
        lockFile.parentFile?.mkdirs()
        val lines = ArrayList<String>()
        lines.add("# DEVSTUDIO dependency lock v26.8")
        dependencies.sortedBy { it.key() }.forEach { lines.add(it.key() + "=" + it.version) }
        val temp = File(lockFile.parentFile, lockFile.name + ".tmp")
        temp.writeText(lines.joinToString("\n") + "\n")
        if (lockFile.exists()) lockFile.delete()
        temp.renameTo(lockFile)
    } catch (_: Exception) { false }

    fun check(dependencies: List<DependencyCoordinate>): List<String> {
        val locked = read()
        val problems = ArrayList<String>()
        for (dependency in dependencies) {
            val version = locked[dependency.key()]
            if (version != null && version != dependency.version) problems.add("Lock mismatch: ${dependency.key()} locked=$version declared=${dependency.version}")
        }
        return problems
    }
}
