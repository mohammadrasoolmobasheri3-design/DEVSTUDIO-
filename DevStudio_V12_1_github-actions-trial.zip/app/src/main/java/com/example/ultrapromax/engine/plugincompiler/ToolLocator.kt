package com.example.ultrapromax.engine.plugincompiler

import java.io.File

/**
 * TOOL LOCATOR
 * Finds command-line tools (javac, d8/dx) already present on this device's
 * AndroidIDE-style environment, without needing a hardcoded path — since
 * that path differs across devices/AndroidIDE builds. It checks, in order:
 *   1. Every directory in the PATH environment variable
 *   2. A handful of known common install locations
 *   3. `which <tool>` via the shell, as a last resort
 *
 * This mirrors how BuildEngine already locates ./gradlew successfully, just
 * generalized to arbitrary tool names.
 */
object ToolLocator {

    private val commonDirs = listOf(
        "/data/data/com.itsaky.androidide/files/usr/bin",
        "/data/data/com.itsaky.androidide/files/home/.local/bin",
        "/data/user/0/com.itsaky.androidide/files/usr/bin",
        "/system/bin",
        "/system/xbin",
        "/usr/bin",
        "/usr/local/bin"
    )

    private val cache = mutableMapOf<String, String?>()

    fun find(toolName: String): String? {
        cache[toolName]?.let { return it }
        if (cache.containsKey(toolName)) return null // cached "not found"

        val fromPath = System.getenv("PATH")?.split(":")?.asSequence()
            ?.map { File(it, toolName) }
            ?.firstOrNull { it.exists() }
            ?.absolutePath

        val fromCommon = fromPath ?: commonDirs.asSequence()
            .map { File(it, toolName) }
            .firstOrNull { it.exists() }
            ?.absolutePath

        val resolved = fromCommon ?: runCatching {
            val process = ProcessBuilder("sh", "-c", "which $toolName")
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText().trim()
            process.waitFor()
            output.takeIf { it.isNotEmpty() && File(it).exists() }
        }.getOrNull()

        cache[toolName] = resolved
        return resolved
    }

    /** True if both javac and a dex converter (d8 preferred, dx fallback) are available. */
    fun hasCompilerToolchain(): Boolean =
        find("javac") != null && (find("d8") != null || find("dx") != null)

    fun describeAvailability(): String {
        val javac = find("javac")
        val d8 = find("d8")
        val dx = find("dx")
        return buildString {
            append("javac: ${javac ?: "NOT FOUND"}\n")
            append("d8: ${d8 ?: "not found"}\n")
            append("dx: ${dx ?: "not found"}")
        }
    }
}
