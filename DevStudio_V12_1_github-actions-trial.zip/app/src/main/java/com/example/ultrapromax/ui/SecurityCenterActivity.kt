package com.example.ultrapromax.ui

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.security.SecurityPolicyEngine
import java.io.File

/** V30.1.0 Stage 19 — Security / Sandbox Center. */
class SecurityCenterActivity : AppCompatActivity() {
    private lateinit var engine: SecurityPolicyEngine
    private lateinit var content: LinearLayout
    private var project: Project? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = SecurityPolicyEngine(this)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = if (id >= 0L) ProjectStore.getById(this, id) else null
        buildUi()
        refreshAudit()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(5, 8, 16))
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }

        val title = TextView(this).apply {
            text = "SECURITY / SANDBOX CENTER"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(48)))

        val subtitle = TextView(this).apply {
            text = "V30.1.0 • OFFLINE SECURITY GATE • NO ARBITRARY CODE EXECUTION"
            textSize = 10f
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(subtitle)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(action("SCAN PROJECT", Color.parseColor("#00E5FF")) { refreshAudit() }, weightParams())
        actions.addView(action(if (engine.isLocked()) "UNLOCK" else "LOCKDOWN", Color.parseColor("#FF6B7A")) { toggleLockdown() }, weightParams())
        actions.addView(action("POLICY", Color.parseColor("#B47CFF")) { showPolicy() }, weightParams())
        root.addView(actions)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun refreshAudit() {
        content.removeAllViews()
        val report = engine.audit(project?.let { File(it.folderPath) })
        addCard("POLICY STATE", if (report.policyLocked) "LOCKDOWN ENABLED" else "NORMAL / CONTROLLED", if (report.policyLocked) Color.parseColor("#FF6B7A") else Color.parseColor("#7CFF9B"))
        addCard("PROJECT", if (report.projectPath.isEmpty()) "No project selected" else report.projectPath, Color.WHITE)
        addCard("AUDIT", "${report.filesScanned} files • ${formatBytes(report.bytesScanned)} scanned • ${report.blockedOperations} blocked findings", if (report.critical() > 0) Color.parseColor("#FF6B7A") else Color.parseColor("#7CFF9B"))
        addCard("POLICY FINGERPRINT", engine.policyFingerprint(), Color.parseColor("#B47CFF"))

        val heading = TextView(this).apply {
            text = "SECURITY FINDINGS"
            textSize = 13f
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(dp(4), dp(14), dp(4), dp(8))
        }
        content.addView(heading)

        report.findings.forEach { finding ->
            val color = when (finding.severity) {
                "BLOCK" -> Color.parseColor("#FF6B7A")
                "WARN" -> Color.parseColor("#FFD166")
                else -> Color.parseColor("#7CFF9B")
            }
            addCard(finding.severity + " • " + finding.title, finding.detail, color)
        }
    }

    private fun toggleLockdown() {
        val next = !engine.isLocked()
        if (next) {
            AlertDialog.Builder(this)
                .setTitle("Enable Security Lockdown?")
                .setMessage("Lockdown blocks extension execution gates and other controlled execution requests. It does not delete project files.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("ENABLE") { _, _ ->
                    engine.setLocked(true)
                    Toast.makeText(this, "Security lockdown enabled", Toast.LENGTH_SHORT).show()
                    refreshAudit()
                }.show()
        } else {
            engine.setLocked(false)
            Toast.makeText(this, "Security lockdown disabled", Toast.LENGTH_SHORT).show()
            refreshAudit()
        }
    }

    private fun showPolicy() {
        AlertDialog.Builder(this)
            .setTitle("DEVSTUDIO Security Policy")
            .setMessage("• Offline-first network boundary\n• Localhost / loopback allowed\n• Project path traversal blocked\n• Arbitrary shell/process execution not exposed\n• External DEX/JAR loading not exposed\n• Extension permissions deny by default\n• ZIP package extraction must remain inside its sandbox\n• Security fingerprint: ${engine.policyFingerprint()}")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun addCard(title: String, message: String, color: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundResource(R.drawable.glass_card)
        }
        val t = TextView(this).apply {
            text = title
            textSize = 11f
            setTextColor(color)
        }
        val m = TextView(this).apply {
            text = message
            textSize = 11f
            setTextColor(Color.parseColor("#D6DBE8"))
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(t)
        box.addView(m)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(5), 0, dp(5))
        content.addView(box, lp)
    }

    private fun action(text: String, color: Int, click: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 8f
        setTextColor(color)
        setBackgroundResource(R.drawable.studio_tool_button)
        backgroundTintList = null
        minHeight = 0
        minWidth = 0
        setOnClickListener { click() }
    }

    private fun weightParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        setMargins(dp(2), 0, dp(2), 0)
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object { const val EXTRA_PROJECT_ID = "extra_security_project_id" }
}
