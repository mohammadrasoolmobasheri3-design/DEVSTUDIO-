package com.example.ultrapromax.engine.dependency

enum class DependencyScope { IMPLEMENTATION, API, COMPILE_ONLY, RUNTIME_ONLY, TEST_IMPLEMENTATION, DEBUG_IMPLEMENTATION, RELEASE_IMPLEMENTATION, UNKNOWN }

data class DependencyCoordinate(val group: String, val artifact: String, val version: String, val scope: DependencyScope = DependencyScope.IMPLEMENTATION) {
    fun notation(): String = "$group:$artifact:$version"
    fun key(): String = "$group:$artifact"
}

enum class DependencyStatus { DECLARED, VALID, INVALID, DUPLICATE, CONFLICT, MISSING_VERSION, UNSUPPORTED }

data class DependencyRecord(val coordinate: DependencyCoordinate, val status: DependencyStatus, val sourceFile: String?, val rawNotation: String, val detail: String)

data class DependencyReport(val dependencies: List<DependencyRecord>, val conflicts: List<String>, val invalid: List<String>) {
    fun validCount(): Int = dependencies.count { it.status == DependencyStatus.VALID || it.status == DependencyStatus.DECLARED }
    fun hasProblems(): Boolean = conflicts.isNotEmpty() || invalid.isNotEmpty() || dependencies.any { it.status == DependencyStatus.INVALID || it.status == DependencyStatus.MISSING_VERSION }
}
