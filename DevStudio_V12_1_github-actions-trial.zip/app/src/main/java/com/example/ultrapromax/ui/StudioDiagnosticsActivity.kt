package com.example.ultrapromax.ui

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.ultrapromax.engine.diagnostics.StudioOutputStore

class StudioDiagnosticsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(24,24,24,24)
        root.setBackgroundColor(Color.rgb(7,9,16))

        val title = TextView(this)
        title.text = "STUDIO OUTPUT"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title, LinearLayout.LayoutParams(-1, 60))

        val tabs = LinearLayout(this)
        tabs.gravity = Gravity.CENTER
        val console = tab("CONSOLE")
        val problems = tab("PROBLEMS")
        val terminal = tab("TERMINAL")
        tabs.addView(console, LinearLayout.LayoutParams(0, 56, 1f))
        tabs.addView(problems, LinearLayout.LayoutParams(0, 56, 1f))
        tabs.addView(terminal, LinearLayout.LayoutParams(0, 56, 1f))
        root.addView(tabs)

        val body = TextView(this)
        body.setTextColor(Color.LTGRAY)
        body.textSize = 13f
        body.setPadding(12,20,12,20)
        val scroll = ScrollView(this)
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        val store = StudioOutputStore(this)
        fun showConsole() { body.text = store.console().ifEmpty { "Console is empty." } }
        fun showProblems() {
            val list = store.problems()
            body.text = if (list.isEmpty()) "No problems." else list.joinToString("\n\n") {
                "[${it.severity}] ${it.filePath}:${it.line}:${it.column}\n${it.message}"
            }
        }
        fun showTerminal() {
            body.text = "TERMINAL\n\nTerminal bridge is ready for project commands.\nUse the Build/Run actions to feed output here."
        }

        console.setOnClickListener { showConsole() }
        problems.setOnClickListener { showProblems() }
        terminal.setOnClickListener { showTerminal() }
        showConsole()
        setContentView(root)
    }

    private fun tab(text: String): TextView {
        val v = TextView(this)
        v.text = text
        v.gravity = Gravity.CENTER
        v.setTextColor(Color.WHITE)
        v.textSize = 12f
        v.setBackgroundColor(Color.rgb(20,24,35))
        return v
    }
}
