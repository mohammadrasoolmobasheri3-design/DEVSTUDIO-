package com.example.ultrapromax.engine.run

import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Universal on-device run dispatcher.
 *
 * It never pretends a compiler/runtime exists: each language is routed to
 * a real runtime/compiler only when that executable is available on-device.
 * Web files use the existing PreviewActivity/WebView path. Android/Gradle
 * projects continue to use BuildEngine.
 */
class UniversalRunEngine(private val runtimeRoot: File) {

    private val registry = LanguageRuntimeRegistry(runtimeRoot)

    data class Result(
        val success: Boolean,
        val mode: String,
        val language: String,
        val output: String,
        val previewDir: File? = null
    )

    fun detectLanguage(file: File, source: String, projectDir: File): String {
        if (File(projectDir, "gradlew").exists() || File(projectDir, "build.gradle").exists()) {
            if (file.name.endsWith(".kt", true) || file.name.endsWith(".java", true)) return "android"
        }

        return when {
            file.name.endsWith(".html", true) || file.name.endsWith(".htm", true) -> "html"
            file.name.endsWith(".css", true) -> "css"
            file.name.endsWith(".js", true) || file.name.endsWith(".mjs", true) -> "javascript"
            file.name.endsWith(".ts", true) || file.name.endsWith(".tsx", true) -> "typescript"
            file.name.endsWith(".py", true) -> "python"
            file.name.endsWith(".java", true) -> "java"
            file.name.endsWith(".kt", true) -> "kotlin"
            file.name.endsWith(".kts", true) -> "kotlin-script"
            file.name.endsWith(".c", true) -> "c"
            file.name.endsWith(".cc", true) || file.name.endsWith(".cpp", true) || file.name.endsWith(".cxx", true) -> "cpp"
            file.name.endsWith(".cs", true) -> "csharp"
            file.name.endsWith(".go", true) -> "go"
            file.name.endsWith(".rs", true) -> "rust"
            file.name.endsWith(".swift", true) -> "swift"
            file.name.endsWith(".dart", true) -> "dart"
            file.name.endsWith(".php", true) -> "php"
            file.name.endsWith(".rb", true) -> "ruby"
            file.name.endsWith(".pl", true) -> "perl"
            file.name.endsWith(".lua", true) -> "lua"
            file.name.endsWith(".sh", true) -> "shell"
            file.name.endsWith(".bash", true) -> "bash"
            file.name.endsWith(".sql", true) -> "sql"
            file.name.endsWith(".txt", true) && looksLikeHtml(source) -> "html"
            file.name.endsWith(".txt", true) && looksLikePython(source) -> "python"
            file.name.endsWith(".txt", true) && looksLikeJavaScript(source) -> "javascript"
            file.name.endsWith(".txt", true) && looksLikeShell(source) -> "shell"
            else -> "text"
        }
    }

    fun run(file: File, source: String, projectDir: File, cacheDir: File): Result {
        val language = if (File(projectDir, "pubspec.yaml").isFile && (File(projectDir, "lib").exists() || file.name.endsWith(".dart", true))) "flutter" else detectLanguage(file, source, projectDir)

        if (language == "android") {
            return Result(
                false,
                "ANDROID_BUILD",
                language,
                "ANDROID_PROJECT: use BuildEngine for the real Gradle/APK build."
            )
        }

        if (language == "html" || language == "css") {
            val preview = prepareWebPreview(projectDir, file, source, cacheDir)
                ?: return Result(false, "PREVIEW", language, "Unable to prepare web preview.")
            return Result(true, "PREVIEW", language, "WEB_PREVIEW_READY", preview)
        }

        val workDir = File(cacheDir, "universal-run/${System.currentTimeMillis()}")
        if (!workDir.mkdirs()) {
            return Result(false, "PROCESS", language, "Unable to create run directory: ${workDir.absolutePath}")
        }

        return when (language) {
            "javascript" -> runCandidates(workDir, file.name, source, listOf(listOf("node", "SOURCE"), listOf("nodejs", "SOURCE")), language)
            "typescript" -> runCandidates(workDir, file.name, source, listOf(listOf("tsx", "SOURCE"), listOf("ts-node", "SOURCE")), language)
            "python" -> runPythonEmbedded(file, source, projectDir, workDir)
            "php" -> runCandidates(workDir, file.name, source, listOf(listOf("php", "SOURCE")), language)
            "ruby" -> runCandidates(workDir, file.name, source, listOf(listOf("ruby", "SOURCE")), language)
            "perl" -> runCandidates(workDir, file.name, source, listOf(listOf("perl", "SOURCE")), language)
            "lua" -> runCandidates(workDir, file.name, source, listOf(listOf("lua", "SOURCE")), language)
            "shell" -> runCandidates(workDir, file.name, source, listOf(listOf("sh", "SOURCE")), language)
            "bash" -> runCandidates(workDir, file.name, source, listOf(listOf("bash", "SOURCE")), language)
            "go" -> runCandidates(workDir, file.name, source, listOf(listOf("go", "run", "SOURCE")), language)
            "swift" -> runCandidates(workDir, file.name, source, listOf(listOf("swift", "SOURCE")), language)
            "dart" -> runDart(workDir, file.name, source)
            "flutter" -> runFlutter(projectDir)
            "kotlin-script" -> runCandidates(workDir, file.name, source, listOf(listOf("kotlinc", "-script", "SOURCE")), language)
            "kotlin" -> runKotlin(workDir, file.name, source)
            "java" -> runJava(workDir, file.name, source, projectDir)
            "c" -> runNativeCpp(workDir, file, source, language)
            "cpp" -> runNativeCpp(workDir, file, source, language)
            "csharp" -> runCSharp(workDir, file.name, source)
            "rust" -> runCompiled(workDir, file.name, source, "rustc", language)
            "sql" -> runCandidates(workDir, file.name, source, listOf(listOf("sqlite3", "SOURCE")), language)
            else -> Result(false, "PROCESS", language, "No runnable runtime is registered for this file type yet. Rename the file with a supported extension or add its runtime to the device.")
        }
    }

    private fun runPythonEmbedded(file: File, source: String, projectDir: File, workDir: File): Result {
        val profile = registry.find("python") ?: return missing("python", "embedded runtime")
        val runtime = PythonEmbeddedRuntime(registry.runtimeDir(profile))
        val script = File(workDir, safeSourceName(file.name, ".py"))
        script.writeText(source)
        val result = runtime.run(script, projectDir)
        return Result(
            result.success,
            "PYTHON_EMBEDDED",
            "python",
            result.output
        )
    }

    private fun runJava(workDir: File, name: String, source: String, projectDir: File): Result {
        val profile = registry.find("java")
        if (profile == null) return missing("java", "java runtime profile")
        val runtime = JavaRuntimeEngine(registry.runtimeDir(profile))
        val result = runtime.run(name, source, projectDir, workDir)
        return Result(result.success, "JAVA_RUNTIME", "java", result.output)
    }

    private fun runKotlin(workDir: File, name: String, source: String): Result {
        if (!isAvailable("kotlin", "kotlinc") || !isAvailable("kotlin", "java")) {
            return missing("kotlin", "kotlinc/java")
        }
        val sourceFile = File(workDir, safeSourceName(name, ".kt"))
        sourceFile.writeText(source)
        val jar = File(workDir, "run.jar")
        val compile = execute(listOf(resolve("kotlin", "kotlinc"), sourceFile.absolutePath, "-include-runtime", "-d", jar.absolutePath), workDir)
        if (compile.exitCode != 0) return Result(false, "PROCESS", "kotlin", compile.output)
        val run = execute(listOf(resolve("kotlin", "java"), "-jar", jar.absolutePath), workDir)
        return Result(run.exitCode == 0, "PROCESS", "kotlin", run.output)
    }


    private fun runNativeCpp(workDir: File, file: File, source: String, language: String): Result {
        val profile = registry.find(language) ?: return missing(language, "native compiler profile")
        val runtime = NativeCppRuntimeEngine(registry.runtimeDir(profile))
        val result = runtime.run(listOf(Pair(file.name, source)), language, workDir)
        return Result(result.success, "NATIVE_COMPILE", language, result.output)
    }

    private fun runDart(workDir: File, name: String, source: String): Result {
        val dartProfile = registry.find("dart") ?: return missing("dart", "dart runtime profile")
        var runtimeDir = registry.runtimeDir(dartProfile)
        if (registry.findExecutable(dartProfile, "dart") == null) {
            val flutterProfile = registry.find("flutter")
            if (flutterProfile != null && registry.findExecutable(flutterProfile, "dart") != null) {
                runtimeDir = registry.runtimeDir(flutterProfile)
            }
        }
        val runtime = DartFlutterRuntimeEngine(runtimeDir)
        val result = runtime.runDart(source, name, workDir)
        return Result(result.success, result.mode, "dart", result.output)
    }

    private fun runFlutter(projectDir: File): Result {
        val profile = registry.find("flutter") ?: return missing("flutter", "flutter runtime profile")
        val runtime = DartFlutterRuntimeEngine(registry.runtimeDir(profile))
        val result = runtime.buildFlutter(projectDir, "apk")
        return Result(result.success, result.mode, "flutter", result.output)
    }

    private fun runCSharp(workDir: File, name: String, source: String): Result {
        val sourceFile = File(workDir, safeSourceName(name, ".cs"))
        sourceFile.writeText(source)
        if (isAvailable("csharp", "dotnet")) {
            return runCandidates(workDir, sourceFile.name, source, listOf(listOf("dotnet", "SOURCE")), "csharp")
        }
        if (isAvailable("csharp", "mono")) {
            return runCandidates(workDir, sourceFile.name, source, listOf(listOf("mono", "SOURCE")), "csharp")
        }
        if (isAvailable("csharp", "csc")) {
            return runCandidates(workDir, sourceFile.name, source, listOf(listOf("csc", "SOURCE")), "csharp")
        }
        return missing("csharp", "dotnet/mono/csc")
    }

    private fun runCompiled(workDir: File, name: String, source: String, compiler: String, language: String): Result {
        if (!isAvailable(language, compiler)) return missing(language, compiler)
        val ext = if (language == "cpp") ".cpp" else if (language == "c") ".c" else ".rs"
        val sourceFile = File(workDir, safeSourceName(name, ext))
        sourceFile.writeText(source)
        val binary = File(workDir, "program")
        val compileCommand = listOf(resolve(language, compiler), sourceFile.absolutePath, "-o", binary.absolutePath)
        val compile = execute(compileCommand, workDir)
        if (compile.exitCode != 0) return Result(false, "PROCESS", language, compile.output)
        val runCommand = if (binary.canExecute()) listOf(binary.absolutePath) else listOf("sh", binary.absolutePath)
        val run = execute(runCommand, workDir)
        return Result(run.exitCode == 0, "PROCESS", language, compile.output + "\n" + run.output)
    }

    private fun runCandidates(workDir: File, name: String, source: String, candidates: List<List<String>>, language: String): Result {
        val ext = extensionFor(language)
        val sourceFile = File(workDir, safeSourceName(name, ext))
        sourceFile.writeText(source)
        var missingNames = StringBuilder()
        for (candidate in candidates) {
            val executable = candidate.firstOrNull() ?: continue
            if (!isAvailable(language, executable)) {
                if (missingNames.isNotEmpty()) missingNames.append(", ")
                missingNames.append(executable)
                continue
            }
            val args = candidate.mapIndexed { index, it -> if (index == 0) resolve(language, it) else if (it == "SOURCE") sourceFile.absolutePath else it }
            val result = execute(args, workDir)
            return Result(result.exitCode == 0, "PROCESS", language, result.output)
        }
        return missing(language, missingNames.toString())
    }

    private fun prepareWebPreview(projectDir: File, currentFile: File, source: String, cacheDir: File): File? {
        val previewDir = File(cacheDir, "universal-preview/${System.currentTimeMillis()}")
        if (!previewDir.mkdirs()) return null
        copyWebProject(projectDir, previewDir)
        File(previewDir, "index.html").writeText(source)
        return previewDir
    }

    private fun copyWebProject(source: File, target: File) {
        source.walkTopDown().forEach { file ->
            if (!file.isFile) return@forEach
            val relative = file.relativeTo(source).path
            if (relative.startsWith(".gradle") || relative.startsWith("build") || relative.startsWith(".git")) return@forEach
            val out = File(target, relative)
            out.parentFile?.mkdirs()
            try { file.copyTo(out, true) } catch (_: Exception) {}
        }
    }

    private fun execute(command: List<String>, workDir: File): ExecResult {
        return try {
            val process = ProcessBuilder(command).directory(workDir).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (!process.waitFor(60, TimeUnit.SECONDS)) {
                process.destroy()
                ExecResult(124, output + "\nProcess timed out after 60 seconds.")
            } else {
                ExecResult(process.exitValue(), output)
            }
        } catch (e: Exception) {
            ExecResult(127, "Unable to start '${command.firstOrNull() ?: "process"}': ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun isAvailable(language: String, command: String): Boolean {
        val profile = registry.find(language)
        if (profile != null && registry.findExecutable(profile, command) != null) return true
        return commandAvailable(command)
    }

    private fun resolve(language: String, command: String): String {
        val profile = registry.find(language)
        val bundled = if (profile != null) registry.findExecutable(profile, command) else null
        return bundled?.absolutePath ?: command
    }

    private fun commandAvailable(command: String): Boolean {
        return try {
            val p = ProcessBuilder("sh", "-c", "command -v $command").redirectErrorStream(true).start()
            p.inputStream.close()
            p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0
        } catch (_: Exception) { false }
    }

    private fun missing(language: String, runtime: String): Result = Result(false, "PROCESS", language, "Runtime/compiler not available on this device: $runtime")

    private fun looksLikeHtml(source: String): Boolean {
        val s = source.trim().toLowerCase()
        return s.startsWith("<!doctype html") || s.startsWith("<html") || (s.contains("<script") && s.contains("<body"))
    }

    private fun looksLikePython(source: String): Boolean {
        val s = source.trim()
        return s.contains("print(") && (s.contains(" = ") || s.contains("def ") || s.contains("for ") || s.contains("import "))
    }

    private fun looksLikeJavaScript(source: String): Boolean {
        val s = source.trim()
        return s.contains("console.log(") || s.contains("function ") || s.contains("const ") || s.contains("let ")
    }

    private fun looksLikeShell(source: String): Boolean {
        val s = source.trim()
        return s.startsWith("#!/bin/sh") || s.startsWith("#!/bin/bash") || s.contains("echo ") && s.contains("$" )
    }

    private fun safeSourceName(name: String, fallbackExt: String): String {
        val clean = name.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        return if (clean.contains(".")) clean else "Main$fallbackExt"
    }

    private fun extensionFor(language: String): String = when (language) {
        "javascript" -> ".js"
        "typescript" -> ".ts"
        "python" -> ".py"
        "php" -> ".php"
        "ruby" -> ".rb"
        "perl" -> ".pl"
        "lua" -> ".lua"
        "shell", "bash" -> ".sh"
        "go" -> ".go"
        "swift" -> ".swift"
        "dart" -> ".dart"
        "kotlin-script" -> ".kts"
        "sql" -> ".sql"
        else -> ".txt"
    }

    private data class ExecResult(val exitCode: Int, val output: String)
}
