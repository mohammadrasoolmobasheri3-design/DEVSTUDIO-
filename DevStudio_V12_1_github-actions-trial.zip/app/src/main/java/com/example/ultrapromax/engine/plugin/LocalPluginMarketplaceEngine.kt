package com.example.ultrapromax.engine.plugin

import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

/**
 * Device-local plugin marketplace. There is deliberately no URL/repository support.
 * Packages are discovered from a local catalog, validated, installed and can be removed.
 */
class LocalPluginMarketplaceEngine {
    data class PackageInfo(val id: String, val name: String, val version: String, val file: File, val sha256: String)
    data class Result(val success: Boolean, val message: String)

    fun isCatalogOperational(root: File): Boolean {
        return root.isDirectory && root.canRead() && root.canWrite()
    }

    fun scan(root: File): List<PackageInfo> {
        if (!root.isDirectory) return emptyList()
        val result = ArrayList<PackageInfo>()
        root.listFiles()?.forEach { file ->
            if (file.isFile && file.name.toLowerCase().endsWith(".zip")) {
                val info = read(file)
                if (info != null) result.add(info)
            }
        }
        return result.sortedBy { it.name.toLowerCase() }
    }

    fun install(packageFile: File, installedRoot: File): Result {
        if (!packageFile.isFile) return Result(false, "Plugin package not found")
        val info = read(packageFile) ?: return Result(false, "Invalid plugin package")
        return try {
            val target = File(installedRoot, info.id).canonicalFile
            val base = installedRoot.canonicalFile
            if (!target.absolutePath.startsWith(base.absolutePath + File.separator)) return Result(false, "Unsafe plugin target")
            if (target.exists()) target.deleteRecursively()
            target.mkdirs()
            ZipFile(packageFile).use { zip ->
                zip.entries().asSequence().forEach { entry ->
                    if (entry.isDirectory) return@forEach
                    val out = File(target, entry.name).canonicalFile
                    if (!out.absolutePath.startsWith(target.absolutePath + File.separator)) throw SecurityException("Unsafe plugin path")
                    out.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input -> out.outputStream().use { input.copyTo(it) } }
                }
            }
            File(target, ".integrity").writeText(contentSha(target))
            Result(true, "Installed ${info.id} ${info.version}")
        } catch (e: Exception) { Result(false, e.message ?: "Plugin installation failed") }
    }

    fun uninstall(id: String, installedRoot: File): Result {
        if (!id.matches(Regex("[A-Za-z0-9_.-]+"))) return Result(false, "Invalid plugin id")
        val target = File(installedRoot, id).canonicalFile
        val base = installedRoot.canonicalFile
        if (!target.absolutePath.startsWith(base.absolutePath + File.separator)) return Result(false, "Unsafe plugin target")
        return if (target.isDirectory) Result(target.deleteRecursively(), if (target.exists()) "Could not remove plugin" else "Removed $id")
        else Result(false, "Plugin is not installed")
    }

    fun verifyInstalled(id: String, installedRoot: File): Boolean {
        val target = File(installedRoot, id)
        val marker = File(target, ".integrity")
        if (!target.isDirectory || !marker.isFile) return false
        val expected = marker.readText().trim()
        val sourceFiles = target.walkTopDown().filter { it.isFile && it.name != ".integrity" }.sortedBy { it.relativeTo(target).path }
        val digest = MessageDigest.getInstance("SHA-256")
        sourceFiles.forEach { f ->
            digest.update(f.relativeTo(target).path.replace(File.separatorChar, '/').toByteArray(Charsets.UTF_8))
            digest.update(0)
            digest.update(f.readBytes())
            digest.update(0)
        }
        return digest.digest().toHex() == expected
    }

    private fun read(file: File): PackageInfo? {
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry("devstudio.extension") ?: return null
                var id = file.nameWithoutExtension
                var name = id
                var version = "0.0.0"
                zip.getInputStream(entry).bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val i = line.indexOf('=')
                        if (i <= 0) return@forEach
                        when (line.substring(0, i).trim()) {
                            "id" -> id = line.substring(i + 1).trim()
                            "name" -> name = line.substring(i + 1).trim()
                            "version" -> version = line.substring(i + 1).trim()
                        }
                    }
                }
                if (!id.matches(Regex("[A-Za-z0-9_.-]+"))) return null
                PackageInfo(id, name, version, file, packageSha(file))
            }
        } catch (_: Exception) { null }
    }

    private fun packageSha(file: File): String {
        val d = MessageDigest.getInstance("SHA-256")
        d.update(file.readBytes())
        return d.digest().toHex()
    }

    private fun contentSha(root: File): String {
        val d = MessageDigest.getInstance("SHA-256")
        root.walkTopDown().filter { it.isFile && it.name != ".integrity" }
            .sortedBy { it.relativeTo(root).path }
            .forEach { f ->
                d.update(f.relativeTo(root).path.replace(File.separatorChar, '/').toByteArray(Charsets.UTF_8))
                d.update(0)
                d.update(f.readBytes())
                d.update(0)
            }
        return d.digest().toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { String.format("%02x", it) }
}
