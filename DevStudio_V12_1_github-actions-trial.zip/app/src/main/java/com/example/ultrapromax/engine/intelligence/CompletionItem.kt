package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.symbol.SymbolKind

data class CompletionItem(
    val label: String,
    val kind: SymbolKind?,
    val detail: String?,
    val score: Int,
    val source: String
)
