package com.example.ultrapromax.nextupdate.ai.patch

data class FilePatch(
    val path: String,
    val before: String,
    val after: String
)

data class PatchSet(
    val id: String,
    val patches: List<FilePatch>
)
