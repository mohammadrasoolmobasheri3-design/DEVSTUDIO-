package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class GenericLanguageProvider(
    private val id: String,
    private val name: String,
    private val extensions: List<String>,
    private val lineComment: String?,
    private val blockCommentEnd: String?
) : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition(id, name, extensions, lineComment, null, blockCommentEnd, true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor(id).parse(source)
}
