package com.example.ultrapromax.engine.backup

import android.content.Context
import com.example.ultrapromax.engine.builder.AppBuilderEngine
import com.example.ultrapromax.engine.plugin.BuiltInPlugins
import com.example.ultrapromax.engine.security.SecurityEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * BACKUP ENGINE
 * Real, working local backups: zips a project into <filesDir>/backups/ with a
 * timestamped name, lists them, and can restore (unzip) back over a project
 * folder. Entirely offline — no cloud involved.
 *
 * Each backup also writes a companion ".manifest" file (relativePath|sha256
 * per line) so SecurityEngine/autoHealIfCorrupted() can detect and repair a
 * corrupted file automatically without needing the whole project restored.
 *
 * Backup rotation is supported through rotateBackups(). Scheduled WorkManager
 * integration and diff-based incremental archives remain optional extensions.
 */
class BackupEngine(private val context: Context) {

    private val builder = AppBuilderEngine()
    private val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    private val backupsDir: File
        get() = File(context.filesDir, "backups").apply { mkdirs() }

    fun backup(projectDir: File, projectName: String): File {
        val zipFile = File(backupsDir, "${projectName}_${stamp.format(Date())}.zip")
        builder.exportAsZip(projectDir, zipFile)
        writeManifest(projectDir, zipFile)
        return zipFile
    }

    /**
     * A "build" export: same as backup(), but runs the Minifier plugin over
     * every .css/.js file if it's enabled — separate from backup() so your
     * restorable backups always stay byte-for-byte faithful.
     */
    fun exportMinified(projectDir: File, projectName: String): File {
        val zipFile = File(backupsDir, "${projectName}_minified_${stamp.format(Date())}.zip")
        builder.exportAsZip(projectDir, zipFile) { fileName, bytes ->
            val language = when {
                fileName.endsWith(".css") -> "css"
                fileName.endsWith(".js") -> "js"
                else -> return@exportAsZip bytes
            }
            BuiltInPlugins.minifier.minify(String(bytes, Charsets.UTF_8), language).toByteArray()
        }
        return zipFile
    }

    fun listBackups(projectName: String? = null): List<File> {
        val all = backupsDir.listFiles()
            ?.filter { it.isFile && it.extension == "zip" && !it.name.contains("_minified_") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        return if (projectName != null) all.filter { it.name.startsWith(projectName) } else all
    }

    fun restore(backupZip: File, targetDir: File) {
        targetDir.mkdirs()
        ZipInputStream(backupZip.inputStream()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val outFile = safeZipTarget(targetDir, entry.name)
                    ?: throw SecurityException("Unsafe backup entry: ${entry.name}")
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output -> zis.copyTo(output) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun rotateBackups(projectName: String, keepLatest: Int = 10): Int {
        if (keepLatest < 1) return 0
        val backups = listBackups(projectName)
        var deleted = 0
        backups.drop(keepLatest).forEach { file ->
            val manifest = File(file.parentFile, file.nameWithoutExtension + ".manifest")
            if (file.delete()) {
                manifest.delete()
                deleted++
            }
        }
        return deleted
    }

    fun backupAndRotate(projectDir: File, projectName: String, keepLatest: Int = 10): File {
        val result = backup(projectDir, projectName)
        rotateBackups(projectName, keepLatest)
        return result
    }

    fun deleteBackup(backupZip: File): Boolean = backupZip.delete()

    data class IntegrityReport(
        val backup: File?,
        val checked: Int,
        val valid: Int,
        val missing: Int,
        val invalid: Int
    )

    fun latestBackup(projectName: String): File? = listBackups(projectName).firstOrNull()

    fun verifyLatest(projectName: String): IntegrityReport {
        val zip = latestBackup(projectName) ?: return IntegrityReport(null, 0, 0, 0, 0)
        val manifest = File(zip.parentFile, zip.nameWithoutExtension + ".manifest")
        if (!manifest.exists()) return IntegrityReport(zip, 0, 0, 0, 0)
        var checked = 0
        var valid = 0
        var missing = 0
        var invalid = 0
        // Verify the archive itself by reading every entry; the manifest is used as
        // the source-of-truth for the expected file count and hashes.
        val expected = manifest.readLines().filter { it.contains("|") }
        checked = expected.size
        ZipInputStream(zip.inputStream()).use { zis ->
            val seen = HashSet<String>()
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val bytes = zis.readBytes()
                    seen.add(entry.name)
                    val line = expected.firstOrNull { it.substringBefore("|") == entry.name }
                    if (line != null) {
                        val wanted = line.substringAfter("|")
                        val digest = SecurityEngine.checksumBytes(bytes)
                        if (digest == wanted) valid++ else invalid++
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
            missing = expected.count { !seen.contains(it.substringBefore("|")) }
        }
        return IntegrityReport(zip, checked, valid, missing, invalid)
    }

    private fun safeZipTarget(targetDir: File, entryName: String): File? {
        val root = targetDir.canonicalFile
        val candidate = File(root, entryName).canonicalFile
        val prefix = root.path + File.separator
        return if (candidate.path == root.path || candidate.path.startsWith(prefix)) candidate else null
    }

    private fun writeManifest(projectDir: File, zipFile: File) {
        val parentDir = zipFile.parentFile ?: return
        val manifest = File(parentDir, zipFile.nameWithoutExtension + ".manifest")
        val lines = projectDir.walkTopDown().filter { it.isFile }.map { file ->
            val relative = file.relativeTo(projectDir).path
            "$relative|${SecurityEngine.checksum(file)}"
        }
        manifest.writeText(lines.joinToString("\n"))
    }

    /**
     * SELF-HEALING: compares every file in [projectDir] against the newest
     * backup's manifest. If a file that the manifest says should have real
     * content is now missing or empty (the classic sign of accidental
     * truncation/corruption), it's silently restored from that backup zip.
     * Returns the number of files healed.
     */
    fun autoHealIfCorrupted(projectDir: File, projectName: String): Int {
        val backups = listBackups(projectName)

        if (backups.isEmpty()) {
            return 0
        }

        val latestZip: File = backups.maxBy { it.lastModified() } ?: return 0
        val parentDir = latestZip.parentFile ?: return 0
        val manifestFile = File(parentDir, latestZip.nameWithoutExtension + ".manifest")
        if (!manifestFile.exists()) return 0

        var healedCount = 0
        manifestFile.readLines().forEach { line: String ->
            val parts = line.split("|")
            if (parts.size != 2) return@forEach
            val (relativePath, expectedChecksum) = parts
            val file = File(projectDir, relativePath)

            val looksCorrupted = !file.exists() || (file.length() == 0L && expectedChecksum != EMPTY_FILE_CHECKSUM)
            if (looksCorrupted) {
                if (!file.exists()) file.parentFile?.mkdirs()
                val healed = SecurityEngine.selfHealIfNeeded(
                    file = file.apply { if (!exists()) createNewFile() },
                    knownGoodChecksum = expectedChecksum,
                    backupZip = latestZip,
                    relativePathInZip = relativePath
                )
                if (healed) healedCount++
            }
        }
        return healedCount
    }

    companion object {
        // SHA-256 of zero bytes — used to tell "legitimately empty file" apart from "corrupted".
        private const val EMPTY_FILE_CHECKSUM = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    }
}
