package com.example.ultrapromax.engine.visual

/** Offline responsive layout model shared by Design, Preview and Code generation. */
class ResponsiveLayoutEngine {
    data class Constraint(val id: String, val minWidthDp: Int, val maxWidthDp: Int, val columns: Int, val gapDp: Int)
    fun defaults(): List<Constraint> = listOf(
        Constraint("compact", 0, 599, 1, 12),
        Constraint("medium", 600, 839, 2, 16),
        Constraint("expanded", 840, 10000, 4, 24)
    )
    fun columns(widthDp: Int): Int = defaults().firstOrNull { widthDp >= it.minWidthDp && widthDp <= it.maxWidthDp }?.columns ?: 1
}
