package com.example.ultrapromax.nextupdate.security

class AgentSecurityPolicy {
    fun allowsMutation(approved: Boolean): Boolean = approved
    fun allowsNetwork(isOffline: Boolean, localHost: Boolean): Boolean = isOffline && localHost
}
