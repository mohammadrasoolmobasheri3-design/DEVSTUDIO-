package com.example.ultrapromax.engine.plugin

import android.content.Context

/** Transactional local plugin lifecycle. State changes happen only after permission checks. */
class PluginLifecycleEngine(private val context: Context, private val manager: PluginManager) {
    data class Result(val success: Boolean, val message: String)
    fun enable(plugin: Plugin): Result {
        if (plugin.permissions.any { !manager.grantedPermissions(plugin).contains(it) }) return Result(false, "Permission grant required before enabling ${plugin.id}.")
        manager.setEnabled(context, plugin, true)
        return Result(manager.isEnabled(plugin), if (manager.isEnabled(plugin)) "Enabled ${plugin.id}." else "Enable failed.")
    }
    fun disable(plugin: Plugin): Result { manager.setEnabled(context, plugin, false); return Result(!manager.isEnabled(plugin), "Disabled ${plugin.id}.") }
}
