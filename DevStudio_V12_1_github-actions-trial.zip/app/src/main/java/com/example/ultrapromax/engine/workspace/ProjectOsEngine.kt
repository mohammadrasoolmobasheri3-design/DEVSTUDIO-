package com.example.ultrapromax.engine.workspace

import android.content.Context
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import java.io.File
import java.util.Properties

/**
 * ENDGAME Stage 3: Project OS.
 *
 * Provides a single, offline control plane for project mounting, workspace
 * metadata, project discovery, safe path resolution and recent-project state.
 * It deliberately uses only local files and Android APIs so it remains
 * compatible with the existing Gradle/AGP/Kotlin baseline.
 */
class ProjectOsEngine(private val context: Context) {

    data class ProjectOsState(
        val project: Project,
        val root: File,
        val mounted: Boolean,
        val writable: Boolean,
        val manifestPresent: Boolean,
        val studioDirPresent: Boolean,
        val fileCount: Int,
        val folderCount: Int,
        val bytes: Long
    )

    data class ProjectEntry(
        val project: Project,
        val exists: Boolean,
        val valid: Boolean
    )

    private val workspaceEngine = WorkspaceEngine(context)

    fun mount(project: Project): ProjectOsState {
        val root = File(project.folderPath)
        val mounted = workspaceEngine.mount(project)
        ensureStudioStructure(root)
        writeManifestIfMissing(project, root)
        return inspect(project)
    }

    fun inspect(project: Project): ProjectOsState {
        val root = File(project.folderPath)
        val workspace = workspaceEngine.inspect(project)
        val studioDir = File(root, ".devstudio")
        return ProjectOsState(
            project = project,
            root = root,
            mounted = workspace.exists,
            writable = workspace.writable,
            manifestPresent = File(root, ".devstudio-project").isFile,
            studioDirPresent = studioDir.isDirectory,
            fileCount = workspace.fileCount,
            folderCount = workspace.directoryCount,
            bytes = workspace.bytes
        )
    }

    fun discoverProjects(): List<ProjectEntry> =
        ProjectStore.list(context).map { project ->
            val root = File(project.folderPath)
            ProjectEntry(project, root.isDirectory, isValidProjectRoot(root))
        }

    fun open(project: Project): ProjectOsState {
        val state = mount(project)
        if (state.mounted) {
            WorkspaceSession.open(context, project, WorkspaceSession.lastTab(context), WorkspaceSession.resolveLastFile(context, project))
            ProjectStore.touch(context, project.id)
        }
        return state
    }

    fun close(project: Project) {
        if (WorkspaceSession.lastProjectId(context) == project.id) WorkspaceSession.clear(context)
    }

    fun resolve(project: Project, relativePath: String): File? =
        workspaceEngine.resolveRelative(project, relativePath)

    fun relative(project: Project, file: File): String? =
        workspaceEngine.relativePath(project, file)

    fun stateSummary(state: ProjectOsState): String {
        if (!state.mounted) return "PROJECT OS • UNMOUNTED"
        val writable = if (state.writable) "RW" else "RO"
        val manifest = if (state.manifestPresent) "META✓" else "META!"
        val studio = if (state.studioDirPresent) "STUDIO✓" else "STUDIO!"
        return "PROJECT OS • $writable • $manifest • $studio • ${state.fileCount} files"
    }

    private fun ensureStudioStructure(root: File) {
        listOf(
            ".devstudio",
            ".devstudio/backups",
            ".devstudio/cache",
            ".devstudio/tasks",
            ".devstudio/index"
        ).forEach { File(root, it).mkdirs() }
    }

    private fun writeManifestIfMissing(project: Project, root: File) {
        val manifest = File(root, ".devstudio/project-os.properties")
        if (manifest.exists()) return
        try {
            val properties = Properties()
            properties.setProperty("format", "1")
            properties.setProperty("projectId", project.id.toString())
            properties.setProperty("name", project.name)
            properties.setProperty("template", project.template)
            properties.setProperty("version", "30.1.0")
            properties.setProperty("offline", "true")
            properties.setProperty("workspace", "project-os")
            manifest.outputStream().use { properties.store(it, "DEVSTUDIO Project OS") }
        } catch (_: Exception) {
            // Project metadata is auxiliary; never block opening a project.
        }
    }

    private fun isValidProjectRoot(root: File): Boolean {
        if (!root.isDirectory) return false
        return try {
            root.canonicalFile.isDirectory && root.canRead()
        } catch (_: Exception) {
            false
        }
    }
}
