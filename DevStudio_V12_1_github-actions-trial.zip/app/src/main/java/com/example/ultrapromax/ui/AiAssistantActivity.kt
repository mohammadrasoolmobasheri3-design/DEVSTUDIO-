package com.example.ultrapromax.ui

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.ai.AiStudioAssistantEngine
import com.example.ultrapromax.engine.ai.OfflineAiAgentEngine
import com.example.ultrapromax.nextupdate.agent.AiAgentLoopEngine
import com.example.ultrapromax.engine.editor.EditorEngine
import com.example.ultrapromax.engine.theme.ThemeEngine
import java.io.File

/** V30.1.0 Stage 15 — offline, project-aware AI Assistant. */
class AiAssistantActivity : AppCompatActivity() {
    private var projectRoot: File? = null
    private var currentFile: File? = null
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var studioAi: AiStudioAssistantEngine
    private lateinit var agent: OfflineAiAgentEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_assistant)
        ThemeEngine.applyTo(this)

        val projectId = intent.getLongExtra("extra_project_id", -1L)
        val project = if (projectId != -1L) ProjectStore.getById(this, projectId) else null
        projectRoot = project?.folderPath?.let { File(it) }
        currentFile = intent.getStringExtra("extra_file_path")?.let { File(it) }
        studioAi = AiStudioAssistantEngine(projectRoot)
        agent = OfflineAiAgentEngine(projectRoot)

        chat = findViewById(R.id.aiChat)
        input = findViewById(R.id.aiInput)
        status = findViewById(R.id.aiStatus)
        status.text = if (project != null) "Offline AI • ${project.name}" else "Offline AI • General"

        findViewById<Button>(R.id.btnAskAi).setOnClickListener { ask() }
        findViewById<Button>(R.id.btnAnalyzeProject).setOnClickListener { askPreset("پروژه را تحلیل کن") }
        findViewById<Button>(R.id.btnCheckCode).setOnClickListener { askPreset("کد را بررسی کن") }
        findViewById<Button>(R.id.btnListFiles).setOnClickListener { askPreset("فایل‌های پروژه را لیست کن") }
        findViewById<Button>(R.id.btnAiPlan).setOnClickListener { showPlan() }
        findViewById<Button>(R.id.btnAgentLoop).setOnClickListener { runAgentLoop() }
    }

    private fun askPreset(text: String) {
        input.setText(text)
        ask()
    }

    private fun ask() {
        val question = input.text.toString().trim()
        if (question.isEmpty()) return
        addMessage(question, true)
        val text = readCurrentFile()
        val response = agent.ask(question, currentFile, text)
        addMessage(response.text, false)
        if (response.action == OfflineAiAgentEngine.Action.FIX_CURRENT_FILE) showFixPreview(text)
        input.setText("")
    }

    private fun runAgentLoop() {
        val file = currentFile
        if (file == null || !file.exists()) {
            addMessage("Agent Loop: ابتدا یک فایل پروژه را باز کنید.", false)
            return
        }
        val before = readCurrentFile()
        val engine = AiAgentLoopEngine(projectRoot)
        val result = engine.inspectAndPropose(file, before)
        addMessage(result.message, false)
        val session = result.session
        if (session == null || !session.changed) return

        val details = "فایل: ${file.name}\nزبان: ${session.language}\nمشکلات قبل: ${session.beforeIssues}\nمشکلات بعد از پیشنهاد: ${session.afterIssues}\n\nاین Agent Loop محدود، آفلاین و فقط داخل پروژه است. تغییرات فقط با تأیید شما اعمال می‌شود."
        AlertDialog.Builder(this)
            .setTitle("AI Agent Loop • Safe Patch")
            .setMessage(details)
            .setNegativeButton("لغو", null)
            .setPositiveButton("تأیید و اجرا") { _, _ ->
                val applied = engine.applyApproved(session)
                addMessage(applied.message, false)
            }
            .show()
    }

    private fun showPlan() {
        val question = input.text.toString().trim().ifEmpty { "پروژه را بررسی و برای اصلاح آماده کن" }
        val plan = studioAi.preparePlan(question)
        addMessage(plan.text, false)
    }

    private fun showFixPreview(before: String) {
        val file = currentFile
        if (file == null || !file.exists()) {
            addMessage("فایل فعلی برای Auto Fix پیدا نشد.", false)
            return
        }
        val patch = studioAi.createSafePatch(file, before)
        if (patch == null) {
            addMessage("تغییر امن و مشخصی برای اعمال پیدا نشد.", false)
            return
        }
        val after = patch.patches[0].after
        val preview = Button(this)
        preview.text = "مشاهده تغییرات و تأیید Auto Fix"
        preview.setOnClickListener {
            val message = "فایل: ${file.name}\n\nقبل: ${before.length} کاراکتر\nبعد: ${after.length} کاراکتر\n\nتغییر فقط پس از تأیید شما اعمال می‌شود."
            AlertDialog.Builder(this)
                .setTitle("AI Safe Patch")
                .setMessage(message)
                .setNegativeButton("لغو", null)
                .setPositiveButton("تأیید و اعمال") { _, _ ->
                    if (studioAi.approve(patch) && studioAi.applyApproved(patch)) {
                        addMessage("✓ اصلاح امن روی ${file.name} اعمال شد.", false)
                        preview.visibility = View.GONE
                    } else {
                        addMessage("✕ اعمال تغییرات انجام نشد.", false)
                    }
                }
                .show()
        }
        chat.addView(preview)
    }

    private fun readCurrentFile(): String {
        val file = currentFile ?: return ""
        return try { if (file.exists() && file.length() <= 1024 * 1024L) file.readText() else "" } catch (_: Exception) { "" }
    }

    private fun addMessage(text: String, user: Boolean) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(if (user) Color.WHITE else Color.parseColor("#D6DEEB"))
        tv.textSize = 14f
        tv.setPadding(18, 14, 18, 14)
        tv.setBackgroundColor(if (user) Color.parseColor("#3B2B78") else Color.parseColor("#151C28"))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 6, 0, 6)
        chat.addView(tv, lp)
    }
}
