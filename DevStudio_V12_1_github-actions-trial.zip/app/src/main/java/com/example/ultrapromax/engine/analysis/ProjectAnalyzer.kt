package com.example.ultrapromax.engine.analysis

import com.example.ultrapromax.engine.language.LanguageService
import java.io.File

/** Project-level analysis facade. Keeps analysis independent from UI and runtime execution. */
class ProjectAnalyzer(private val root: File) {
    private val languageService = LanguageService()
    private val diagnostics = DiagnosticEngine(languageService)

    data class Report(
        val diagnostics: List<Diagnostic>,
        val summary: AnalysisSummary
    )

    fun run(): Report {
        if (!root.isDirectory) {
            return Report(emptyList(), AnalysisSummary(0, 0, 0, 0, 0, 0))
        }
        languageService.indexProject(root)
        val found = diagnostics.analyzeProject(root)
        return Report(found, diagnostics.summarize(root, found))
    }

    fun analyzeFile(file: File): List<Diagnostic> = diagnostics.analyzeFile(file)

    fun analyzeBuffer(fileName: String, source: String): List<Diagnostic> =
        diagnostics.analyzeBuffer(fileName, source)
}
