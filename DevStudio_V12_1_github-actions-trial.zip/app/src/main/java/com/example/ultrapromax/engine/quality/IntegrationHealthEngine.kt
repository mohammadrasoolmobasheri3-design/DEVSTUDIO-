package com.example.ultrapromax.engine.quality

import android.content.Context
import com.example.ultrapromax.engine.workspace.WorkspaceEngine
import java.io.File

/** V30.1.0 cross-module integration health checks. Offline and deterministic. */
class IntegrationHealthEngine(private val context: Context) {
    data class Check(val name: String, val passed: Boolean, val detail: String)
    data class Report(val checks: List<Check>, val durationMs: Long) {
        fun passed(): Int = checks.count { it.passed }
        fun failed(): Int = checks.count { !it.passed }
        fun isHealthy(): Boolean = failed() == 0
    }

    fun run(projectRoot: File?): Report {
        val started = System.currentTimeMillis()
        val checks = ArrayList<Check>()
        checks.add(classCheck("Workspace Core", "com.example.ultrapromax.engine.workspace.WorkspaceEngine"))
        checks.add(classCheck("Recovery Core", "com.example.ultrapromax.engine.security.RecoveryEngine"))
        checks.add(classCheck("Language Core", "com.example.ultrapromax.engine.language.LanguageService"))
        checks.add(classCheck("Code Intelligence", "com.example.ultrapromax.engine.intelligence.CodeIntelligenceService"))
        checks.add(classCheck("Diagnostics", "com.example.ultrapromax.engine.analysis.AnalysisService"))
        checks.add(classCheck("Build Pipeline", "com.example.ultrapromax.engine.buildrun.BuildPipelineEngine"))
        checks.add(classCheck("Runtime Registry", "com.example.ultrapromax.engine.run.LanguageRuntimeRegistry"))
        checks.add(classCheck("Dependency Core", "com.example.ultrapromax.engine.dependency.PackageDependencyEngine"))
        checks.add(classCheck("Extension Platform", "com.example.ultrapromax.engine.plugin.ExtensionPlatformEngine"))
        checks.add(classCheck("Studio Experience", "com.example.ultrapromax.engine.studio.StudioExperienceEngine"))
        checks.add(classCheck("Advanced Studio", "com.example.ultrapromax.engine.studio.AdvancedStudioEngine"))
        checks.add(classCheck("Studio Tasks", "com.example.ultrapromax.engine.studio.StudioTaskEngine"))
        checks.add(classCheck("Studio Navigation", "com.example.ultrapromax.engine.studio.StudioNavigationEngine"))
        checks.add(classCheck("V30 Final Release", "com.example.ultrapromax.engine.finalrelease.FinalReleaseEngine"))
        checks.add(classCheck("Offline Mode", "com.example.ultrapromax.engine.offline.OfflineModeEngine"))
        checks.add(classCheck("Studio Visual System", "com.example.ultrapromax.engine.visual.StudioVisualEngine"))
        checks.add(classCheck("Self Healing", "com.example.ultrapromax.engine.selfhealing.SelfHealingEngine"))
        checks.add(classCheck("Web App Project Builder", "com.example.ultrapromax.engine.webapp.WebAppProjectEngine"))
        checks.add(classCheck("Local Plugin Catalog", "com.example.ultrapromax.engine.plugin.LocalPluginCatalogEngine"))

        if (projectRoot != null) {
            checks.add(workspaceCheck(projectRoot))
            checks.add(roundTripCheck(projectRoot))
        } else {
            checks.add(Check("Workspace Integration", true, "Skipped: no project supplied"))
        }

        return Report(checks, System.currentTimeMillis() - started)
    }

    private fun workspaceCheck(root: File): Check {
        return try {
            val info = WorkspaceEngine(context).inspect(root)
            Check("Workspace Integration", info.exists && info.root?.isDirectory == true,
                if (info.exists && info.root?.isDirectory == true) "Workspace boundary is available" else "Workspace is unavailable")
        } catch (e: Throwable) {
            Check("Workspace Integration", false, e.message ?: "Workspace check failed")
        }
    }

    private fun roundTripCheck(root: File): Check {
        return try {
            val probeDir = File(root, ".devstudio/v30.1.0-quality")
            if (!probeDir.exists() && !probeDir.mkdirs()) {
                return Check("Workspace Write Round-trip", false, "Could not create quality probe directory")
            }
            val probe = File(probeDir, "probe.txt")
            val text = "DEVSTUDIO_V30_1_0_OK"
            probe.writeText(text)
            val ok = probe.readText() == text
            probe.delete()
            if (probeDir.listFiles()?.isEmpty() == true) probeDir.delete()
            Check("Workspace Write Round-trip", ok, if (ok) "Write/read verification passed" else "Read-back mismatch")
        } catch (e: Throwable) {
            Check("Workspace Write Round-trip", false, e.message ?: "Round-trip failed")
        }
    }

    private fun classCheck(name: String, className: String): Check {
        val exists = try { Class.forName(className); true } catch (_: Throwable) { false }
        return Check(name, exists, if (exists) "Available" else "Missing: $className")
    }
}
