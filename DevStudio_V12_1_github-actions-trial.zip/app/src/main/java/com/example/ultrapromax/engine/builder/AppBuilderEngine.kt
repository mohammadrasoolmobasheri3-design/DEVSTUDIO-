package com.example.ultrapromax.engine.builder

import java.io.File
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * APP BUILDER ENGINE. Archive/export primitive used by project backup and sharing.
 * Web projects are converted by WebAppProjectEngine and built by WebAppApkPipelineEngine
 * when the real offline Android toolchain is installed; signing is never simulated.
 */
class AppBuilderEngine {

    fun exportAsZip(
        projectDir: File,
        outputZip: File,
        transform: ((fileName: String, bytes: ByteArray) -> ByteArray)? = null
    ): File {
        BufferedOutputStream(outputZip.outputStream(), 64 * 1024).use { bufferedOut ->
            ZipOutputStream(bufferedOut).use { zos ->
                projectDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entryName = file.relativeTo(projectDir).path
                    zos.putNextEntry(ZipEntry(entryName))
                    if (transform == null) {
                        BufferedInputStream(file.inputStream(), 64 * 1024).use { input ->
                            val buffer = ByteArray(64 * 1024)
                            var count = input.read(buffer)
                            while (count >= 0) {
                                if (count > 0) zos.write(buffer, 0, count)
                                count = input.read(buffer)
                            }
                        }
                    } else {
                        // Transformation is intentionally byte-based for compatibility.
                        zos.write(transform.invoke(file.name, file.readBytes()))
                    }
                    zos.closeEntry()
                }
            }
        }
        return outputZip
    }
}
