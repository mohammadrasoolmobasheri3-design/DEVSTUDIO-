package com.example.ultrapromax.engine.plugin

import java.io.File
import java.util.zip.ZipFile

/** Offline/local plugin catalog. It never contacts a remote marketplace. */
class LocalPluginCatalogEngine {
    data class Entry(val id: String, val name: String, val version: String, val file: File, val valid: Boolean)

    fun scan(root: File): List<Entry> {
        if (!root.isDirectory) return emptyList()
        val result = ArrayList<Entry>()
        root.listFiles()?.forEach { file ->
            if (!file.isFile || !file.name.toLowerCase().endsWith(".zip")) return@forEach
            result.add(readEntry(file))
        }
        return result
    }

    fun validatePackage(file: File): Boolean {
        if (!file.isFile) return false
        return try {
            ZipFile(file).use { zip ->
                zip.getEntry("devstudio.extension") != null
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun readEntry(file: File): Entry {
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry("devstudio.extension") ?: return Entry(file.name, file.nameWithoutExtension, "unknown", file, false)
                val text = zip.getInputStream(entry).bufferedReader().use { it.readText() }
                var id = file.nameWithoutExtension
                var name = id
                var version = "unknown"
                text.lineSequence().forEach { line ->
                    val index = line.indexOf('=')
                    if (index <= 0) return@forEach
                    val key = line.substring(0, index).trim()
                    val value = line.substring(index + 1).trim()
                    when (key) {
                        "id" -> id = value
                        "name" -> name = value
                        "version" -> version = value
                    }
                }
                Entry(id, name, version, file, true)
            }
        } catch (_: Exception) {
            Entry(file.nameWithoutExtension, file.nameWithoutExtension, "unknown", file, false)
        }
    }
}
