package com.example.ultrapromax.engine.workspace

import android.content.Context
import com.example.ultrapromax.data.Project
import java.io.File

/**
 * V26.3 Studio Workspace Core.
 * Keeps workspace mounting, validation and lightweight statistics separate from UI.
 * No network dependency and no changes to the existing project storage format.
 */
class WorkspaceEngine(private val context: Context) {

    data class WorkspaceInfo(
        val project: Project?,
        val root: File?,
        val exists: Boolean,
        val writable: Boolean,
        val fileCount: Int,
        val directoryCount: Int,
        val bytes: Long
    )

    /**
     * File-based inspection overload used by quality/integration checks.
     * Keeps the original Project-based API intact.
     */
    fun inspect(root: File?): WorkspaceInfo {
        if (root == null) {
            return WorkspaceInfo(null, null, false, false, 0, 0, 0L)
        }

        val exists = root.isDirectory
        if (!exists) {
            return WorkspaceInfo(null, root, false, false, 0, 0, 0L)
        }

        var files = 0
        var directories = 0
        var bytes = 0L
        try {
            root.walkTopDown().forEach { item ->
                if (item.isDirectory) directories++
                else if (item.isFile) {
                    files++
                    bytes += item.length()
                }
            }
        } catch (_: Exception) {
            // Diagnostic only.
        }

        return WorkspaceInfo(
            null,
            root,
            true,
            root.canWrite(),
            files,
            directories,
            bytes
        )
    }

    fun inspect(project: Project?): WorkspaceInfo {
        val root = project?.let { File(it.folderPath) }
        val exists = root?.isDirectory == true
        if (!exists) {
            return WorkspaceInfo(project, root, false, false, 0, 0, 0L)
        }

        var files = 0
        var directories = 0
        var bytes = 0L
        try {
            root!!.walkTopDown().forEach { item ->
                if (item.isDirectory) directories++
                else if (item.isFile) {
                    files++
                    bytes += item.length()
                }
            }
        } catch (_: Exception) {
            // Workspace inspection is diagnostic only and must never crash Studio.
        }

        return WorkspaceInfo(
            project,
            root,
            true,
            root!!.canWrite(),
            files,
            directories,
            bytes
        )
    }

    fun mount(project: Project): Boolean {
        return try {
            val root = File(project.folderPath)
            root.isDirectory || root.mkdirs()
        } catch (_: Exception) {
            false
        }
    }

    fun isInsideWorkspace(project: Project, file: File): Boolean {
        return try {
            val rootPath = File(project.folderPath).canonicalFile.toPath()
            val filePath = file.canonicalFile.toPath()
            filePath.startsWith(rootPath)
        } catch (_: Exception) {
            false
        }
    }

    fun relativePath(project: Project, file: File): String? {
        if (!isInsideWorkspace(project, file)) return null
        return try {
            File(project.folderPath).canonicalFile.toPath()
                .relativize(file.canonicalFile.toPath())
                .toString()
                .replace(File.separatorChar, '/')
        } catch (_: Exception) {
            null
        }
    }

    fun resolveRelative(project: Project, relativePath: String): File? {
        if (relativePath.isBlank()) return null
        return try {
            val root = File(project.folderPath).canonicalFile
            val candidate = File(root, relativePath).canonicalFile
            if (!isInsideWorkspace(project, candidate)) null else candidate
        } catch (_: Exception) {
            null
        }
    }

    fun summary(info: WorkspaceInfo): String {
        if (!info.exists) return "Workspace unavailable"
        return "${info.fileCount} files • ${info.directoryCount} folders • ${formatBytes(info.bytes)}"
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> "${bytes / (1024L * 1024L)} MB"
    }
}
