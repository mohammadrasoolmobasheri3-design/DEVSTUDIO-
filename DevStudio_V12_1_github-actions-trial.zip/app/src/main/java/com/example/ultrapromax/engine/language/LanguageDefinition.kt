package com.example.ultrapromax.engine.language

data class LanguageDefinition(
    val id: String,
    val displayName: String,
    val extensions: List<String>,
    val lineComment: String?,
    val blockCommentStart: String?,
    val blockCommentEnd: String?,
    val supportsClasses: Boolean,
    val supportsFunctions: Boolean
)
