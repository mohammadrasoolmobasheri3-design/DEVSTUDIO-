package com.example.ultrapromax.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class AutocompleteManager(
    private val editor: EditText
) {

    private var language = "text"

    private var popup: PopupWindow? = null
    private var popupList: LinearLayout? = null

    private var isApplying = false

    private var currentSuggestions = emptyList<String>()

    private var projectSuggestions = emptyList<String>()

    private var selectedIndex = 0

    private var savedWordStart = -1
    private var savedWordEnd = -1
    private var savedPrefix = ""

    private val allSuggestions =
        mutableMapOf<String, List<String>>()

    private val snippets =
        mutableMapOf<String, List<String>>()

    init {

        loadSuggestions()
        loadSnippets()

        editor.addTextChangedListener(
            object : android.text.TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                }

                override fun afterTextChanged(
                    s: android.text.Editable?
                ) {

                    if (!isApplying) {
                        updateSuggestions()
                    }
                }
            }
        )

        editor.setOnKeyListener { _, keyCode, event ->

            if (event.action != KeyEvent.ACTION_DOWN) {
                return@setOnKeyListener false
            }

            if (
                popup == null ||
                currentSuggestions.isEmpty()
            ) {
                return@setOnKeyListener false
            }

            when (keyCode) {

                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    moveSelection(1)
                    true
                }

                KeyEvent.KEYCODE_DPAD_UP -> {
                    moveSelection(-1)
                    true
                }

                KeyEvent.KEYCODE_ENTER -> {
                    applySelectedSuggestion()
                    true
                }

                KeyEvent.KEYCODE_TAB -> {
                    applySelectedSuggestion()
                    true
                }

                KeyEvent.KEYCODE_ESCAPE -> {
                    hide()
                    true
                }

                else -> false
            }
        }
    }

    fun setProjectSuggestions(suggestions: List<String>) {
        projectSuggestions = suggestions.distinct()
        updateSuggestions()
    }

    fun setLanguage(newLanguage: String) {

        language =
            newLanguage.toLowerCase()

        hide()
    }

    /*
     * ============================================================
     * STAGE 5.2
     * استخراج نام‌های تعریف‌شده در فایل فعلی
     * ============================================================
     */

    private fun collectLocalSymbols(
        text: String
    ): List<String> {

        if (text.isEmpty()) {
            return emptyList()
        }

        val result =
            mutableListOf<String>()

        when (language) {

            "kt" -> {

                collectRegex(
                    text,
                    "\\b(?:val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\bfun\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(",
                    result
                )

                collectRegex(
                    text,
                    "\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\bobject\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\binterface\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectFunctionParameters(
                    text,
                    "fun",
                    result
                )
            }

            "java" -> {

                collectRegex(
                    text,
                    "\\b(?:class|interface|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\b(?:void|boolean|byte|short|int|long|float|double|char|String|[A-Z][A-Za-z0-9_]*)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*(?:=|;|\\))",
                    result
                )

                collectRegex(
                    text,
                    "\\b(?:public|private|protected|static|final|abstract|synchronized|native|default)?\\s*(?:void|boolean|byte|short|int|long|float|double|char|String|[A-Z][A-Za-z0-9_<>,\\[\\]]*)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(",
                    result
                )

                collectJavaParameters(
                    text,
                    result
                )
            }

            "python" -> {

                collectRegex(
                    text,
                    "\\bdef\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(",
                    result
                )

                collectRegex(
                    text,
                    "\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\b([A-Za-z_][A-Za-z0-9_]*)\\s*=",
                    result
                )

                collectRegex(
                    text,
                    "\\bfor\\s+([A-Za-z_][A-Za-z0-9_]*)\\s+in\\b",
                    result
                )

                collectPythonParameters(
                    text,
                    result
                )
            }

            "js",
            "ts" -> {

                collectRegex(
                    text,
                    "\\b(?:let|const|var)\\s+([A-Za-z_$][A-Za-z0-9_$]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\bfunction\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(",
                    result
                )

                collectRegex(
                    text,
                    "\\bclass\\s+([A-Za-z_$][A-Za-z0-9_$]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\binterface\\s+([A-Za-z_$][A-Za-z0-9_$]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\btype\\s+([A-Za-z_$][A-Za-z0-9_$]*)",
                    result
                )

                collectJsParameters(
                    text,
                    result
                )
            }

            "php" -> {

                collectRegex(
                    text,
                    "\\$([A-Za-z_][A-Za-z0-9_]*)",
                    result,
                    true
                )

                collectRegex(
                    text,
                    "\\bfunction\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(",
                    result
                )

                collectRegex(
                    text,
                    "\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )
            }

            "dart" -> {

                collectRegex(
                    text,
                    "\\b(?:var|final|const|late)\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\b(?:class|enum|extension|mixin)\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\b([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^)]*\\)\\s*(?:async\\s*)?\\{",
                    result
                )

                collectDartParameters(
                    text,
                    result
                )
            }

            "c",
            "cpp" -> {

                collectRegex(
                    text,
                    "\\b(?:class|struct|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)",
                    result
                )

                collectRegex(
                    text,
                    "\\b(?:int|long|short|float|double|char|bool|auto|string|void)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*(?:=|;|,)",
                    result
                )

                collectRegex(
                    text,
                    "\\b(?:int|long|short|float|double|char|bool|auto|void|string)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(",
                    result
                )
            }
        }

        return result
            .filter {
                it.length > 0
            }
            .distinct()
    }

    private fun collectRegex(
        text: String,
        pattern: String,
        result: MutableList<String>,
        addDollar: Boolean = false
    ) {

        val regex =
            Regex(pattern)

        regex.findAll(text).forEach { match ->

            if (match.groupValues.size > 1) {

                var value =
                    match.groupValues[1]

                if (addDollar) {
                    value = "$" + value
                }

                if (value.isNotEmpty()) {
                    result.add(value)
                }
            }
        }
    }

    private fun collectFunctionParameters(
        text: String,
        keyword: String,
        result: MutableList<String>
    ) {

        val regex =
            Regex(
                "\\b$keyword\\s+[A-Za-z_][A-Za-z0-9_]*\\s*\\(([^)]*)\\)"
            )

        regex.findAll(text).forEach { match ->

            val parameters =
                match.groupValues[1]

            parameters
                .split(",")
                .forEach { parameter ->

                    val clean =
                        parameter
                            .trim()
                            .replace(
                                Regex(
                                    "=.*"
                                ),
                                ""
                            )
                            .trim()

                    val name =
                        clean
                            .split(":")
                            .firstOrNull()
                            ?.trim()
                            ?: ""

                    if (
                        name.matches(
                            Regex(
                                "[A-Za-z_][A-Za-z0-9_]*"
                            )
                        )
                    ) {
                        result.add(name)
                    }
                }
        }
    }

    private fun collectJavaParameters(
        text: String,
        result: MutableList<String>
    ) {

        val regex =
            Regex(
                "\\(([^)]*)\\)\\s*\\{"
            )

        regex.findAll(text).forEach { match ->

            val parameters =
                match.groupValues[1]

            parameters
                .split(",")
                .forEach { parameter ->

                    val parts =
                        parameter.trim()
                            .split(
                                Regex("\\s+")
                            )

                    if (parts.size >= 2) {

                        val name =
                            parts[
                                parts.size - 1
                            ]

                        if (
                            name.matches(
                                Regex(
                                    "[A-Za-z_][A-Za-z0-9_]*"
                                )
                            )
                        ) {
                            result.add(name)
                        }
                    }
                }
        }
    }

    private fun collectPythonParameters(
        text: String,
        result: MutableList<String>
    ) {

        val regex =
            Regex(
                "\\bdef\\s+[A-Za-z_][A-Za-z0-9_]*\\s*\\(([^)]*)\\)"
            )

        regex.findAll(text).forEach { match ->

            val parameters =
                match.groupValues[1]

            parameters
                .split(",")
                .forEach { parameter ->

                    var name =
                        parameter.trim()

                    name =
                        name.replace(
                            Regex(
                                "=.*"
                            ),
                            ""
                        ).trim()

                    name =
                        name.removePrefix(
                            "*"
                        )

                    if (
                        name.matches(
                            Regex(
                                "[A-Za-z_][A-Za-z0-9_]*"
                            )
                        )
                    ) {
                        result.add(name)
                    }
                }
        }
    }

    private fun collectJsParameters(
        text: String,
        result: MutableList<String>
    ) {

        val regex =
            Regex(
                "\\b(?:function\\s+[A-Za-z_$][A-Za-z0-9_$]*|[A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(([^)]*)\\)"
            )

        regex.findAll(text).forEach { match ->

            val parameters =
                match.groupValues[1]

            parameters
                .split(",")
                .forEach { parameter ->

                    var name =
                        parameter.trim()

                    name =
                        name.replace(
                            Regex(
                                "=.*"
                            ),
                            ""
                        ).trim()

                    name =
                        name.replace(
                            Regex(
                                ":.*"
                            ),
                            ""
                        ).trim()

                    if (
                        name.matches(
                            Regex(
                                "[A-Za-z_$][A-Za-z0-9_$]*"
                            )
                        )
                    ) {
                        result.add(name)
                    }
                }
        }
    }

    private fun collectDartParameters(
        text: String,
        result: MutableList<String>
    ) {

        val regex =
            Regex(
                "\\(([^)]*)\\)\\s*\\{"
            )

        regex.findAll(text).forEach { match ->

            val parameters =
                match.groupValues[1]

            parameters
                .split(",")
                .forEach { parameter ->

                    val parts =
                        parameter.trim()
                            .split(
                                Regex("\\s+")
                            )

                    if (parts.isNotEmpty()) {

                        var name =
                            parts.last()

                        name =
                            name.replace(
                                Regex(
                                    "=.*"
                                ),
                                ""
                            )

                        if (
                            name.matches(
                                Regex(
                                    "[A-Za-z_][A-Za-z0-9_]*"
                                )
                            )
                        ) {
                            result.add(name)
                        }
                    }
                }
        }
    }

    /*
     * ============================================================
     * پیشنهادهای ثابت
     * ============================================================
     */

    private fun loadSuggestions() {

        allSuggestions["kt"] = listOf(
            "abstract",
            "actual",
            "annotation",
            "as",
            "break",
            "by",
            "catch",
            "class",
            "companion",
            "const",
            "constructor",
            "continue",
            "data",
            "delegate",
            "do",
            "else",
            "enum",
            "expect",
            "false",
            "field",
            "file",
            "final",
            "for",
            "fun",
            "get",
            "if",
            "import",
            "in",
            "init",
            "inline",
            "interface",
            "internal",
            "is",
            "lateinit",
            "lazy",
            "object",
            "open",
            "operator",
            "override",
            "package",
            "private",
            "protected",
            "public",
            "return",
            "sealed",
            "set",
            "super",
            "suspend",
            "this",
            "throw",
            "true",
            "try",
            "typealias",
            "typeof",
            "val",
            "var",
            "when",
            "while",
            "println",
            "print",
            "toString",
            "length",
            "let",
            "also",
            "apply",
            "run",
            "with",
            "forEach",
            "map",
            "filter",
            "find",
            "isEmpty",
            "isNotEmpty",
            "mutableListOf",
            "mutableMapOf",
            "listOf",
            "mapOf",
            "arrayOf",
            "String",
            "Int",
            "Long",
            "Boolean",
            "Double",
            "Float",
            "Any",
            "Unit"
        )

        allSuggestions["java"] = listOf(
            "abstract",
            "boolean",
            "break",
            "byte",
            "case",
            "catch",
            "char",
            "class",
            "const",
            "continue",
            "default",
            "do",
            "double",
            "else",
            "enum",
            "extends",
            "final",
            "finally",
            "float",
            "for",
            "if",
            "implements",
            "import",
            "instanceof",
            "int",
            "interface",
            "long",
            "new",
            "package",
            "private",
            "protected",
            "public",
            "return",
            "short",
            "static",
            "super",
            "switch",
            "this",
            "throw",
            "throws",
            "try",
            "void",
            "while",
            "true",
            "false",
            "null",
            "System",
            "println",
            "String",
            "Integer",
            "Long",
            "Boolean",
            "Double",
            "ArrayList",
            "HashMap",
            "List",
            "Map",
            "toString",
            "length",
            "equals",
            "size",
            "add",
            "remove",
            "get",
            "set"
        )

        allSuggestions["python"] = listOf(
            "and",
            "as",
            "assert",
            "async",
            "await",
            "break",
            "class",
            "continue",
            "def",
            "del",
            "elif",
            "else",
            "except",
            "False",
            "finally",
            "for",
            "from",
            "global",
            "if",
            "import",
            "in",
            "is",
            "lambda",
            "None",
            "not",
            "or",
            "pass",
            "raise",
            "return",
            "True",
            "try",
            "while",
            "with",
            "yield",
            "print",
            "input",
            "range",
            "len",
            "list",
            "dict",
            "set",
            "str",
            "int",
            "float",
            "open",
            "self",
            "__init__",
            "append",
            "remove",
            "insert",
            "sort",
            "reverse",
            "items",
            "keys",
            "values"
        )

        allSuggestions["js"] = listOf(
            "break",
            "case",
            "catch",
            "class",
            "const",
            "continue",
            "debugger",
            "default",
            "delete",
            "do",
            "else",
            "export",
            "extends",
            "false",
            "finally",
            "for",
            "function",
            "if",
            "import",
            "in",
            "instanceof",
            "let",
            "new",
            "null",
            "return",
            "static",
            "super",
            "switch",
            "this",
            "throw",
            "true",
            "try",
            "typeof",
            "var",
            "void",
            "while",
            "with",
            "yield",
            "console",
            "log",
            "document",
            "window",
            "querySelector",
            "querySelectorAll",
            "addEventListener",
            "JSON",
            "parse",
            "stringify",
            "map",
            "filter",
            "forEach",
            "length",
            "push",
            "pop",
            "slice",
            "splice"
        )

        val jsSuggestions =
            allSuggestions["js"]
                ?: emptyList()

        allSuggestions["ts"] =
            jsSuggestions +
                listOf(
                    "interface",
                    "type",
                    "public",
                    "private",
                    "protected",
                    "readonly",
                    "namespace",
                    "implements",
                    "abstract",
                    "unknown",
                    "never",
                    "any",
                    "string",
                    "number",
                    "boolean",
                    "enum",
                    "generic"
                )

        allSuggestions["html"] = listOf(
            "html",
            "head",
            "body",
            "title",
            "meta",
            "link",
            "style",
            "script",
            "div",
            "span",
            "section",
            "header",
            "footer",
            "main",
            "nav",
            "article",
            "button",
            "input",
            "textarea",
            "form",
            "label",
            "select",
            "option",
            "table",
            "tr",
            "td",
            "th",
            "ul",
            "ol",
            "li",
            "a",
            "img",
            "video",
            "audio",
            "canvas"
        )

        allSuggestions["css"] = listOf(
            "color",
            "background",
            "background-color",
            "margin",
            "padding",
            "display",
            "position",
            "width",
            "height",
            "top",
            "left",
            "right",
            "bottom",
            "font-size",
            "font-family",
            "font-weight",
            "text-align",
            "border",
            "border-radius",
            "box-shadow",
            "flex",
            "flex-direction",
            "justify-content",
            "align-items",
            "grid",
            "gap",
            "opacity",
            "overflow"
        )

        allSuggestions["php"] = listOf(
            "abstract",
            "and",
            "array",
            "as",
            "break",
            "case",
            "class",
            "const",
            "continue",
            "declare",
            "default",
            "do",
            "echo",
            "else",
            "elseif",
            "extends",
            "false",
            "final",
            "for",
            "foreach",
            "function",
            "global",
            "if",
            "implements",
            "include",
            "interface",
            "namespace",
            "new",
            "null",
            "private",
            "protected",
            "public",
            "require",
            "return",
            "static",
            "switch",
            "this",
            "throw",
            "trait",
            "true",
            "try",
            "use",
            "var",
            "while",
            "isset",
            "empty",
            "count",
            "strlen"
        )

        allSuggestions["dart"] = listOf(
            "abstract",
            "as",
            "assert",
            "async",
            "await",
            "break",
            "case",
            "catch",
            "class",
            "const",
            "continue",
            "default",
            "do",
            "dynamic",
            "else",
            "enum",
            "export",
            "extends",
            "extension",
            "external",
            "factory",
            "false",
            "final",
            "finally",
            "for",
            "Function",
            "if",
            "implements",
            "import",
            "in",
            "is",
            "late",
            "library",
            "mixin",
            "new",
            "null",
            "on",
            "operator",
            "part",
            "required",
            "return",
            "show",
            "static",
            "super",
            "switch",
            "this",
            "throw",
            "true",
            "try",
            "typedef",
            "var",
            "void",
            "while",
            "with",
            "yield",
            "print",
            "String",
            "int",
            "double",
            "bool",
            "List",
            "Map"
        )

        allSuggestions["sql"] = listOf(
            "SELECT",
            "FROM",
            "WHERE",
            "INSERT",
            "INTO",
            "VALUES",
            "UPDATE",
            "DELETE",
            "CREATE",
            "TABLE",
            "ALTER",
            "DROP",
            "JOIN",
            "INNER",
            "LEFT",
            "RIGHT",
            "GROUP",
            "BY",
            "ORDER",
            "HAVING",
            "LIMIT",
            "OFFSET",
            "AS",
            "AND",
            "OR",
            "NOT",
            "NULL",
            "PRIMARY",
            "KEY",
            "FOREIGN",
            "INDEX",
            "COUNT",
            "SUM",
            "AVG",
            "MAX",
            "MIN"
        )

        val cCpp =
            listOf(
                "auto",
                "bool",
                "break",
                "case",
                "char",
                "class",
                "const",
                "continue",
                "default",
                "delete",
                "do",
                "double",
                "else",
                "enum",
                "false",
                "float",
                "for",
                "if",
                "include",
                "int",
                "long",
                "namespace",
                "new",
                "nullptr",
                "private",
                "protected",
                "public",
                "return",
                "short",
                "signed",
                "sizeof",
                "static",
                "struct",
                "switch",
                "template",
                "this",
                "throw",
                "true",
                "try",
                "typedef",
                "typename",
                "using",
                "virtual",
                "void",
                "volatile",
                "while",
                "string",
                "vector",
                "cout",
                "cin",
                "printf",
                "scanf",
                "push_back",
                "size",
                "begin",
                "end"
            )

        allSuggestions["c"] = cCpp
        allSuggestions["cpp"] = cCpp
    }

    private fun loadSnippets() {

        snippets["kt"] =
            listOf(
                "fun",
                "if",
                "else",
                "for",
                "when",
                "class",
                "object",
                "try",
                "trycatch",
                "println"
            )

        snippets["java"] =
            listOf(
                "class",
                "if",
                "else",
                "for",
                "while",
                "try",
                "println",
                "main"
            )

        snippets["python"] =
            listOf(
                "def",
                "class",
                "if",
                "elif",
                "else",
                "for",
                "while",
                "try",
                "print"
            )

        snippets["js"] =
            listOf(
                "function",
                "if",
                "else",
                "for",
                "while",
                "class",
                "console"
            )

        snippets["ts"] =
            snippets["js"]
                ?: emptyList()
    }

    /*
     * ============================================================
     * پیشنهادها
     * ============================================================
     */

    private fun updateSuggestions() {

        val cursor =
            editor.selectionStart

        if (cursor < 0) {
            hide()
            return
        }

        val text =
            editor.text.toString()

        if (cursor > text.length) {
            hide()
            return
        }

        val prefix =
            getCurrentWord(
                text,
                cursor
            )

        val afterDot =
            cursor > 0 &&
                text[cursor - 1] == '.'

        if (
            prefix.isEmpty() &&
            !afterDot
        ) {
            hide()
            return
        }

        val baseSuggestions =
            allSuggestions[language]
                ?: allSuggestions["kt"]
                ?: emptyList()

        val languageSnippets =
            snippets[language]
                ?: emptyList()

        /*
         * Stage 5.2:
         * اول نمادهای خود فایل
         * بعد پیشنهادهای ثابت
         */
        val localSymbols =
            collectLocalSymbols(text)

        var filteredLocal =
            localSymbols
                .filter {
                    it.startsWith(
                        prefix,
                        ignoreCase = true
                    )
                }
                .distinct()

        val combined =
            projectSuggestions +
                baseSuggestions +
                languageSnippets

        var filteredBase =
            combined
                .filter {
                    it.startsWith(
                        prefix,
                        ignoreCase = true
                    )
                }
                .distinct()

        /*
         * پیشنهادهای مربوط به .
         */
        if (afterDot) {

            filteredLocal =
                emptyList()

            filteredBase =
                memberSuggestions(
                    language
                )
                    .filter {
                        it.startsWith(
                            prefix,
                            ignoreCase = true
                        )
                    }
        }

        if (
            filteredLocal.isEmpty() &&
            filteredBase.isEmpty()
        ) {
            hide()
            return
        }

        /*
         * نمادهای محلی اولویت بالاتری دارند.
         */
        val localSorted =
            sortSuggestions(
                filteredLocal,
                prefix
            )

        val baseSorted =
            sortSuggestions(
                filteredBase,
                prefix
            )

        val finalList =
            (localSorted + baseSorted)
                .distinct()
                .take(12)

        if (finalList.isEmpty()) {
            hide()
            return
        }

        currentSuggestions =
            finalList

        selectedIndex = 0

        savedPrefix =
            prefix

        savedWordEnd =
            cursor

        savedWordStart =
            cursor - prefix.length

        showPopup(
            currentSuggestions
        )
    }

    private fun sortSuggestions(
        list: List<String>,
        prefix: String
    ): List<String> {

        return list.sortedWith(
            Comparator { a, b ->

                val aExact =
                    if (
                        a.equals(
                            prefix,
                            ignoreCase = true
                        )
                    ) {
                        0
                    } else {
                        1
                    }

                val bExact =
                    if (
                        b.equals(
                            prefix,
                            ignoreCase = true
                        )
                    ) {
                        0
                    } else {
                        1
                    }

                if (
                    aExact != bExact
                ) {
                    aExact - bExact
                } else {

                    val aStarts =
                        if (
                            a.startsWith(
                                prefix,
                                ignoreCase = true
                            )
                        ) {
                            0
                        } else {
                            1
                        }

                    val bStarts =
                        if (
                            b.startsWith(
                                prefix,
                                ignoreCase = true
                            )
                        ) {
                            0
                        } else {
                            1
                        }

                    if (
                        aStarts != bStarts
                    ) {
                        aStarts - bStarts
                    } else {
                        a.length - b.length
                    }
                }
            }
        )
    }

    private fun memberSuggestions(
        lang: String
    ): List<String> {

        return when (lang) {

            "kt" -> listOf(
                "length",
                "toString",
                "isEmpty",
                "isNotEmpty",
                "let",
                "also",
                "apply",
                "run",
                "with",
                "forEach",
                "map",
                "filter"
            )

            "java" -> listOf(
                "length",
                "toString",
                "equals",
                "hashCode",
                "size",
                "add",
                "remove",
                "get",
                "set"
            )

            "python" -> listOf(
                "append",
                "remove",
                "insert",
                "pop",
                "sort",
                "reverse",
                "lower",
                "upper",
                "strip",
                "split"
            )

            "js",
            "ts" -> listOf(
                "length",
                "toString",
                "map",
                "filter",
                "forEach",
                "push",
                "pop",
                "slice",
                "splice",
                "includes"
            )

            "php" -> listOf(
                "length",
                "toString",
                "count",
                "trim"
            )

            "dart" -> listOf(
                "length",
                "toString",
                "isEmpty",
                "isNotEmpty",
                "map",
                "where",
                "forEach",
                "add",
                "remove"
            )

            "c",
            "cpp" -> listOf(
                "size",
                "begin",
                "end",
                "push_back",
                "clear",
                "empty"
            )

            else -> listOf(
                "length",
                "toString",
                "size"
            )
        }
    }

    private fun getCurrentWord(
        text: String,
        cursor: Int
    ): String {

        if (cursor <= 0) {
            return ""
        }

        var start =
            cursor - 1

        while (start >= 0) {

            val c =
                text[start]

            if (
                !(
                    c.isLetterOrDigit() ||
                    c == '_' ||
                    c == '$'
                )
            ) {
                break
            }

            start--
        }

        return text.substring(
            start + 1,
            cursor
        )
    }

    /*
     * ============================================================
     * Popup
     * ============================================================
     */

    private fun showPopup(
        suggestions: List<String>
    ) {

        hide()

        if (suggestions.isEmpty()) {
            return
        }

        val density =
            editor.resources
                .displayMetrics
                .density

        val container =
            LinearLayout(
                editor.context
            )

        popupList =
            container

        container.orientation =
            LinearLayout.VERTICAL

        container.setPadding(
            (4 * density).toInt(),
            (4 * density).toInt(),
            (4 * density).toInt(),
            (4 * density).toInt()
        )

        val background =
            GradientDrawable()

        background.setColor(
            Color.rgb(
                35,
                35,
                45
            )
        )

        background.cornerRadius =
            8 * density

        container.background =
            background

        suggestions.forEachIndexed {
                index,
                suggestion ->

            val row =
                TextView(
                    editor.context
                )

            row.text =
                suggestion

            row.setTextColor(
                Color.WHITE
            )

            row.textSize =
                16f

            row.gravity =
                Gravity.CENTER_VERTICAL

            row.setPadding(
                (14 * density).toInt(),
                0,
                (14 * density).toInt(),
                0
            )

            row.isClickable = true

            row.isFocusable = false

            if (index == 0) {
                row.setBackgroundColor(
                    Color.rgb(
                        170,
                        110,
                        255
                    )
                )
            }

            val params =
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    (42 * density).toInt()
                )

            container.addView(
                row,
                params
            )

            row.setOnClickListener {

                val selected =
                    suggestion

                editor.post {

                    applySuggestionAtSavedPosition(
                        selected
                    )

                    hide()
                }
            }
        }

        val width =
            (280 * density).toInt()

        val visibleCount =
            minOf(
                suggestions.size,
                6
            )

        val height =
            (
                visibleCount * 42 + 8
            ) * density

        popup =
            PopupWindow(
                container,
                width,
                height.toInt(),
                false
            )

        popup?.isTouchable = true
        popup?.isFocusable = false
        popup?.isOutsideTouchable = true

        popup?.setBackgroundDrawable(
            ColorDrawable(
                Color.TRANSPARENT
            )
        )

        popup?.elevation = 12f

        val cursor =
            editor.selectionStart
                .coerceIn(
                    0,
                    editor.text.length
                )

        val layout =
            editor.layout

        if (layout == null) {

            editor.post {
                showPopup(
                    suggestions
                )
            }

            return
        }

        val location =
            IntArray(2)

        editor.getLocationOnScreen(
            location
        )

        val line =
            layout.getLineForOffset(
                cursor
            )

        val cursorX =
            layout
                .getPrimaryHorizontal(
                    cursor
                )
                .toInt()

        val lineBottom =
            layout.getLineBottom(
                line
            )

        val screenWidth =
            editor.resources
                .displayMetrics
                .widthPixels

        var popupX =
            location[0] +
                cursorX -
                (20 * density).toInt()

        if (
            popupX + width >
            screenWidth - 8
        ) {

            popupX =
                screenWidth -
                    width -
                    8
        }

        if (popupX < 8) {
            popupX = 8
        }

        val popupY =
            location[1] +
                lineBottom -
                editor.scrollY

        popup?.showAtLocation(
            editor,
            Gravity.TOP or
                Gravity.START,
            popupX,
            popupY
        )
    }

    private fun moveSelection(
        direction: Int
    ) {

        if (
            currentSuggestions.isEmpty()
        ) {
            return
        }

        selectedIndex +=
            direction

        if (
            selectedIndex < 0
        ) {
            selectedIndex =
                currentSuggestions.size - 1
        }

        if (
            selectedIndex >=
            currentSuggestions.size
        ) {
            selectedIndex = 0
        }

        updateSelectedRow()
    }

    private fun updateSelectedRow() {

        val container =
            popupList
                ?: return

        for (
            i in 0 until
                container.childCount
        ) {

            val row =
                container.getChildAt(i)
                    as? TextView
                    ?: continue

            if (
                i == selectedIndex
            ) {

                row.setBackgroundColor(
                    Color.rgb(
                        170,
                        110,
                        255
                    )
                )

            } else {

                row.setBackgroundColor(
                    Color.TRANSPARENT
                )
            }
        }
    }

    /*
     * ============================================================
     * Apply
     * ============================================================
     */

    private fun applySelectedSuggestion() {

        if (
            currentSuggestions.isEmpty()
        ) {
            return
        }

        if (
            selectedIndex < 0 ||
            selectedIndex >=
            currentSuggestions.size
        ) {
            return
        }

        val selected =
            currentSuggestions[
                selectedIndex
            ]

        applySuggestionAtSavedPosition(
            selected
        )

        hide()
    }

    private fun applySuggestionAtSavedPosition(
        suggestion: String
    ) {

        if (
            savedWordStart < 0 ||
            savedWordEnd < 0
        ) {
            return
        }

        val currentText =
            editor.text.toString()

        if (
            savedWordStart >
            currentText.length
        ) {
            return
        }

        if (
            savedWordEnd >
            currentText.length
        ) {
            return
        }

        if (
            savedWordStart >
            savedWordEnd
        ) {
            return
        }

        isApplying = true

        try {

            var replacement =
                expandSnippet(
                    suggestion
                )

            if (
                shouldAddParentheses(
                    suggestion
                )
            ) {

                if (
                    !replacement.endsWith(")")
                ) {
                    replacement += "()"
                }
            }

            editor.text.replace(
                savedWordStart,
                savedWordEnd,
                replacement
            )

            if (
                replacement.endsWith("()")
            ) {

                editor.setSelection(
                    savedWordStart +
                        replacement.length -
                        1
                )

            } else {

                editor.setSelection(
                    savedWordStart +
                        replacement.length
                )
            }

        } finally {

            isApplying = false
        }

        savedWordStart = -1
        savedWordEnd = -1
        savedPrefix = ""
    }

    private fun shouldAddParentheses(
        suggestion: String
    ): Boolean {

        return when (language) {

            "kt" -> suggestion in
                listOf(
                    "print",
                    "println",
                    "toString",
                    "let",
                    "also",
                    "apply",
                    "run",
                    "with",
                    "forEach",
                    "map",
                    "filter",
                    "find",
                    "isEmpty",
                    "isNotEmpty",
                    "mutableListOf",
                    "mutableMapOf",
                    "listOf",
                    "mapOf",
                    "arrayOf"
                )

            "java" -> suggestion in
                listOf(
                    "println",
                    "toString",
                    "equals",
                    "hashCode",
                    "add",
                    "remove",
                    "get",
                    "set"
                )

            "python" -> suggestion in
                listOf(
                    "print",
                    "input",
                    "range",
                    "len",
                    "open",
                    "append",
                    "remove",
                    "insert",
                    "pop",
                    "sort",
                    "reverse",
                    "lower",
                    "upper",
                    "strip",
                    "split"
                )

            "js",
            "ts" -> suggestion in
                listOf(
                    "log",
                    "querySelector",
                    "querySelectorAll",
                    "addEventListener",
                    "parse",
                    "stringify",
                    "map",
                    "filter",
                    "forEach",
                    "push",
                    "pop",
                    "slice",
                    "splice",
                    "includes"
                )

            "php" -> suggestion in
                listOf(
                    "count",
                    "strlen",
                    "isset",
                    "empty"
                )

            else -> false
        }
    }

    /*
     * ============================================================
     * Snippets
     * ============================================================
     */

    private fun expandSnippet(
        suggestion: String
    ): String {

        if (language == "kt") {

            when (suggestion) {

                "fun" ->
                    return "fun name() {\n    \n}"

                "if" ->
                    return "if (condition) {\n    \n}"

                "else" ->
                    return "else {\n    \n}"

                "for" ->
                    return "for (item in items) {\n    \n}"

                "when" ->
                    return "when (value) {\n    \n}"

                "class" ->
                    return "class Name {\n    \n}"

                "object" ->
                    return "object Name {\n    \n}"

                "trycatch" ->
                    return "try {\n    \n} catch (e: Exception) {\n    \n}"

                "println" ->
                    return "println()"
            }
        }

        if (language == "python") {

            when (suggestion) {

                "def" ->
                    return "def name():\n    "

                "if" ->
                    return "if condition:\n    "

                "else" ->
                    return "else:\n    "

                "for" ->
                    return "for item in items:\n    "

                "while" ->
                    return "while condition:\n    "

                "print" ->
                    return "print()"
            }
        }

        if (
            language == "js" ||
            language == "ts"
        ) {

            when (suggestion) {

                "function" ->
                    return "function name() {\n    \n}"

                "if" ->
                    return "if (condition) {\n    \n}"

                "else" ->
                    return "else {\n    \n}"

                "for" ->
                    return "for (let i = 0; i < length; i++) {\n    \n}"

                "while" ->
                    return "while (condition) {\n    \n}"

                "class" ->
                    return "class Name {\n    \n}"

                "console" ->
                    return "console.log()"
            }
        }

        if (language == "java") {

            when (suggestion) {

                "class" ->
                    return "class Name {\n    \n}"

                "if" ->
                    return "if (condition) {\n    \n}"

                "else" ->
                    return "else {\n    \n}"

                "for" ->
                    return "for (int i = 0; i < length; i++) {\n    \n}"

                "while" ->
                    return "while (condition) {\n    \n}"

                "println" ->
                    return "System.out.println()"

                "main" ->
                    return "public static void main(String[] args) {\n    \n}"
            }
        }

        return suggestion
    }

    fun hide() {

        popup?.dismiss()

        popup = null

        popupList = null

        currentSuggestions =
            emptyList()

        selectedIndex = 0
    }
}