package com.example.ultrapromax.engine.buildrun

import com.example.ultrapromax.engine.diagnostics.StudioDiagnostic
import java.io.File

/**
 * Conservative offline build fixer. It only applies deterministic fixes when the
 * referenced symbol/import is provably present in the same project.
 */
class BuildAutoFixEngine {

    data class FixResult(
        val applied: Boolean,
        val filePath: String?,
        val description: String
    )

    fun apply(projectDir: File, diagnostics: List<StudioDiagnostic>): List<FixResult> {
        val results = ArrayList<FixResult>()
        for (diagnostic in diagnostics) {
            val result = tryFix(projectDir, diagnostic)
            if (result.applied) results.add(result)
        }
        return results
    }

    private fun tryFix(projectDir: File, diagnostic: StudioDiagnostic): FixResult {
        val message = diagnostic.message
        val match = Regex("Unresolved reference: ([A-Za-z_][A-Za-z0-9_]*)").find(message)
            ?: return FixResult(false, null, "No safe automatic fix for: $message")
        val symbol = match.groupValues[1]
        val sourceFile = File(diagnostic.filePath)
        if (!sourceFile.exists() || !sourceFile.isFile) {
            return FixResult(false, null, "Source file not found: ${diagnostic.filePath}")
        }

        val importName = knownAndroidImport(symbol) ?: findProjectClass(projectDir, symbol)
        if (importName == null) {
            return FixResult(false, null, "No provable import found for $symbol")
        }

        val source = sourceFile.readText()
        val importLine = "import $importName"
        if (Regex("(?m)^\\s*import\\s+${Regex.escape(importName)}\\s*$").containsMatchIn(source)) {
            return FixResult(false, null, "Import already present: $importName")
        }
        if (source.contains(importLine)) {
            return FixResult(false, null, "Import already present: $importName")
        }

        val updated = insertImport(source, importLine)
        if (updated == source) return FixResult(false, null, "Could not safely insert import: $importName")
        sourceFile.writeText(updated)
        return FixResult(true, sourceFile.absolutePath, "Added import $importName")
    }

    private fun knownAndroidImport(symbol: String): String? {
        return when (symbol) {
            "View" -> "android.view.View"
            "Intent" -> "android.content.Intent"
            "Context" -> "android.content.Context"
            "Bundle" -> "android.os.Bundle"
            "Uri" -> "android.net.Uri"
            "File" -> "java.io.File"
            "IOException" -> "java.io.IOException"
            "Locale" -> "java.util.Locale"
            "Date" -> "java.util.Date"
            "ArrayList" -> "java.util.ArrayList"
            "HashMap" -> "java.util.HashMap"
            "HashSet" -> "java.util.HashSet"
            "LinkedHashMap" -> "java.util.LinkedHashMap"
            "LinkedHashSet" -> "java.util.LinkedHashSet"
            else -> null
        }
    }

    private fun findProjectClass(projectDir: File, symbol: String): String? {
        val roots = listOf(
            File(projectDir, "app/src/main/java"),
            File(projectDir, "app/src/main/kotlin"),
            File(projectDir, "src/main/java"),
            File(projectDir, "src/main/kotlin")
        )
        for (root in roots) {
            if (!root.exists()) continue
            val file = root.walkTopDown().firstOrNull {
                it.isFile && (it.extension == "kt" || it.extension == "java") &&
                    Regex("(?m)^(?:public\\s+|internal\\s+|private\\s+|protected\\s+)?(?:class|object|interface|enum\\s+class)\\s+$symbol\\b").containsMatchIn(it.readText())
            } ?: continue
            val relative = file.relativeTo(root).path
            val noExt = relative.substringBeforeLast('.')
            return noExt.split(File.separator).joinToString(".")
        }
        return null
    }

    private fun insertImport(source: String, importLine: String): String {
        val lines = source.split("\n").toMutableList()
        var packageIndex = -1
        var lastImportIndex = -1
        for (i in lines.indices) {
            val line = lines[i]
            if (line.trim().startsWith("package ")) packageIndex = i
            if (line.trim().startsWith("import ")) lastImportIndex = i
        }
        val index = if (lastImportIndex >= 0) lastImportIndex + 1 else if (packageIndex >= 0) packageIndex + 1 else 0
        lines.add(index, importLine)
        return lines.joinToString("\n")
    }
}
