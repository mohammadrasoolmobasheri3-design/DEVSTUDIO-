package com.example.ultrapromax.engine.ai

/** Offline AI facade. Uses deterministic local parsing, completion dictionaries and safe transforms.
 * No network, remote model or remote service is required. A real local ML model can be plugged in later without changing the interface. */
interface AiEngine {
    fun suggest(currentLine: String, language: String): List<String>
    fun lint(fullText: String, language: String): List<LintIssue>
    fun autoFix(fullText: String, language: String): String
}

data class LintIssue(val line: Int, val message: String)

class RuleBasedAiEngine : AiEngine {

    private val dictionary = mapOf(
        "html" to listOf(
            "<div class=\"\"></div>", "<span></span>", "<script src=\"\"></script>",
            "<link rel=\"stylesheet\" href=\"\">", "<h1></h1>", "<h2></h2>", "<p></p>",
            "<a href=\"\"></a>", "<img src=\"\" alt=\"\">", "<button type=\"button\"></button>",
            "<input type=\"text\" placeholder=\"\">", "<form action=\"\" method=\"post\"></form>",
            "<ul>\n  <li></li>\n</ul>", "<table>\n  <tr><td></td></tr>\n</table>",
            "<meta charset=\"UTF-8\">", "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
        ),
        "css" to listOf(
            "display: flex;", "display: grid;", "margin: 0;", "padding: 0;",
            "color: #ffffff;", "background-color: #000000;", "border-radius: 8px;",
            "box-shadow: 0 2px 8px rgba(0,0,0,0.2);", "position: absolute;", "position: relative;",
            "justify-content: center;", "align-items: center;", "font-size: 16px;",
            "font-weight: bold;", "text-align: center;", "width: 100%;", "height: 100vh;",
            "transition: all 0.3s ease;", "@media (max-width: 768px) {\n  \n}"
        ),
        "js" to listOf(
            "function () {}", "const  = () => {}", "console.log()", "document.querySelector('')",
            "document.getElementById('')", "addEventListener('', () => {})", "fetch('')",
            "if () {\n  \n}", "for (let i = 0; i < ; i++) {\n  \n}", "while () {\n  \n}",
            "try {\n  \n} catch (e) {\n  \n}", "JSON.stringify()", "JSON.parse()",
            "setTimeout(() => {\n  \n}, 1000);", "localStorage.setItem('', '');",
            "array.map(item => item)", "array.filter(item => item)"
        ),
        "kt" to listOf(
            "fun main() {}", "val  = ", "var  = ", "class  {}", "data class  ()",
            "when () {\n  \n}", "if () {\n  \n} else {\n  \n}", "for ( in ) {\n  \n}",
            "while () {\n  \n}", "try {\n  \n} catch (e: Exception) {\n  \n}",
            "companion object {}", "override fun ", "private val ", "lateinit var "
        )
    )

    override fun suggest(currentLine: String, language: String): List<String> {
        val trimmed = currentLine.trim()
        val pool = dictionary[language] ?: emptyList()
        if (trimmed.isEmpty()) return pool.take(8)
        val direct = pool.filter { it.startsWith(trimmed, ignoreCase = true) }
        if (direct.isNotEmpty()) return direct.take(8)
        val token = trimmed.substringAfterLast(' ').substringAfterLast('.')
        return pool.filter { it.contains(token, ignoreCase = true) }.take(8)
    }

    override fun lint(fullText: String, language: String): List<LintIssue> {
        val issues = mutableListOf<LintIssue>()
        val lines = fullText.lines()

        if (language == "html") {
            val openTags = Regex("<([a-zA-Z0-9]+)(?:\\s[^>]*)?>").findAll(fullText).map { it.groupValues[1] }.toList()
            val closeTags = Regex("</([a-zA-Z0-9]+)>").findAll(fullText).map { it.groupValues[1] }.toList()
            val selfClosing = setOf("br", "img", "meta", "link", "input", "hr")
            openTags.filterNot { it in selfClosing }.forEach { tag ->
                if (closeTags.count { it == tag } < openTags.count { it == tag }) {
                    issues.add(LintIssue(0, "Possibly unclosed tag: <$tag>"))
                }
            }
        }

        if (language == "js" || language == "kt" || language == "css") {
            val totalOpen = fullText.count { it == '{' }
            val totalClose = fullText.count { it == '}' }
            if (totalOpen != totalClose) {
                issues.add(LintIssue(lines.size, "Mismatched braces: $totalOpen '{' vs $totalClose '}'"))
            }
        }

        if (language == "js" || language == "kt" || language == "css" || language == "html") {
            lines.forEachIndexed { index, line ->
                if (hasUnbalancedQuotesOnLine(line)) {
                    issues.add(LintIssue(index + 1, "Possibly unclosed quote on this line"))
                }
            }
        }

        return issues
    }

    /** Safe structural repair based on the offline lexer. Never rewrites arbitrary user logic. */
    override fun autoFix(fullText: String, language: String): String {
        var fixed = fullText

        if (language == "js" || language == "kt" || language == "css") {
            val opens = fixed.count { it == '{' }
            val closes = fixed.count { it == '}' }
            if (opens > closes) {
                fixed += "\n" + "}".repeat(opens - closes)
            }
        }

        if (language == "html") {
            val selfClosing = setOf("br", "img", "meta", "link", "input", "hr")
            val openTags = Regex("<([a-zA-Z0-9]+)(?:\\s[^>]*)?>").findAll(fixed)
                .map { it.groupValues[1] }.filterNot { it in selfClosing }.toList()
            val closeTags = Regex("</([a-zA-Z0-9]+)>").findAll(fixed).map { it.groupValues[1] }.toList()
            val missing = mutableListOf<String>()
            openTags.groupingBy { it }.eachCount().forEach { (tag, count) ->
                val closedCount = closeTags.count { it == tag }
                repeat(count - closedCount) { missing.add(tag) }
            }
            missing.reversed().forEach { tag -> fixed += "\n</$tag>" }
        }

        if (language == "js" || language == "kt" || language == "css" || language == "html") {
            fixed = fixed.lines().joinToString("\n") { line ->
                if (hasUnbalancedQuotesOnLine(line)) closeDanglingQuote(line) else line
            }
        }

        return fixed
    }

    /** True if this single line has an odd count of un-escaped ' or " (a likely unclosed string). */
    private fun hasUnbalancedQuotesOnLine(line: String): Boolean {
        val doubleCount = Regex("(?<!\\\\)\"").findAll(line).count()
        val singleCount = Regex("(?<!\\\\)'").findAll(line).count()
        return doubleCount % 2 != 0 || singleCount % 2 != 0
    }

    private fun closeDanglingQuote(line: String): String {
        val doubleCount = Regex("(?<!\\\\)\"").findAll(line).count()
        val singleCount = Regex("(?<!\\\\)'").findAll(line).count()
        var result = line
        if (doubleCount % 2 != 0) result += "\""
        if (singleCount % 2 != 0) result += "'"
        return result
    }
}
