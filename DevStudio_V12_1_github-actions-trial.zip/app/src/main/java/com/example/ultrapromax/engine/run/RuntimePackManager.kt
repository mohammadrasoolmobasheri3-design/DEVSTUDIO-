package com.example.ultrapromax.engine.run

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Offline runtime-pack manager. Packs are installed only from a user-selected
 * local ZIP and are extracted inside DEVSTUDIO's private runtime sandbox.
 */
class RuntimePackManager(private val root: File) {

    data class PackInfo(val id: String, val ready: Boolean, val files: Int, val sizeBytes: Long)

    companion object {
        private const val MAX_PACK_BYTES = 512L * 1024L * 1024L
    }

    fun listInstalled(registry: LanguageRuntimeRegistry): List<PackInfo> {
        return registry.all().map { profile ->
            val dir = registry.runtimeDir(profile)
            var count = 0
            var size = 0L
            if (dir.exists()) {
                dir.walkTopDown().forEach { f -> if (f.isFile) { count++; size += f.length() } }
            }
            PackInfo(profile.id, count > 0, count, size)
        }
    }

    fun installZip(zipFile: File, registry: LanguageRuntimeRegistry): String {
        if (!zipFile.isFile) return "Runtime pack file not found."
        val target = File(root, "_import_${System.currentTimeMillis()}")
        if (!target.mkdirs()) return "Unable to create temporary runtime directory."
        var extracted = 0
        var extractedBytes = 0L
        try {
            if (zipFile.length() > MAX_PACK_BYTES) return "Runtime pack rejected: ZIP exceeds 512 MB limit."
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val name = entry!!.name.replace('\\', '/')
                    if (name.startsWith("/") || name.contains("../") || name.contains("..\\")) {
                        return "Rejected unsafe runtime pack path."
                    }
                    val out = File(target, name)
                    val canonicalRoot = target.canonicalPath + File.separator
                    val canonicalOut = out.canonicalPath
                    if (canonicalOut != target.canonicalPath && !canonicalOut.startsWith(canonicalRoot)) {
                        return "Rejected runtime pack path outside sandbox."
                    }
                    if (entry!!.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { fos ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val n = zis.read(buffer)
                                if (n <= 0) break
                                extractedBytes += n
                                if (extractedBytes > MAX_PACK_BYTES) return "Runtime pack rejected: extracted data exceeds 512 MB limit."
                                fos.write(buffer, 0, n)
                            }
                        }
                        extracted++
                        out.setExecutable(true, false)
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            val detected = detectPackProfile(target, registry)
                ?: return "Could not detect a supported runtime id in this pack."
            val profile = detected.first
            val packRoot = detected.second
            val validation = validatePack(packRoot, profile)
            if (validation != null) return validation
            val destination = registry.runtimeDir(profile)
            if (destination.exists()) destination.deleteRecursively()
            destination.mkdirs()
            packRoot.walkTopDown().forEach { file ->
                if (file == packRoot) return@forEach
                val relative = file.relativeTo(packRoot)
                val out = File(destination, relative.path)
                if (file.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    file.copyTo(out, true)
                    out.setExecutable(true, false)
                }
            }
            target.deleteRecursively()
            return "Installed runtime pack: ${profile.displayName} ($extracted files)."
        } catch (e: Exception) {
            target.deleteRecursively()
            return "Runtime pack install failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun detectPackProfile(dir: File, registry: LanguageRuntimeRegistry): Pair<LanguageRuntimeRegistry.Profile, File>? {
        val candidates = ArrayList<File>()
        candidates.add(dir)
        dir.listFiles()?.filter { it.isDirectory }?.forEach { first ->
            candidates.add(first)
            first.listFiles()?.filter { it.isDirectory }?.forEach { second -> candidates.add(second) }
        }

        for (candidate in candidates) {
            val marker = File(candidate, "runtime.id")
            if (marker.isFile) {
                val profile = registry.find(marker.readText().trim())
                if (profile != null) return Pair(profile, candidate)
            }
        }

        for (candidate in candidates) {
            val bin = File(candidate, "bin")
            for (profile in registry.all()) {
                if (profile.id == "java" && File(bin, "javac").isFile && File(bin, "java").isFile) {
                    return Pair(profile, candidate)
                }
                if (profile.id == "python" && File(candidate, "lib/libdevstudio_python_bridge.so").isFile) {
                    return Pair(profile, candidate)
                }
                if (profile.id == "c" && File(bin, "clang").isFile) return Pair(profile, candidate)
                if (profile.id == "cpp" && File(bin, "clang++").isFile) return Pair(profile, candidate)
                if (profile.id == "dart" && File(bin, "dart").isFile) return Pair(profile, candidate)
                if (profile.id == "flutter" && File(bin, "flutter").isFile) return Pair(profile, candidate)
            }
        }
        return null
    }
    private fun validatePack(dir: File, profile: LanguageRuntimeRegistry.Profile): String? {
        if (profile.id == "java") {
            val javac = File(dir, "bin/javac")
            val java = File(dir, "bin/java")
            if (!javac.isFile || !java.isFile) {
                return "Java pack rejected: expected bin/javac and bin/java."
            }
        }
        if (profile.id == "cpp" || profile.id == "c") {
            val compiler = if (profile.id == "cpp") "clang++" else "clang"
            if (!File(dir, "bin/$compiler").isFile) return "${profile.displayName} pack rejected: expected bin/$compiler."
        }
        if (profile.id == "kotlin") {
            if (!File(dir, "bin/kotlinc").isFile) return "Kotlin pack rejected: expected bin/kotlinc."
            // Java may be supplied by the separate Java runtime pack.
        }
        if (profile.id == "dart") {
            if (!File(dir, "bin/dart").isFile) return "Dart pack rejected: expected bin/dart."
        }
        if (profile.id == "flutter") {
            if (!File(dir, "bin/flutter").isFile) return "Flutter pack rejected: expected bin/flutter."
        }
        if (profile.id == "python") {
            val bridge = File(dir, "lib/libdevstudio_python_bridge.so")
            if (!bridge.isFile) return "Python pack rejected: embedded JNI bridge is missing."
        }
        return null
    }

}
