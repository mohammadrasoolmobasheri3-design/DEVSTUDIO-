package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.server.MiniServerEngine
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** DEVSTUDIO v21 — local-only Mini Server console. */
class LocalServerActivity : AppCompatActivity() {
    private lateinit var project: Project
    private lateinit var status: TextView
    private lateinit var log: TextView
    private var server: MiniServerEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_local_server)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, id) ?: run { finish(); return }
        status = findViewById(R.id.serverStatus)
        log = findViewById(R.id.serverLog)
        findViewById<TextView>(R.id.serverBack).setOnClickListener { stopServer(); finish() }
        findViewById<Button>(R.id.serverStart).setOnClickListener { startServer() }
        findViewById<Button>(R.id.serverStop).setOnClickListener { stopServer() }
        findViewById<Button>(R.id.serverPing).setOnClickListener { ping() }
        append("Local-only service. Bound to 127.0.0.1.")
    }

    private fun startServer() {
        stopServer()
        val srv = MiniServerEngine(File(project.folderPath), File(filesDir, "libs"))
        srv.start()
        server = srv
        status.text = "● RUNNING  ${srv.baseUrl()}"
        status.setTextColor(Color.parseColor("#4CD964"))
        append("Started on port ${srv.port}")
        append("GET /api/ping is available")
    }

    private fun stopServer() {
        server?.stop()
        server = null
        status.text = "● STOPPED"
        status.setTextColor(Color.parseColor("#9AA4C0"))
    }

    private fun ping() {
        val srv = server ?: run { append("Ping skipped: server is stopped."); return }
        Thread {
            val result = try {
                val conn = URL(srv.baseUrl() + "api/ping").openConnection() as HttpURLConnection
                conn.connectTimeout = 1500
                conn.readTimeout = 1500
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                "PING OK: $text"
            } catch (e: Exception) { "PING FAILED: ${e.message}" }
            runOnUiThread { append(result) }
        }.start()
    }

    private fun append(text: String) { log.append("$text\n") }

    override fun onDestroy() { stopServer(); super.onDestroy() }

    companion object { const val EXTRA_PROJECT_ID = "extra_local_server_project_id" }
}
