package com.example.ultrapromax.engine.intelligence

import com.example.ultrapromax.engine.language.LanguageRegistry
import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.language.symbol.SymbolIndex
import com.example.ultrapromax.engine.language.symbol.SymbolKind

class CompletionEngine(private val index: SymbolIndex) {
    fun complete(fileName: String, source: String, cursorOffset: Int, limit: Int = 40): List<CompletionItem> {
        if (limit <= 0) return emptyList()
        val language = LanguageRegistry.detectId(fileName)
        val safeOffset = cursorOffset.coerceIn(0, source.length)
        val prefix = currentPrefix(source, safeOffset)
        val local = LanguageRegistry.detect(fileName)?.parse(source)?.symbols ?: emptyList()
        val candidates = ArrayList<Symbol>()
        candidates.addAll(local)
        candidates.addAll(index.allSymbols())

        val unique = LinkedHashMap<String, CompletionItem>()
        for (symbol in candidates) {
            if (symbol.language != language && language != "text") continue
            val score = score(symbol.name, prefix)
            if (score < 0) continue
            val key = symbol.name + "|" + symbol.kind.name
            val item = CompletionItem(symbol.name, symbol.kind, symbol.signature, score, if (symbol.filePath == null) "buffer" else "project")
            val old = unique[key]
            if (old == null || item.score < old.score) unique[key] = item
        }

        return unique.values.sortedWith(compareBy<CompletionItem> { it.score }.thenBy { it.label.toLowerCase() }).take(limit)
    }

    private fun currentPrefix(source: String, offset: Int): String {
        var i = offset - 1
        while (i >= 0) {
            val c = source[i]
            if (!(c.isLetterOrDigit() || c == '_' || c == '$')) break
            i--
        }
        return source.substring(i + 1, offset)
    }

    private fun score(name: String, prefix: String): Int {
        if (prefix.isEmpty()) return 5
        val n = name.toLowerCase()
        val p = prefix.toLowerCase()
        return when {
            n == p -> 0
            n.startsWith(p) -> 1
            n.contains(p) -> 3
            else -> -1
        }
    }
}
