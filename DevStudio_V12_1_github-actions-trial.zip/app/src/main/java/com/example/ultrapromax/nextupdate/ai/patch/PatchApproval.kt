package com.example.ultrapromax.nextupdate.ai.patch

enum class ApprovalState { PENDING, APPROVED, REJECTED }

data class PatchApproval(
    val patchSetId: String,
    var state: ApprovalState = ApprovalState.PENDING
)
