package com.example.ultrapromax.engine.buildrun

import com.example.ultrapromax.engine.builder.BuildEngine
import java.io.File

/** V26.7 build pipeline facade. Keeps real Gradle execution behind one stable API. */
class BuildPipelineEngine(context: android.content.Context? = null, private val buildEngine: BuildEngine = BuildEngine(context)) {
    data class Request(val projectDir: File, val variant: Variant = Variant.DEBUG)
    enum class Variant { DEBUG, RELEASE }
    data class Result(
        val success: Boolean,
        val variant: Variant,
        val apkFile: File?,
        val output: String,
        val startedAt: Long,
        val finishedAt: Long
    )

    fun build(request: Request): Result {
        val started = System.currentTimeMillis()
        val result = when (request.variant) {
            Variant.DEBUG -> buildEngine.buildDebug(request.projectDir)
            Variant.RELEASE -> buildEngine.buildRelease(request.projectDir)
        }
        return Result(result.success, request.variant, result.apkFile, result.output, started, System.currentTimeMillis())
    }
}
