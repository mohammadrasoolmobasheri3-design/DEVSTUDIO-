package com.example.ultrapromax.engine.language.symbol

enum class SymbolKind {
    CLASS, INTERFACE, OBJECT, ENUM, STRUCT, MIXIN, FUNCTION, METHOD,
    PROPERTY, FIELD, VARIABLE, CONSTANT, PARAMETER, CONSTRUCTOR,
    IMPORT, PACKAGE, MODULE, TYPE
}
