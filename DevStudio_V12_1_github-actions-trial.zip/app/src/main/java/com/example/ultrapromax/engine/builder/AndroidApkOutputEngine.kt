package com.example.ultrapromax.engine.builder

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Final APK output stage modelled on a standard AIDE/Android toolchain:
 * Gradle produces the real APK; SDK zipalign and apksigner certify the artifact.
 * No APK is synthesized and no signing result is assumed.
 */
class AndroidApkOutputEngine(private val context: Context?) {
    data class Result(val success: Boolean, val apk: File?, val output: String)

    fun finish(apk: File): Result {
        if (!apk.isFile || apk.length() <= 0L)
            return Result(false, null, "APK OUTPUT: MISSING or empty APK")

        val tc = LocalToolchainResolver(context).resolve()
        if (!tc.ready) return Result(false, apk, "APK OUTPUT: LOCAL TOOLCHAIN INCOMPLETE\n${tc.details}")

        val sdk = tc.sdk ?: return Result(false, apk, "APK OUTPUT: Android SDK Platform 29 MISSING")
        val bt = File(sdk, "build-tools/34.0.4")
        val tools = if (bt.isDirectory) bt else File(sdk, "build-tools").listFiles()
            ?.filter { it.isDirectory && File(it, "zipalign").isFile && File(it, "apksigner").isFile }
            ?.maxBy { it.name }
        if (tools == null) return Result(false, apk, "APK OUTPUT: zipalign/apksigner tools MISSING")

        val align = run(File(tools, "zipalign"), listOf("-c", "4", apk.absolutePath))
        if (align.code != 0) return Result(false, apk, "APK OUTPUT: zipalign verification failed\n${tail(align.output)}")

        val verify = run(File(tools, "apksigner"), listOf("verify", "--verbose", apk.absolutePath))
        if (verify.code != 0) return Result(false, apk, "APK OUTPUT: apksigner verification failed\n${tail(verify.output)}")

        return Result(true, apk, "APK OUTPUT: REAL\nzipalign=verified\napksigner=verified\nsize=${apk.length()} bytes\npath=${apk.absolutePath}")
    }

    private data class Cmd(val code: Int, val output: String)
    private fun run(file: File, args: List<String>): Cmd = try {
        val p = ProcessBuilder(listOf(file.absolutePath) + args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        if (!p.waitFor(30, TimeUnit.SECONDS)) { p.destroy(); Cmd(-2, "$out\nTIMEOUT") }
        else Cmd(p.exitValue(), out)
    } catch (t: Throwable) { Cmd(-1, t.message ?: t.javaClass.simpleName) }

    private fun tail(s: String): String = s.trim().takeLast(1200)
}
