package com.example.ultrapromax.ui

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout

/**
 * Positions the eight invisible touch targets using the same normalized
 * coordinates as the supplied 1536x1024 final dashboard artwork.
 * This keeps the artwork unchanged while making it responsive to any phone size.
 */
class DashboardOverlayLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private data class Zone(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float
    )

    private val zones = arrayOf(
        Zone(0.116f, 0.367f, 0.279f, 0.592f), // New Project
        Zone(0.289f, 0.367f, 0.437f, 0.592f), // Open Project
        Zone(0.449f, 0.367f, 0.601f, 0.592f), // Templates
        Zone(0.612f, 0.367f, 0.769f, 0.592f), // AI Assistant
        Zone(0.116f, 0.604f, 0.279f, 0.849f), // Plugin OS
        Zone(0.289f, 0.604f, 0.437f, 0.849f), // UI Builder
        Zone(0.449f, 0.604f, 0.601f, 0.849f), // File Explorer
        Zone(0.612f, 0.604f, 0.769f, 0.849f)  // Project Studio
    )

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(width, height)
        for (i in 0 until childCount) {
            val zone = zones.getOrNull(i) ?: zones.last()
            val childWidth = ((zone.right - zone.left) * width).toInt().coerceAtLeast(1)
            val childHeight = ((zone.bottom - zone.top) * height).toInt().coerceAtLeast(1)
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val width = r - l
        val height = b - t
        for (i in 0 until childCount) {
            val child: View = getChildAt(i)
            val zone = zones.getOrNull(i) ?: zones.last()
            val left = (zone.left * width).toInt()
            val top = (zone.top * height).toInt()
            val right = (zone.right * width).toInt()
            val bottom = (zone.bottom * height).toInt()
            child.layout(left, top, right, bottom)
        }
    }
}
