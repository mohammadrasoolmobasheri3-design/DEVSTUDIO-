package com.example.ultrapromax.engine.language.parser

interface ParserProvider {
    fun parse(source: String): ParseResult
}
