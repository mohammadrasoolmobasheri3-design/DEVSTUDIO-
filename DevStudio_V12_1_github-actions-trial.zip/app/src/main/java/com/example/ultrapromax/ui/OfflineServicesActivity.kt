package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.engine.offline.OfflineModeEngine
import com.example.ultrapromax.engine.offline.OfflineNetworkPolicy

/** DEVSTUDIO V30.1.0 Stage 23 — Offline / Local Services Center. */
class OfflineServicesActivity : AppCompatActivity() {
    private lateinit var mode: OfflineModeEngine
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = OfflineModeEngine(this)
        setContentView(buildUi())
        render()
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(5, 7, 14))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "OFFLINE / LOCAL SERVICES"
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, 1)
        }
        root.addView(title, lp(-1, -2, 0, 0, 0, 8))

        val sub = TextView(this).apply {
            text = "Local-first service control • no external network required"
            textSize = 11f
            setTextColor(Color.rgb(150, 160, 185))
        }
        root.addView(sub, lp(-1, -2, 0, 0, 0, 14))

        toggle = Switch(this).apply {
            text = "STRICT OFFLINE MODE"
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = mode.isOffline()
            setOnCheckedChangeListener { _, checked ->
                mode.setOffline(checked)
                render()
            }
        }
        root.addView(toggle, lp(-1, -2, 0, 0, 0, 8))

        status = TextView(this).apply { textSize = 14f; setTypeface(null, 1) }
        root.addView(status, lp(-1, -2, 0, 0, 0, 16))

        val testTitle = TextView(this).apply {
            text = "LOCAL NETWORK GATE"
            textSize = 12f
            setTextColor(Color.rgb(100, 210, 255))
            setTypeface(null, 1)
        }
        root.addView(testTitle, lp(-1, -2, 0, 0, 0, 6))

        val tests = arrayOf(
            "http://127.0.0.1:8080/api/ping",
            "http://localhost:8080/api/ping",
            "http://8.8.8.8/",
            "https://example.com/",
            "file:///devstudio/local/index.html"
        )
        for (url in tests) {
            val b = Button(this).apply {
                text = "TEST  $url"
                setTextColor(Color.WHITE)
                setOnClickListener { testUrl(url) }
            }
            root.addView(b, lp(-1, dp(46), 0, 0, 0, 5))
        }

        val actions = TextView(this).apply {
            text = "LOCAL SERVICES"
            textSize = 12f
            setTextColor(Color.rgb(190, 140, 255))
            setTypeface(null, 1)
        }
        root.addView(actions, lp(-1, -2, 0, 0, 0, 6))

        addAction(root, "LOCAL SERVER", "Start/inspect 127.0.0.1 service") {
            startActivity(android.content.Intent(this, LocalServerActivity::class.java)
                .putExtra(LocalServerActivity.EXTRA_PROJECT_ID, intent.getLongExtra("extra_local_server_project_id", -1L)))
        }
        addAction(root, "RUNTIME MANAGER", "Inspect local runtime packs") {
            startActivity(android.content.Intent(this, RuntimeManagerActivity::class.java))
        }
        addAction(root, "REFRESH STATUS", "Re-read offline policy and service state") { render() }

        log = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.rgb(190, 200, 220))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.rgb(13, 17, 29))
            gravity = Gravity.TOP
        }
        root.addView(log, lp(-1, dp(210), 0, 12, 0, 0))

        val back = Button(this).apply {
            text = "BACK TO STUDIO"
            setOnClickListener { finish() }
        }
        root.addView(back, lp(-1, dp(48), 0, 10, 0, 0))
        return scroll
    }

    private fun addAction(root: LinearLayout, title: String, description: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$title\n$description"
            setTextColor(Color.WHITE)
            setOnClickListener { action() }
        }
        root.addView(b, lp(-1, dp(58), 0, 0, 0, 6))
    }

    private fun testUrl(url: String) {
        val allowed = OfflineNetworkPolicy(this).allow(url)
        append("${if (allowed) "ALLOW" else "BLOCK"}  $url")
    }

    private fun render() {
        if (!::status.isInitialized) return
        val offline = mode.isOffline()
        toggle.isChecked = offline
        status.text = if (offline) "● STRICT OFFLINE — external network blocked" else "● NETWORK OPTIONAL — external network allowed by policy"
        status.setTextColor(if (offline) Color.rgb(70, 220, 150) else Color.rgb(255, 190, 70))
        append("Mode: ${mode.modeLabel()}")
        append("Loopback: 127.0.0.1 / localhost / ::1")
        append("File URLs: local resources allowed")
    }

    private fun append(text: String) {
        if (::log.isInitialized) log.append(text + "\n")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(if (w < 0) w else dp(w), if (h < 0) h else dp(h))
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }
}
