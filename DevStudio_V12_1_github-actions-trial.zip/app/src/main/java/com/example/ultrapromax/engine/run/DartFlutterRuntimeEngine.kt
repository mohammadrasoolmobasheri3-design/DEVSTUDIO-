package com.example.ultrapromax.engine.run

import java.io.File
import java.util.concurrent.TimeUnit

/** Offline Dart/Flutter runner. Flutter projects are routed to the Flutter SDK toolchain. */
class DartFlutterRuntimeEngine(private val runtimeDir: File) {
    data class Result(val success: Boolean, val mode: String, val output: String)

    fun runDart(source: String, fileName: String, workDir: File): Result {
        val dart = File(runtimeDir, "bin/dart")
        if (!dart.isFile || !dart.canExecute()) return Result(false, "DART", "Dart runtime pack is not installed: expected bin/dart")
        workDir.mkdirs()
        val file = File(workDir, if (fileName.endsWith(".dart")) fileName else "main.dart")
        file.writeText(source)
        val r = exec(listOf(dart.absolutePath, "run", file.absolutePath), workDir)
        return Result(r.exit == 0, "DART", r.output)
    }

    fun buildFlutter(projectDir: File, target: String): Result {
        val flutter = File(runtimeDir, "bin/flutter")
        if (!flutter.isFile || !flutter.canExecute()) return Result(false, "FLUTTER", "Flutter runtime pack is not installed: expected bin/flutter")
        val pubspec = File(projectDir, "pubspec.yaml")
        if (!pubspec.isFile) return Result(false, "FLUTTER", "Flutter project not found: pubspec.yaml is missing.")
        val args = if (target == "apk") listOf(flutter.absolutePath, "build", "apk", "--offline") else listOf(flutter.absolutePath, "run", "--offline")
        val r = exec(args, projectDir)
        return Result(r.exit == 0, "FLUTTER", r.output)
    }

    private data class Exec(val exit: Int, val output: String)
    private fun exec(command: List<String>, dir: File): Exec = try {
        val p = ProcessBuilder(command).directory(dir).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().use { it.readText() }
        if (!p.waitFor(120, TimeUnit.SECONDS)) { p.destroy(); Exec(124, text + "\nProcess timed out after 120 seconds.") }
        else Exec(p.exitValue(), text)
    } catch (e: Exception) { Exec(127, "Unable to start Dart/Flutter: ${e.message ?: e.javaClass.simpleName}") }
}
