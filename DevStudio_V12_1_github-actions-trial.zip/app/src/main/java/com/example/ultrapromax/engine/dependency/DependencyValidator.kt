package com.example.ultrapromax.engine.dependency

object DependencyValidator {
    fun validate(records: List<DependencyRecord>): DependencyReport {
        val byKey = LinkedHashMap<String, MutableList<DependencyRecord>>()
        val output = ArrayList<DependencyRecord>()
        val invalid = ArrayList<String>()
        val conflicts = ArrayList<String>()
        for (record in records) {
            val c = record.coordinate
            if (c.group.isBlank() || c.artifact.isBlank()) {
                output.add(record.copy(status = DependencyStatus.INVALID, detail = "Group and artifact are required"))
                invalid.add(record.rawNotation)
            } else if (c.version.isBlank()) {
                output.add(record.copy(status = DependencyStatus.MISSING_VERSION, detail = "Version is required for offline validation"))
                invalid.add(record.rawNotation)
            } else {
                byKey.getOrPut(c.key()) { ArrayList() }.add(record)
            }
        }
        for ((key, items) in byKey) {
            val versions = LinkedHashSet<String>()
            for (item in items) versions.add(item.coordinate.version)
            if (versions.size > 1) {
                val message = "$key has conflicting versions: ${versions.joinToString(", ")}" 
                conflicts.add(message)
                for (item in items) output.add(item.copy(status = DependencyStatus.CONFLICT, detail = message))
            } else if (items.size > 1) {
                for (item in items) output.add(item.copy(status = DependencyStatus.DUPLICATE, detail = "Duplicate declaration"))
            } else output.add(items[0].copy(status = DependencyStatus.VALID, detail = "Declaration is structurally valid"))
        }
        return DependencyReport(output, conflicts, invalid)
    }
}
