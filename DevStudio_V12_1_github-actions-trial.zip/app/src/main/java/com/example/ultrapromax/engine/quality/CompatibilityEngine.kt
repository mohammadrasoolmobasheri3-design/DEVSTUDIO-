package com.example.ultrapromax.engine.quality

/** V30.1.0 project/toolchain compatibility contract. It reports facts and never upgrades anything. */
class CompatibilityEngine {
    data class Contract(
        val gradle: String,
        val androidGradlePlugin: String,
        val kotlin: String,
        val compileSdk: Int,
        val minSdk: Int
    )

    data class Check(val name: String, val valid: Boolean, val detail: String)

    fun expected(): Contract = Contract("6.1.1", "3.5.3", "1.3.72", 29, 23)

    fun validate(actual: Contract): List<Check> {
        val target = expected()
        return listOf(
            check("Gradle", target.gradle == actual.gradle, target.gradle, actual.gradle),
            check("Android Gradle Plugin", target.androidGradlePlugin == actual.androidGradlePlugin, target.androidGradlePlugin, actual.androidGradlePlugin),
            check("Kotlin", target.kotlin == actual.kotlin, target.kotlin, actual.kotlin),
            check("compileSdk", target.compileSdk == actual.compileSdk, target.compileSdk.toString(), actual.compileSdk.toString()),
            check("minSdk", target.minSdk == actual.minSdk, target.minSdk.toString(), actual.minSdk.toString())
        )
    }

    private fun check(name: String, valid: Boolean, expected: String, actual: String): Check {
        return Check(name, valid, if (valid) "${actual} OK" else "Expected $expected, found $actual")
    }
}
