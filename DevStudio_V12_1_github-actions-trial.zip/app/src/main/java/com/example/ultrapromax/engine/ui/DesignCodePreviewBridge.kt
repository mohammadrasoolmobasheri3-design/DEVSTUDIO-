package com.example.ultrapromax.engine.ui

import java.io.File

/** Shared file bridge for Design, generated Code and offline Preview. */
object DesignCodePreviewBridge {
    fun generatedHtmlFile(projectDir: File): File = File(projectDir, "devstudio/generated/index.html")

    fun writeGeneratedHtml(projectDir: File, html: String): File {
        val file = generatedHtmlFile(projectDir)
        file.parentFile?.mkdirs()
        file.writeText(html)
        return file
    }

    fun readGeneratedHtml(projectDir: File): String {
        val file = generatedHtmlFile(projectDir)
        return if (file.exists()) file.readText() else ""
    }
}
