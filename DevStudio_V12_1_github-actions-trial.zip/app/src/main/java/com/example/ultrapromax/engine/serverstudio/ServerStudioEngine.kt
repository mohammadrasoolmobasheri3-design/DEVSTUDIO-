package com.example.ultrapromax.engine.serverstudio

import com.example.ultrapromax.engine.run.LanguageRuntimeRegistry
import com.example.ultrapromax.engine.server.MiniServerEngine
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

/** ENDGAME Stage 6: offline Server Studio control plane. */
class ServerStudioEngine(private val projectDir: File, private val runtimeRoot: File) {
    data class ServerProfile(val id: String, val name: String, val language: String, val runtimeId: String, val notes: String)
    data class Route(val method: String, val path: String, val responseBody: String, val contentType: String = "application/json; charset=utf-8")
    data class RequestResult(val code: Int, val body: String, val durationMs: Long, val error: String? = null)

    private val logs = CopyOnWriteArrayList<String>()
    private val routes = CopyOnWriteArrayList<Route>()
    private val env = LinkedHashMap<String, String>()
    private var server: MiniServerEngine? = null
    var selectedProfileId: String = "javascript"
    var configuredPort: Int = 0
    private var root: File = projectDir

    init { routes.add(Route("GET", "/api/health", "{\"status\":\"ok\",\"offline\":true}")) }

    fun profiles(): List<ServerProfile> = listOf(
        ServerProfile("javascript", "Node.js / JavaScript", "JavaScript", "javascript", "Requires a real local Node runtime pack."),
        ServerProfile("typescript", "TypeScript", "TypeScript", "typescript", "Requires a real local TS runtime/toolchain."),
        ServerProfile("python", "Python", "Python 3", "python", "Requires the real embedded Python runtime contract."),
        ServerProfile("java", "Java", "Java", "java", "Requires a real local JDK pack."),
        ServerProfile("kotlin", "Kotlin", "Kotlin", "kotlin", "Requires a real Kotlin/JVM toolchain."),
        ServerProfile("csharp", "C# / .NET", "C#", "csharp", "Requires a real local .NET/Mono toolchain."),
        ServerProfile("go", "Go", "Go", "go", "Requires a real local Go toolchain."),
        ServerProfile("rust", "Rust", "Rust", "rust", "Requires a real local Rust toolchain."),
        ServerProfile("php", "PHP", "PHP", "php", "Requires a real local PHP runtime."),
        ServerProfile("ruby", "Ruby", "Ruby", "ruby", "Requires a real local Ruby runtime."),
        ServerProfile("shell", "Shell", "Shell", "shell", "Requires a real local shell runtime.")
    )

    fun readiness(): String {
        val registry = LanguageRuntimeRegistry(runtimeRoot)
        val p = profiles().firstOrNull { it.id == selectedProfileId } ?: profiles()[0]
        val profile = registry.find(p.runtimeId) ?: return "[MISSING] ${p.name}: runtime profile not registered"
        val r = registry.readiness(profile)
        return if (r.ready) "[READY] ${p.name}" else "[MISSING] ${p.name}: ${r.missing.joinToString(", ")}" 
    }

    fun configure(projectRoot: File, port: Int) {
        root = projectRoot
        configuredPort = port.coerceIn(1024, 65535)
        logs.add("Configured ${selectedProfileId} on 127.0.0.1:$configuredPort")
    }

    fun setEnv(key: String, value: String) { if (key.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) env[key] = value }
    fun environment(): Map<String, String> = LinkedHashMap(env)

    fun addRoute(method: String, path: String, body: String, contentType: String = "application/json; charset=utf-8") {
        val normalized = if (path.startsWith("/")) path else "/$path"
        routes.removeAll { it.method == method.toUpperCase() && it.path == normalized }
        routes.add(Route(method.toUpperCase(), normalized, body, contentType))
        logs.add("Route ${method.toUpperCase()} $normalized registered")
    }

    fun routeSnapshot(): List<Route> = routes.toList()

    fun start(): Boolean {
        stop()
        val srv = MiniServerEngine(root, File(root, "libs").takeIf { it.isDirectory() })
        routes.forEach { route ->
            if (route.method == "GET") srv.addApiRoute(route.path) { route.responseBody }
        }
        val p = runCatching { if (configuredPort > 0) srv.startOnPort(configuredPort) else srv.start() }.getOrElse {
            logs.add("START FAILED: ${it.message}"); return false
        }
        configuredPort = p
        server = srv
        logs.add("SERVER STARTED 127.0.0.1:$p")
        return true
    }

    fun stop() { server?.stop(); if (server != null) logs.add("SERVER STOPPED"); server = null }
    fun restart(): Boolean { stop(); return start() }
    fun isRunning(): Boolean = server?.isRunning() == true
    fun baseUrl(): String = server?.baseUrl() ?: "http://127.0.0.1:$configuredPort/"

    fun test(method: String, path: String): RequestResult {
        if (!isRunning()) return RequestResult(-1, "", 0, "Server is stopped")
        val started = System.currentTimeMillis()
        return try {
            val conn = URL(baseUrl().trimEnd('/') + "/" + path.trimStart('/')).openConnection() as HttpURLConnection
            conn.requestMethod = method.toUpperCase()
            conn.connectTimeout = 2000; conn.readTimeout = 2000
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val result = RequestResult(code, body, System.currentTimeMillis() - started)
            logs.add("TEST ${method.toUpperCase()} $path -> $code (${result.durationMs}ms)")
            conn.disconnect(); result
        } catch (e: Exception) {
            val result = RequestResult(-1, "", System.currentTimeMillis() - started, e.message)
            logs.add("TEST FAILED ${method.toUpperCase()} $path: ${e.message}"); result
        }
    }

    fun logs(): List<String> = logs.toList()
    fun clearLogs() = logs.clear()
}
