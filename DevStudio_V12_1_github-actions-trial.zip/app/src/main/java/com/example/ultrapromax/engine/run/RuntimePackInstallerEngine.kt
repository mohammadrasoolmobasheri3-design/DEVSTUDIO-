package com.example.ultrapromax.engine.run

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream
import java.security.MessageDigest

/** Secure offline runtime-pack installer. Accepts only declared Android/ARM packs. */
class RuntimePackInstallerEngine(private val context: Context) {
    data class Result(val success: Boolean, val id: String, val message: String)
    private val root = File(context.filesDir, "runtimes")

    fun install(zip: File, expectedId: String): Result {
        if (!zip.isFile) return Result(false, expectedId, "PACK_NOT_FOUND")
        if (zip.length() > 1024L * 1024L * 1024L) return Result(false, expectedId, "PACK_TOO_LARGE")
        val staging = File(context.cacheDir, "runtime-install-${System.currentTimeMillis()}")
        if (!staging.mkdirs()) return Result(false, expectedId, "STAGING_FAILED")
        try {
            ZipInputStream(FileInputStream(zip)).use { input ->
                while (true) {
                    val e = input.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    if (name.startsWith("/") || name.contains("../") || name.contains("..\\") || name.contains(":") || name.startsWith("/")) {
                        return Result(false, expectedId, "PATH_TRAVERSAL_REJECTED")
                    }
                    val out = File(staging, name)
                    val canonicalRoot = staging.canonicalPath + File.separator
                    if (!out.canonicalPath.startsWith(canonicalRoot)) return Result(false, expectedId, "PATH_ESCAPE_REJECTED")
                    if (e.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
            val meta = File(staging, "runtime-pack.properties")
            if (!meta.isFile) return Result(false, expectedId, "PACK_METADATA_MISSING")
            val props = java.util.Properties().apply { meta.inputStream().use { load(it) } }
            if (props.getProperty("id") != expectedId) return Result(false, expectedId, "PACK_ID_MISMATCH")
            if (props.getProperty("platform") != "android") return Result(false, expectedId, "ANDROID_PACK_REQUIRED")
            if (props.getProperty("abi") !in setOf("arm64-v8a", "armeabi-v7a")) return Result(false, expectedId, "UNSUPPORTED_ABI")
            if (props.getProperty("offline") != "true") return Result(false, expectedId, "OFFLINE_ONLY_REQUIRED")
            val required = props.getProperty("required.files", "").split(',').map { it.trim() }.filter { it.isNotEmpty() }
            val missing = required.filter { !File(staging, it).isFile }
            if (missing.isNotEmpty()) return Result(false, expectedId, "MISSING:" + missing.joinToString(","))
            val target = File(root, expectedId)
            target.parentFile?.mkdirs()
            if (target.exists()) target.deleteRecursively()
            if (!staging.renameTo(target)) return Result(false, expectedId, "INSTALL_MOVE_FAILED")
            return Result(true, expectedId, "INSTALLED")
        } finally {
            if (staging.exists()) staging.deleteRecursively()
        }
    }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(8192)
            while (true) { val n = input.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
