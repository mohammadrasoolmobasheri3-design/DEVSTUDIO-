package com.example.ultrapromax.engine.preview

import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import java.io.File

/**
 * PREVIEW ENGINE
 *
 * Offline WebView preview with automatic reload.
 *
 * Compatible with Kotlin 1.3.72.
 */
object PreviewEngine {

    fun configure(webView: WebView) {

        webView.settings.apply {

            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true

            cacheMode = WebSettings.LOAD_NO_CACHE

            mixedContentMode =
                WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
    }

    fun loadUrl(
        webView: WebView,
        url: String
    ) {
        webView.loadUrl(url)
    }

    fun reload(webView: WebView) {
        webView.reload()
    }

    private val handler =
        Handler(Looper.getMainLooper())

    private var watcherRunnable: Runnable? = null

    fun startAutoReload(
        webView: WebView,
        projectDir: File,
        intervalMs: Long = 1000
    ) {

        stopAutoReload()

        var lastKnown =
            newestModifiedTime(projectDir)

        val runnable = object : Runnable {

            override fun run() {

                val current =
                    newestModifiedTime(projectDir)

                if (current != lastKnown) {

                    lastKnown = current

                    reload(webView)
                }

                handler.postDelayed(
                    this,
                    intervalMs
                )
            }
        }

        watcherRunnable = runnable

        handler.postDelayed(
            runnable,
            intervalMs
        )
    }

    fun stopAutoReload() {

        watcherRunnable?.let {
            handler.removeCallbacks(it)
        }

        watcherRunnable = null
    }

    /**
     * Kotlin 1.3-compatible replacement for maxOfOrNull.
     */
    private fun newestModifiedTime(
        dir: File
    ): Long {

        var newest = 0L

        dir.walkTopDown()
            .filter { it.isFile }
            .forEach {

                val modified =
                    it.lastModified()

                if (modified > newest) {
                    newest = modified
                }
            }

        return newest
    }
}