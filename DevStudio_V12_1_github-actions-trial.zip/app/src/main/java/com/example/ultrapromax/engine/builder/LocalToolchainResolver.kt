package com.example.ultrapromax.engine.builder

import android.content.Context
import android.os.Environment
import java.io.File

/**
 * Resolves one fixed, local DevStudio toolchain.
 *
 * Priority:
 *  1) filesDir/internal-toolchain
 *  2) DEVSTUDIO_TOOLCHAIN_ROOT
 *  3) Android SDK/JDK already exposed to the process
 *  4) public Downloads/DevStudioToolchain (only if the user placed it there)
 *
 * Network downloads are performed by Gradle only when the build is started online.
 */
class LocalToolchainResolver(private val context: Context?) {

    data class Result(
        val root: File?,
        val sdk: File?,
        val javaHome: File?,
        val gradleExecutable: File?,
        val mavenRepo: File?,
        val buildTools: File?,
        val ready: Boolean,
        val details: String
    )

    fun resolve(): Result {
        val roots = linkedSetOf<File>()
        context?.let {
            roots += File(it.filesDir, "internal-toolchain")
            roots += File(it.filesDir, "toolchain")
        }
        System.getenv("DEVSTUDIO_TOOLCHAIN_ROOT")?.takeIf { it.isNotBlank() }?.let { roots += File(it) }

        try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            roots += File(downloads, "DevStudioToolchain")
            roots += File(downloads, "DevStudioToolchain/android-sdk")
        } catch (_: Throwable) {}

        // Do not stop at the first existing root. An empty internal-toolchain directory
        // must not hide a valid user-supplied Downloads/DevStudioToolchain directory.
        val existingRoots = roots.filter { it.isDirectory }.toList()

        val sdkCandidates = linkedSetOf<File>().apply {
            existingRoots.forEach {
                add(File(it, "android-sdk"))
                add(File(it, "sdk"))
                add(it)
            }
            System.getenv("ANDROID_HOME")?.takeIf { it.isNotBlank() }?.let { add(File(it)) }
            System.getenv("ANDROID_SDK_ROOT")?.takeIf { it.isNotBlank() }?.let { add(File(it)) }
            // Common Linux/proot package-manager install locations — this device's
            // AndroidIDE environment already exposes /usr/bin/gradle (checked below),
            // so a system-wide SDK package under one of these is plausible too.
            add(File("/usr/lib/android-sdk"))
            add(File("/usr/share/android-sdk"))
            add(File("/opt/android-sdk"))
            add(File("/opt/android_sdk"))
            add(File("/usr/local/android-sdk"))
            add(File("/opt/android_sdk/android-sdk"))
        }
        val sdk = sdkCandidates.firstOrNull { File(it, "platforms/android-29/android.jar").isFile }

        val javaHomeCandidates = linkedSetOf<File>().apply {
            existingRoots.forEach { add(File(it, "jdk")) }
            System.getenv("JAVA_HOME")?.takeIf { it.isNotBlank() }?.let { add(File(it)) }
            add(File("/opt/java/jdk1.8.0_212"))
            add(File("/opt/java/openjdk"))
        }
        // Android/Termux installations may expose java through PATH without JAVA_HOME.
        val pathJava = (System.getenv("PATH") ?: "").split(File.pathSeparator)
            .asSequence()
            .map { File(it, "java") }
            .firstOrNull { it.isFile }
        pathJava?.parentFile?.parentFile?.let { javaHomeCandidates.add(it) }
        val javaHome = javaHomeCandidates.firstOrNull { File(it, "bin/java").isFile }

        val gradleCandidates = linkedSetOf<File>().apply {
            existingRoots.forEach {
                add(File(it, "gradle/bin/gradle"))
                add(File(it, "gradle/gradle-6.1.1/bin/gradle"))
            }
            add(File("/usr/bin/gradle"))
            add(File("/opt/gradle/gradle-6.1.1/bin/gradle"))
        }
        val gradle = gradleCandidates.firstOrNull { it.isFile }

        val mavenCandidates = linkedSetOf<File>().apply {
            existingRoots.forEach {
                add(File(it, "m2"))
                add(File(it, "maven"))
                add(File(it, ".aide/maven"))
            }
            System.getenv("DEVSTUDIO_MAVEN_REPO")?.takeIf { it.isNotBlank() }?.let { add(File(it)) }
            add(File(System.getProperty("user.home") ?: ".", ".m2/repository"))
            add(File("/opt/maven-repo"))
            add(File("/opt/android_sdk/extras/m2repository"))
        }
        val mavenRepo = mavenCandidates.firstOrNull { it.isDirectory }

        val buildToolsCandidates = linkedSetOf<File>()
        sdk?.let { sdkRoot ->
            val dir = File(sdkRoot, "build-tools")
            dir.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }?.forEach { buildToolsCandidates.add(it) }
        }
        existingRoots.forEach { root ->
            File(root, "android-sdk/build-tools").listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }?.forEach { buildToolsCandidates.add(it) }
            File(root, "sdk/build-tools").listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }?.forEach { buildToolsCandidates.add(it) }
            File(root, "build-tools").listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }?.forEach { buildToolsCandidates.add(it) }
        }
        // aapt2 is confirmed to live directly at /usr/bin/aapt2 in this AndroidIDE
        // environment (seen in its own Gradle logs), so treat /usr/bin itself as a
        // candidate "build-tools directory" too.
        buildToolsCandidates.add(File("/usr/bin"))
        val buildTools = buildToolsCandidates.firstOrNull { bt ->
            File(bt, "aapt2").isFile && File(bt, "d8").isFile &&
            File(bt, "zipalign").isFile && File(bt, "apksigner").isFile
        }

        val selectedBuildTools = buildTools

        val missing = mutableListOf<String>()
        if (sdk == null) missing += "Android SDK Platform 29"
        if (buildTools == null) missing += "Android Build Tools (aapt2, d8, zipalign, apksigner)"
        if (javaHome == null) missing += "JDK (java)"
        // Maven cache is optional for online builds; Gradle can populate its user cache.

        val ready = sdk != null && buildTools != null && javaHome != null
        val details = if (ready) {
            "LOCAL TOOLCHAIN FOUND: SDK=${sdk?.absolutePath ?: "missing"}; BuildTools=${buildTools?.name ?: "missing"}; JDK=${javaHome?.absolutePath ?: "missing"}; Gradle=${gradle?.absolutePath ?: "use project wrapper if available"}; MavenCache=${mavenRepo?.absolutePath ?: "will download online"}"
        } else {
            "MISSING: ${missing.joinToString(", ")}. Put the real toolchain under ${File(context?.filesDir ?: File("."), "internal-toolchain").absolutePath}. Gradle dependency downloads are enabled when network is available."
        }
        val resolvedRoot = existingRoots.firstOrNull { candidate ->
            (sdk != null && (sdk == candidate || sdk.absolutePath.startsWith(candidate.absolutePath + File.separator))) ||
            (javaHome != null && (javaHome == candidate || javaHome.absolutePath.startsWith(candidate.absolutePath + File.separator))) ||
            (gradle != null && (gradle == candidate || gradle.absolutePath.startsWith(candidate.absolutePath + File.separator)))
        } ?: existingRoots.firstOrNull()

        return Result(resolvedRoot, sdk, javaHome, gradle, mavenRepo, selectedBuildTools, ready, details)
    }
}
