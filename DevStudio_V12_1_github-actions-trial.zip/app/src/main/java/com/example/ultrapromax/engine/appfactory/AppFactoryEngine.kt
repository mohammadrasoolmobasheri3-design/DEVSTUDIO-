package com.example.ultrapromax.engine.appfactory

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import java.io.File

/** Central application factory: selects a project family and reports only real local readiness. */
class AppFactoryEngine(private val context: Context) {
    enum class Kind { ANDROID, FLUTTER, WEB, NATIVE, CLI, SERVER }
    data class Profile(val kind: Kind, val title: String, val description: String, val required: List<String>)
    data class Readiness(val ready: Boolean, val details: String)

    fun profiles(): List<Profile> = listOf(
        Profile(Kind.ANDROID, "Android App", "Native Android project with real Gradle/APK pipeline.", listOf("Android SDK", "Build Tools")),
        Profile(Kind.FLUTTER, "Flutter App", "Flutter application with the real local Flutter toolchain.", listOf("Flutter SDK", "Dart")),
        Profile(Kind.WEB, "Web App", "HTML/CSS/JS/TS application with local preview and packaging path.", listOf("Web assets")),
        Profile(Kind.NATIVE, "Native App", "C/C++/Rust native project using an installed local toolchain.", listOf("Native compiler")),
        Profile(Kind.CLI, "CLI App", "Console application driven by a local language runtime/toolchain.", listOf("Language runtime")),
        Profile(Kind.SERVER, "Server App", "Local backend/API service with database-ready project structure.", listOf("Server runtime"))
    )

    fun readiness(kind: Kind): Readiness = when (kind) {
        Kind.ANDROID -> {
            val r = AndroidToolchainDiscoveryEngine(context).discover()
            Readiness(r.ready, r.details)
        }
        Kind.WEB -> Readiness(true, "Local Web project generation and preview are available.")
        Kind.FLUTTER -> toolExists("flutter", "Flutter SDK")
        Kind.NATIVE -> if (toolExistsAny("clang", "clang++", "gcc", "g++").ready) toolExistsAny("clang", "clang++", "gcc", "g++") else Readiness(false, "No local native compiler was found.")
        Kind.CLI -> Readiness(true, "Runtime readiness is evaluated when a language is selected.")
        Kind.SERVER -> Readiness(true, "Server project structure is available; selected runtime must be installed locally.")
    }

    private fun toolExists(name: String, label: String): Readiness =
        toolExistsAny(name).let { if (it.ready) Readiness(true, "$label found locally.") else Readiness(false, "$label was not found locally.") }

    private fun toolExistsAny(vararg names: String): Readiness {
        for (name in names) {
            val p = findOnPath(name)
            if (p != null) return Readiness(true, "Local toolchain: ${p.absolutePath}")
        }
        return Readiness(false, "Required local toolchain was not found.")
    }

    private fun findOnPath(name: String): File? {
        val path = System.getenv("PATH") ?: return null
        for (part in path.split(File.pathSeparator)) {
            val f = File(part, name)
            if (f.isFile && f.canExecute()) return f
        }
        return null
    }
}
