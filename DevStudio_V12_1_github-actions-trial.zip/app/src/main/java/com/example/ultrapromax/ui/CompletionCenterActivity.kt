package com.example.ultrapromax.ui

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import com.example.ultrapromax.engine.ai.OfflineAiAppBuilderEngine
import com.example.ultrapromax.engine.completion.StudioCompletionEngine
import com.example.ultrapromax.engine.finalcompletion.StudioFeatureCompletionEngine
import com.example.ultrapromax.engine.finalrelease.CompletionScoreEngine
import com.example.ultrapromax.engine.offline.OfflineInternetSimulationEngine
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.webapp.WebAppProjectEngine
import com.example.ultrapromax.engine.power.PowerFeatureCompletionEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import java.io.File

/** Final hardening center for capabilities that need deterministic local verification. */
class CompletionCenterActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var prompt: EditText

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundResource(com.example.ultrapromax.R.drawable.studio_background) }
        val title = TextView(this).apply { text = "✦  COMPLETION CENTER\nV30.1.0 FINAL HARDENING"; setTextColor(Color.WHITE); textSize = 21f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) }
        val info = TextView(this).apply { text = "All checks and builders run locally. No external network, cloud AI or fake build success."; setTextColor(Color.parseColor("#A8B1CF")); textSize = 11f; setPadding(0, 0, 0, dp(10)) }
        val run = Button(this).apply { text = "RUN COMPLETION AUDIT"; setOnClickListener { runAudit() } }
        val ten = Button(this).apply { text = "RUN 10/10 FEATURE COMPLETION"; setOnClickListener { runTenDomainAudit() } }
        val power = Button(this).apply { text = "RUN 4/4 POWER FEATURES"; setOnClickListener { runPowerAudit() } }
        prompt = EditText(this).apply { hint = "Describe an app to generate offline…"; setSingleLine(false); minLines = 2; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setBackgroundResource(com.example.ultrapromax.R.drawable.glass_card); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val generate = Button(this).apply { text = "AI PLAN + GENERATE PROJECT"; setOnClickListener { generateProject() } }
        val webBuild = Button(this).apply { text = "WEB → ANDROID → APK"; setOnClickListener { webToAndroid() } }
        output = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundResource(com.example.ultrapromax.R.drawable.glass_card) }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title); root.addView(info); root.addView(run); root.addView(ten); root.addView(power); root.addView(prompt, LinearLayout.LayoutParams(-1, dp(90))); root.addView(generate); root.addView(webBuild); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        runAudit()
    }

    private fun runAudit() {
        output.text = "Running final local completion audit…"
        val report = StudioCompletionEngine(this).run()
        val score = CompletionScoreEngine().calculate()
        val header = "${score.percent}% COMPLETE • STUDIO SOFTWARE\nPASS ${report.passed()}   WARN ${report.warnings()}   FAIL ${report.failed()}\n\n"
        output.text = header + report.checks.joinToString("\n\n") { "${it.status} • ${it.title}\n${it.detail}" }
    }

    private fun runTenDomainAudit() {
        output.text = "Running 10-domain feature completion audit…"
        Thread {
            val report = StudioFeatureCompletionEngine(this).run()
            val score = CompletionScoreEngine().calculate()
            val text = "${score.percent}% COMPLETE • STUDIO SOFTWARE\n10/10 FEATURE COMPLETION\nPASS ${report.passed()}   WARN ${report.warnings()}   FAIL ${report.failed()}\n\n" +
                    report.items.joinToString("\n\n") { "${it.number}. ${it.status} • ${it.title}\n${it.detail}" }
            runOnUiThread { output.text = text }
        }.start()
    }

    private fun runPowerAudit() {
        output.text = "Running 4/4 power feature audit…"
        Thread {
            val checks = PowerFeatureCompletionEngine(this).run()
            val text = "4/4 POWER FEATURES\nPASS ${checks.count { it.status == "PASS" }}   WARN ${checks.count { it.status == "WARN" }}   FAIL ${checks.count { it.status == "FAIL" }}\n\n" +
                    checks.joinToString("\n\n") { "${it.status} • ${it.title}\n${it.detail}" }
            runOnUiThread { output.text = text }
        }.start()
    }

    private fun webToAndroid() {
        val id = intent.getLongExtra("project_id", -1L)
        val project = ProjectStore.getById(this, id)
        val root = project?.let { File(it.folderPath) }
        if (root == null || !root.isDirectory) { output.text = "No project workspace is mounted."; return }
        val hasWeb = root.walkTopDown().any { it.isFile && it.extension.toLowerCase() in listOf("html", "htm", "css", "js") }
        if (!hasWeb) { output.text = "No HTML/CSS/JS source was found in the current project."; return }
        val outRoot = File(root, "devstudio/generated-web-app")
        try {
            val generated = WebAppProjectEngine().generateWebViewProject(root, outRoot, project.name)
            output.text = "WEB → ANDROID\n\nGenerated project: ${generated.projectDir.absolutePath}\nFiles: ${generated.filesCreated}\n\nStarting real local Gradle build…"
            Thread {
                val result = BuildEngine().buildDebug(generated.projectDir)
                runOnUiThread { output.text = "WEB → ANDROID → APK\n\n${result.output}\n\nAPK: ${result.apkFile?.absolutePath ?: "No verified APK"}" }
            }.start()
        } catch (t: Throwable) { output.text = "WEB → ANDROID FAILED\n\n${t.message ?: "unknown"}" }
    }

    private fun generateProject() {
        val text = prompt.text.toString().trim()
        if (text.isEmpty()) { output.text = "Describe the app first."; return }
        val result = OfflineAiAppBuilderEngine(this).generate(text)
        output.text = result.log.joinToString("\n") + if (result.success) "\n\nDONE • Project #${result.projectId}" else "\n\nFAILED • ${result.error ?: "unknown"}"
        if (result.success) Toast.makeText(this, "Offline project generated", Toast.LENGTH_SHORT).show()
    }
}
