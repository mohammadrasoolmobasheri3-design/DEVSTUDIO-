package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.file.ProjectTemplate
import com.example.ultrapromax.engine.project.AdvancedProjectGenerator

class AdvancedNewProjectActivity : AppCompatActivity() {
    companion object { const val EXTRA_TEMPLATE_ID = "extra_template_id" }

    private lateinit var container: LinearLayout
    private lateinit var stepIndicator: TextView
    private lateinit var stepHint: TextView
    private lateinit var previous: Button
    private lateinit var next: Button
    private lateinit var nameInput: EditText
    private lateinit var packageInput: EditText
    private lateinit var logView: TextView

    private var step = 1
    private var selectedProduct = "Android App"
    private var selectedStatus = "AVAILABLE"
    private var androidLanguage = "Kotlin"
    private var androidUi = "XML Views"
    private var androidArchitecture = "Basic"
    private var androidMinSdk = "23"

    private data class Product(val title: String, val icon: String, val status: String, val description: String)
    private val products = listOf(
        Product("Android App", "📱", "AVAILABLE", "Native Android project")
    )

    private val templates = ProjectTemplate.all()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_advanced_new_project)
        container = findViewById(R.id.wizardContainer)
        stepIndicator = findViewById(R.id.stepIndicator)
        stepHint = findViewById(R.id.stepHint)
        previous = findViewById(R.id.btnPrevious)
        next = findViewById(R.id.btnNext)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        previous.setOnClickListener { if (step > 1) { step--; render() } else finish() }
        next.setOnClickListener { nextStep() }
        render()
    }

    private fun render() {
        container.removeAllViews()
        when (step) {
            1 -> renderDetails()
            2 -> renderProducts()
            3 -> renderConfiguration()
            else -> renderReview()
        }
        stepIndicator.text = when (step) {
            1 -> "1  DETAILS"
            2 -> "2  PRODUCT"
            3 -> "3  CONFIGURATION"
            else -> "4  REVIEW"
        }
        stepHint.text = when (step) {
            1 -> "Project identity"
            2 -> "What do you want to build?"
            3 -> "Product-specific options"
            else -> "Check before creation"
        }
        previous.text = if (step == 1) "CANCEL" else "BACK"
        next.text = if (step == 4) "CREATE PROJECT" else "NEXT  →"
    }

    private fun renderDetails() {
        addTitle("PROJECT DETAILS", "Start with the same simple identity flow you expect from a mobile IDE wizard.")
        nameInput = edit("Project Name", "MyProject", false)
        packageInput = edit("Project Package / App ID", "com.example.myproject", false)
        addInfo("Tip", "Package is validated automatically for Android projects. Other project types can use a simple project identifier.")
    }

    private fun renderProducts() {
        addTitle("ANDROID APP", "Create a native Android application with the local DevStudio generator.")
        products.forEach { product ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(9), dp(12), dp(9))
                background = resources.getDrawable(if (product.title == selectedProduct) R.drawable.studio_action_primary else R.drawable.studio_panel, theme)
                isClickable = true
            }
            val icon = TextView(this).apply { text = product.icon; textSize = 19f; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(38), dp(52)) }
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            text.addView(tv(product.title, 14f, Color.WHITE, true))
            text.addView(tv(product.description, 10f, Color.rgb(145,160,194), false))
            val status = tv(product.status, 9f, statusColor(product.status), true)
            row.addView(icon); row.addView(text); row.addView(status)
            row.setOnClickListener {
                selectedProduct = product.title
                selectedStatus = product.status
                renderProducts()
            }
            container.addView(row, LinearLayout.LayoutParams(-1, dp(70)).apply { bottomMargin = dp(8) })
        }
    }

    private fun renderConfiguration() {
        addTitle("CONFIGURATION", "These options change with the selected product.")
        addInfo("Selected", "$selectedProduct • $selectedStatus")
        renderAndroidOptions()
    }

    private fun renderAndroidOptions() {
        addTitle("ANDROID", "Choose the starter configuration before creating the project.")
        addChoice("Language", listOf("Kotlin", "Java"), androidLanguage) { androidLanguage = it }
        addChoice("UI", listOf("XML Views", "Jetpack Compose", "Empty UI"), androidUi) { androidUi = it }
        addChoice("Architecture", listOf("Basic", "Activity Based", "MVVM"), androidArchitecture) { androidArchitecture = it }
        addChoice("Minimum SDK", listOf("23", "26", "28", "29", "35"), androidMinSdk) { androidMinSdk = it }
        addInfo("Build System", "Gradle • local/offline-first workflow")
    }

    private fun renderReview() {
        addTitle("REVIEW & CREATE", "Everything is local. No cloud account or online authentication is required.")
        addInfo("Project", nameInput.text.toString().trim())
        addInfo("Package / ID", packageInput.text.toString().trim())
        addInfo("Product", "$selectedProduct • $selectedStatus")
        addInfo("Android", "$androidLanguage • $androidUi • $androidArchitecture • minSdk $androidMinSdk")
        logView = tv("READY • Review complete. Press CREATE PROJECT.", 10f, Color.rgb(191,233,255), false)
        logView.setPadding(dp(14), dp(14), dp(14), dp(14))
        logView.background = resources.getDrawable(R.drawable.studio_panel, theme)
        container.addView(logView, LinearLayout.LayoutParams(-1, dp(120)).apply { topMargin = dp(10) })
    }

    private fun nextStep() {
        if (step == 1) {
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) { nameInput.error = "Project name is required"; return }
            if (!name.matches(Regex("[A-Za-z0-9][A-Za-z0-9 _-]*"))) { nameInput.error = "Use letters, numbers, spaces, _ or -"; return }
            step = 2
        } else if (step == 2) {
            step = 3
        } else if (step == 3) {
            step = 4
        } else {
            generate()
            return
        }
        render()
    }

    private fun generate() {
        val name = nameInput.text.toString().trim()
        val pkg = packageInput.text.toString().trim()
        val template = if (androidLanguage == "Java") ProjectTemplate.AndroidJava else ProjectTemplate.AndroidKotlin
        if (!validatePackage(pkg, template)) { packageInput.error = "Use a valid package / project ID"; step = 1; render(); return }
        val generator = AdvancedProjectGenerator(com.example.ultrapromax.engine.file.FileEngine(this))
        next.isEnabled = false
        val result = generator.generate(AdvancedProjectGenerator.Options(name = name, packageName = pkg, template = template, addReadme = true, addGitignore = true, addMetadata = true, addStudioFolders = true), this)
        if (result.success) {
            Toast.makeText(this, "Project created successfully", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, ProjectStudioActivity::class.java).putExtra(ProjectStudioActivity.EXTRA_PROJECT_ID, result.projectId))
            finish()
        } else {
            Toast.makeText(this, result.error ?: "Project creation failed", Toast.LENGTH_LONG).show()
            next.isEnabled = true
        }
    }

    private fun validatePackage(value: String, template: ProjectTemplate): Boolean {
        if (value.isEmpty()) return false
        val android = template.isAndroidGradleProject
        return if (android) value.matches(Regex("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+")) else value.matches(Regex("[A-Za-z0-9][A-Za-z0-9_-]*"))
    }

    private fun addChoice(label: String, values: List<String>, selected: String, onSelect: (String) -> Unit) {
        container.addView(tv(label, 10f, Color.rgb(143,232,255), true), LinearLayout.LayoutParams(-1, dp(26)).apply { topMargin = dp(10) })
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        values.forEach { value ->
            val radio = RadioButton(this).apply { text = value; textSize = 12f; textColorCompat(Color.rgb(214,226,255)); isChecked = value == selected; setPadding(0,0,0,0); setOnClickListener { onSelect(value); renderConfiguration() } }
            group.addView(radio, RadioGroup.LayoutParams(-1, dp(42)))
        }
        container.addView(group)
    }

    private fun edit(label: String, value: String, password: Boolean): EditText {
        container.addView(tv(label, 10f, Color.rgb(143,232,255), true), LinearLayout.LayoutParams(-1, dp(26)).apply { topMargin = dp(12) })
        val e = EditText(this).apply { setText(value); hint = label; isSingleLine = true; textSize = 13f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(143,160,200)); background = resources.getDrawable(R.drawable.studio_input, theme); setPadding(dp(14),0,dp(14),0); if (password) inputType = 0x81 }
        container.addView(e, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(4) })
        return e
    }

    private fun addTitle(title: String, subtitle: String) {
        container.addView(tv(title, 11f, Color.rgb(143,232,255), true), LinearLayout.LayoutParams(-1, dp(24)))
        container.addView(tv(subtitle, 11f, Color.rgb(145,160,194), false), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun addInfo(title: String, text: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = resources.getDrawable(R.drawable.studio_panel, theme) }
        box.addView(tv(title, 9f, Color.rgb(143,232,255), true))
        box.addView(tv(text, 12f, Color.rgb(214,226,255), false))
        container.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
    private fun statusColor(s: String) = when (s) { "AVAILABLE" -> Color.rgb(105,240,170); "BETA" -> Color.rgb(255,210,100); "IN DEVELOPMENT" -> Color.rgb(143,180,255); else -> Color.rgb(190,140,255) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun RadioButton.textColorCompat(color: Int) { setTextColor(color); buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(143,232,255)) }
}
