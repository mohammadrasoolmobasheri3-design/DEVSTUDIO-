package com.example.ultrapromax.engine.endgame

/** Built-in server profiles plus extension points for offline server packs. */
object UniversalServerRegistry {
    private val builtIns = listOf(
        EndgameAdapterContract(
            "node", "Node.js / TypeScript", EndgameAdapterContract.Kind.SERVER,
            listOf("node"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.API,
                EndgameAdapterContract.Capability.WEBSOCKET)
        ),
        EndgameAdapterContract(
            "python", "Python", EndgameAdapterContract.Kind.SERVER,
            listOf("python3", "python"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.API,
                EndgameAdapterContract.Capability.WEBSOCKET)
        ),
        EndgameAdapterContract(
            "go", "Go", EndgameAdapterContract.Kind.SERVER,
            listOf("go"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.BUILD,
                EndgameAdapterContract.Capability.API, EndgameAdapterContract.Capability.WEBSOCKET)
        ),
        EndgameAdapterContract(
            "java", "Java", EndgameAdapterContract.Kind.SERVER,
            listOf("java", "javac"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.BUILD,
                EndgameAdapterContract.Capability.API, EndgameAdapterContract.Capability.WEBSOCKET)
        ),
        EndgameAdapterContract(
            "dotnet", "C# / .NET", EndgameAdapterContract.Kind.SERVER,
            listOf("dotnet"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.BUILD,
                EndgameAdapterContract.Capability.API, EndgameAdapterContract.Capability.WEBSOCKET)
        ),
        EndgameAdapterContract(
            "php", "PHP", EndgameAdapterContract.Kind.SERVER,
            listOf("php"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.API)
        ),
        EndgameAdapterContract(
            "rust", "Rust", EndgameAdapterContract.Kind.SERVER,
            listOf("cargo", "rustc"), emptyList(),
            setOf(EndgameAdapterContract.Capability.RUN, EndgameAdapterContract.Capability.BUILD,
                EndgameAdapterContract.Capability.API, EndgameAdapterContract.Capability.WEBSOCKET)
        )
    )

    private val custom = LinkedHashMap<String, EndgameAdapterContract>()

    @Synchronized
    fun register(contract: EndgameAdapterContract) {
        require(contract.kind == EndgameAdapterContract.Kind.SERVER)
        custom[contract.id] = contract
    }

    fun all(): List<EndgameAdapterContract> = builtIns + custom.values

    fun find(id: String): EndgameAdapterContract? = all().firstOrNull { it.id == id }
}
