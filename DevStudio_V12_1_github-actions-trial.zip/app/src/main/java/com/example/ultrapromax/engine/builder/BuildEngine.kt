package com.example.ultrapromax.engine.builder

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** Real Gradle build bridge. Uses a local JDK/SDK and lets Gradle resolve missing dependencies online. */
class BuildEngine(private val context: Context? = null) {

    data class Result(
        val success: Boolean,
        val apkFile: File?,
        val output: String
    )

    fun buildDebug(projectDir: File): Result = build(projectDir, "assembleDebug", "debug")

    fun buildRelease(projectDir: File): Result = build(projectDir, "assembleRelease", "release")

    private fun build(projectDir: File, task: String, variant: String): Result {
        if (!projectDir.exists() || !projectDir.isDirectory) {
            return Result(false, null, "Project directory not found: ${projectDir.absolutePath}")
        }

        val toolchain = LocalToolchainResolver(context).resolve()
        if (!toolchain.ready) {
            return Result(false, null, "LOCAL TOOLCHAIN MISSING\n${toolchain.details}")
        }

        val gradlew = File(projectDir, "gradlew")
        val gradleBat = File(projectDir, "gradlew.bat")
        val gradleExecutable = toolchain.gradleExecutable
        if (!gradlew.exists() && !gradleBat.exists() && gradleExecutable == null) {
            return Result(false, null, "No Gradle launcher found. Add gradlew/gradlew.bat to the project or install Gradle 6.1.1 in the local toolchain.")
        }

        if (gradlew.exists()) {
            try { gradlew.setExecutable(true, false) } catch (_: SecurityException) {}
        }

        // Prefer the project wrapper. Online mode allows Gradle to download its distribution
        // and resolve missing Maven artifacts when network access is available.
        val command = when {
            gradlew.exists() -> listOf("sh", gradlew.absolutePath, task, "--no-daemon", "--stacktrace")
            gradleBat.exists() -> listOf(gradleBat.absolutePath, task, "--no-daemon", "--stacktrace")
            gradleExecutable != null -> listOf(gradleExecutable.absolutePath, task, "--no-daemon", "--stacktrace")
            else -> emptyList()
        }

        return try {
            val pb = ProcessBuilder(command)
                .directory(projectDir)
                .redirectErrorStream(true)

            // Force the build to the DevStudio local SDK/JDK instead of host defaults.
            val env = pb.environment()
            toolchain.javaHome?.let {
                env["JAVA_HOME"] = it.absolutePath
                env["PATH"] = File(it, "bin").absolutePath + File.pathSeparator + (env["PATH"] ?: "")
            }
            toolchain.sdk?.let {
                env["ANDROID_HOME"] = it.absolutePath
                env["ANDROID_SDK_ROOT"] = it.absolutePath
                toolchain.buildTools?.let { bt -> env["PATH"] = bt.absolutePath + File.pathSeparator + (env["PATH"] ?: "") }
            }
            toolchain.gradleExecutable?.parentFile?.parentFile?.let {
                env["PATH"] = File(it, "bin").absolutePath + File.pathSeparator + (env["PATH"] ?: "")
            }
            toolchain.mavenRepo?.let { env["DEVSTUDIO_MAVEN_REPO"] = it.absolutePath }
            context?.let { env["GRADLE_USER_HOME"] = File(it.filesDir, "internal-toolchain/gradle-home").absolutePath }
            env["GRADLE_OPTS"] = ((env["GRADLE_OPTS"] ?: "") + " -Dorg.gradle.daemon=false").trim()

            val process = pb.start()
            val output = StringBuilder()
            val reader = Thread {
                try {
                    process.inputStream.bufferedReader().use { reader ->
                        var line = reader.readLine()
                        while (line != null) {
                            output.append(line).append('\n')
                            line = reader.readLine()
                        }
                    }
                } catch (_: Throwable) {}
            }
            reader.start()

            val finished = process.waitFor(10, TimeUnit.MINUTES)
            if (!finished) {
                process.destroy()
                return Result(false, null, output.toString() + "\nBuild TIMEOUT after 10 minutes")
            }
            reader.join(5000)

            val text = output.toString()
            val exitCode = process.exitValue()
            val apk = findNewestApk(projectDir, variant)
            if (exitCode == 0 && apk != null && apk.exists() && apk.length() > 0L) {
                val finalOutput = AndroidApkOutputEngine(context).finish(apk)
                if (finalOutput.success) Result(true, apk, text + "\n" + finalOutput.output)
                else Result(false, apk, text + "\n" + finalOutput.output)
            } else {
                Result(false, apk, text + "\nBuild exit code: $exitCode")
            }
        } catch (e: Exception) {
            Result(false, null, "Unable to start local Gradle build: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun findNewestApk(projectDir: File, variant: String): File? {
        val marker = "/outputs/apk/$variant/"
        val winMarker = "\\outputs\\apk\\$variant\\"
        val candidates = projectDir.walkTopDown()
            .filter { it.isFile && it.extension.equals("apk", true) }
            .filter { it.absolutePath.contains(marker) || it.absolutePath.contains(winMarker) }
            .toList()
        return if (candidates.isEmpty()) null else candidates.maxBy { it.lastModified() }
    }
}
