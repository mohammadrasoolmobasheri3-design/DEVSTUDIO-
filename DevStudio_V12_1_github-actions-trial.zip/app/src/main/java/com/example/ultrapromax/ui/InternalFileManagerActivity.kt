package com.example.ultrapromax.ui

import android.content.Context
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import java.io.File
import java.util.Locale

/**
 * DEVSTUDIO INTERNAL FILE MANAGER
 *
 * Project-scoped file manager. It never uses the Android document picker.
 * All operations are restricted to the selected project's directory.
 */
class InternalFileManagerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROJECT_ID = "extra_project_id"
    }

    private lateinit var project: Project
    private lateinit var root: File
    private lateinit var list: LinearLayout
    private lateinit var pathText: TextView
    private var currentDir: File? = null
    private var clipboard: File? = null
    private var clipboardCut = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        val loaded = if (id >= 0) ProjectStore.getById(this, id) else null
        if (loaded == null) {
            Toast.makeText(this, "Project not found.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        project = loaded
        root = File(project.folderPath).canonicalFile
        if (!root.exists() || !root.isDirectory) {
            Toast.makeText(this, "Project folder is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        buildUi()
        openDirectory(root)
    }

    private fun buildUi() {
        val bg = Color.rgb(6, 8, 16)
        val cyan = Color.rgb(90, 220, 255)
        val white = Color.WHITE
        val secondary = Color.rgb(145, 160, 200)

        val base = LinearLayout(this)
        base.orientation = LinearLayout.VERTICAL
        base.setBackgroundColor(bg)

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(8), dp(8), dp(8), dp(8))
        header.setBackgroundResource(R.drawable.neon_panel)

        val back = TextView(this)
        back.text = "‹"
        back.textSize = 30f
        back.gravity = Gravity.CENTER
        back.setTextColor(white)
        back.setOnClickListener { finish() }
        header.addView(back, LinearLayout.LayoutParams(dp(44), dp(48)))

        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "INTERNAL FILE MANAGER"
        title.textSize = 15f
        title.setTextColor(white)
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        val sub = TextView(this)
        sub.text = project.name
        sub.textSize = 9f
        sub.setTextColor(secondary)
        titleBox.addView(title)
        titleBox.addView(sub)
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        val plus = Button(this)
        plus.text = "+"
        plus.setTextColor(cyan)
        plus.textSize = 20f
        plus.background = null
        plus.setOnClickListener { createMenu(currentDir ?: root) }
        header.addView(plus, LinearLayout.LayoutParams(dp(48), dp(48)))

        val refresh = Button(this)
        refresh.text = "↻"
        refresh.setTextColor(white)
        refresh.textSize = 18f
        refresh.background = null
        refresh.setOnClickListener { refresh() }
        header.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(48)))
        base.addView(header)

        pathText = TextView(this)
        pathText.setTextColor(cyan)
        pathText.textSize = 10f
        pathText.setPadding(dp(12), dp(9), dp(12), dp(9))
        pathText.setSingleLine(true)
        base.addView(pathText)

        val tools = LinearLayout(this)
        tools.setPadding(dp(8), 0, dp(8), dp(6))
        val search = Button(this)
        search.text = "SEARCH"
        search.setTextColor(white)
        search.background = null
        search.setOnClickListener { searchFiles() }
        tools.addView(search, LinearLayout.LayoutParams(0, dp(38), 1f))
        val paste = Button(this)
        paste.text = "PASTE"
        paste.setTextColor(white)
        paste.background = null
        paste.setOnClickListener { pasteClipboard() }
        tools.addView(paste, LinearLayout.LayoutParams(0, dp(38), 1f))
        base.addView(tools)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(10), dp(4), dp(10), dp(20))
        scroll.addView(list)
        base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(base)
    }

    private fun openDirectory(dir: File) {
        val canonical = try { dir.canonicalFile } catch (_: Exception) { return }
        if (!isInsideProject(canonical) || !canonical.isDirectory) return
        currentDir = canonical
        refresh()
    }

    private fun refresh() {
        val dir = currentDir ?: root
        pathText.text = "PROJECT / " + relativePath(dir)
        list.removeAllViews()

        if (dir != root) {
            addRow("..", true, "Parent directory") { openDirectory(dir.parentFile ?: root) }
        }

        val children = dir.listFiles()?.sortedWith(
            compareBy<File>({ !it.isDirectory }, { it.name.toLowerCase(Locale.US) })
        ) ?: emptyList<File>()

        if (children.isEmpty()) {
            val empty = TextView(this)
            empty.text = "This folder is empty."
            empty.setTextColor(Color.rgb(145, 160, 190))
            empty.setPadding(dp(12), dp(18), dp(12), dp(18))
            list.addView(empty)
        } else {
            children.forEach { file ->
                addRow(
                    if (file.isDirectory) "▸  ${file.name}" else "    ${file.name}",
                    file.isDirectory,
                    if (file.isDirectory) "Folder" else "${formatBytes(file.length())}"
                ) {
                    if (file.isDirectory) openDirectory(file)
                    else openInEditor(file)
                }
                list.getChildAt(list.childCount - 1).setOnLongClickListener {
                    fileMenu(file)
                    true
                }
            }
        }
    }

    private fun addRow(name: String, folder: Boolean, meta: String, click: () -> Unit) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(10), dp(6), dp(8), dp(6))
        row.setBackgroundResource(R.drawable.glass_card)
        row.setOnClickListener { click() }

        val icon = TextView(this)
        icon.text = if (folder) "▣" else "□"
        icon.textSize = 17f
        icon.setTextColor(if (folder) Color.rgb(255, 205, 90) else Color.rgb(90, 220, 255))
        row.addView(icon, LinearLayout.LayoutParams(dp(30), dp(42)))

        val nameText = TextView(this)
        nameText.text = name
        nameText.textSize = 12f
        nameText.setTextColor(Color.WHITE)
        nameText.setSingleLine(true)
        row.addView(nameText, LinearLayout.LayoutParams(0, dp(42), 1f))

        val metaText = TextView(this)
        metaText.text = meta
        metaText.textSize = 9f
        metaText.setTextColor(Color.rgb(145, 160, 190))
        row.addView(metaText, LinearLayout.LayoutParams(dp(78), dp(42)))

        val lp = LinearLayout.LayoutParams(-1, dp(52))
        lp.setMargins(0, 0, 0, dp(6))
        list.addView(row, lp)
    }

    private fun fileMenu(file: File): Boolean {
        val actions = if (file.isDirectory)
            arrayOf("Open", "Rename", "Copy", "Cut", "Delete", "Properties")
        else
            arrayOf("Open in Editor", "Rename", "Copy", "Cut", "Delete", "Properties")

        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(actions) { _, which ->
                when (actions[which]) {
                    "Open", "Open in Editor" -> if (file.isDirectory) openDirectory(file) else openInEditor(file)
                    "Rename" -> rename(file)
                    "Copy" -> { clipboard = file; clipboardCut = false; toast("Copied to internal clipboard") }
                    "Cut" -> { clipboard = file; clipboardCut = true; toast("Ready to move") }
                    "Delete" -> confirmDelete(file)
                    "Properties" -> properties(file)
                }
            }.show()
        return true
    }

    private fun createMenu(parent: File) {
        AlertDialog.Builder(this).setTitle("Create in ${parent.name}")
            .setItems(arrayOf("New File", "New Folder")) { _, which ->
                if (which == 0) createEntry(parent, false) else createEntry(parent, true)
            }.show()
    }

    private fun createEntry(parent: File, folder: Boolean) {
        val input = EditText(this)
        input.hint = if (folder) "Folder name" else "File name"
        input.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle(if (folder) "New Folder" else "New File")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val name = safeName(input.text.toString())
                if (name.isEmpty()) { toast("Invalid name"); return@setPositiveButton }
                val target = File(parent, name)
                if (!isInsideProject(target)) { toast("Blocked path"); return@setPositiveButton }
                if (target.exists()) { toast("Already exists"); return@setPositiveButton }
                try {
                    if (folder) target.mkdirs() else {
                        target.parentFile?.mkdirs()
                        target.writeText("")
                    }
                    refresh()
                } catch (e: Exception) { toast("Create failed: ${e.message}") }
            }.show()
    }

    private fun rename(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        input.setSingleLine(true)
        AlertDialog.Builder(this).setTitle("Rename").setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Rename") { _, _ ->
                val name = safeName(input.text.toString())
                if (name.isEmpty()) { toast("Invalid name"); return@setPositiveButton }
                val target = File(file.parentFile, name)
                if (!isInsideProject(target) || target.exists()) { toast("Invalid or existing target"); return@setPositiveButton }
                try {
                    if (!file.renameTo(target)) toast("Rename failed") else refresh()
                } catch (_: Exception) { toast("Rename failed") }
            }.show()
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this).setTitle("Delete ${file.name}?")
            .setMessage(if (file.isDirectory) "This deletes the entire folder and its contents." else "This file will be permanently removed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                try {
                    if (!isInsideProject(file)) { toast("Blocked path"); return@setPositiveButton }
                    if (!file.deleteRecursively()) toast("Delete failed") else refresh()
                } catch (_: Exception) { toast("Delete failed") }
            }.show()
    }

    private fun pasteClipboard() {
        val src = clipboard ?: run { toast("Clipboard is empty"); return }
        val destDir = currentDir ?: root
        if (!src.exists() || !isInsideProject(src) || !isInsideProject(destDir)) { toast("Invalid clipboard item"); return }
        if (src.canonicalFile == destDir.canonicalFile) { toast("Cannot paste into itself"); return }
        var target = File(destDir, src.name)
        if (target.exists()) {
            var n = 2
            val base = src.nameWithoutExtension
            val ext = if (src.extension.isEmpty()) "" else "." + src.extension
            do { target = File(destDir, "${base}_$n$ext"); n++ } while (target.exists())
        }
        try {
            if (clipboardCut) {
                if (!src.renameTo(target)) {
                    copyRecursive(src, target)
                    src.deleteRecursively()
                }
                clipboard = null
                clipboardCut = false
            } else copyRecursive(src, target)
            refresh()
        } catch (e: Exception) { toast("Paste failed: ${e.message}") }
    }

    private fun copyRecursive(src: File, dest: File) {
        if (src.isDirectory) {
            if (!dest.mkdirs() && !dest.isDirectory) throw IllegalStateException("Cannot create folder")
            src.listFiles()?.forEach { child -> copyRecursive(child, File(dest, child.name)) }
        } else {
            dest.parentFile?.mkdirs()
            src.inputStream().use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
        }
    }

    private fun searchFiles() {
        val input = EditText(this)
        input.hint = "File or folder name"
        input.setSingleLine(true)
        AlertDialog.Builder(this).setTitle("Search Project").setView(input)
            .setNegativeButton("Close", null)
            .setPositiveButton("Search") { _, _ ->
                val q = input.text.toString().trim().toLowerCase(Locale.US)
                if (q.isEmpty()) return@setPositiveButton
                val matches = root.walkTopDown().filter { isInsideProject(it) && it.name.toLowerCase(Locale.US).contains(q) }.toList()
                if (matches.isEmpty()) { toast("No matches"); return@setPositiveButton }
                AlertDialog.Builder(this).setTitle("${matches.size} matches")
                    .setItems(matches.map { relativePath(it) }.toTypedArray()) { _, which ->
                        val f = matches[which]
                        if (f.isFile) openInEditor(f) else openDirectory(f)
                    }.show()
            }.show()
    }

    private fun openInEditor(file: File) {
        if (!isInsideProject(file)) { toast("Blocked path"); return }
        startActivity(android.content.Intent(this, EditorActivity::class.java)
            .putExtra(EditorActivity.EXTRA_PROJECT_ID, project.id)
            .putExtra(EditorActivity.EXTRA_FILE_PATH, file.absolutePath))
    }

    private fun properties(file: File) {
        val type = if (file.isDirectory) "Folder" else "File"
        val size = if (file.isDirectory) directorySize(file) else file.length()
        AlertDialog.Builder(this).setTitle("Properties")
            .setMessage("Name: ${file.name}\nType: $type\nPath: ${relativePath(file)}\nSize: ${formatBytes(size)}")
            .setPositiveButton("OK", null).show()
    }

    private fun directorySize(dir: File): Long {
        var total = 0L
        dir.walkTopDown().filter { it.isFile }.forEach { total += it.length() }
        return total
    }

    private fun safeName(value: String): String {
        val name = value.trim()
        if (name.isEmpty() || name == "." || name == "..") return ""
        if (name.contains("/") || name.contains("\\") || name.contains("\u0000")) return ""
        return name
    }

    private fun isInsideProject(file: File): Boolean {
        return try {
            val r = root.canonicalPath
            val p = file.canonicalFile.canonicalPath
            p == r || p.startsWith(r + File.separator)
        } catch (_: Exception) { false }
    }

    private fun relativePath(file: File): String {
        val r = root.canonicalPath
        val p = file.canonicalFile.canonicalPath
        return if (p == r) project.name else p.removePrefix(r).trimStart(File.separatorChar).replace(File.separatorChar, '/')
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value B"
        if (value < 1024 * 1024) return "${value / 1024} KB"
        if (value < 1024L * 1024L * 1024L) return "${value / (1024L * 1024L)} MB"
        return "${value / (1024L * 1024L * 1024L)} GB"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
