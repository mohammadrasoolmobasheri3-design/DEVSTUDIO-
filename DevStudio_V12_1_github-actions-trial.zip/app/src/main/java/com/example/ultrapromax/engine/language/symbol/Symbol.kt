package com.example.ultrapromax.engine.language.symbol

data class Symbol(
    val name: String,
    val kind: SymbolKind,
    val language: String,
    val filePath: String?,
    val line: Int,
    val column: Int,
    val endLine: Int,
    val endColumn: Int,
    val container: String?,
    val signature: String?,
    val visibility: String?
)
