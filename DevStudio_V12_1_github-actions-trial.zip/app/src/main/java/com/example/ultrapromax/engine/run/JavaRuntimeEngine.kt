package com.example.ultrapromax.engine.run

import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Offline Java runtime adapter for DEVSTUDIO.
 *
 * A Java pack must contain a Java launcher/compiler pair under:
 *   runtimes/java/bin/java
 *   runtimes/java/bin/javac
 *
 * v23.5.2 adds workspace compilation: every .java file already present in the
 * project is copied into an isolated run workspace, so imports and helper
 * classes can participate in the same compile instead of compiling only the
 * currently opened file.
 */
class JavaRuntimeEngine(private val runtimeDir: File) {

    data class Result(val success: Boolean, val output: String)

    fun status(): String {
        val javac = File(runtimeDir, "bin/javac")
        val java = File(runtimeDir, "bin/java")
        return when {
            !runtimeDir.exists() -> "JAVA_RUNTIME_NOT_INSTALLED"
            !javac.isFile -> "JAVA_COMPILER_MISSING"
            !java.isFile -> "JAVA_RUNTIME_MISSING"
            !javac.canExecute() || !java.canExecute() -> "JAVA_RUNTIME_NOT_EXECUTABLE"
            else -> "JAVA_RUNTIME_READY"
        }
    }

    fun run(sourceFileName: String, source: String, projectDir: File, workDir: File): Result {
        val javac = File(runtimeDir, "bin/javac")
        val java = File(runtimeDir, "bin/java")
        if (!javac.isFile || !java.isFile) {
            return Result(false, "Java runtime pack is not ready. Expected runtimes/java/bin/javac and runtimes/java/bin/java.")
        }
        if (!javac.canExecute()) javac.setExecutable(true, false)
        if (!java.canExecute()) java.setExecutable(true, false)
        if (!workDir.exists() && !workDir.mkdirs()) {
            return Result(false, "Unable to create Java work directory: ${workDir.absolutePath}")
        }

        // Always start from a clean Java workspace so stale .class files cannot
        // make a broken source appear successful.
        workDir.listFiles()?.forEach { it.deleteRecursively() }

        val fileName = if (sourceFileName.endsWith(".java", true)) sourceFileName else "$sourceFileName.java"
        val sourceFile = File(workDir, fileName)
        sourceFile.parentFile?.mkdirs()
        sourceFile.writeText(source)

        // Bring project Java sources into the isolated workspace. The currently
        // opened source wins, while build/.gradle/.git are never copied.
        if (projectDir.isDirectory) copyJavaSources(projectDir, projectDir, workDir, sourceFile)

        val javaSources = workDir.walkTopDown()
            .filter { it.isFile && it.extension.equals("java", true) }
            .toList()
        if (javaSources.isEmpty()) return Result(false, "No Java source files found in the run workspace.")

        val className = findMainClass(source, sourceFile.nameWithoutExtension)
            ?: findMainClassInSources(javaSources)
        if (className == null) {
            return Result(false, "Java entry point not found. Add: public static void main(String[] args)")
        }

        val compileCommand = ArrayList<String>()
        compileCommand.add(javac.absolutePath)
        compileCommand.add("-d")
        compileCommand.add(workDir.absolutePath)
        javaSources.forEach { compileCommand.add(it.absolutePath) }

        val compile = execute(compileCommand, workDir, projectDir)
        if (compile.exitCode != 0) {
            return Result(false, "JAVA COMPILE FAILED\n${compile.output}")
        }

        val run = execute(listOf(java.absolutePath, "-cp", workDir.absolutePath, className), workDir, projectDir)
        return Result(
            run.exitCode == 0,
            "JAVA RUN ${if (run.exitCode == 0) "OK" else "FAILED"}\n${run.output}"
        )
    }

    private fun copyJavaSources(root: File, current: File, targetRoot: File, opened: File) {
        current.listFiles()?.forEach { file ->
            val relative = file.relativeTo(root).path
            if (relative == "build" || relative.startsWith("build/") ||
                relative == ".gradle" || relative.startsWith(".gradle/") ||
                relative == ".git" || relative.startsWith(".git/")) return@forEach
            if (file.isDirectory) {
                copyJavaSources(root, file, targetRoot, opened)
            } else if (file.isFile && file.extension.equals("java", true)) {
                val out = File(targetRoot, relative)
                if (out.absoluteFile != opened.absoluteFile) {
                    out.parentFile?.mkdirs()
                    try { file.copyTo(out, true) } catch (_: Exception) {}
                }
            }
        }
    }

    private fun findMainClassInSources(sources: List<File>): String? {
        sources.forEach { file ->
            val found = findMainClass(file.readText(), file.nameWithoutExtension)
            if (found != null) return found
        }
        return null
    }

    private fun findMainClass(source: String, fallback: String): String? {
        val pkg = Regex("\\bpackage\\s+([A-Za-z_][A-Za-z0-9_.]*)\\s*;").find(source)?.groupValues?.get(1)
        val publicClass = Regex("\\bpublic\\s+(?:final\\s+|abstract\\s+)?class\\s+([A-Za-z_][A-Za-z0-9_]*)").find(source)?.groupValues?.get(1)
        val anyClass = Regex("\\bclass\\s+([A-Za-z_][A-Za-z0-9_]*)").find(source)?.groupValues?.get(1)
        val name = publicClass ?: anyClass ?: fallback
        return if (Regex("\\bstatic\\s+void\\s+main\\s*\\(").containsMatchIn(source)) {
            if (pkg.isNullOrEmpty()) name else "$pkg.$name"
        } else null
    }

    private data class ExecResult(val exitCode: Int, val output: String)

    private fun execute(command: List<String>, workDir: File, projectDir: File): ExecResult {
        return try {
            val process = ProcessBuilder(command)
                .directory(workDir)
                .redirectErrorStream(true)
                .apply { environment()["DEVSTUDIO_PROJECT"] = projectDir.absolutePath }
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            if (!process.waitFor(60, TimeUnit.SECONDS)) {
                process.destroy()
                ExecResult(124, output + "\nProcess timed out after 60 seconds.")
            } else {
                ExecResult(process.exitValue(), output)
            }
        } catch (e: Exception) {
            ExecResult(127, "Unable to start Java process: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
