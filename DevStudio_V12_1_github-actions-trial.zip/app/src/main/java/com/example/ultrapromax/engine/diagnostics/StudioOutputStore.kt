package com.example.ultrapromax.engine.diagnostics

import android.content.Context

class StudioOutputStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("studio_output", Context.MODE_PRIVATE)

    fun appendConsole(message: String) {
        val old = prefs.getString("console", "") ?: ""
        val next = (old + if (old.isEmpty()) "" else "\n" + message).takeLast(12000)
        prefs.edit().putString("console", next).apply()
    }

    fun setProblems(items: List<StudioDiagnostic>) {
        val encoded = items.joinToString("\n") {
            listOf(it.filePath, it.line.toString(), it.column.toString(), it.severity, it.message.replace("\n"," ")).joinToString("|")
        }
        prefs.edit().putString("problems", encoded.takeLast(12000)).apply()
    }

    fun problems(): List<StudioDiagnostic> {
        val raw = prefs.getString("problems", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\n").mapNotNull {
            val p = it.split("|", limit = 5)
            if (p.size < 5) null else StudioDiagnostic(
                p[0], p[1].toIntOrNull() ?: 1, p[2].toIntOrNull() ?: 1, p[3], p[4]
            )
        }
    }

    fun console(): String = prefs.getString("console", "") ?: ""
}
