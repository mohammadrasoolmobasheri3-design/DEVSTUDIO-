package com.example.ultrapromax.engine.theme

import android.content.Context
import android.graphics.Color

/**
 * THEME ENGINE
 * Real, working theme switching stored locally. Three themes ship out of the
 * box (Dark, Light, Cyberpunk). Activities read ThemeEngine.current(context)
 * and apply the returned palette to their root views/buttons at onCreate.
 *
 * Runtime palette application is supported. Custom profiles are persisted locally through ThemeProfileEngine.
 */
enum class ThemeId { DARK, LIGHT, CYBERPUNK }

data class ThemePalette(
    val background: Int,
    val surface: Int,
    val textPrimary: Int,
    val textSecondary: Int,
    val accent: Int
)

object ThemeEngine {
    private const val PREFS = "theme_state"
    private const val KEY = "theme_id"

    data class DesignTokens(
        val theme: ThemeId,
        val colors: Map<String, Int>,
        val spacingDp: IntArray,
        val radiusDp: Float,
        val elevationDp: Float,
        val motionMs: Long,
        val glassAlpha: Int
    )

    private val palettes = mapOf(
        ThemeId.DARK to ThemePalette(
            background = Color.parseColor("#0B0E1A"),
            surface = Color.parseColor("#141A2E"),
            textPrimary = Color.WHITE,
            textSecondary = Color.parseColor("#9AA4C0"),
            accent = Color.parseColor("#9B5CFF")
        ),
        ThemeId.LIGHT to ThemePalette(
            background = Color.parseColor("#FAFAFA"),
            surface = Color.parseColor("#FFFFFF"),
            textPrimary = Color.parseColor("#121212"),
            textSecondary = Color.parseColor("#5B5B5B"),
            accent = Color.parseColor("#6750A4")
        ),
        ThemeId.CYBERPUNK to ThemePalette(
            background = Color.parseColor("#050014"),
            surface = Color.parseColor("#160029"),
            textPrimary = Color.parseColor("#00F6FF"),
            textSecondary = Color.parseColor("#FF2DA8"),
            accent = Color.parseColor("#FFEA00")
        )
    )

    fun current(context: Context): ThemeId {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY, ThemeId.DARK.name) ?: ThemeId.DARK.name
        return ThemeId.valueOf(name)
    }

    fun setTheme(context: Context, id: ThemeId) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, id.name).apply()
    }

    fun setThemeAndApply(activity: android.app.Activity, id: ThemeId) {
        setTheme(activity, id)
        applyTo(activity)
    }

    fun paletteFor(id: ThemeId): ThemePalette = palettes.getValue(id)

    fun paletteOrCustom(context: Context, id: String): ThemePalette = ThemeProfileEngine(context).load(id) ?: paletteFor(ThemeId.DARK)

    fun designTokens(): List<DesignTokens> = all().map { id ->
        val p = paletteFor(id)
        DesignTokens(
            id,
            mapOf("background" to p.background, "surface" to p.surface, "textPrimary" to p.textPrimary, "textSecondary" to p.textSecondary, "accent" to p.accent),
            intArrayOf(4, 8, 12, 16, 24, 32),
            14f, 8f, 180L, 150
        )
    }

    fun all(): List<ThemeId> = ThemeId.values().toList()

    /**
     * Actually applies a palette to a view tree: recolors the window
     * background and walks every child, recoloring plain-color backgrounds
     * (skips custom drawables like the glass-card style so it doesn't wreck
     * gradients/borders) and TextView/EditText text colors.
     * Call this once from onCreate after setContentView(...).
     */
    fun applyTo(activity: android.app.Activity) {
        val palette = paletteFor(current(activity))
        activity.window.decorView.setBackgroundColor(palette.background)
        val root = activity.findViewById<android.view.View>(android.R.id.content)
        applyToViewTree(root, palette)
    }

    private fun applyToViewTree(view: android.view.View, palette: ThemePalette) {
        val bg = view.background
        if (bg is android.graphics.drawable.ColorDrawable) {
            view.setBackgroundColor(palette.background)
        }

        if (view is android.widget.TextView) {
            view.setTextColor(palette.textPrimary)
            if (view is android.widget.EditText) {
                view.setHintTextColor(palette.textSecondary)
            }
        }

        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                applyToViewTree(view.getChildAt(i), palette)
            }
        }
    }
}
