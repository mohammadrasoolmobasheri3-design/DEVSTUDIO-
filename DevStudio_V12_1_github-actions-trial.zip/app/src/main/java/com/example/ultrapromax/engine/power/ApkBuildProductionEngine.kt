package com.example.ultrapromax.engine.power

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.ApkRuntimeController
import com.example.ultrapromax.engine.builder.ApkSigningEngine
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import java.io.File

/** Real APK build/sign/inspect/install bridge. External tool availability is detected, never faked. */
class ApkBuildProductionEngine(private val context: Context) {
    data class Result(val success: Boolean, val apk: File?, val log: List<String>)

    fun build(projectDir: File, release: Boolean = false): Result {
        val log = ArrayList<String>()
        val tool = AndroidToolchainDiscoveryEngine(context).discover()
        if (!tool.ready) return Result(false, null, listOf("TOOLCHAIN • ${tool.details}"))
        val build = if (release) BuildEngine().buildRelease(projectDir) else BuildEngine().buildDebug(projectDir)
        log.add(build.output)
        val apk = build.apkFile
        if (!build.success || apk == null || !apk.isFile) return Result(false, apk, log + "VERIFY • build did not produce a real APK")
        val validation = ApkValidationEngine().validate(apk)
        log.add("VALIDATION • ${if (validation.valid) "PASS" else "FAIL"} ${validation.errors.joinToString("; ")}")
        return Result(validation.valid, apk.takeIf { validation.valid }, log)
    }

    fun sign(apk: File, keystore: File, alias: String, storePassword: String, keyPassword: String): Result {
        val r = ApkSigningEngine().sign(apk, keystore, alias, storePassword, keyPassword)
        return Result(r.success, r.apk, listOf(r.output))
    }

    fun inspect(apk: File): ApkRuntimeController.Inspection = ApkRuntimeController.inspect(context, apk)

    fun install(apk: File): Boolean = com.example.ultrapromax.engine.builder.ApkInstaller.install(context, apk)
}
