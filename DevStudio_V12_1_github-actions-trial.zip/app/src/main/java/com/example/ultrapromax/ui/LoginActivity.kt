package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R

/** Local demo login. No network authentication is used. */
class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.rgb(3, 7, 19)
        setContentView(R.layout.activity_login)
        val username = findViewById<EditText>(R.id.loginUsername)
        val status = findViewById<TextView>(R.id.loginStatus)
        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            if (username.text.toString().trim().isEmpty()) { username.error = "Enter your profile name"; username.requestFocus(); return@setOnClickListener }
            openWorkspace()
        }
        findViewById<Button>(R.id.btnContinueOffline).setOnClickListener {
            status.text = "OFFLINE MODE • LOCAL WORKSPACE READY"
            Toast.makeText(this, "Opening local workspace", Toast.LENGTH_SHORT).show()
            openWorkspace()
        }
    }
    private fun openWorkspace() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
