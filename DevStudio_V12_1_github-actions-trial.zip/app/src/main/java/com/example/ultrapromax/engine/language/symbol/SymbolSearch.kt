package com.example.ultrapromax.engine.language.symbol

class SymbolSearch(private val index: SymbolIndex) {
    fun search(query: String, limit: Int = 50): List<Symbol> {
        if (limit <= 0) return emptyList()
        return index.search(query).take(limit)
    }
}
