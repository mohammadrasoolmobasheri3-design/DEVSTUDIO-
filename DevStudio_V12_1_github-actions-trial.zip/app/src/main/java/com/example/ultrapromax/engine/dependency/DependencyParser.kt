package com.example.ultrapromax.engine.dependency

/** Lightweight parser for common Gradle dependency declarations. */
object DependencyParser {
    private val scopes = mapOf(
        "implementation" to DependencyScope.IMPLEMENTATION,
        "api" to DependencyScope.API,
        "compileOnly" to DependencyScope.COMPILE_ONLY,
        "runtimeOnly" to DependencyScope.RUNTIME_ONLY,
        "testImplementation" to DependencyScope.TEST_IMPLEMENTATION,
        "debugImplementation" to DependencyScope.DEBUG_IMPLEMENTATION,
        "releaseImplementation" to DependencyScope.RELEASE_IMPLEMENTATION
    )

    fun parseLine(line: String): DependencyCoordinate? {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) return null
        var scope: DependencyScope? = null
        var scopeName: String? = null
        for ((name, value) in scopes) {
            if (trimmed.startsWith(name) && (trimmed.length == name.length || trimmed[name.length].isWhitespace() || trimmed[name.length] == '(')) {
                scope = value
                scopeName = name
                break
            }
        }
        if (scope == null || scopeName == null) return null
        val after = trimmed.substring(scopeName.length).trimStart().removePrefix("(").trimStart()
        val notation = Regex("'([^']+)'|\\\"([^\\\"]+)\\\"").find(after)?.let {
            if (it.groupValues[1].isNotEmpty()) it.groupValues[1] else it.groupValues[2]
        } ?: return null
        return parseNotation(notation, scope)
    }

    fun parseNotation(notation: String, scope: DependencyScope = DependencyScope.IMPLEMENTATION): DependencyCoordinate? {
        val clean = notation.trim().trim('"', '\'', ' ', ')', ',')
        val parts = clean.split(':')
        if (parts.size < 3) return null
        val group = parts[0].trim()
        val artifact = parts[1].trim()
        val version = parts[2].trim()
        if (group.isEmpty() || artifact.isEmpty() || version.isEmpty()) return null
        return DependencyCoordinate(group, artifact, version, scope)
    }

    fun parseFile(text: String, sourceFile: String? = null): List<DependencyRecord> {
        val result = ArrayList<DependencyRecord>()
        for (line in text.lines()) {
            val coordinate = parseLine(line) ?: continue
            result.add(DependencyRecord(coordinate, DependencyStatus.DECLARED, sourceFile, coordinate.notation(), "Declared in Gradle source"))
        }
        return result
    }
}
