package com.example.ultrapromax.engine.plugin

import java.io.File

/** Executes only declarative, allow-listed extension actions; arbitrary code is never loaded. */
class PluginPackageRuntime {
    data class Result(val success: Boolean, val message: String)

    fun actions(packageDir: File): List<String> {
        val manifest = File(packageDir, "devstudio.extension")
        if (!manifest.isFile) return emptyList()
        return manifest.readLines().filter { it.startsWith("action=") }.map { it.substringAfter("=").trim() }
    }

    fun execute(packageDir: File, action: String): Result {
        val allowed = setOf("open_preview", "run_build", "run_diagnostics", "format_project", "refresh_symbols")
        if (action !in allowed) return Result(false, "Action is not allowed by the Plugin OS")
        if (!packageDir.isDirectory) return Result(false, "Plugin package is not installed")
        if (action !in actions(packageDir)) return Result(false, "Action is not declared by the extension")
        return Result(true, "Plugin action queued: $action")
    }
}
