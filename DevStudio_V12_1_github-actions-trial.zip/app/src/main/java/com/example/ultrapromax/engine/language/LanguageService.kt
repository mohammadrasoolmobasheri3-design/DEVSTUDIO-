package com.example.ultrapromax.engine.language

import com.example.ultrapromax.engine.language.symbol.Symbol
import com.example.ultrapromax.engine.language.symbol.SymbolIndex
import com.example.ultrapromax.engine.language.symbol.SymbolIndexer
import com.example.ultrapromax.engine.language.symbol.SymbolSearch
import java.io.File

/** Language/Symbol facade used by V26.4+ code intelligence while keeping UI and runtimes decoupled. */
class LanguageService {
    val index = SymbolIndex()
    private val indexer = SymbolIndexer(index)
    private val searcher = SymbolSearch(index)

    fun languageFor(fileName: String): LanguageDefinition? = LanguageRegistry.detect(fileName)?.definition()

    fun indexFile(file: File): Boolean = indexer.indexFile(file)

    fun indexProject(root: File): Int = indexer.indexProject(root)

    fun removeFile(file: File) = indexer.removeFile(file)

    fun symbolsForFile(file: File): List<Symbol> = index.symbolsForFile(file.absolutePath)

    fun searchSymbols(query: String, limit: Int = 50): List<Symbol> = searcher.search(query, limit)

    fun analyzeBuffer(fileName: String, source: String): List<Symbol> {
        val provider = LanguageRegistry.detect(fileName) ?: return emptyList()
        return provider.parse(source).symbols
    }
}
