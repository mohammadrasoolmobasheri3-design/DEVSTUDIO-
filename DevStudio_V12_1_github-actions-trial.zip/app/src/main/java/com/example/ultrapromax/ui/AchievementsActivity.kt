package com.example.ultrapromax.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.engine.gamify.Achievement
import com.example.ultrapromax.engine.gamify.GamificationEngine

class AchievementsActivity : AppCompatActivity() {

    private lateinit var gamify: GamificationEngine
    private lateinit var levelText: TextView
    private lateinit var xpText: TextView
    private lateinit var xpBar: ProgressBar
    private lateinit var dailyChallengeText: TextView
    private lateinit var streakText: TextView
    private lateinit var missionList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)
        gamify = GamificationEngine(this)
        levelText = findViewById(R.id.levelText)
        xpText = findViewById(R.id.xpText)
        xpBar = findViewById(R.id.xpBar)
        dailyChallengeText = findViewById(R.id.dailyChallengeText)
        streakText = findViewById(R.id.streakText)
        missionList = findViewById(R.id.missionList)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::gamify.isInitialized) render()
    }

    private fun render() {
        levelText.text = "LEVEL ${gamify.level}"
        xpBar.progress = gamify.xpIntoLevel
        xpText.text = "${gamify.xpIntoLevel} / ${gamify.xpForNextLevel} XP   •   TOTAL ${gamify.xp} XP"

        val (dailyCount, dailyGoalMet) = gamify.dailyProgress(3)
        dailyChallengeText.text = if (dailyGoalMet) {
            "Daily Challenge  ✓  $dailyCount/3 actions"
        } else {
            "Daily Challenge  •  $dailyCount/3 actions"
        }
        streakText.text = "🔥 ${gamify.dailyStreak()} day streak"

        missionList.removeAllViews()
        gamify.missions().forEach { mission -> missionList.addView(buildMissionRow(mission)) }

        val container = findViewById<LinearLayout>(R.id.achievementList)
        container.removeAllViews()
        Achievement.ALL.forEach { achievement ->
            container.addView(buildAchievementRow(achievement, gamify.isUnlocked(achievement)))
        }
    }

    private fun buildMissionRow(mission: GamificationEngine.Mission): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(if (mission.completed) Color.parseColor("#1D5A3A") else Color.parseColor("#18202C"))
                cornerRadius = dp(12).toFloat()
                setStroke(1, Color.parseColor(if (mission.completed) "#557CFFB4" else "#33405060"))
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
        }

        val title = TextView(this).apply {
            text = mission.title
            setTextColor(if (mission.completed) Color.parseColor("#7CFFB4") else Color.WHITE)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val progress = TextView(this).apply {
            text = "${mission.progress}/${mission.goal}  •  +${mission.rewardXp} XP"
            setTextColor(Color.parseColor("#8FA1B8"))
            textSize = 11f
            setPadding(0, dp(4), 0, dp(8))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = mission.goal
            setProgress(mission.progress)
            layoutParams = LinearLayout.LayoutParams(-1, dp(7))
        }
        row.addView(title)
        row.addView(progress)
        row.addView(bar)

        if (mission.completed) {
            val claim = Button(this).apply {
                text = if (gamify.isMissionClaimed(mission.id)) "REWARD CLAIMED" else "CLAIM +${mission.rewardXp} XP"
                isEnabled = !gamify.isMissionClaimed(mission.id)
                setOnClickListener {
                    val reward = gamify.claimMission(mission.id)
                    if (reward > 0) {
                        Toast.makeText(this@AchievementsActivity, "+$reward XP earned", Toast.LENGTH_SHORT).show()
                        render()
                    }
                }
            }
            row.addView(claim, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })
        }
        return row
    }

    private fun buildAchievementRow(achievement: Achievement, unlocked: Boolean): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(if (unlocked) Color.parseColor("#332ECC71") else Color.parseColor("#22FFFFFF"))
                cornerRadius = dp(12).toFloat()
                setStroke(1, Color.parseColor("#33FFFFFF"))
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
        }
        val icon = TextView(this).apply {
            text = if (unlocked) "🏆" else "🔒"
            textSize = 20f
            setPadding(0, 0, dp(12), 0)
        }
        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val title = TextView(this).apply {
            text = achievement.title
            setTextColor(if (unlocked) Color.parseColor("#7CFFB4") else Color.WHITE)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val desc = TextView(this).apply {
            text = achievement.description + "  •  +${achievement.xpReward} XP"
            setTextColor(Color.parseColor("#8FA1B8"))
            textSize = 11f
        }
        textColumn.addView(title)
        textColumn.addView(desc)
        row.addView(icon)
        row.addView(textColumn)
        return row
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
