package com.example.ultrapromax.engine.workspace

import android.content.Context
import com.example.ultrapromax.data.Project
import java.io.File

/** Small offline workspace session store. No network or external dependencies. */
object WorkspaceSession {
    private const val PREFS = "devstudio_workspace_session"
    private const val LAST_PROJECT_ID = "last_project_id"
    private const val LAST_PROJECT_PATH = "last_project_path"
    private const val LAST_PROJECT_NAME = "last_project_name"
    private const val LAST_TAB = "last_tab"
    private const val LAST_FILE = "last_file"
    private const val LAST_OPENED = "last_opened"

    fun open(context: Context, project: Project, tab: String = "files", file: File? = null) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(LAST_PROJECT_ID, project.id)
            .putString(LAST_PROJECT_PATH, project.folderPath)
            .putString(LAST_PROJECT_NAME, project.name)
            .putString(LAST_TAB, tab)
            .putString(LAST_FILE, relative(project, file))
            .putLong(LAST_OPENED, System.currentTimeMillis())
            .apply()
    }

    fun update(context: Context, project: Project, tab: String, file: File? = null) {
        open(context, project, tab, file)
    }

    fun lastProjectId(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(LAST_PROJECT_ID, -1L)

    fun lastProjectPath(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_PROJECT_PATH, "") ?: ""

    fun lastProjectName(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_PROJECT_NAME, "") ?: ""

    fun lastTab(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_TAB, "files") ?: "files"

    fun lastFile(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_FILE, "") ?: ""

    fun lastOpened(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(LAST_OPENED, 0L)

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun resolveLastProject(context: Context): Project? {
        val id = lastProjectId(context)
        if (id < 0L) return null
        val project = com.example.ultrapromax.data.ProjectStore.getById(context, id)
        if (project == null || !File(project.folderPath).exists()) return null
        return project
    }

    fun resolveLastFile(context: Context, project: Project): File? {
        val rel = lastFile(context)
        if (rel.isBlank()) return null
        val candidate = File(project.folderPath, rel)
        val root = File(project.folderPath).canonicalFile
        val target = try { candidate.canonicalFile } catch (_: Exception) { return null }
        if (!target.path.startsWith(root.path + File.separator) || !target.isFile) return null
        return target
    }

    private fun relative(project: Project, file: File?): String {
        if (file == null) return ""
        return try { file.canonicalFile.relativeTo(File(project.folderPath).canonicalFile).path } catch (_: Exception) { "" }
    }
}
