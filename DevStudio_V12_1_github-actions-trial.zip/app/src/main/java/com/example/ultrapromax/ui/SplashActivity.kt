package com.example.ultrapromax.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R

/**
 * DevStudio Gateway.
 * The gateway is the actual artwork supplied for the launch screen.
 * No login, account creation, or loading screen is inserted in front of it.
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show the supplied artwork edge-to-edge so the Android status/navigation bars
        // do not change its composition or add another UI layer over it.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )

        setContentView(R.layout.activity_splash)

        val root = findViewById<View>(android.R.id.content)
        val enter = findViewById<View>(R.id.gatewayEnter)

        // The artwork is a fixed 841x1870 portrait composition. Place the invisible
        // touch target over its ENTER DEVSTUDIO button while scaling responsively.
        root.post {
            val parent = enter.parent as? FrameLayout ?: return@post
            val height = parent.height
            val params = enter.layoutParams as FrameLayout.LayoutParams
            params.width = parent.width
            params.height = (height * 0.082f).toInt().coerceAtLeast(72)
            params.topMargin = (height * 0.755f).toInt()
            enter.layoutParams = params
        }

        enter.setOnClickListener {
            openWorkspace()
        }
    }

    private fun openWorkspace() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
