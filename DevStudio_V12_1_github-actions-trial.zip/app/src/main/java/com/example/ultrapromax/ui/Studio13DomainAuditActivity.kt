package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.engine.endgame.Studio13DomainCompletionEngine

class Studio13DomainAuditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = Studio13DomainCompletionEngine(this).audit()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(20))
            setBackgroundResource(com.example.ultrapromax.R.drawable.studio_background)
        }
        val title = TextView(this).apply {
            text = "DEVSTUDIO ULTRA PRO MAX+\n13-DOMAIN FINAL AUDIT"
            setTextColor(Color.WHITE); textSize = 21f; gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(70)))
        val summary = TextView(this).apply {
            text = report.summary()
            setTextColor(Color.parseColor("#46F7B1")); textSize = 15f; gravity = Gravity.CENTER
        }
        root.addView(summary, LinearLayout.LayoutParams(-1, dp(44)))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        report.domains.forEach { d ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundResource(com.example.ultrapromax.R.drawable.glass_card)
            }
            val state = when (d.status) { Studio13DomainCompletionEngine.Status.COMPLETE -> "✓ COMPLETE"; Studio13DomainCompletionEngine.Status.CONDITIONAL -> "◐ CONDITIONAL"; Studio13DomainCompletionEngine.Status.BLOCKED -> "✗ BLOCKED" }
            val h = TextView(this).apply { text = "%02d  %s  •  %s".format(d.id, d.title, state); setTextColor(Color.WHITE); textSize = 14f }
            val body = TextView(this).apply { text = d.detail; setTextColor(Color.parseColor("#A8B1CF")); textSize = 10f; setPadding(0, dp(4), 0, 0) }
            card.addView(h); card.addView(body)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(7)) })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val note = TextView(this).apply { text = "REAL EVIDENCE IS REQUIRED • NO SELF-CERTIFICATION"; setTextColor(Color.parseColor("#FFD166")); gravity = Gravity.CENTER; textSize = 11f }
        root.addView(note, LinearLayout.LayoutParams(-1, dp(40)))
        setContentView(root)
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
