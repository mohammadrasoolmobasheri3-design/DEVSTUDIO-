package com.example.ultrapromax.nextupdate.core

object UpdateFoundation {
    const val VERSION = "NEXT-UPDATE"
    const val ARCHITECTURE = "AI-MAX-AGENT"
    const val OFFLINE_FIRST = true
    const val APPROVAL_REQUIRED_FOR_FILE_MUTATION = true
}
