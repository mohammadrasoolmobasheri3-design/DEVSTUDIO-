package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.builder.AppBuilderEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.builder.ApkInstaller
import com.example.ultrapromax.engine.builder.ApkRuntimeController
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.buildrun.BuildPipelineCoordinator
import com.example.ultrapromax.engine.diagnostics.StudioOutputStore
import com.example.ultrapromax.engine.preview.PreviewEngine
import com.example.ultrapromax.engine.run.UniversalRunEngine
import com.example.ultrapromax.engine.server.MiniServerEngine
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Unified operation monitor.
 * RUN = test/preview monitor, BUILD = full scan + real build, PRLY = full scan + real APK build + strict validation + install/run handoff.
 * No operation is reported successful until its real operation returns success.
 */
class MonitorActivity : AppCompatActivity() {

    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var progress: TextView
    private lateinit var output: TextView
    private lateinit var webView: android.webkit.WebView
    private lateinit var actionButton: Button
    private lateinit var stopButton: Button

    private var server: MiniServerEngine? = null
    private var running = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private var project: Project? = null
    private var mode = MODE_RUN
    private var targetPath: String? = null
    private var prlyApk: File? = null
    private var prlyInstalledPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#02051A")
        window.navigationBarColor = Color.parseColor("#02051A")

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_RUN
        targetPath = intent.getStringExtra(EXTRA_TARGET)
        val projectId = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = ProjectStore.getById(this, projectId)

        if (project == null) {
            finish()
            return
        }

        buildUi()
        append("DEVSTUDIO OPERATION MONITOR")
        append("Project: ${project!!.name}")
        append("Mode: ${mode.toUpperCase()}")
        if (targetPath != null) append("Target: ${targetPath!!.substringAfterLast(File.separator)}")

        when (mode) {
            MODE_BUILD -> startBuildMonitor()
            MODE_PRLY -> startPrlyMonitor()
            else -> startRunMonitor()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#050814"))
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(44), dp(50)))

        title = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) }
        header.addView(title, LinearLayout.LayoutParams(0, dp(50), 1f))

        val modeLabel = TextView(this).apply {
            text = mode.toUpperCase()
            textSize = 10f
            setTextColor(Color.parseColor("#B47CFF"))
            gravity = Gravity.CENTER
        }
        header.addView(modeLabel, LinearLayout.LayoutParams(dp(72), dp(36)))
        root.addView(header)

        status = TextView(this).apply {
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.parseColor("#FFC857"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = panel(Color.parseColor("#10182A"), Color.parseColor("#35456B"), 14)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(48)))

        progress = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#8FA0D0"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(34)))

        webView = android.webkit.WebView(this)
        webView.visibility = View.GONE
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))

        val scroll = ScrollView(this)
        output = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#D6DEEB"))
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setTextIsSelectable(true)
        }
        scroll.addView(output, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actionButton = Button(this).apply { text = "START"; setOnClickListener { executeMode() } }
        stopButton = Button(this).apply { text = "STOP"; isEnabled = false; setOnClickListener { stopOperation() } }
        actions.addView(actionButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(0, dp(8), dp(5), 0) })
        actions.addView(stopButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(5), dp(8), 0, 0) })
        root.addView(actions)

        setContentView(root)
        title.text = when (mode) {
            MODE_BUILD -> "BUILD MONITOR"
            MODE_PRLY -> "PRLY MONITOR"
            else -> "RUN MONITOR"
        }
    }

    private fun executeMode() {
        if (running) return
        when (mode) {
            MODE_BUILD -> startBuildMonitor()
            MODE_PRLY -> startPrlyMonitor()
            else -> startRunMonitor()
        }
    }

    private fun startRunMonitor() {
        if (running) return
        running = true
        actionButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "● RUN • ANALYZING CURRENT PROJECT"
        status.setTextColor(Color.parseColor("#55E6A5"))
        output.text = ""

        val p = project ?: return
        val root = File(p.folderPath)
        Thread {
            val scan = scanProject(root)
            ui {
                appendScan(scan)
                if (!scan.ok) {
                    finishOperation(false, "● RUN BLOCKED • PROJECT PROBLEMS")
                    return@ui
                }
            }

            val target = targetPath?.let { File(it) } ?: findTarget(root)
            if (target == null || !target.isFile) {
                ui { append("\n❌ No runnable target found."); finishOperation(false, "● RUN FAILED") }
                return@Thread
            }

            val source = try { target.readText() } catch (e: Exception) {
                ui { append("\n❌ Cannot read target: ${e.message}"); finishOperation(false, "● RUN FAILED") }
                return@Thread
            }
            val runtime = UniversalRunEngine(File(filesDir, "runtimes"))
            val language = runtime.detectLanguage(target, source, root)
            ui { append("\nDetected language: $language") }

            if (language == "android") {
                ui {
                    append("\n✓ Android source/project scan complete.")
                    append("\nℹ RUN does not silently invoke BUILD.")
                    append("\nℹ Interactive Android preview requires a built APK/runtime; use BUILD for the real Android compilation path.")
                    finishOperation(true, "● RUN TEST READY • ANDROID PREVIEW REQUIRES BUILD")
                }
                return@Thread
            }

            val result = runtime.run(target, source, root, cacheDir)
            ui {
                append("\n${result.output.ifBlank { "Program finished with no output." }}")
                if (result.previewDir != null) {
                    startWebPreview(result.previewDir, root)
                } else {
                    finishOperation(result.success, if (result.success) "● RUN SUCCESS" else "● RUN FAILED")
                }
            }
        }.start()
    }

    private fun startBuildMonitor() {
        if (running) return
        running = true
        actionButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "● BUILD • PROJECT SCAN"
        status.setTextColor(Color.parseColor("#FFC857"))
        output.text = ""
        val p = project ?: return
        val root = File(p.folderPath)

        Thread {
            val scan = scanProject(root)
            ui {
                appendScan(scan)
                if (!scan.ok) {
                    finishOperation(false, "● BUILD BLOCKED • PROJECT PROBLEMS")
                    return@ui
                }
                status.text = "● BUILD • REAL COMPILATION"
            }
            val result = BuildEngine(this@MonitorActivity).buildDebug(root)
            ui {
                append("\n========== REAL BUILD OUTPUT ==========")
                append("\n${result.output}")
                if (result.success && result.apkFile != null) {
                    append("\n\n✓ APK: ${result.apkFile.absolutePath}")
                    append("\n✓ Size: ${result.apkFile.length()} bytes")
                    finishOperation(true, "● BUILD SUCCESS • APK CREATED")
                } else {
                    append("\n\n❌ No verified APK was produced.")
                    finishOperation(false, "● BUILD FAILED")
                }
            }
        }.start()
    }

    private fun startPrlyMonitor() {
        if (running) return
        running = true
        actionButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "● PRLY • FULL PROJECT SCAN"
        status.setTextColor(Color.parseColor("#FFD98A"))
        output.text = ""
        val p = project ?: return
        val root = File(p.folderPath)

        Thread {
            val scan = scanProject(root)
            ui {
                appendScan(scan)
                if (!scan.ok) {
                    finishOperation(false, "● PRLY BLOCKED • PROJECT PROBLEMS")
                    return@ui
                }
            }
            ui {
                status.text = "● PRLY • CODE ANALYSIS"
                status.setTextColor(Color.parseColor("#FFD98A"))
                append("\n========== FULL CODE ANALYSIS ==========")
                append("\n✓ All readable project source/config files are being inspected.")
            }

            val analysis = analyzeAllCode(root)
            ui {
                append(analysis.output)
                if (!analysis.ok) {
                    finishOperation(false, "● PRLY BLOCKED • CODE ANALYSIS FAILED")
                    return@ui
                }
                status.text = "● PRLY • REAL APK BUILD"
                status.setTextColor(Color.parseColor("#55E6A5"))
                append("\n========== REAL APK BUILD ==========")
                append("\n✓ Analysis passed. Starting real Gradle assembleDebug...")
            }

            val report = BuildPipelineCoordinator(StudioOutputStore(this@MonitorActivity)).execute(
                root,
                com.example.ultrapromax.engine.buildrun.BuildPipelineEngine.Variant.DEBUG,
                this@MonitorActivity
            )
            ui {
                append("\n${report.result.output}")
                if (!report.verified || report.result.apkFile == null) {
                    append("\n❌ No verified APK was produced.")
                    if (report.diagnostics.isNotEmpty()) append("\n❌ Problems: ${report.diagnostics.size}")
                    finishOperation(false, "● PRLY FAILED • APK BUILD")
                    return@ui
                }

                val apk = report.result.apkFile
                val inspection = ApkRuntimeController.inspect(this@MonitorActivity, apk)
                append("\n========== APK VERIFICATION ==========")
                append("\nPackage metadata valid: ${inspection.valid}")
                append("\nPackage: ${inspection.packageName ?: "-"}")
                append("\nVersion: ${inspection.versionName ?: "-"} (${inspection.versionCode})")
                append("\nSize: ${apk.length()} bytes")

                if (!inspection.valid || inspection.packageName == null) {
                    finishOperation(false, "● PRLY FAILED • APK METADATA")
                    return@ui
                }

                val strict = ApkValidationEngine(this@MonitorActivity).validate(apk)
                append("\nStrict APK structure/signature validation: ${if (strict.valid) "PASS" else "FAIL"}")
                if (strict.errors.isNotEmpty()) strict.errors.forEach { append("\n❌ $it") }
                if (!strict.valid) {
                    finishOperation(false, "● PRLY FAILED • APK VALIDATION")
                    return@ui
                }

                prlyApk = archivePrlyApk(apk)
                prlyInstalledPackage = inspection.packageName
                append("\n✓ REAL APK READY: ${prlyApk!!.absolutePath}")
                append("\n✓ PRLY finished with a verified installable APK.")
                actionButton.text = "INSTALL APK"
                actionButton.isEnabled = true
                actionButton.setOnClickListener { installPrlyApk() }
                stopButton.text = "RUN APP"
                stopButton.isEnabled = true
                stopButton.setOnClickListener { runPrlyApp() }
                running = false
                status.text = "● PRLY SUCCESS • APK READY TO INSTALL"
                status.setTextColor(Color.parseColor("#55E6A5"))
            }
        }.start()
    }

    private fun scanProject(root: File): ScanResult {
        if (!root.exists() || !root.isDirectory) return ScanResult(false, emptyList(), 0, 0, 0, 0)
        val messages = mutableListOf<String>()
        var files = 0
        var folders = 0
        var lines = 0
        var sourceFiles = 0
        var blocking = false

        root.walkTopDown()
            .onEnter { !shouldSkip(it) }
            .forEach { f ->
                if (shouldSkip(f)) return@forEach
                if (f.isDirectory) { folders++; return@forEach }
                files++
                if (!f.canRead()) {
                    messages += "❌ UNREADABLE: ${f.relativeTo(root).path}"
                    blocking = true
                    return@forEach
                }
                val n = f.name
                if (n.endsWith(".kt") || n.endsWith(".java") || n.endsWith(".xml") || n.endsWith(".gradle") || n.endsWith(".kts") || n == "AndroidManifest.xml") {
                    sourceFiles++
                    try {
                        val text = f.readText()
                        lines += if (text.isEmpty()) 0 else text.count { it == '\n' } + 1
                        if ((n.endsWith(".kt") || n.endsWith(".java")) && braceBalance(text) != 0) {
                            messages += "❌ POSSIBLE BRACE ERROR: ${f.relativeTo(root).path}"
                            blocking = true
                        }
                        if (n.endsWith(".xml")) {
                            try {
                                val db = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                                db.parse(f)
                            } catch (e: Exception) {
                                messages += "❌ XML ERROR: ${f.relativeTo(root).path} • ${e.message ?: "invalid XML"}"
                                blocking = true
                            }
                        }
                    } catch (e: Exception) {
                        messages += "❌ READ ERROR: ${f.relativeTo(root).path} • ${e.message}"
                        blocking = true
                    }
                }
            }

        val hasManifest = File(root, "app/src/main/AndroidManifest.xml").isFile || File(root, "AndroidManifest.xml").isFile
        val hasGradle = File(root, "settings.gradle").isFile || File(root, "settings.gradle.kts").isFile || File(root, "build.gradle").isFile || File(root, "build.gradle.kts").isFile
        if (!hasManifest) messages += "⚠ AndroidManifest.xml not found at common project locations."
        if (!hasGradle) messages += "⚠ Gradle configuration not found at common project locations."
        if (files == 0) { messages += "❌ Project contains no files."; blocking = true }

        messages.add(0, "✓ Project structure scanned")
        messages += "✓ Files: $files • Folders: $folders • Source/config files: $sourceFiles • Lines: $lines"
        if (hasManifest) messages += "✓ Manifest detected"
        if (hasGradle) messages += "✓ Build configuration detected"
        return ScanResult(!blocking, messages, files, folders, lines, sourceFiles)
    }

    private fun appendScan(scan: ScanResult) {
        append("\n========== PROJECT SCAN ==========")
        scan.messages.forEach { append(it) }
        progress.text = "Files ${scan.files} • Folders ${scan.folders} • Lines ${scan.lines}"
    }

    private fun findTarget(root: File): File? {
        val generated = File(root, "devstudio/generated/index.html")
        val index = File(root, "index.html")
        if (generated.isFile) return generated
        if (index.isFile) return index
        return root.walkTopDown().firstOrNull { it.isFile && !shouldSkip(it) && (it.extension.toLowerCase(java.util.Locale.US) in setOf("kt", "java", "html", "js", "py", "dart", "cpp", "c")) }
    }

    private fun startWebPreview(dir: File, watchRoot: File) {
        stopServerOnly()
        val srv = MiniServerEngine(dir, File(filesDir, "libs"))
        srv.start()
        server = srv
        PreviewEngine.configure(webView)
        webView.visibility = View.VISIBLE
        PreviewEngine.loadUrl(webView, srv.baseUrl())
        PreviewEngine.startAutoReload(webView, watchRoot)
        output.visibility = View.GONE
        status.text = "● RUN • PREVIEW ACTIVE"
        actionButton.isEnabled = false
        stopButton.isEnabled = true
    }

    private fun analyzeAllCode(root: File): CodeAnalysisResult {
        var inspected = 0
        var lines = 0
        val problems = ArrayList<String>()
        val codeExtensions = setOf(
            "kt", "kts", "java", "xml", "gradle", "properties", "pro", "json",
            "toml", "yaml", "yml", "js", "ts", "html", "css", "sh", "bat", "md"
        )
        root.walkTopDown().onEnter { !shouldSkip(it) }.forEach { file ->
            if (!file.isFile || shouldSkip(file)) return@forEach
            val name = file.name
            val isCode = name == "AndroidManifest.xml" || codeExtensions.contains(file.extension.toLowerCase())
            if (!isCode || !file.canRead()) {
                if (isCode && !file.canRead()) problems += "❌ UNREADABLE: ${file.relativeTo(root).path}"
                return@forEach
            }
            inspected++
            try {
                val text = file.readText()
                lines += if (text.isEmpty()) 0 else text.count { it == '\n' } + 1
                if (text.indexOf('\u0000') >= 0) problems += "❌ INVALID TEXT/BINARY CONTENT: ${file.relativeTo(root).path}"
                if (name.endsWith(".kt") || name.endsWith(".java")) {
                    val balance = braceBalance(text)
                    if (balance != 0) problems += "❌ POSSIBLE BRACE ERROR: ${file.relativeTo(root).path} (balance=$balance)"
                }
                if (name.endsWith(".xml")) {
                    try {
                        DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file)
                    } catch (e: Exception) {
                        problems += "❌ XML ERROR: ${file.relativeTo(root).path} • ${e.message ?: "invalid XML"}"
                    }
                }
            } catch (e: Exception) {
                problems += "❌ READ ERROR: ${file.relativeTo(root).path} • ${e.message ?: e.javaClass.simpleName}"
            }
        }
        val out = StringBuilder()
        out.append("\n✓ Inspected code/config files: $inspected")
        out.append("\n✓ Inspected lines: $lines")
        if (problems.isNotEmpty()) {
            out.append("\n❌ Blocking analysis problems: ${problems.size}")
            problems.forEach { out.append("\n$it") }
            return CodeAnalysisResult(false, out.toString())
        }
        out.append("\n✓ No static blocking problems found.")
        return CodeAnalysisResult(true, out.toString())
    }

    private fun archivePrlyApk(apk: File): File {
        val dir = File(project!!.folderPath, "devstudio/prly-output")
        if (!dir.exists()) dir.mkdirs()
        val target = File(dir, "${project!!.name.replace(" ", "_")}_PRLY.apk")
        apk.copyTo(target, overwrite = true)
        return target
    }

    private fun installPrlyApk() {
        val apk = prlyApk
        if (apk == null || !apk.isFile) {
            append("\n❌ PRLY APK is missing.")
            return
        }
        try {
            if (ApkInstaller.install(this, apk)) {
                status.text = "● PRLY • ANDROID INSTALLER OPENED"
                status.setTextColor(Color.parseColor("#55E6A5"))
                append("\n✓ Android package installer opened for ${apk.name}")
            }
        } catch (e: Exception) {
            append("\n❌ INSTALL FAILED: ${e.message ?: e.javaClass.simpleName}")
            status.text = "● PRLY • INSTALL FAILED"
            status.setTextColor(Color.parseColor("#FF5B6E"))
        }
    }

    private fun runPrlyApp() {
        val pkg = prlyInstalledPackage ?: prlyApk?.let { ApkRuntimeController.inspect(this, it).packageName }
        if (pkg == null) {
            append("\n❌ Install the PRLY APK first.")
            return
        }
        val inspection = prlyApk?.let { ApkRuntimeController.inspect(this, it) }
        if (inspection != null && !inspection.installed) {
            append("\nℹ APK is not installed yet. Tap INSTALL APK first.")
            return
        }
        try {
            if (ApkRuntimeController.launchInstalled(this, pkg)) {
                append("\n✓ Launched installed app: $pkg")
                status.text = "● PRLY • APP RUNNING"
                status.setTextColor(Color.parseColor("#55E6A5"))
            }
        } catch (e: Exception) {
            append("\n❌ RUN FAILED: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun stopOperation() {
        running = false
        stopServerOnly()
        PreviewEngine.stopAutoReload()
        status.text = "● OPERATION STOPPED"
        status.setTextColor(Color.parseColor("#FF5B6E"))
        actionButton.isEnabled = true
        stopButton.isEnabled = false
    }

    private fun finishOperation(success: Boolean, text: String) {
        running = false
        status.text = text
        status.setTextColor(if (success) Color.parseColor("#55E6A5") else Color.parseColor("#FF5B6E"))
        actionButton.isEnabled = true
        stopButton.isEnabled = false
    }

    private fun append(text: String) {
        if (!::output.isInitialized) return
        output.append(if (output.text.isEmpty()) text else "\n$text")
    }

    private fun ui(action: () -> Unit) {
        if (!isFinishing && !isDestroyed) mainHandler.post(action)
    }

    private fun stopServerOnly() {
        server?.stop()
        server = null
    }

    override fun onDestroy() {
        PreviewEngine.stopAutoReload()
        stopServerOnly()
        super.onDestroy()
    }

    private fun shouldSkip(f: File): Boolean {
        val n = f.name
        return n == ".gradle" || n == "build" || n == ".cxx" || n == "node_modules" || n == "captures" || n == ".git"
    }

    private fun braceBalance(text: String): Int {
        var balance = 0
        var inString = false
        var escaped = false
        var lineComment = false
        var blockComment = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            val next = if (i + 1 < text.length) text[i + 1] else '\u0000'
            if (lineComment) { if (c == '\n') lineComment = false; i++; continue }
            if (blockComment) { if (c == '*' && next == '/') { blockComment = false; i += 2 } else i++; continue }
            if (!inString && c == '/' && next == '/') { lineComment = true; i += 2; continue }
            if (!inString && c == '/' && next == '*') { blockComment = true; i += 2; continue }
            if (c == '"' && !escaped) inString = !inString
            if (!inString) {
                if (c == '{') balance++
                if (c == '}') balance--
            }
            escaped = c == '\\' && !escaped
            if (c != '\\') escaped = false
            i++
        }
        return balance
    }

    private fun panel(fill: Int, stroke: Int, radius: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(fill)
            setStroke(dp(1), stroke)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private data class CodeAnalysisResult(
        val ok: Boolean,
        val output: String
    )

    private data class ScanResult(
        val ok: Boolean,
        val messages: List<String>,
        val files: Int,
        val folders: Int,
        val lines: Int,
        val sourceFiles: Int
    )

    companion object {
        const val EXTRA_PROJECT_ID = "monitor_project_id"
        const val EXTRA_MODE = "monitor_mode"
        const val EXTRA_TARGET = "monitor_target"
        const val EXTRA_LANGUAGE = "monitor_language"
        const val EXTRA_SUCCESS = "monitor_success"
        const val EXTRA_OUTPUT = "monitor_output"
        const val EXTRA_PREVIEW_DIR = "monitor_preview_dir"
        const val MODE_RUN = "run"
        const val MODE_BUILD = "build"
        const val MODE_PRLY = "prly"
    }
}
