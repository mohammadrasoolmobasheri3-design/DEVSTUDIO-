package com.example.ultrapromax.engine.websocket

import android.util.Base64
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * WEBSOCKET ENGINE
 * A minimal but real RFC 6455 WebSocket server implementation: does the
 * handshake (Sec-WebSocket-Accept) and reads/writes basic TEXT frames
 * (no fragmentation, no ping/pong, no compression extensions). This is
 * enough for a project's JS to do:
 *   const ws = new WebSocket('ws://127.0.0.1:PORT/ws');
 *   ws.onmessage = e => console.log(e.data);
 *   ws.send('hello');
 * entirely offline, on top of the same MiniServerEngine socket.
 *
 * Text fragmentation and ping/pong control frames are supported. Binary frames and
 * per-connection routing remain intentionally outside the current local text API.
 */
object WebSocketEngine {

    private const val MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    fun isUpgradeRequest(headers: Map<String, String>): Boolean =
        headers["Upgrade"]?.equals("websocket", ignoreCase = true) == true

    fun acceptKeyFor(clientKey: String): String {
        val sha1 = MessageDigest.getInstance("SHA-1").digest((clientKey + MAGIC).toByteArray())
        return Base64.encodeToString(sha1, Base64.NO_WRAP)
    }

    fun writeHandshakeResponse(output: OutputStream, clientKey: String) {
        val accept = acceptKeyFor(clientKey)
        val response = "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: $accept\r\n\r\n"
        output.write(response.toByteArray())
        output.flush()
    }

    const val OPCODE_CONTINUATION = 0x0
    const val OPCODE_TEXT = 0x1
    const val OPCODE_CLOSE = 0x8
    const val OPCODE_PING = 0x9
    const val OPCODE_PONG = 0xA

    fun controlFrame(opcode: Int, payload: ByteArray = ByteArray(0)): ByteArray {
        require(opcode in 0x8..0xF) { "Invalid WebSocket control opcode" }
        require(payload.size <= 125) { "Control frame payload must be <= 125 bytes" }
        return byteArrayOf((0x80 or opcode).toByte(), payload.size.toByte()) + payload
    }

    fun writePing(output: OutputStream, payload: String = "") {
        output.write(controlFrame(OPCODE_PING, payload.toByteArray(Charsets.UTF_8)))
        output.flush()
    }

    fun writePong(output: OutputStream, payload: String = "") {
        output.write(controlFrame(OPCODE_PONG, payload.toByteArray(Charsets.UTF_8)))
        output.flush()
    }

    fun writeClose(output: OutputStream, code: Int = 1000) {
        val payload = byteArrayOf((code shr 8).toByte(), code.toByte())
        output.write(controlFrame(OPCODE_CLOSE, payload))
        output.flush()
    }

    data class Frame(val opcode: Int, val fin: Boolean, val payload: ByteArray)

    fun readFrame(input: InputStream): Frame? {
        val first = input.read()
        if (first < 0) return null
        val second = input.read()
        if (second < 0) return null

        val fin = (first and 0x80) != 0
        val opcode = first and 0x0F
        val masked = (second and 0x80) != 0
        var payloadLen = (second and 0x7F).toLong()

        if (payloadLen == 126L) {
            val b1 = input.read()
            val b2 = input.read()
            if (b1 < 0 || b2 < 0) return null
            payloadLen = ((b1 and 0xFF) shl 8 or (b2 and 0xFF)).toLong()
        } else if (payloadLen == 127L) {
            var longLen = 0L
            repeat(8) {
                val b = input.read()
                if (b < 0) return null
                longLen = (longLen shl 8) or (b.toLong() and 0xFF)
            }
            payloadLen = longLen
        }

        if (payloadLen < 0L || payloadLen > 8L * 1024L * 1024L) return null
        if (opcode >= 0x8 && (!fin || payloadLen > 125L)) return null

        val maskKey = ByteArray(4)
        if (masked && !readFully(input, maskKey)) return null

        val payload = ByteArray(payloadLen.toInt())
        if (!readFully(input, payload)) return null

        if (masked) {
            for (i in payload.indices) {
                payload[i] = (payload[i].toInt() xor maskKey[i % 4].toInt()).toByte()
            }
        }
        return Frame(opcode, fin, payload)
    }

    fun readMessage(input: InputStream): Frame? {
        var first = readFrame(input) ?: return null
        if (first.opcode == OPCODE_PING || first.opcode == OPCODE_PONG || first.opcode == OPCODE_CLOSE) {
            return first
        }
        if (first.opcode != OPCODE_TEXT || first.fin) return first

        val chunks = ArrayList<ByteArray>()
        chunks.add(first.payload)
        var total = first.payload.size
        while (true) {
            val next = readFrame(input) ?: return null
            if (next.opcode == OPCODE_PING || next.opcode == OPCODE_PONG) {
                continue
            }
            if (next.opcode != OPCODE_CONTINUATION) return null
            total += next.payload.size
            if (total > 8 * 1024 * 1024) return null
            chunks.add(next.payload)
            if (next.fin) break
        }
        val merged = ByteArray(total)
        var offset = 0
        chunks.forEach { chunk ->
            System.arraycopy(chunk, 0, merged, offset, chunk.size)
            offset += chunk.size
        }
        return Frame(OPCODE_TEXT, true, merged)
    }

    fun readTextFrame(input: InputStream): String? {
        val frame = readMessage(input) ?: return null
        if (frame.opcode != OPCODE_TEXT) return null
        return String(frame.payload, Charsets.UTF_8)
    }

    private fun readFully(input: InputStream, buffer: ByteArray): Boolean {
        var offset = 0
        while (offset < buffer.size) {
            val count = input.read(buffer, offset, buffer.size - offset)
            if (count < 0) return false
            if (count == 0) continue
            offset += count
        }
        return true
    }

    fun writeTextFrame(output: OutputStream, message: String) {
        val payload = message.toByteArray(Charsets.UTF_8)
        val header = mutableListOf<Int>()
        header.add(0x81)

        when {
            payload.size < 126 -> header.add(payload.size)
            payload.size < 65536 -> {
                header.add(126)
                header.add((payload.size shr 8) and 0xFF)
                header.add(payload.size and 0xFF)
            }
            else -> {
                header.add(126)
                header.add(0xFF); header.add(0xFF)
            }
        }

        output.write(header.map { it.toByte() }.toByteArray())
        output.write(payload)
        output.flush()
    }
}
