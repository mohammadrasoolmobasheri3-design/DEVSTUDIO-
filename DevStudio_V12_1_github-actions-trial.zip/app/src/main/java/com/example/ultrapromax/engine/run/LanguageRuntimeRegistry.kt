package com.example.ultrapromax.engine.run

import java.io.File

/**
 * Central registry for DEVSTUDIO's built-in language execution profiles.
 *
 * Runtime binaries are looked up inside the app-private runtime directory first,
 * then on the device PATH. This keeps the app architecture stable and allows
 * native runtime packs to be added later without changing the editor.
 */
class LanguageRuntimeRegistry(private val runtimeRoot: File) {

    data class Profile(
        val id: String,
        val displayName: String,
        val extensions: List<String>,
        val executableCandidates: List<String>,
        val kind: Kind
    )

    enum class Kind { WEB, INTERPRETER, COMPILER, DATABASE, ANDROID }

    private val profiles = listOf(
        Profile("html", "HTML", listOf("html", "htm"), emptyList(), Kind.WEB),
        Profile("css", "CSS", listOf("css"), emptyList(), Kind.WEB),
        Profile("javascript", "JavaScript", listOf("js", "mjs"), listOf("node", "nodejs"), Kind.INTERPRETER),
        Profile("typescript", "TypeScript", listOf("ts", "tsx"), listOf("tsx", "ts-node"), Kind.INTERPRETER),
        Profile("python", "Python", listOf("py"), listOf("python3", "python"), Kind.INTERPRETER),
        Profile("java", "Java", listOf("java"), listOf("javac", "java"), Kind.COMPILER),
        Profile("kotlin", "Kotlin", listOf("kt"), listOf("kotlinc", "java"), Kind.COMPILER),
        Profile("kotlin-script", "Kotlin Script", listOf("kts"), listOf("kotlinc", "java"), Kind.INTERPRETER),
        Profile("c", "C", listOf("c"), listOf("gcc"), Kind.COMPILER),
        Profile("cpp", "C++", listOf("cc", "cpp", "cxx"), listOf("clang++", "g++"), Kind.COMPILER),
        Profile("csharp", "C#", listOf("cs"), listOf("dotnet", "mono", "csc"), Kind.COMPILER),
        Profile("go", "Go", listOf("go"), listOf("go"), Kind.COMPILER),
        Profile("rust", "Rust", listOf("rs"), listOf("rustc"), Kind.COMPILER),
        Profile("swift", "Swift", listOf("swift"), listOf("swift"), Kind.COMPILER),
        Profile("dart", "Dart", listOf("dart"), listOf("dart"), Kind.INTERPRETER),
        Profile("flutter", "Flutter", listOf(), listOf("flutter"), Kind.COMPILER),
        Profile("php", "PHP", listOf("php"), listOf("php"), Kind.INTERPRETER),
        Profile("ruby", "Ruby", listOf("rb"), listOf("ruby"), Kind.INTERPRETER),
        Profile("perl", "Perl", listOf("pl"), listOf("perl"), Kind.INTERPRETER),
        Profile("lua", "Lua", listOf("lua"), listOf("lua"), Kind.INTERPRETER),
        Profile("shell", "Shell", listOf("sh"), listOf("sh", "bash"), Kind.INTERPRETER),
        Profile("bash", "Bash", listOf("bash"), listOf("bash", "sh"), Kind.INTERPRETER),
        Profile("sql", "SQLite SQL", listOf("sql"), listOf("sqlite3"), Kind.DATABASE),
        Profile("android", "Android / Gradle", emptyList(), listOf("gradlew"), Kind.ANDROID)
    )

    data class Readiness(
        val profile: Profile,
        val ready: Boolean,
        val missing: List<String>
    )

    fun readiness(profile: Profile): Readiness {
        val dir = runtimeDir(profile)
        val missing = ArrayList<String>()
        when (profile.id) {
            "html", "css" -> { /* WebView is built into DEVSTUDIO. */ }
            "javascript" -> {
                if (!hasExecutable(dir, "node") && !hasExecutable(dir, "nodejs")) missing.add("bin/node or bin/nodejs")
            }
            "python" -> {
                if (!hasExecutable(dir, "python3") && !hasExecutable(dir, "python")) missing.add("bin/python3 or bin/python")
            }
            "java" -> {
                if (!hasExecutable(dir, "javac")) missing.add("bin/javac")
                if (!hasExecutable(dir, "java")) missing.add("bin/java")
            }
            "kotlin" -> {
                if (!hasExecutable(dir, "kotlinc")) missing.add("bin/kotlinc")
                if (!hasExecutable(dir, "java") && !hasExecutable(runtimeDir(find("java")!!), "java")) {
                    missing.add("bin/java (Kotlin pack or Java pack)")
                }
            }
            "c" -> if (!hasExecutable(dir, "clang")) missing.add("bin/clang")
            "cpp" -> if (!hasExecutable(dir, "clang++")) missing.add("bin/clang++")
            "dart" -> {
                if (!hasExecutable(dir, "dart") && !hasExecutable(runtimeDir(find("flutter")!!), "dart")) {
                    missing.add("bin/dart (Dart pack or Flutter pack)")
                }
            }
            "flutter" -> if (!hasExecutable(dir, "flutter")) missing.add("bin/flutter")
            else -> {
                if (profile.executableCandidates.isNotEmpty() && !profile.executableCandidates.any { hasExecutable(dir, it) }) {
                    missing.add("bin/${profile.executableCandidates.joinToString(" or bin/")}")
                }
            }
        }
        return Readiness(profile, missing.isEmpty(), missing)
    }

    fun readinessReport(): String {
        return profiles.joinToString("\n") { p ->
            val r = readiness(p)
            if (r.ready) "[READY] ${p.displayName}"
            else if (r.missing.isEmpty()) "[BUILT-IN] ${p.displayName}"
            else "[MISSING] ${p.displayName}: ${r.missing.joinToString(", ")}"
        }
    }

    private fun hasExecutable(dir: File, name: String): Boolean {
        val f = File(dir, "bin/$name")
        return f.isFile && (f.canExecute() || f.setExecutable(true, false))
    }

    fun all(): List<Profile> = profiles

    fun find(id: String): Profile? = profiles.firstOrNull { it.id == id }

    fun runtimeDir(profile: Profile): File = File(runtimeRoot, profile.id)

    fun findExecutable(profile: Profile, command: String): File? {
        val local = File(runtimeDir(profile), "bin/$command")
        if (local.isFile && (local.canExecute() || local.setExecutable(true, false))) return local

        // Kotlin may use the Java runtime supplied by the Java pack.
        if (profile.id == "kotlin" || profile.id == "kotlin-script") {
            val javaProfile = find("java")
            if (javaProfile != null) {
                val java = File(runtimeDir(javaProfile), "bin/$command")
                if (java.isFile && (java.canExecute() || java.setExecutable(true, false))) return java
            }
        }

        // Flutter SDKs normally contain Dart as part of the same offline pack.
        if (profile.id == "dart") {
            val flutterProfile = find("flutter")
            if (flutterProfile != null) {
                val dart = File(runtimeDir(flutterProfile), "bin/$command")
                if (dart.isFile && (dart.canExecute() || dart.setExecutable(true, false))) return dart
            }
        }
        return null
    }

    fun summary(): String {
        return profiles.joinToString("\n") { profile ->
            val localDir = runtimeDir(profile)
            val readiness = readiness(profile)
            val status = if (readiness.ready) "READY" else "MISSING"
            "• ${profile.displayName}: $status" + if (readiness.missing.isNotEmpty()) " (${readiness.missing.joinToString(", ")})" else ""
        }
    }
}
