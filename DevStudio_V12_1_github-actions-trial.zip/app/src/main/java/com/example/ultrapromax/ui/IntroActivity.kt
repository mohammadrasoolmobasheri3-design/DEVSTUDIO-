package com.example.ultrapromax.ui

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R

/** DevStudio gateway: system status + entry into the local development workspace. */
class IntroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(2, 3, 14)
        window.navigationBarColor = Color.rgb(2, 3, 14)
        window.decorView.systemUiVisibility = 0
        setContentView(R.layout.activity_intro)

        val logo = findViewById<View>(R.id.introLogo)
        val statusPanel = findViewById<View>(R.id.systemStatusPanel)
        val enter = findViewById<Button>(R.id.btnIntroGetStarted)

        logo.alpha = 0f
        logo.scaleX = 0.88f
        logo.scaleY = 0.88f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650L)
            .setInterpolator(DecelerateInterpolator()).start()

        statusPanel.alpha = 0f
        statusPanel.translationY = 18f
        statusPanel.animate().alpha(1f).translationY(0f).setStartDelay(220L).setDuration(550L)
            .setInterpolator(DecelerateInterpolator()).start()

        val pulse = ObjectAnimator.ofFloat(enter, "alpha", 1f, 0.88f, 1f).apply {
            duration = 1800L
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.RESTART
        }
        pulse.start()

        enter.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }
}
