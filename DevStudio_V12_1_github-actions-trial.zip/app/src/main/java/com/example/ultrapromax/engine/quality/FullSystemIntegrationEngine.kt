package com.example.ultrapromax.engine.quality

import android.content.Context
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.engine.studio.StudioIntegrationEngine
import java.io.File

/** V30.1.0 cross-module integration coordinator. Offline, deterministic and non-destructive. */
class FullSystemIntegrationEngine(private val context: Context) {
    data class Item(val name: String, val ready: Boolean, val detail: String)
    data class Report(val items: List<Item>, val projectName: String, val fileCount: Int, val durationMs: Long) {
        fun passed(): Int = items.count { it.ready }
        fun failed(): Int = items.count { !it.ready }
    }

    fun run(project: Project?): Report {
        val started = System.currentTimeMillis()
        val items = ArrayList<Item>()
        val root = project?.let { File(it.folderPath) }

        val integration = try {
            StudioIntegrationEngine(context).inspect(project)
        } catch (e: Throwable) {
            null
        }

        if (integration != null) {
            integration.modules.forEach {
                items.add(Item(it.name, it.ready, it.detail))
            }
        } else {
            items.add(Item("Studio Integration", false, "Integration snapshot unavailable"))
        }

        items.add(classCheck("Workspace Session", "com.example.ultrapromax.engine.workspace.WorkspaceSession"))
        items.add(classCheck("Build Pipeline", "com.example.ultrapromax.engine.buildrun.BuildPipelineCoordinator"))
        items.add(classCheck("Editor Engine", "com.example.ultrapromax.engine.editor.EditorEngine"))
        items.add(classCheck("UI Builder", "com.example.ultrapromax.engine.uibuilder.UiBuilderEngine"))
        items.add(classCheck("Preview Engine", "com.example.ultrapromax.engine.preview.PreviewEngine"))
        items.add(classCheck("Security Policy", "com.example.ultrapromax.engine.security.SecurityPolicyEngine"))
        items.add(classCheck("Recovery Engine", "com.example.ultrapromax.engine.security.RecoveryEngine"))
        items.add(classCheck("APK Runtime", "com.example.ultrapromax.engine.builder.ApkRuntimeController"))
        items.add(classCheck("Offline Services", "com.example.ultrapromax.engine.offline.LocalServicesEngine"))
        items.add(classCheck("Plugin Platform", "com.example.ultrapromax.engine.plugin.ExtensionPlatformEngine"))
        items.add(classCheck("Template Engine", "com.example.ultrapromax.engine.project.AdvancedTemplateEngine"))
        items.add(classCheck("Gamification", "com.example.ultrapromax.engine.gamify.GamificationEngine"))
        items.add(classCheck("AI Assistant", "com.example.ultrapromax.engine.ai.AiStudioAssistantEngine"))
        items.add(classCheck("Project Intelligence", "com.example.ultrapromax.engine.intelligence.ProjectIntelligenceEngine"))

        if (root != null && root.isDirectory) {
            val count = root.walkTopDown().count { it.isFile }
            items.add(Item("Project Boundary", true, "Project root is accessible"))
            return Report(items, project.name, count, System.currentTimeMillis() - started)
        }

        items.add(Item("Project Boundary", false, "No accessible project is mounted"))
        return Report(items, project?.name ?: "No project", 0, System.currentTimeMillis() - started)
    }

    private fun classCheck(name: String, className: String): Item {
        return try {
            Class.forName(className)
            Item(name, true, "Available")
        } catch (e: Throwable) {
            Item(name, false, "Unavailable")
        }
    }
}
