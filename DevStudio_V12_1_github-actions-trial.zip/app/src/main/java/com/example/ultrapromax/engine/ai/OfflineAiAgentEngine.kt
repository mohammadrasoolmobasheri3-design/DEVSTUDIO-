package com.example.ultrapromax.engine.ai

import com.example.ultrapromax.engine.editor.EditorEngine
import java.io.File

/**
 * Lightweight, fully offline project assistant for DEVSTUDIO v22.
 * No network, no external service and no extra runtime dependency.
 * The agent exposes small, safe project tools that can later sit behind
 * a stronger on-device model without changing the Studio UI.
 */
class OfflineAiAgentEngine(private val projectRoot: File?) {

    data class Response(
        val text: String,
        val action: Action = Action.NONE
    )

    enum class Action { NONE, FIX_CURRENT_FILE }

    fun ask(question: String, currentFile: File?, currentText: String): Response {
        val q = question.trim()
        if (q.isEmpty()) return Response("سؤالت خالی است. درباره کد، پروژه یا خطا بنویس.")

        val lower = q.toLowerCase()
        if (containsAny(lower, "تحلیل پروژه", "analyze project", "project analysis", "پروژه رو تحلیل")) {
            return Response(projectSummary())
        }

        if (containsAny(lower, "لیست فایل", "فایل ها", "فایل‌های پروژه", "list files", "project files")) {
            return Response(listFiles())
        }

        if (containsAny(lower, "خطا", "مشکل کد", "بررسی کد", "check code", "lint", "error")) {
            return Response(analyzeCode(currentFile, currentText))
        }

        if (containsAny(lower, "اصلاح کن", "درستش کن", "fix it", "auto fix", "fix code")) {
            val engine = RuleBasedAiEngine()
            val language = currentFile?.let { EditorEngine.languageForFileName(it.name) } ?: "text"
            val issues = engine.lint(currentText, language)
            if (issues.isEmpty()) return Response("در فایل فعلی مشکل مشخصی پیدا نشد.")
            return Response(
                "چند مشکل قابل‌اصلاح خودکار پیدا شد. اگر تأیید کنی، Auto Fix روی فایل فعلی اجرا می‌شود.",
                Action.FIX_CURRENT_FILE
            )
        }

        val searchPrefix = listOf("جستجو ", "search ", "پیدا کن ", "find ")
            .firstOrNull { lower.startsWith(it) }
        if (searchPrefix != null && projectRoot != null) {
            val term = q.substring(searchPrefix.length).trim()
            return Response(search(term))
        }

        if (containsAny(lower, "kotlin", "کاتلین")) {
            return Response("Kotlin برای ساخت اپ اندرویدی مناسب است. در DEVSTUDIO می‌توانی فایل‌های .kt را مستقیماً ویرایش، بررسی، Build و Run کنی.")
        }
        if (containsAny(lower, "android", "اندروید")) {
            return Response("برای ساخت اپ اندروید می‌توانیم از Activity، XML، Kotlin، منابع res و Manifest استفاده کنیم. اگر پروژه را باز کرده باشی، می‌توانم ساختار فایل‌های همین پروژه را هم بررسی کنم.")
        }
        if (containsAny(lower, "html", "css", "javascript", "جاوااسکریپت")) {
            return Response("HTML ساختار، CSS ظاهر و JavaScript رفتار برنامه را کنترل می‌کند. DEVSTUDIO ابزارهای Preview و Local Server را هم برای پروژه‌های وب دارد.")
        }

        return Response(
            "من در v22 یک دستیار آفلاین سبک هستم. می‌توانم ساختار پروژه را تحلیل کنم، فایل‌ها را پیدا کنم، کد فعلی را بررسی کنم و اصلاحات امن را پیشنهاد بدهم.\n\nمثال:\n• پروژه را تحلیل کن\n• فایل‌های پروژه را لیست کن\n• این کد را بررسی کن\n• مشکل کد را اصلاح کن\n• جستجو MainActivity"
        )
    }

    private fun projectSummary(): String {
        val root = projectRoot ?: return "هیچ پروژه‌ای به AI متصل نیست."
        if (!root.exists()) return "پوشه پروژه پیدا نشد."
        val files = safeFiles(root)
        val kotlin = files.count { it.extension.toLowerCase() == "kt" }
        val java = files.count { it.extension.toLowerCase() == "java" }
        val xml = files.count { it.extension.toLowerCase() == "xml" }
        val web = files.count { it.extension.toLowerCase() in listOf("html", "css", "js") }
        return "تحلیل سریع پروژه:\n\nنام پوشه: ${root.name}\nتعداد فایل: ${files.size}\nKotlin: $kotlin\nJava: $java\nXML: $xml\nWeb: $web\n\nوضعیت: پروژه برای بررسی آفلاین آماده است."
    }

    private fun listFiles(): String {
        val root = projectRoot ?: return "هیچ پروژه‌ای به AI متصل نیست."
        val files = safeFiles(root).take(40)
        if (files.isEmpty()) return "فایلی در پروژه پیدا نشد."
        return "فایل‌های پروژه (حداکثر ۴۰ مورد):\n\n" + files.joinToString("\n") { "• ${it.relativeTo(root).path}" }
    }

    private fun search(term: String): String {
        if (term.isEmpty()) return "عبارت جستجو را بعد از «جستجو» بنویس."
        val root = projectRoot ?: return "هیچ پروژه‌ای به AI متصل نیست."
        val matches = mutableListOf<String>()
        safeFiles(root).forEach { file ->
            if (matches.size >= 25) return@forEach
            val nameHit = file.name.toLowerCase().contains(term.toLowerCase())
            val contentHit = if (file.length() <= 512 * 1024L && isTextFile(file)) {
                try { file.readText().toLowerCase().contains(term.toLowerCase()) } catch (_: Exception) { false }
            } else false
            if (nameHit || contentHit) matches.add(file.relativeTo(root).path)
        }
        return if (matches.isEmpty()) "برای «$term» نتیجه‌ای پیدا نشد." else "نتایج جستجو برای «$term»:\n\n" + matches.joinToString("\n") { "• $it" }
    }

    private fun analyzeCode(file: File?, text: String): String {
        if (file == null) return "فایلی برای بررسی انتخاب نشده است."
        val language = EditorEngine.languageForFileName(file.name)
        val issues = RuleBasedAiEngine().lint(text, language)
        if (issues.isEmpty()) return "✓ فایل ${file.name} بررسی شد؛ مشکل ساختاری واضحی پیدا نشد."
        return "بررسی ${file.name}:\n\n" + issues.joinToString("\n") {
            val line = if (it.line > 0) "خط ${it.line}: " else ""
            "• $line${it.message}"
        }
    }

    private fun safeFiles(root: File): List<File> {
        return try {
            root.walkTopDown()
                .filter { it.isFile && !it.path.contains("${File.separator}.gradle${File.separator}") && !it.path.contains("${File.separator}build${File.separator}") }
                .toList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun isTextFile(file: File): Boolean =
        file.extension.toLowerCase() in listOf("kt", "java", "xml", "json", "txt", "md", "html", "css", "js", "gradle", "properties")

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { text.contains(it) }
}
