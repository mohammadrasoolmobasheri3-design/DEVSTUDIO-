package com.example.ultrapromax.engine.theme

import android.content.Context
import android.graphics.Color

/** User-defined local theme profiles persisted as six ARGB values. */
class ThemeProfileEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("custom_theme_profiles", Context.MODE_PRIVATE)
    fun save(id: String, palette: ThemePalette) { prefs.edit().putInt("$id:bg", palette.background).putInt("$id:surface", palette.surface).putInt("$id:text", palette.textPrimary).putInt("$id:secondary", palette.textSecondary).putInt("$id:accent", palette.accent).apply() }
    fun load(id: String): ThemePalette? {
        val sentinel = Int.MIN_VALUE; val bg = prefs.getInt("$id:bg", sentinel); if (bg == sentinel) return null
        return ThemePalette(bg, prefs.getInt("$id:surface", Color.WHITE), prefs.getInt("$id:text", Color.BLACK), prefs.getInt("$id:secondary", Color.GRAY), prefs.getInt("$id:accent", Color.BLUE))
    }
    fun delete(id: String) { prefs.edit().remove("$id:bg").remove("$id:surface").remove("$id:text").remove("$id:secondary").remove("$id:accent").apply() }
}
