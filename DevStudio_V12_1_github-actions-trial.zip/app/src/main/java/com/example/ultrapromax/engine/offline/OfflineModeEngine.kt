package com.example.ultrapromax.engine.offline

import android.content.Context

/** Central offline-mode policy. Network permission may still exist for local server features. */
class OfflineModeEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("devstudio_offline_mode", Context.MODE_PRIVATE)

    fun isOffline(): Boolean = prefs.getBoolean("enabled", true)

    fun setOffline(enabled: Boolean) {
        prefs.edit().putBoolean("enabled", enabled).apply()
    }

    fun canUseExternalNetwork(): Boolean = !isOffline()

    fun modeLabel(): String = if (isOffline()) "OFFLINE" else "NETWORK OPTIONAL"
}
