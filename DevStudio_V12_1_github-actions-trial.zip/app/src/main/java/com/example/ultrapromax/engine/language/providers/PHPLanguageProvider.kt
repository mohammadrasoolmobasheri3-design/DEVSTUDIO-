package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class PHPLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("php", "PHP", listOf("php"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("php").parse(source)
}
