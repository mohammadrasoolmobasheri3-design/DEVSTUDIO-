package com.example.ultrapromax.engine.endgame

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Cryptographically bound evidence store. Marker files alone are never accepted. */
class EndgameEvidenceStore(private val context: Context) {
    private val root = File(context.filesDir, "endgame/evidence")

    data class Evidence(val id: String, val status: String, val timestamp: Long, val digest: String, val detail: String)

    fun write(id: String, status: String, detail: String): File {
        if (!root.exists()) root.mkdirs()
        val payload = "id=$id\nstatus=$status\ntimestamp=${System.currentTimeMillis()}\ndetail=$detail\n"
        val file = File(root, "$id.evidence")
        file.writeText(payload, Charsets.UTF_8)
        File(root, "$id.sha256").writeText(sha256(payload), Charsets.UTF_8)
        return file
    }

    fun verify(id: String): Evidence? {
        val file = File(root, "$id.evidence")
        val hash = File(root, "$id.sha256")
        if (!file.isFile || !hash.isFile) return null
        val payload = file.readText(Charsets.UTF_8)
        if (sha256(payload) != hash.readText(Charsets.UTF_8).trim()) return null
        val values = HashMap<String, String>()
        payload.lines().forEach { line ->
            val p = line.indexOf('=')
            if (p > 0) values[line.substring(0, p)] = line.substring(p + 1)
        }
        val ts = values["timestamp"]?.toLongOrNull() ?: return null
        return Evidence(id, values["status"] ?: return null, ts, hash.readText(Charsets.UTF_8).trim(), values["detail"] ?: "")
    }

    private fun sha256(value: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
