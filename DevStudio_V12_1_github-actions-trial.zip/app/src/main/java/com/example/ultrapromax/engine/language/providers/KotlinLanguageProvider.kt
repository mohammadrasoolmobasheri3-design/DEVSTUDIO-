package com.example.ultrapromax.engine.language.providers

import com.example.ultrapromax.engine.language.LanguageDefinition
import com.example.ultrapromax.engine.language.LanguageProvider
import com.example.ultrapromax.engine.language.parser.ParseResult
import com.example.ultrapromax.engine.language.parser.SymbolExtractor

class KotlinLanguageProvider : LanguageProvider {
    override fun definition(): LanguageDefinition = LanguageDefinition("kt", "Kotlin", listOf("kt", "kts"), "//", "/*", "*/", true, true)
    override fun parse(source: String): ParseResult = SymbolExtractor("kt").parse(source)
}
