package com.example.ultrapromax.ui

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.security.DiagnosticEngine
import java.io.File

class DiagnosticsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostics)
        val output = findViewById<TextView>(R.id.diagnosticOutput)
        findViewById<Button>(R.id.diagnosticBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.diagnosticScan).setOnClickListener { output.text = runScan() }
        output.text = runScan()
    }

    private fun runScan(): String {
        val projects = ProjectStore.list(this)
        val selected = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        val project = if (selected >= 0) ProjectStore.getById(this, selected) else projects.firstOrNull()
        val root = filesDir
        val report = DiagnosticEngine(root).scanProject(
            project?.let { File(it.folderPath) }, project?.name
        )
        return report.text
    }

    companion object { const val EXTRA_PROJECT_ID = "diagnostic_project_id" }
}
