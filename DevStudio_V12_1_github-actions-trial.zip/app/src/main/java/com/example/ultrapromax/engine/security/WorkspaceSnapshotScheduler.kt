package com.example.ultrapromax.engine.security

import java.io.File

/** Deterministic local snapshot policy; callers decide when to execute IO. */
class WorkspaceSnapshotScheduler(private val intervalMs: Long = 60_000L) {
    private var lastSnapshot = 0L
    fun shouldSnapshot(now: Long = System.currentTimeMillis()): Boolean = now - lastSnapshot >= intervalMs
    fun markSnapshot(now: Long = System.currentTimeMillis()) { lastSnapshot = now }
    fun snapshotName(now: Long = System.currentTimeMillis()): String = ".devstudio-auto-${now}"
    fun nextSnapshotFile(root: File, now: Long = System.currentTimeMillis()): File = File(root, snapshotName(now))
}
