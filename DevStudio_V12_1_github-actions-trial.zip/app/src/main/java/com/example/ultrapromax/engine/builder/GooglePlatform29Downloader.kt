package com.example.ultrapromax.engine.builder

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Explicit, single-purpose online installer.
 *
 * DevStudio remains offline for Build/Run/Sign/Verify/etc.
 * This class is the only code path added for downloading Android SDK
 * Platform 29 from Google's official repository only.
 *
 * This is the only explicit external download path in DevStudio. No mirror,
 * redirect, repository fallback, Gradle network fallback, or automatic build
 * download is permitted.
 */
class GooglePlatform29Downloader(private val context: Context) {
    /** Starts the real Google-only Platform 29 download. */
    fun startDownload(listener: Listener) {
        downloadFromGoogle(File(android.os.Environment.getExternalStorageDirectory(), "Download/platform-29_r05.zip"), listener)
    }


    companion object {
        private const val REPO_PATH = "/android/repository/platform-29_r05.zip"

        private const val GOOGLE_URL = "https://dl.google.com$REPO_PATH"
        private const val ALLOWED_HOST = "dl.google.com"

        // Android SDK repository metadata identifies platform-29_r05 with this SHA-1.
        private const val EXPECTED_SHA1 =
            "9d8a7e0ffa5168dbca6c60355b9129c6c7572aff"

        private const val EXPECTED_SIZE = 78293913L

        const val COMPONENT_NAME = "Android SDK Platform 29"
    }

    data class Result(
        val success: Boolean,
        val message: String
    )

    interface Listener {
        fun onProgress(downloaded: Long, total: Long)
        fun onFinished(result: Result)
    }

    fun isInstalled(): Boolean {
        val sdk = File(context.filesDir, "internal-toolchain/android-sdk")
        return File(sdk, "platforms/android-29/android.jar").isFile
    }

    fun downloadAndInstall(listener: Listener) {
        Thread {
            val result = try {
                downloadAndInstallInternal(listener)
            } catch (t: Throwable) {
                Result(false, "Download failed: ${t.message ?: t.javaClass.simpleName}")
            }
            listener.onFinished(result)
        }.start()
    }

    private fun downloadAndInstallInternal(listener: Listener): Result {
        if (isInstalled()) {
            return Result(true, "$COMPONENT_NAME is already installed.")
        }

        val root = File(context.filesDir, "internal-toolchain")
        val sdkRoot = File(root, "android-sdk")
        val cacheDir = File(root, "downloads")
        val zipFile = File(cacheDir, "platform-29_r05.zip")
        val extractDir = File(cacheDir, "platform-29_r05_extract")

        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            return Result(false, "Cannot create local toolchain download directory.")
        }

        if (extractDir.exists()) extractDir.deleteRecursively()

        downloadFromGoogle(zipFile, listener)

        if (!zipFile.isFile || zipFile.length() != EXPECTED_SIZE) {
            zipFile.delete()
            return Result(false, "Downloaded file size is invalid. Expected $EXPECTED_SIZE bytes.")
        }

        val actualSha1 = sha1(zipFile)
        if (!EXPECTED_SHA1.equals(actualSha1, ignoreCase = true)) {
            zipFile.delete()
            return Result(false, "Downloaded file checksum mismatch. Toolchain was NOT installed.")
        }

        if (!extractDir.mkdirs()) {
            return Result(false, "Cannot create extraction directory.")
        }

        unzipSafely(zipFile, extractDir)

        val platformSource = File(extractDir, "android-29")
        val androidJar = File(platformSource, "android.jar")
        if (!platformSource.isDirectory || !androidJar.isFile || androidJar.length() <= 1024L * 1024L) {
            extractDir.deleteRecursively()
            return Result(false, "Downloaded archive does not contain a valid Android 29 platform.")
        }

        val platformTarget = File(sdkRoot, "platforms/android-29")
        val platformsDir = platformTarget.parentFile
        if (platformsDir != null && !platformsDir.exists() && !platformsDir.mkdirs()) {
            extractDir.deleteRecursively()
            return Result(false, "Cannot create SDK platforms directory.")
        }

        if (platformTarget.exists()) platformTarget.deleteRecursively()

        if (!platformSource.renameTo(platformTarget)) {
            copyDirectory(platformSource, platformTarget)
            platformSource.deleteRecursively()
        }

        extractDir.deleteRecursively()

        if (!File(platformTarget, "android.jar").isFile) {
            return Result(false, "Installation verification failed: android.jar is missing.")
        }

        // The cache is not needed after successful installation.
        zipFile.delete()

        return Result(
            true,
            "$COMPONENT_NAME installed successfully.\n" +
                "Location: ${platformTarget.absolutePath}\n" +
                "SHA-1: $actualSha1"
        )
    }

    private fun downloadFromGoogle(target: File, listener: Listener) {
        downloadFrom(GOOGLE_URL, target, listener)
    }

    private fun downloadFrom(urlString: String, target: File, listener: Listener) {
        val url = URL(urlString)

        if (url.protocol != "https" || url.host.toLowerCase() != ALLOWED_HOST) {
            throw SecurityException("Download host is not allowed: ${url.host}")
        }

        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("User-Agent", "DevStudio-Toolchain-Manager/1.0")
            connection.connect()

            val code = connection.responseCode
            if (code in 300..399) {
                throw java.io.IOException("Redirect rejected: Google download must not leave dl.google.com")
            }
            if (code !in 200..299) {
                throw java.io.IOException("${url.host} returned HTTP $code")
            }

            val total = connection.contentLengthLong

            BufferedInputStream(connection.inputStream, 64 * 1024).use { input ->
                BufferedOutputStream(FileOutputStream(target, false), 64 * 1024).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var downloaded = 0L
                    var count = input.read(buffer)
                    while (count >= 0) {
                        if (count > 0) {
                            output.write(buffer, 0, count)
                            downloaded += count.toLong()
                            listener.onProgress(downloaded, if (total > 0L) total else EXPECTED_SIZE)
                        }
                        count = input.read(buffer)
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun unzipSafely(zipFile: File, destination: File) {
        val destinationRoot = destination.canonicalFile
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile), 64 * 1024)).use { input ->
            var entry: ZipEntry? = input.nextEntry
            while (entry != null) {
                val output = File(destinationRoot, entry.name).canonicalFile
                val rootPath = destinationRoot.path + File.separator
                if (output.path != destinationRoot.path && !output.path.startsWith(rootPath)) {
                    throw SecurityException("Unsafe ZIP entry: ${entry.name}")
                }

                if (entry.isDirectory) {
                    if (!output.exists() && !output.mkdirs()) {
                        throw java.io.IOException("Cannot create ${output.absolutePath}")
                    }
                } else {
                    output.parentFile?.let { if (!it.exists()) it.mkdirs() }
                    BufferedOutputStream(FileOutputStream(output), 64 * 1024).use { out ->
                        val buffer = ByteArray(64 * 1024)
                        var count = input.read(buffer)
                        while (count >= 0) {
                            if (count > 0) out.write(buffer, 0, count)
                            count = input.read(buffer)
                        }
                    }
                }
                input.closeEntry()
                entry = input.nextEntry
            }
        }
    }

    private fun sha1(file: File): String {
        val digest = MessageDigest.getInstance("SHA-1")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            var count = input.read(buffer)
            while (count >= 0) {
                if (count > 0) digest.update(buffer, 0, count)
                count = input.read(buffer)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun copyDirectory(source: File, target: File) {
        if (!target.exists() && !target.mkdirs()) {
            throw java.io.IOException("Cannot create ${target.absolutePath}")
        }
        source.listFiles()?.forEach { child ->
            val out = File(target, child.name)
            if (child.isDirectory) copyDirectory(child, out)
            else child.copyTo(out, overwrite = true)
        }
    }
}
