package com.example.ultrapromax.engine.studio

import android.content.Context
import com.example.ultrapromax.data.Project
import java.io.File

/** V30.1.0 offline integration/status layer for the existing Studio engines. */
class StudioIntegrationEngine(private val context: Context) {
    data class ModuleStatus(val name: String, val ready: Boolean, val detail: String)
    data class Snapshot(val project: Project?, val modules: List<ModuleStatus>, val files: Int, val bytes: Long)

    fun inspect(project: Project?): Snapshot {
        val root = project?.let { File(it.folderPath) }
        val exists = root?.isDirectory == true
        val files = if (exists) root!!.walkTopDown().count { it.isFile } else 0
        val bytes = if (exists) root!!.walkTopDown().filter { it.isFile }.fold(0L) { total, f -> total + f.length() } else 0L
        val modules = listOf(
            ModuleStatus("Project Studio", exists, if (exists) "Workspace mounted" else "No project"),
            ModuleStatus("Code Editor", true, "Connected"),
            ModuleStatus("UI Builder", true, "Connected"),
            ModuleStatus("Preview / Run Studio", true, "Connected"),
            ModuleStatus("Build / Release", true, "Connected"),
            ModuleStatus("Assets / Virtual FS", true, "Connected"),
            ModuleStatus("Offline AI", true, "Connected"),
            ModuleStatus("Plugins / Sandbox", true, "Connected"),
            ModuleStatus("Security / Diagnostics", true, "Connected"),
            ModuleStatus("Universal Runtime", true, "Connected")
        )
        return Snapshot(project, modules, files, bytes)
    }

    fun summary(snapshot: Snapshot): String {
        val ready = snapshot.modules.count { it.ready }
        return "Studio V30.1.0 • $ready/${snapshot.modules.size} modules connected • ${snapshot.files} files • ${formatBytes(snapshot.bytes)}"
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> "${bytes / (1024L * 1024L)} MB"
    }
}
