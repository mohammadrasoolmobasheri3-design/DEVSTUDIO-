package com.example.ultrapromax.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ultrapromax.R
import com.example.ultrapromax.data.Project
import com.example.ultrapromax.data.ProjectStore
import com.example.ultrapromax.engine.security.BetaTestEngine

class BetaTestActivity : AppCompatActivity() {
    private var project: Project? = null
    private lateinit var resultsBox: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beta_test)
        val id = intent.getLongExtra(EXTRA_PROJECT_ID, -1L)
        project = if (id >= 0L) ProjectStore.getById(this, id) else null
        summary = findViewById(R.id.betaSummary)
        resultsBox = findViewById(R.id.betaResults)
        findViewById<Button>(R.id.btnRunBeta).setOnClickListener { runTests() }
        findViewById<TextView>(R.id.btnBetaBack).setOnClickListener { finish() }
        runTests()
    }

    private fun runTests() {
        val report = BetaTestEngine(this).run(project)
        summary.text = BetaTestEngine(this).summary(report)
        resultsBox.removeAllViews()
        report.results.forEach { result ->
            val row = TextView(this)
            row.text = "${result.state}   ${result.name}\n${result.detail}"
            row.setTextColor(when (result.state) {
                "PASS" -> Color.parseColor("#72F1B8")
                "WARN" -> Color.parseColor("#FFD166")
                else -> Color.parseColor("#FF6B6B")
            })
            row.textSize = 12f
            row.setPadding(dp(12), dp(10), dp(12), dp(10))
            row.gravity = Gravity.CENTER_VERTICAL
            resultsBox.addView(row)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_PROJECT_ID = "extra_project_id"
    }
}
