package com.example.ultrapromax.engine.uibuilder

/**
 * UI Builder data/HTML engine for DEVSTUDIO v17.
 * The visual editor is backed by real Android drag/drop and persists a small
 * project-local layout description. This engine remains dependency-free so it
 * works with the project's Kotlin 1.3.72 toolchain.
 */
enum class UiComponent(val label: String) {
    HEADING("Heading"),
    PARAGRAPH("Paragraph"),
    BUTTON("Button"),
    IMAGE("Image"),
    INPUT("Text input"),
    CARD("Card"),
    CONTAINER("Container"),
    ROW("Row"),
    DIVIDER("Divider")
}

object UiBuilderEngine {

    fun htmlFor(component: UiComponent): String = when (component) {
        UiComponent.HEADING -> "<h2>New heading</h2>"
        UiComponent.PARAGRAPH -> "<p>New paragraph text.</p>"
        UiComponent.BUTTON -> "<button type=\"button\">Click me</button>"
        UiComponent.IMAGE -> "<img src=\"\" alt=\"image\">"
        UiComponent.INPUT -> "<input type=\"text\" placeholder=\"Enter text\">"
        UiComponent.CARD -> "<div class=\"ds-card\"><h3>Card</h3><p>Content</p></div>"
        UiComponent.CONTAINER -> "<div class=\"ds-container\"></div>"
        UiComponent.ROW -> "<div class=\"ds-row\"></div>"
        UiComponent.DIVIDER -> "<hr>"
    }

    fun appendComponent(pageHtml: String, component: UiComponent): String {
        val snippet = "  " + htmlFor(component) + "\n"
        return if (pageHtml.contains("</body>")) {
            pageHtml.replaceFirst("</body>", snippet + "</body>")
        } else {
            pageHtml + "\n" + snippet
        }
    }
}
