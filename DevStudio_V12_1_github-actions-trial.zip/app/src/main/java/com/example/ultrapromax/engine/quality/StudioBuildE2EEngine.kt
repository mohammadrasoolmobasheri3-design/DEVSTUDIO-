package com.example.ultrapromax.engine.quality

import android.content.Context
import com.example.ultrapromax.engine.builder.AndroidToolchainDiscoveryEngine
import com.example.ultrapromax.engine.builder.ApkValidationEngine
import com.example.ultrapromax.engine.builder.BuildEngine
import com.example.ultrapromax.engine.endgame.EndgameEvidenceStore
import java.io.File
import java.util.concurrent.TimeUnit

/** Full local E2E: toolchain -> offline build -> APK validation -> install -> launch -> process check. */
class StudioBuildE2EEngine(private val context: Context) {
    data class Result(val executed: Boolean, val passed: Boolean, val steps: List<String>)

    fun run(project: File): Result {
        val steps = ArrayList<String>()
        if (!project.isDirectory) return Result(false, false, listOf("project-missing"))
        val tc = AndroidToolchainDiscoveryEngine(context).discover()
        if (!tc.ready) return Result(false, false, listOf("toolchain-not-ready", tc.details))
        steps.add("toolchain-ready")

        val build = BuildEngine().buildDebug(project)
        if (!build.success || build.apkFile == null) return record(false, steps + "offline-debug-build-failed")
        steps.add("offline-debug-apk-built")

        val validation = ApkValidationEngine().validate(build.apkFile)
        if (!validation.valid) return record(false, steps + "apk-validation-failed")
        steps.add("apk-validated")

        val adb = tc.adb ?: return record(false, steps + "adb-missing")
        val pkg = readPackage(project) ?: return record(false, steps + "application-id-missing")
        val activity = readActivity(project, pkg) ?: return record(false, steps + "launcher-activity-missing")
        val devices = command(adb, listOf("devices"), 20)
        if (devices.exit != 0 || !devices.out.lines().any { it.trim().endsWith("\tdevice") }) return record(false, steps + "device-missing")
        val install = command(adb, listOf("install", "-r", build.apkFile.absolutePath), 120)
        if (install.exit != 0 || !install.out.contains("success", true)) return record(false, steps + "install-failed")
        steps.add("apk-installed")
        val launch = command(adb, listOf("shell", "am", "start", "-W", "-n", "$pkg/$activity"), 30)
        if (launch.exit != 0 || !launch.out.contains("Status: ok", true)) return record(false, steps + "launch-failed")
        steps.add("activity-started")
        val pid = command(adb, listOf("shell", "pidof", pkg), 15)
        if (pid.exit != 0 || pid.out.trim().isEmpty()) return record(false, steps + "process-not-observed")
        steps.add("process-observed")
        return record(true, steps + "full-e2e-pass")
    }

    private fun record(pass: Boolean, steps: List<String>): Result {
        EndgameEvidenceStore(context).write("e2e", if (pass) "PASS" else "FAIL", steps.joinToString(" -> "))
        return Result(true, pass, steps)
    }

    private data class Cmd(val exit: Int, val out: String)
    private fun command(file: File, args: List<String>, timeout: Long): Cmd = try {
        val p = ProcessBuilder(listOf(file.absolutePath) + args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        if (!p.waitFor(timeout, TimeUnit.SECONDS)) { p.destroy(); Cmd(-2, out + " TIMEOUT") } else Cmd(p.exitValue(), out)
    } catch (t: Throwable) { Cmd(-1, t.message ?: t.javaClass.simpleName) }

    private fun readPackage(project: File): String? {
        val gradle = File(project, "app/build.gradle")
        if (!gradle.isFile) return null
        val text = gradle.readText()
        val m = Regex("applicationId\\s+['\\\"]([^'\\\"]+)['\\\"]").find(text)
        return m?.groupValues?.get(1)
    }
    private fun readActivity(project: File, pkg: String): String? {
        val manifest = File(project, "app/src/main/AndroidManifest.xml")
        if (!manifest.isFile) return null
        val text = manifest.readText()
        val m = Regex("<activity[^>]*android:name=['\\\"]([^'\\\"]+)['\\\"][\\s\\S]*?<intent-filter>[\\s\\S]*?android.intent.action.MAIN[\\s\\S]*?android.intent.category.LAUNCHER", RegexOption.IGNORE_CASE).find(text) ?: return null
        val raw = m.groupValues[1]
        return if (raw.startsWith(".")) pkg + raw else if (raw.contains(".")) raw else "$pkg.$raw"
    }
}
