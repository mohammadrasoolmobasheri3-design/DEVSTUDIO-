package com.example.ultrapromax.nextupdate.ai.model

data class AiPlanStep(
    val id: String,
    val title: String,
    val description: String,
    val destructive: Boolean = false
)

data class AiPlan(
    val taskId: String,
    val steps: List<AiPlanStep>
)
