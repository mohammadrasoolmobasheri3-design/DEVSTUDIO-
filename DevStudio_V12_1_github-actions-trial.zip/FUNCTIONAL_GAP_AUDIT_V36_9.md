# DEVSTUDIO V36.9 Functional Gap Audit / Hardening

## Baseline
- Gradle 6.1.1
- Android Gradle Plugin 3.5.3
- Kotlin 1.3.72
- compileSdk 29 / minSdk 23 / targetSdk 29
- versionCode 302 / versionName 30.1.0
- Application ID: com.example.ultrapromax

## Findings
1. Android toolchain discovery previously accepted any newest Build Tools directory. This could report a toolchain that did not match the required baseline. **Fixed:** exact Build Tools 29.0.3 and Android platform 29 are now required, with JDK java/javac checks.
2. BuildEngine previously launched Gradle without an explicit offline switch. **Fixed:** real Gradle builds now run with `--offline` and `--no-daemon`; missing cached dependencies fail truthfully.
3. Plugin compiler accepted arbitrary class names/source sizes. **Fixed:** Java identifier validation and 512 KB source limit.
4. Plugin execution accepted any filesystem path supplied to the run API. **Fixed:** compiled artifacts must remain inside the app-private compiled plugin directory and be <=5 MB.
5. No fake success path was added. Build/APK/runtime/certification status still depends on real local evidence.

## Remaining evidence gates
- A real JDK/Android SDK/Build Tools installation must exist on the device.
- All generated-project dependencies must be available from local Gradle cache or local project artifacts.
- A real APK must be produced before APK validation/install/run can PASS.
- Runtime packs must be imported locally and pass readiness checks before a language is READY.
- ENDGAME certification must remain NOT CERTIFIED until real build/E2E/recovery/security evidence exists.

## Offline rule
No new online API, downloader, external compiler service, cloud AI, fake compiler, fake APK, or fake READY state was introduced.
